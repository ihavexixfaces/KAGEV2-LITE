// v55: reliable decorated Discord identity paint + final layout safeguards.
(() => {
  'use strict';

  const safeDiscordMedia = value => {
    const raw = String(value || '').trim();
    if (!raw) return '';
    try {
      const url = new URL(raw);
      const host = url.hostname.toLowerCase();
      if (url.protocol !== 'https:' || (host !== 'cdn.discordapp.com' && host !== 'media.discordapp.net')) return '';
      return url.href;
    } catch { return ''; }
  };

  const paintSettingsDiscord = discord => {
    const image = document.getElementById('settings-discord-avatar-image');
    const decoration = document.getElementById('settings-discord-decoration');
    if (!image || !decoration) return;

    const avatarUrl = safeDiscordMedia(discord?.avatar || discord?.avatarUrl);
    const decorationUrl = safeDiscordMedia(discord?.decoration || discord?.decorationUrl);

    if (avatarUrl) {
      image.src = avatarUrl;
      image.style.display = 'block';
    } else {
      image.removeAttribute('src');
      image.style.display = 'none';
    }

    if (decorationUrl) {
      decoration.src = decorationUrl;
      decoration.style.display = 'block';
    } else {
      decoration.removeAttribute('src');
      decoration.style.display = 'none';
    }
  };

  // Listen to the native account-info event directly. This avoids depending on
  // wrapper order between legacy version scripts and guarantees the Settings
  // decoration receives the same OAuth metadata as the rest of the app.
  try {
    window.chrome?.webview?.addEventListener?.('message', event => {
      const payload = event?.data;
      if (payload?.event === 'accountInfo' && payload?.data?.discord) paintSettingsDiscord(payload.data.discord);
    });
  } catch { /* no-op outside WebView2 */ }

  // Also wrap the public update path for browser/static tests and reconnects.
  const previous = window.updateAccountInfo;
  if (typeof previous === 'function') {
    window.updateAccountInfo = function(data) {
      previous(data);
      paintSettingsDiscord(data?.discord || {});
    };
  }

  window.__kagePaintSettingsDiscord = paintSettingsDiscord;
})();
