namespace KAGE.Desktop.Updates;

internal sealed class UpdateManifest
{
    public int Version { get; set; } = 2;
    public string ReleaseVersion { get; set; } = string.Empty;
    public int ProtocolGeneration { get; set; }
    public long BuildId { get; set; }
    public string Package { get; set; } = string.Empty;
    public string Sha256 { get; set; } = string.Empty;
    public string ExecutableSha256 { get; set; } = string.Empty;
    public long Size { get; set; }
    public string DistributionMode { get; set; } = string.Empty;
    public string SignatureAlgorithm { get; set; } = "ECDSA_P256_SHA256";
    public string Signature { get; set; } = string.Empty;
}

internal sealed record AvailableUpdate(
    UpdateManifest Manifest,
    string PackageUrl,
    string ReleaseUrl,
    string RepositoryRevision = "",
    string Changelog = "",
    string ChangelogBuildId = "");

internal sealed record UpdateDownloadProgress(
    long BytesReceived,
    long TotalBytes,
    double BytesPerSecond,
    double? EtaSeconds);
