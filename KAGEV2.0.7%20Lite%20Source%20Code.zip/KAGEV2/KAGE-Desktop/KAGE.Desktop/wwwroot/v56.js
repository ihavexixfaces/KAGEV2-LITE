// v56 — narrow stability fixes for tabs, Settings Discord media and v49 Reupload geometry.
(() => {
  'use strict';
  if (new URLSearchParams(location.search).get('shadePopout') === '1') return;

  const tabButtons = [...document.querySelectorAll('.top-icon-nav .tab-btn[data-tab]')];
  const tabContents = [...document.querySelectorAll('.tab-content[id^="tab-"]')];

  function switchTab(name, source) {
    const tab = String(name || '').trim();
    const target = document.getElementById(`tab-${tab}`);
    if (!target) return false;
    for (const button of tabButtons) {
      const active = button === source || button.dataset.tab === tab;
      button.classList.toggle('active', active);
      button.setAttribute('aria-selected', active ? 'true' : 'false');
    }
    for (const page of tabContents) page.classList.toggle('active', page === target);
    return true;
  }
  window.activateKageTab = switchTab;

  // Use the actual tab buttons as the single navigation surface. Capture-phase
  // handling prevents the draggable title bar from consuming WebView2 clicks.
  for (const button of tabButtons) {
    button.type = 'button';
    button.style.pointerEvents = 'auto';
    button.addEventListener('pointerdown', e => e.stopPropagation(), true);
    button.addEventListener('mousedown', e => e.stopPropagation(), true);
    button.addEventListener('click', e => {
      e.preventDefault();
      e.stopPropagation();
      switchTab(button.dataset.tab, button);
    }, true);
  }

  for (const button of document.querySelectorAll('[data-home-tab]')) {
    button.addEventListener('click', e => {
      e.preventDefault();
      const name = String(button.dataset.homeTab || '');
      switchTab(name, tabButtons.find(tab => tab.dataset.tab === name));
    }, true);
  }

  function safeDiscordMedia(value) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    try {
      const url = new URL(raw);
      const host = url.hostname.toLowerCase();
      if (url.protocol !== 'https:' || (host !== 'cdn.discordapp.com' && host !== 'media.discordapp.net')) return '';
      return url.href;
    } catch { return ''; }
  }

  function paintDiscordIdentity(data) {
    const discord = data?.discord || data || {};
    const avatarUrl = safeDiscordMedia(discord.avatar || discord.avatarUrl);
    const decorationUrl = safeDiscordMedia(discord.decoration || discord.decorationUrl);
    const holder = document.getElementById('settings-discord-avatar');
    const image = document.getElementById('settings-discord-avatar-image');
    const decoration = document.getElementById('settings-discord-decoration');

    if (holder) {
      holder.style.backgroundImage = avatarUrl ? `url("${avatarUrl.replace(/["\\]/g, '')}")` : 'none';
      holder.style.backgroundPosition = 'center';
      holder.style.backgroundRepeat = 'no-repeat';
      holder.style.backgroundSize = '92px 92px';
    }
    if (image) {
      if (avatarUrl) {
        image.src = avatarUrl;
        image.style.display = 'block';
        image.onerror = () => { image.style.display = 'none'; };
        image.onload = () => { image.style.display = 'block'; };
      } else {
        image.removeAttribute('src');
        image.style.display = 'none';
      }
    }
    if (decoration) {
      if (decorationUrl) {
        decoration.src = decorationUrl;
        decoration.style.display = 'block';
        decoration.onerror = () => { decoration.style.display = 'none'; };
        decoration.onload = () => { decoration.style.display = 'block'; };
      } else {
        decoration.removeAttribute('src');
        decoration.style.display = 'none';
      }
    }
  }

  // Paint directly from the authoritative native accountInfo event as well as
  // the normal update path. This avoids version-wrapper ordering regressions.
  try {
    window.chrome?.webview?.addEventListener?.('message', event => {
      const payload = event?.data;
      if (payload?.event === 'accountInfo') paintDiscordIdentity(payload.data);
    });
  } catch { }

  const previousUpdate = window.updateAccountInfo;
  if (typeof previousUpdate === 'function' && !previousUpdate.__v56Wrapped) {
    const wrapped = function(data) {
      previousUpdate(data);
      paintDiscordIdentity(data);
    };
    wrapped.__v56Wrapped = true;
    window.updateAccountInfo = wrapped;
  }
  window.__kagePaintSettingsDiscord = paintDiscordIdentity;

  // The v49 explorer layout does not use connector-derived inline height offsets.
  // Remove any stale variables left by the later experimental alignment pass.
  function clearExperimentalExplorerAlignment() {
    const layout = document.querySelector('#tab-reupload .reupload-layout');
    if (!layout) return;
    layout.style.removeProperty('--explorer-connector-offset');
    layout.style.removeProperty('--explorer-visible-height');
  }
  clearExperimentalExplorerAlignment();
  requestAnimationFrame(clearExperimentalExplorerAlignment);
})();
