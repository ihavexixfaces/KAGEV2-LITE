using System.Net;
using System.Text;
using System.Text.Json;

namespace KAGE.Desktop.Preview;

public sealed class AvatarAppearanceClient : IDisposable
{
    private static readonly Uri RenderEndpoint = new("https://avatar.roblox.com/v1/avatar/render");
    private static readonly UTF8Encoding StrictUtf8 = new(false, true);
    private const int AssetLimit = 8 * 1024 * 1024;
    private const int MetadataLimit = 512 * 1024;
    private const long TotalLimit = 64L * 1024 * 1024;
    private const int TextureLimit = 16;
    private const int PendingAttempts = 40;
    private readonly HttpClient _avatar;
    private readonly HttpClient _cdn;
    private readonly string _cookie;
    private bool _disposed;

    public AvatarAppearanceClient(string cookie, HttpMessageHandler? avatarHandler = null, HttpMessageHandler? cdnHandler = null)
    {
        ArgumentNullException.ThrowIfNull(cookie);
        var value = cookie.Trim();
        if (value.StartsWith(".ROBLOSECURITY=", StringComparison.OrdinalIgnoreCase)) value = value[".ROBLOSECURITY=".Length..];
        if (string.IsNullOrWhiteSpace(value) || value.Any(c => char.IsControl(c) || c == ';'))
            throw new ArgumentException("Avatar rendering requires a valid account cookie.", nameof(cookie));
        if (avatarHandler != null && ReferenceEquals(avatarHandler, cdnHandler))
            throw new ArgumentException("Avatar and CDN transports must be separate.", nameof(cdnHandler));
        _cookie = ".ROBLOSECURITY=" + value;
        _avatar = CreateClient(avatarHandler);
        _cdn = CreateClient(cdnHandler);
    }

    public async Task<AvatarAppearance> LoadAsync(JsonElement avatarDefinition, long avatarUserId, CancellationToken ct)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        if (avatarDefinition.ValueKind != JsonValueKind.Object)
            throw new ArgumentException("Avatar definition must be a JSON object.", nameof(avatarDefinition));
        if (avatarUserId <= 0) throw new ArgumentOutOfRangeException(nameof(avatarUserId), "Avatar user ID must be positive.");
        ct.ThrowIfCancellationRequested();
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(ct);
        deadline.CancelAfter(TimeSpan.FromSeconds(45));
        try
        {
            var token = deadline.Token;
            var budget = new DownloadBudget();
            var manifestUrl = await RenderAsync(avatarDefinition, budget, token).ConfigureAwait(false);
            var manifestBytes = await DownloadCdnAsync(manifestUrl, MetadataLimit, "avatar manifest", budget, token).ConfigureAwait(false);
            using var manifest = ParseJson(manifestBytes, "avatar manifest");
            var root = manifest.RootElement;
            if (root.ValueKind != JsonValueKind.Object)
                throw new InvalidOperationException("Avatar manifest must contain a 3D model object.");
            var objReference = RequiredAssetReference(root, "obj", "objhash");
            var mtlReference = RequiredAssetReference(root, "mtl", "mtlhash");
            var objUrl = ResolveAsset(objReference);
            var mtlUrl = ResolveAsset(mtlReference);
            if (!root.TryGetProperty("textures", out var textures) || textures.ValueKind != JsonValueKind.Array)
                throw new InvalidOperationException("Avatar manifest is missing its texture list.");
            if (textures.GetArrayLength() > TextureLimit)
                throw new InvalidOperationException("Avatar manifest exceeds the limit of 16 textures.");

            // Validate every reference before downloading any model asset.
            var references = new List<(string Reference, Uri Url)>();
            foreach (var texture in textures.EnumerateArray())
            {
                if (texture.ValueKind != JsonValueKind.String || string.IsNullOrWhiteSpace(texture.GetString()))
                    throw new InvalidOperationException("Avatar manifest contains an invalid texture hash.");
                var reference = texture.GetString()!;
                references.Add((reference, ResolveAsset(reference)));
            }
            var obj = DecodeText(await DownloadCdnAsync(objUrl, AssetLimit, "avatar OBJ", budget, token).ConfigureAwait(false), "avatar OBJ");
            var mtl = DecodeText(await DownloadCdnAsync(mtlUrl, AssetLimit, "avatar MTL", budget, token).ConfigureAwait(false), "avatar MTL");
            if (!HasLine(obj, "v ") || !HasLine(obj, "f "))
                throw new InvalidOperationException("Avatar OBJ does not contain a usable 3D mesh.");
            if (!HasLine(mtl, "newmtl "))
                throw new InvalidOperationException("Avatar MTL does not contain model materials.");
            var aliases = new Dictionary<string, string>(StringComparer.Ordinal);
            var downloaded = new Dictionary<string, string>(StringComparer.Ordinal);
            foreach (var texture in references)
            {
                if (!downloaded.TryGetValue(texture.Url.AbsoluteUri, out var dataUri))
                {
                    var bytes = await DownloadCdnAsync(texture.Url, AssetLimit, "avatar texture", budget, token).ConfigureAwait(false);
                    dataUri = "data:" + TextureMime(bytes) + ";base64," + Convert.ToBase64String(bytes);
                    downloaded.Add(texture.Url.AbsoluteUri, dataUri);
                }
                var filename = Uri.UnescapeDataString(texture.Url.Segments[^1]);
                var hash = Path.GetFileNameWithoutExtension(filename);
                aliases[texture.Reference] = dataUri;
                aliases[filename] = dataUri;
                aliases[hash] = dataUri;
                aliases[hash + ".png"] = dataUri;
            }
            return new AvatarAppearance(avatarUserId, obj, mtl, aliases);
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested && deadline.IsCancellationRequested)
        {
            throw new InvalidOperationException("Avatar rendering exceeded its 45-second deadline.");
        }
    }

    private async Task<Uri> RenderAsync(JsonElement definition, DownloadBudget budget, CancellationToken ct)
    {
        var payload = JsonSerializer.Serialize(new
        {
            avatarDefinition = definition,
            thumbnailConfig = new { thumbnailId = 3, thumbnailType = "3d", size = "420x420" }
        });
        string? csrfToken = null;
        var csrfRetried = false;
        for (var attempt = 0; attempt < PendingAttempts; attempt++)
        {
            using var response = await SendRenderAsync(payload, csrfToken, ct).ConfigureAwait(false);
            if (response.StatusCode == HttpStatusCode.Forbidden && !csrfRetried &&
                response.Headers.TryGetValues("x-csrf-token", out var values))
            {
                var challenge = values.FirstOrDefault();
                if (!string.IsNullOrWhiteSpace(challenge) && !challenge.Any(char.IsControl))
                {
                    csrfToken = challenge;
                    csrfRetried = true;
                    // A challenge retry does not consume a pending poll.
                    attempt--;
                    continue;
                }
            }
            RequireSuccess(response, "Avatar render");
            var bytes = await ReadBoundedAsync(response, MetadataLimit, "avatar render response", budget, ct).ConfigureAwait(false);
            using var result = ParseJson(bytes, "avatar render response");
            var state = RequiredString(result.RootElement, "state", "avatar render response");
            if (state.Equals("Completed", StringComparison.OrdinalIgnoreCase))
                return ValidateCdnUrl(RequiredString(result.RootElement, "imageUrl", "completed avatar render"));
            if (!state.Equals("Pending", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Avatar render failed with state " + state + ".");
            if (attempt + 1 < PendingAttempts)
                await Task.Delay(TimeSpan.FromMilliseconds(500), ct).ConfigureAwait(false);
        }
        throw new InvalidOperationException("Avatar render remained pending after the bounded polling deadline.");
    }

    private async Task<HttpResponseMessage> SendRenderAsync(string payload, string? csrfToken, CancellationToken ct)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, RenderEndpoint);
        request.Content = new StringContent(payload, Encoding.UTF8, "application/json");
        request.Headers.Add("Cookie", _cookie);
        if (csrfToken != null) request.Headers.Add("x-csrf-token", csrfToken);
        return await _avatar.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct).ConfigureAwait(false);
    }

    private async Task<byte[]> DownloadCdnAsync(Uri uri, int limit, string label, DownloadBudget budget, CancellationToken ct)
    {
        for (var redirects = 0; ; redirects++)
        {
            uri = ValidateCdnUrl(uri.AbsoluteUri);
            using var request = new HttpRequestMessage(HttpMethod.Get, uri);
            using var response = await _cdn.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct).ConfigureAwait(false);
            if ((int)response.StatusCode is >= 300 and <= 399)
            {
                if (redirects >= 3 || response.Headers.Location == null)
                    throw new InvalidOperationException("Avatar CDN redirect limit exceeded or redirect location is missing.");
                uri = ValidateCdnUrl(new Uri(uri, response.Headers.Location).AbsoluteUri);
                continue;
            }
            RequireSuccess(response, label);
            return await ReadBoundedAsync(response, limit, label, budget, ct).ConfigureAwait(false);
        }
    }

    private static async Task<byte[]> ReadBoundedAsync(HttpResponseMessage response, int limit, string label, DownloadBudget budget, CancellationToken ct)
    {
        var length = response.Content.Headers.ContentLength;
        if (length > limit) throw new InvalidOperationException(label + " exceeds its download size limit.");
        if (length > TotalLimit - budget.Bytes) throw new InvalidOperationException("Avatar downloads exceed the total 64 MiB limit.");
        using var stream = await response.Content.ReadAsStreamAsync(ct).ConfigureAwait(false);
        using var memory = new MemoryStream();
        var buffer = new byte[64 * 1024];
        while (true)
        {
            var read = await stream.ReadAsync(buffer.AsMemory(), ct).ConfigureAwait(false);
            if (read == 0) break;
            if (read > limit - memory.Length) throw new InvalidOperationException(label + " exceeds its download size limit.");
            if (read > TotalLimit - budget.Bytes) throw new InvalidOperationException("Avatar downloads exceed the total 64 MiB limit.");
            budget.Bytes += read;
            await memory.WriteAsync(buffer.AsMemory(0, read), ct).ConfigureAwait(false);
        }
        return memory.ToArray();
    }

    private static Uri ResolveAsset(string reference)
    {
        if (Uri.TryCreate(reference, UriKind.Absolute, out var uri)) return ValidateCdnUrl(uri.AbsoluteUri);
        var candidate = reference.Trim().TrimStart('/');
        var fileName = Path.GetFileName(candidate);
        var hash = Path.GetFileNameWithoutExtension(fileName);
        if (hash.Length is < 32 or > 64 || !hash.All(char.IsAsciiHexDigit) || candidate.Contains("..", StringComparison.Ordinal))
            throw new InvalidOperationException("Avatar manifest contains an invalid CDN reference.");
        var shard = 31;
        foreach (var character in hash) shard ^= character;
        return new Uri($"https://t{Math.Abs(shard) % 8}.rbxcdn.com/{candidate}");
    }

    private static Uri ValidateCdnUrl(string value)
    {
        if (!Uri.TryCreate(value, UriKind.Absolute, out var uri) || uri.Scheme != Uri.UriSchemeHttps ||
            uri.Port != 443 || !string.IsNullOrEmpty(uri.UserInfo) || !string.IsNullOrEmpty(uri.Fragment) ||
            !(uri.Host.Equals("rbxcdn.com", StringComparison.OrdinalIgnoreCase) || uri.Host.EndsWith(".rbxcdn.com", StringComparison.OrdinalIgnoreCase)))
            throw new InvalidOperationException("Avatar CDN URL must use HTTPS on an rbxcdn.com host without credentials.");
        return uri;
    }

    private static HttpClient CreateClient(HttpMessageHandler? handler)
    {
        handler ??= new HttpClientHandler();
        // Cookies and redirect handling are explicit. Never share Roblox's cookie container with CDN downloads.
        if (handler is HttpClientHandler http)
        {
            http.AllowAutoRedirect = false;
            http.UseCookies = false;
            http.UseDefaultCredentials = false;
            http.Credentials = null;
            http.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate | DecompressionMethods.Brotli;
        }
        else if (handler is SocketsHttpHandler sockets)
        {
            sockets.AllowAutoRedirect = false;
            sockets.UseCookies = false;
            sockets.Credentials = null;
            sockets.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate | DecompressionMethods.Brotli;
        }
        return new HttpClient(handler, disposeHandler: true) { Timeout = Timeout.InfiniteTimeSpan };
    }

    private static void RequireSuccess(HttpResponseMessage response, string label)
    {
        if ((int)response.StatusCode is >= 300 and <= 399)
            throw new InvalidOperationException(label + " returned an unsupported redirect.");
        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException(label + " failed with HTTP " + (int)response.StatusCode + ".");
    }

    private static JsonDocument ParseJson(byte[] bytes, string label)
    {
        try { return JsonDocument.Parse(bytes); }
        catch (JsonException e) { throw new InvalidOperationException(label + " is not valid 3D avatar JSON.", e); }
    }

    private static string RequiredString(JsonElement root, string name, string label)
    {
        if (root.ValueKind != JsonValueKind.Object || !root.TryGetProperty(name, out var value) ||
            value.ValueKind != JsonValueKind.String || string.IsNullOrWhiteSpace(value.GetString()))
            throw new InvalidOperationException(label + " is missing " + name + ".");
        return value.GetString()!;
    }

    private static string RequiredAssetReference(JsonElement manifest, string name, string legacyName)
    {
        // Roblox's 3D manifest uses obj/mtl. Retain hash-suffixed aliases for older exports.
        return RequiredString(manifest, manifest.TryGetProperty(name, out _) ? name : legacyName, "avatar manifest");
    }

    private static string DecodeText(byte[] bytes, string label)
    {
        try { return StrictUtf8.GetString(bytes); }
        catch (DecoderFallbackException e) { throw new InvalidOperationException(label + " is not valid UTF-8 model text.", e); }
    }

    private static bool HasLine(string text, string prefix) => text.StartsWith(prefix, StringComparison.Ordinal) || text.Contains("\n" + prefix, StringComparison.Ordinal);

    private static string TextureMime(byte[] bytes)
    {
        var data = bytes.AsSpan();
        if (data.Length >= 8 && data[..8].SequenceEqual(new byte[] { 137, 80, 78, 71, 13, 10, 26, 10 })) return "image/png";
        if (data.Length >= 3 && data[0] == 255 && data[1] == 216 && data[2] == 255) return "image/jpeg";
        if (data.Length >= 12 && data[..4].SequenceEqual("RIFF"u8) && data.Slice(8, 4).SequenceEqual("WEBP"u8)) return "image/webp";
        if (data.Length >= 6 && (data[..6].SequenceEqual("GIF87a"u8) || data[..6].SequenceEqual("GIF89a"u8))) return "image/gif";
        throw new InvalidOperationException("Avatar texture is not a supported bitmap image.");
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _avatar.Dispose();
        _cdn.Dispose();
    }

    private sealed class DownloadBudget { public long Bytes; }
}

public record AvatarAppearance(long AvatarUserId, string Obj, string Mtl, Dictionary<string, string> Textures);
