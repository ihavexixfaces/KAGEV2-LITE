(() => {
  'use strict';
  const bridge = window.chrome && window.chrome.webview;
  if (!bridge) return;
  let dialog, reason;
  const copies = {
    VersionRetired: ['This version of KAGE is no longer available to use.', 'Download KAGE v2.0.7 to continue.'],
    AuthorizationRejected: ['KAGE could not verify your authorization.', 'Access is disabled. Please sign in again or download the official supported version.']
  };
  function isolate() {
    if (typeof document === 'undefined' || !document.body) return;
    for (const child of document.body.children) {
      if (child !== dialog) { child.inert = true; child.setAttribute('aria-hidden', 'true'); }
    }
  }
  function send(type) { bridge.postMessage({ type }); }
  function show(data) {
    if (!data || !Object.hasOwn(copies, data.reason)) return;
    if (dialog) { update(data.secondsRemaining); return; }
    reason = data.reason;
    dialog = document.createElement('dialog');
    dialog.id = 'kage-security-block';
    dialog.className = 'kage-security-block';
    dialog.setAttribute('role', 'alertdialog');
    dialog.setAttribute('aria-modal', 'true');
    dialog.setAttribute('aria-labelledby', 'kage-security-primary');
    dialog.setAttribute('aria-describedby', 'kage-security-support kage-security-countdown');
    const card = document.createElement('div'); card.className = 'kage-security-card';
    const brand = document.createElement('div'); brand.className = 'kage-security-brand'; brand.textContent = 'KAGE';
    const title = document.createElement('h2'); title.id = 'kage-security-primary'; title.textContent = copies[reason][0];
    const support = document.createElement('p'); support.id = 'kage-security-support'; support.textContent = copies[reason][1];
    const countdown = document.createElement('p'); countdown.id = 'kage-security-countdown'; countdown.setAttribute('aria-live', 'polite');
    const actions = document.createElement('div'); actions.className = 'kage-security-actions';
    const download = document.createElement('button'); download.type = 'button'; download.textContent = 'Download KAGE v2.0.7';
    download.addEventListener('click', () => send('securityBlockDownload')); actions.append(download);
    if (reason === 'AuthorizationRejected') {
      const recovery = document.createElement('button'); recovery.type = 'button'; recovery.className = 'kage-security-secondary'; recovery.textContent = 'Sign in again';
      recovery.addEventListener('click', () => send('securityBlockRecovery')); actions.append(recovery);
    }
    card.append(brand, title, support, countdown, actions); dialog.append(card); document.body.append(dialog);
    dialog.addEventListener('cancel', event => event.preventDefault());
    isolate(); new MutationObserver(isolate).observe(document.body, { childList: true });
    if (typeof dialog.showModal === 'function') dialog.showModal(); else dialog.setAttribute('open', '');
    download.focus(); update(data.secondsRemaining);
  }
  function update(seconds) {
    if (!dialog) return;
    // Display only host ticks. JavaScript cannot extend, cancel or trigger shutdown.
    seconds = Number.isInteger(seconds) ? Math.max(0, Math.min(5, seconds)) : 5;
    dialog.querySelector('#kage-security-countdown').textContent = `Closing in ${seconds} ${seconds === 1 ? 'second' : 'seconds'}.`;
  }
  for (const name of ['click', 'pointerdown', 'keydown', 'submit']) {
    document.addEventListener(name, event => {
      if (!dialog || dialog.contains(event.target)) return;
      event.preventDefault(); event.stopImmediatePropagation();
    }, true);
  }
  bridge.addEventListener('message', event => {
    const message = event.data;
    if (message && message.event === 'securityBlock') show(message.data);
    else if (message && message.event === 'securityBlockCountdown') update(message.data && message.data.secondsRemaining);
  });
  send('securityBlockReady');
})();
