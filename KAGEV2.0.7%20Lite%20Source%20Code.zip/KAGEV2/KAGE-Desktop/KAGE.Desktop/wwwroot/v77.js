(() => {
  const scanState = new Map();

  function n(value) {
    const parsed = Number(value);
    return Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : 0;
  }

  function currentExplorerType() {
    return document.querySelector('#asset-type-group .asset-toggle.active')?.dataset?.type || 'Animations';
  }

  function currentPreviewType() {
    return document.querySelector('#preview-type-tabs [data-type].active')?.dataset?.type || 'Animations';
  }

  function indicator(id, processed, total) {
    let node = document.getElementById(id);
    if (!node) {
      node = document.createElement('div');
      node.id = id;
      node.className = 'studio-scan-progress';
      node.setAttribute('role', 'status');
      node.setAttribute('aria-live', 'polite');
      const ring = document.createElement('i');
      ring.className = 'studio-scan-progress-ring';
      ring.setAttribute('aria-hidden', 'true');
      const copy = document.createElement('span');
      copy.className = 'studio-scan-progress-copy';
      node.append(ring, copy);
    }
    const copy = node.querySelector('.studio-scan-progress-copy');
    const shownProcessed = n(processed);
    const shownTotal = n(total);
    if (shownTotal > 0) {
      copy.innerHTML = `Scanning <span class="studio-scan-progress-count">${shownProcessed}/${shownTotal}</span>`;
      node.setAttribute('aria-label', `Scanning ${shownProcessed} of ${shownTotal}`);
    } else {
      // MCP execute_luau is one request: the exact DataModel size is only known
      // after Studio has entered the original-V2 scan. Never show the misleading
      // permanent "0/0" state while that first request is running.
      copy.textContent = 'Scanning project…';
      node.setAttribute('aria-label', 'Scanning Studio project');
    }
    return node;
  }

  function remove(id) {
    document.getElementById(id)?.remove();
  }

  function paint(type) {
    const state = scanState.get(type);
    if (!state || state.done) {
      if (currentExplorerType() === type) remove('studio-explorer-scan-progress');
      if (currentPreviewType() === type) remove('studio-preview-scan-progress');
      return;
    }

    if (currentExplorerType() === type) {
      const tree = document.getElementById('studio-workspace-tree');
      if (tree) tree.prepend(indicator('studio-explorer-scan-progress', state.processed, state.total));
    }

    if (currentPreviewType() === type) {
      const list = document.getElementById('preview-animation-list');
      if (list) list.prepend(indicator('studio-preview-scan-progress', state.processed, state.total));
    }

    const sync = document.getElementById('reupload-info-sync');
    if (sync && currentExplorerType() === type) {
      const total = n(state.total);
      sync.textContent = total > 0
        ? `Scanning ${n(state.processed)}/${total}`
        : 'Scanning project…';
    }
  }

  function complete(type) {
    scanState.delete(type);
    if (currentExplorerType() === type) remove('studio-explorer-scan-progress');
    if (currentPreviewType() === type) remove('studio-preview-scan-progress');
  }

  window.chrome?.webview?.addEventListener('message', event => {
    const message = event.data || {};
    if (message.event === 'studioScanProgress') {
      const data = message.data || {};
      const type = String(data.assetType || 'Animations');
      const state = {
        processed: n(data.processed),
        total: n(data.total),
        found: n(data.found),
        done: data.done === true
      };
      scanState.set(type, state);
      if (state.done) {
        // Keep 100% visible for a fraction of a second so the user can see completion.
        paint(type);
        setTimeout(() => complete(type), 240);
      } else {
        paint(type);
      }
      return;
    }

    if (message.event === 'studioConnectionState') {
      const data = message.data || {};
      const activity = String(data.activity || data.status || '');
      if (data.state === 'StudioConnected' && /scanning/i.test(activity)) {
        const type = currentExplorerType();
        if (!scanState.has(type)) scanState.set(type, { processed: 0, total: 0, found: 0, done: false });
        paint(type);
      }
      if (['Disconnected','ConnectionLost','ConnectionFailed','StudioNotRunning','StudioNotInstalled'].includes(String(data.state || ''))) {
        scanState.clear();
        remove('studio-explorer-scan-progress');
        remove('studio-preview-scan-progress');
      }
      return;
    }

    if (message.event === 'studioWorkspaceSnapshot') {
      const type = String(message.data?.assetType || currentExplorerType());
      const state = scanState.get(type);
      if (state && !state.done) requestAnimationFrame(() => paint(type));
      return;
    }

    if (message.event === 'studioWorkspaceError') {
      const type = currentExplorerType();
      complete(type);
      scanState.clear();
      remove('studio-explorer-scan-progress');
      remove('studio-preview-scan-progress');
      return;
    }
  });

  document.getElementById('asset-type-group')?.addEventListener('click', () => {
    requestAnimationFrame(() => {
      remove('studio-explorer-scan-progress');
      const state = scanState.get(currentExplorerType());
      if (state && !state.done) paint(currentExplorerType());
    });
  });

  document.getElementById('preview-type-tabs')?.addEventListener('click', () => {
    requestAnimationFrame(() => {
      remove('studio-preview-scan-progress');
      const state = scanState.get(currentPreviewType());
      if (state && !state.done) paint(currentPreviewType());
    });
  });
})();
