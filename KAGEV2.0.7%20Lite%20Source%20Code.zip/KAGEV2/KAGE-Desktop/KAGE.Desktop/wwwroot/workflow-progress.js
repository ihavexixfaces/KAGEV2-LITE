// v44 transfer presentation. Native jobs and the original progress view retain
// their counters and bars; this layer only moves text and mirrors painted values.
(() => {
  'use strict';
  if (document.getElementById('workflow-job-rail')) return;
  const byId = id => document.getElementById(id);
  const panel = byId('progress-panel');
  const completeModal = byId('reupload-complete-modal');
  if (!panel || !completeModal) return;

  const count = value => {
    const number = Number(value);
    return Number.isFinite(number) ? Math.max(0, Math.floor(number)) : 0;
  };
  const write = (node, value) => {
    if (node && node.textContent !== String(value)) node.textContent = String(value);
  };
  const hide = (node, hidden) => {
    if (node && node.hidden !== hidden) node.hidden = hidden;
  };
  const element = (tag, className, id) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (id) node.id = id;
    return node;
  };
  const metric = (container, label, values, id) => {
    const row = element('div', 'workflow-metric-row', id);
    const caption = element('span', 'workflow-metric-label');
    caption.textContent = `${label}:`;
    const value = element('span', 'workflow-metric-value');
    values.forEach(node => value.append(node));
    row.append(caption, value);
    container.append(row);
    return row;
  };
  const newValue = (id, text = '0') => {
    const node = element('strong', '', id);
    node.textContent = text;
    return node;
  };
  const rail = (id, label) => {
    const node = element('div', 'workflow-progress-rail', id);
    node.setAttribute('role', 'progressbar');
    node.setAttribute('aria-label', label);
    node.setAttribute('aria-valuemin', '0');
    node.setAttribute('aria-valuenow', '0');
    node.setAttribute('aria-valuemax', '100');
    node.append(element('span', 'workflow-progress-fill'));
    return node;
  };
  const paintRail = (node, completed, total, description) => {
    const percent = total > 0 ? Math.max(0, Math.min(100, completed / total * 100)) : 0;
    node.style.setProperty('--workflow-progress', `${percent}%`);
    node.setAttribute('aria-valuenow', String(completed));
    node.setAttribute('aria-valuemax', String(total));
    node.setAttribute('aria-valuetext', description);
  };

  panel.classList.add('workflow-transfer-panel');
  const jobLine = element('div', 'workflow-progress-line');
  const jobEta = element('span', 'workflow-progress-eta');
  jobEta.append(document.createTextNode('ETA: '), byId('progress-eta'));
  jobLine.append(byId('progress-percent'), jobEta);
  const jobRail = rail('workflow-job-rail', 'Assets processed');
  panel.querySelector('.progress-header').after(jobLine, jobRail);
  const jobMetrics = element('div', 'workflow-transfer-metrics', 'workflow-job-metrics');
  const jobTime = newValue('workflow-job-time', '--:--');
  const instances = newValue('workflow-job-instances');
  const remaining = newValue('workflow-job-remaining');
  metric(jobMetrics, 'Time', [jobTime]);
  jobMetrics.append(byId('asset-info'));
  metric(jobMetrics, 'Assets', [byId('progress-completed'), document.createTextNode('/'), byId('progress-total')]);
  const instancesRow = metric(jobMetrics, 'Instances updated', [instances]);
  const remainingRow = metric(jobMetrics, 'Remaining', [remaining]);
  instancesRow.hidden = true;
  remainingRow.hidden = true;
  panel.append(jobMetrics);
  const engineBar = byId('progress-bar-container');
  engineBar.classList.add('workflow-engine-values');
  engineBar.setAttribute('aria-hidden', 'true');
  const stats = panel.querySelector('.progress-stats');
  stats.classList.add('workflow-engine-values');
  stats.setAttribute('aria-hidden', 'true');
  panel.querySelector('.progress-summary').remove();
  byId('asset-outcome').classList.add('workflow-engine-values');
  byId('asset-outcome').setAttribute('aria-hidden', 'true');
  byId('asset-sequence-display').closest('.asset-detail').hidden = true;

  const completionStats = completeModal.querySelector('.reupload-complete-stats');
  completionStats.classList.add('workflow-transfer-metrics');
  // Keep the outcome nodes alive for the native summary and count animations.
  const hiddenCompletionValues = element('div', 'workflow-engine-values');
  hiddenCompletionValues.setAttribute('aria-hidden', 'true');
  hiddenCompletionValues.append(byId('complete-successful'), byId('complete-failed'));
  const completeTotal = byId('complete-total-assets');
  const completeInstances = byId('complete-references-swapped');
  const completeTime = byId('complete-eta');
  const completeCompleted = newValue('complete-completed');
  completionStats.replaceChildren();
  metric(completionStats, 'Time', [completeTime]);
  metric(completionStats, 'Assets', [completeCompleted, document.createTextNode('/'), completeTotal]);
  metric(completionStats, 'Instances updated', [completeInstances]);
  completionStats.append(hiddenCompletionValues);
  completeModal.querySelector('.completion-particles')?.remove();

  // Reuse the original animation helper, with actual processed and elapsed values.
  // This is a presentation function; no job/event handler is replaced.
  if (typeof animateCountValue === 'function' && typeof animateCompletionStats === 'function') {
    animateCompletionStats = async function (data = {}) {
      const success = count(data.success ?? data.successful);
      const failed = count(data.failed);
      const total = count(data.total);
      const completed = Math.min(total, count(data.completed ?? success + failed));
      const clock = typeof currentRunDurationText === 'function' ? currentRunDurationText() : '--:--';
      const match = /^(\d+):(\d{2})$/.exec(clock);
      const reportedElapsed = data.elapsedSeconds;
      const elapsed = typeof reportedElapsed === 'number' && Number.isFinite(reportedElapsed)
        ? Math.max(0, reportedElapsed)
        : match ? Number(match[1]) * 60 + Number(match[2]) : null;
      const metrics = [
        [completeCompleted, completed], [completeTotal, total],
        [byId('complete-successful'), success], [byId('complete-failed'), failed],
        [completeInstances, count(data.referencesSwapped)]
      ];
      metrics.forEach(([node]) => write(node, 0));
      write(completeTime, elapsed === null ? '--:--' : '00:00');
      await Promise.all(metrics.map(([node, value], index) => animateCountValue(node, value, { duration: 500 + index * 55 })));
      if (elapsed !== null) await animateCountValue(completeTime, elapsed, {
        duration: 650, formatter: value => formatClock(value)
      });
    };
  }

  const syncJob = () => {
    const completed = count(engineBar.getAttribute('aria-valuenow'));
    const total = count(engineBar.getAttribute('aria-valuemax'));
    paintRail(jobRail, completed, total, `${completed} of ${total} assets`);
    write(remaining, Math.max(0, total - completed));
    hide(remainingRow, total === 0 || completed >= total);
    hide(jobEta, !/^\d+:\d{2}$/.test(byId('progress-eta').textContent) || total === 0 || completed >= total);
    const jobStarted = typeof activeJobId === 'undefined' || !!activeJobId;
    write(jobTime, jobStarted && typeof currentRunDurationText === 'function' ? currentRunDurationText() : '--:--');
  };
  const jobObserver = new MutationObserver(syncJob);
  jobObserver.observe(engineBar, { attributes: true, attributeFilter: ['aria-valuenow', 'aria-valuemax'] });
  jobObserver.observe(byId('progress-eta'), { childList: true, characterData: true, subtree: true });
  jobObserver.observe(panel, { attributes: true, attributeFilter: ['class'] });
  syncJob();
  window.setInterval(() => { if (!panel.classList.contains('hidden')) syncJob(); }, 250);

  // Core updater segments remain present because its native event renderer owns
  // them. Its aria-valuenow is the source for the same continuous visible rail.
  const updateBar = byId('update-progress-bar');
  const updateView = byId('update-progress-view');
  if (updateBar && updateView) {
    const updateLine = element('div', 'workflow-progress-line');
    const updatePercent = newValue('workflow-update-percent', '0%');
    updateLine.append(updatePercent, byId('update-eta'));
    const updateRail = rail('workflow-update-rail', 'Update download');
    updateBar.before(updateLine, updateRail);
    updateBar.classList.add('workflow-engine-values');
    updateBar.setAttribute('aria-hidden', 'true');
    const syncUpdate = () => {
      const percent = Math.max(0, Math.min(100, Number(updateBar.getAttribute('aria-valuenow')) || 0));
      paintRail(updateRail, percent, 100, `${percent}%`);
      write(updatePercent, `${percent}%`);
    };
    new MutationObserver(syncUpdate).observe(updateBar, { attributes: true, attributeFilter: ['aria-valuenow'] });
    syncUpdate();
  }

  // Read reference counts when the existing host reports them; never estimate.
  let referenceJobId = '';
  const acceptReferences = message => {
    const event = message?.event;
    const data = message?.data || {};
    if (!['studioJobProgress', 'progressUpdate', 'studioReferencesProgress', 'studioReferencesApplied'].includes(event)) return;
    if (typeof activeJobId !== 'undefined' && data.jobId && String(data.jobId) !== String(activeJobId || '')) return;
    const jobId = String(data.jobId || '');
    if (jobId && jobId !== referenceJobId) {
      referenceJobId = jobId;
      write(instances, 0);
      hide(instancesRow, true);
    }
    const value = event === 'studioReferencesProgress'
      ? (data.synchronized ?? data.mapped ?? data.totalChanged)
      : event === 'studioReferencesApplied'
        ? (data.mapped ?? data.changed)
        : (data.referencesMapped ?? data.referencesSwapped);
    if (value !== undefined && value !== null && Number.isFinite(Number(value))) {
      write(instances, count(value));
      hide(instancesRow, false);
    }
  };
  if (typeof bridge !== 'undefined') bridge.onMessage(acceptReferences);

  const done = byId('reupload-complete-done');
  if (!done.querySelector('.interaction-shine')) {
    const shine = element('span', 'interaction-shine');
    shine.setAttribute('aria-hidden', 'true');
    done.append(shine);
  }
  bindKageInteraction(done);
  let completionOpen = false;
  let previousFocus = null;
  new MutationObserver(() => {
    const open = !completeModal.classList.contains('hidden');
    if (open === completionOpen) return;
    completionOpen = open;
    if (open) {
      previousFocus = document.activeElement;
      done.focus({ preventScroll: true });
    } else if (previousFocus?.isConnected && !completeModal.contains(previousFocus)) {
      previousFocus.focus({ preventScroll: true });
    }
  }).observe(completeModal, { attributes: true, attributeFilter: ['class'] });
  completeModal.addEventListener('keydown', event => {
    if (!completionOpen) return;
    if (event.key === 'Escape') {
      event.preventDefault();
      done.click();
    } else if (event.key === 'Tab') {
      const close = byId('reupload-complete-close');
      if (!event.shiftKey && document.activeElement === done) {
        event.preventDefault(); close.focus();
      } else if (event.shiftKey && document.activeElement === close) {
        event.preventDefault(); done.focus();
      }
    }
  });
})();
