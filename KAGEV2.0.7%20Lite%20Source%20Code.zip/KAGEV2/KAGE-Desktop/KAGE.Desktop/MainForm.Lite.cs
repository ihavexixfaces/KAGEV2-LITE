namespace KAGE.Desktop;

public partial class MainForm
{
    private void CancelAssetPreviewRequests() { }
    private void CancelAssetPreviewRequestsIfContextChanged() { }
    private async void HandleAssetPreviewRequest(Dictionary<string, System.Text.Json.JsonElement> message)
    {
        var requestId = message.TryGetValue("requestId", out var id) && id.ValueKind == System.Text.Json.JsonValueKind.String ? id.GetString() : "";
        await SendToFrontend("assetPreviewResponse", new { requestId, success = false, error = "KAGE Lite previews animations only." });
    }
}
