using System.Diagnostics;

namespace Kage.Bridge;

public static class StudioExecutableLocator
{
    public static string? FindWindowsStudioExecutable()
    {
        if (!OperatingSystem.IsWindows()) return null;

        // When Studio is already open, its process is the most reliable source of
        // the installed executable path and also handles nonstandard normal installs.
        try
        {
            foreach (var process in Process.GetProcessesByName("RobloxStudioBeta"))
            {
                using (process)
                {
                    try
                    {
                        var runningPath = process.MainModule?.FileName;
                        if (!string.IsNullOrWhiteSpace(runningPath) && File.Exists(runningPath))
                            return runningPath;
                    }
                    catch { }
                }
            }
        }
        catch { }

        var localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        if (string.IsNullOrWhiteSpace(localAppData)) return null;

        var direct = Path.Combine(localAppData, "Roblox", "RobloxStudioBeta.exe");
        if (File.Exists(direct)) return direct;

        var versionsRoot = Path.Combine(localAppData, "Roblox", "Versions");
        if (!Directory.Exists(versionsRoot)) return null;

        try
        {
            return Directory.EnumerateDirectories(versionsRoot)
                .Select(dir => new FileInfo(Path.Combine(dir, "RobloxStudioBeta.exe")))
                .Where(file => file.Exists)
                .OrderByDescending(file => file.LastWriteTimeUtc)
                .Select(file => file.FullName)
                .FirstOrDefault();
        }
        catch
        {
            return null;
        }
    }

    public static bool IsStudioAvailable() => OperatingSystem.IsWindows()
        ? FindWindowsStudioExecutable() is not null || StudioMcpClient.IsLauncherAvailable
        : StudioMcpClient.IsLauncherAvailable;

    public static bool IsStudioRunning()
    {
        try
        {
            var names = OperatingSystem.IsWindows()
                ? new[] { "RobloxStudioBeta" }
                : new[] { "RobloxStudioBeta", "RobloxStudio", "roblox-studio", "RobloxStudioBeta.exe" };
            foreach (var name in names)
            {
                foreach (var process in Process.GetProcessesByName(name))
                {
                    using (process)
                    {
                        try { if (!process.HasExited) return true; }
                        catch { }
                    }
                }
            }

            // Linux Studio deployments vary (native wrappers/Wine). An explicit MCP
            // launcher is the authoritative signal that KAGE can attempt a connection.
            return OperatingSystem.IsLinux() && StudioMcpClient.IsLauncherAvailable;
        }
        catch
        {
            return false;
        }
    }
}
