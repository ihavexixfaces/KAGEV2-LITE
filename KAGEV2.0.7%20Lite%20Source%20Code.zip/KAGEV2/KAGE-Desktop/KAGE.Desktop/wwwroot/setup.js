const bridge = {
  send(action, data = {}) { window.chrome.webview.postMessage({ action, ...data }); },
  onMessage(callback) { window.chrome.webview.addEventListener('message', e => callback(e.data)); }
};
function showSetupLoading(title='CONNECTING') {
  const overlay=document.getElementById('setup-loading-overlay');
  const target=document.getElementById('setup-loading-title');
  if(target){target.textContent='';String(title).split('').forEach((ch,i)=>{const span=document.createElement('span');span.className='animated-letter';span.textContent=ch===' '?'\u00a0':ch;span.style.setProperty('--letter-index',String(i));span.style.animationDelay=`${i*.065}s`;target.append(span);});}
  overlay?.classList.add('active');overlay?.setAttribute('aria-hidden','false');
}
function hideSetupLoading(){const overlay=document.getElementById('setup-loading-overlay');overlay?.classList.remove('active');overlay?.setAttribute('aria-hidden','true');}
function showStatus(id,message,kind='tip-message'){const node=document.getElementById(id);if(!node)return;node.textContent=message;node.className=`setup-status ${kind}`;node.classList.remove('hidden');}
const cookie=document.getElementById('input-cookie');
const apiKey=document.getElementById('input-apikey');
const next=document.getElementById('btn-next');
next?.addEventListener('click',()=>{
  const c=String(cookie?.value||'').trim(),k=String(apiKey?.value||'').trim();
  if(!c||!k){showStatus('step1-status','Enter both your Roblox cookie and Open Cloud API key.','tip-message error');return;}
  next.disabled=true;showSetupLoading('CONNECTING');bridge.send('saveCredentials',{cookie:c,apiKey:k});
});
bridge.onMessage(message=>{
  const type=message.type||message.event;const data=message.data||message;
  if(type==='credentialsSaved'){hideSetupLoading();showStatus('step1-status',`Connected as ${data.username||'Roblox user'}`,'tip-message success');}
  else if(type==='credentialsSaveError'){hideSetupLoading();showStatus('step1-status',data.message||'KAGE could not verify these Roblox credentials.','tip-message error');if(next)next.disabled=false;}
  else if(type==='setupComplete'){hideSetupLoading();}
});
document.getElementById('input-cookie')?.addEventListener('keydown',e=>{if(e.key==='Enter')apiKey?.focus();});
document.getElementById('input-apikey')?.addEventListener('keydown',e=>{if(e.key==='Enter')next?.click();});
