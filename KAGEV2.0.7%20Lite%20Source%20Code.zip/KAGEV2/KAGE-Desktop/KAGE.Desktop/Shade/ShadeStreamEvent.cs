namespace KAGE.Desktop.Shade;

internal sealed record ShadeStreamEvent(string Kind, string? Text = null, string? Error = null);

internal sealed record ShadeMessage(string Role, string Content);

internal sealed record ShadeHealthResponse(bool Ok, string Service, string Model, string Status);

internal sealed class ShadeAuthException(string message) : Exception(message);
internal sealed class ShadeAuthConfigurationException(string message) : Exception(message);
internal sealed class ShadeRateLimitException(string message) : Exception(message);
internal sealed class ShadeServiceException(string message) : Exception(message);
internal sealed class ShadeConnectionException(string message, Exception? inner = null) : Exception(message, inner);
internal sealed class ShadeStreamProtocolException(string message) : Exception(message);
