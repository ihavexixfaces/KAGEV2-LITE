// v66: durable temporary-access countdown on Home.
(() => {
  'use strict';

  let accessExpiryEpoch = 0;
  let accessExpiryKind = '';
  let expiryTimer = 0;

  const expiryNodes = () => [
    document.getElementById('home-roblox-access-expiry'),
    document.getElementById('home-discord-access-expiry'),
  ].filter(Boolean);

  function formatRemaining(totalSeconds) {
    const seconds = Math.max(0, Math.floor(totalSeconds));
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    if (days > 0) return `${days}d ${hours}h ${minutes}m ${secs}s`;
    if (hours > 0) return `${hours}h ${minutes}m ${secs}s`;
    if (minutes > 0) return `${minutes}m ${secs}s`;
    return `${secs}s`;
  }

  function paintExpiryCountdown() {
    const nodes = expiryNodes();
    if (!nodes.length) return;

    const temporary = accessExpiryKind === 'temporary' && Number.isFinite(accessExpiryEpoch) && accessExpiryEpoch > 0;
    if (!temporary) {
      for (const node of nodes) {
        node.classList.add('hidden');
        node.classList.remove('expired');
        node.textContent = '';
        node.removeAttribute('title');
      }
      return;
    }

    const remaining = accessExpiryEpoch - (Date.now() / 1000);
    const expired = remaining <= 0;
    const text = expired ? 'TEMP · EXPIRED' : `TEMP · ${formatRemaining(remaining)}`;
    const exact = new Date(accessExpiryEpoch * 1000).toLocaleString([], { dateStyle:'medium', timeStyle:'short' });
    for (const node of nodes) {
      node.textContent = text;
      node.title = `Temporary KAGE access expires ${exact}`;
      node.classList.remove('hidden');
      node.classList.toggle('expired', expired);
    }
  }

  function updateExpiryFromAccount(data) {
    const discord = data?.discord || {};
    accessExpiryKind = String(discord.accessType || '').toLowerCase();
    accessExpiryEpoch = Number(discord.accessExpiresAt || 0);

    // Remove the legacy Home-only injected expiry so the ID line remains pure.
    document.querySelector('#home-discord-id > .discord-expiry')?.remove();
    paintExpiryCountdown();

    if (expiryTimer) clearInterval(expiryTimer);
    if (accessExpiryKind === 'temporary' && accessExpiryEpoch > 0) {
      expiryTimer = window.setInterval(paintExpiryCountdown, 1000);
    } else {
      expiryTimer = 0;
    }
  }

  if (typeof updateAccountInfo === 'function') {
    const priorUpdateAccountInfo = updateAccountInfo;
    updateAccountInfo = function(data) {
      priorUpdateAccountInfo(data);
      updateExpiryFromAccount(data);
    };
  }
})();
