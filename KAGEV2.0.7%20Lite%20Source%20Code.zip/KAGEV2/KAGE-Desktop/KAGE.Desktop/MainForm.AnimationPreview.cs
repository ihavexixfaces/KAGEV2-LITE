using System.Text.Json;
using Kage.Bridge;

namespace KAGE.Desktop;

public partial class MainForm
{
    private readonly object _animationPreviewRequestGate = new();
    private CancellationTokenSource? _animationPreviewLoadCancellation;
    private CancellationTokenSource? _animationPreviewCatalogCancellation;
    private string _animationPreviewLoadClip = "";

    private async void HandleAnimationPreviewRequest(Dictionary<string, JsonElement> message)
    {
        string Read(string key, string fallback = "") => message.TryGetValue(key, out var element) && element.ValueKind == JsonValueKind.String ? element.GetString() ?? fallback : fallback;
        var requestId = Read("requestId");
        var command = Read("command", "status");
        var clipToken = Read("clipToken", requestId);
        if (requestId.Length > 80 || clipToken.Length > 80) return;
        // Catalog discovery can page a very large Studio project. Playback/control
        // requests remain tightly bounded, while catalog scans get enough time to
        // finish instead of surfacing a misleading "operation was canceled".
        var requestTimeout = command == "catalog" ? TimeSpan.FromSeconds(150) : TimeSpan.FromSeconds(60);
        using var deadline = new CancellationTokenSource(requestTimeout);
        using var request = CancellationTokenSource.CreateLinkedTokenSource(_applicationShutdown.Token, deadline.Token);
        var ct = request.Token;
        try
        {
            if (command == "load")
            {
                lock (_animationPreviewRequestGate)
                {
                    // An entry/refresh scan already in flight must release the
                    // shared Studio queue before a user starts loading a clip.
                    _animationPreviewCatalogCancellation?.Cancel();
                    _animationPreviewLoadCancellation?.Cancel();
                    CancelAnimationPreviewAvatarLocked();
                    _animationPreviewLoadCancellation = request;
                    _animationPreviewLoadClip = clipToken;
                }
            }
            else if (command == "stop")
            {
                lock (_animationPreviewRequestGate)
                {
                    if (clipToken.Length == 0 || clipToken == _animationPreviewLoadClip)
                    {
                        _animationPreviewLoadCancellation?.Cancel();
                    }
                }
            }
            if (command == "catalog")
            {
                lock (_animationPreviewRequestGate)
                {
                    _animationPreviewCatalogCancellation?.Cancel();
                    _animationPreviewCatalogCancellation = request;
                }
                // Recover the Studio transport, but do not throw away the project catalog just
                // because StudioMCP assigned a fresh studio_id. PlaceId+UniverseId are the
                // durable project identity and the v85 scan is already the expensive part.
                var project = await _studioSessionManager.EnsureConnectedAsync(ct);
                var refresh = message.TryGetValue("refresh", out var refreshValue) && refreshValue.ValueKind == JsonValueKind.True;
                var requestedType = Read("assetType", "Animations");
                if (!requestedType.Equals("Animations", StringComparison.OrdinalIgnoreCase) && !requestedType.Equals("Animation", StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("KAGE Lite previews animations only.");
                var assetType = "Animations";
                if (!TryGetCachedStudioAssetScan(project, assetType, out var scan) || refresh)
                {
                    scan = await _kageMcpService.ScanPreviewAssetReferencesAsync(assetType, ct);
                    ct.ThrowIfCancellationRequested();
                    CacheStudioAssetScan(project, scan);
                }

                var rigType = "R15";
                var rigSource = "Auto";
                try
                {
                    // Rig detection is presentation metadata. A temporary MCP hiccup must not
                    // make the entire asset catalog disappear or claim Studio is disconnected.
                    var rigInfo = await _studioSessionManager.Workspace.GetAnimationPreviewRigInfoAsync(ct);
                    rigType = rigInfo.TryGetProperty("rigType", out var rigValue) && rigValue.ValueKind == JsonValueKind.String
                        ? rigValue.GetString() ?? "R15" : "R15";
                    rigSource = rigInfo.TryGetProperty("rigSource", out var rigSourceValue) && rigSourceValue.ValueKind == JsonValueKind.String
                        ? rigSourceValue.GetString() ?? "Studio" : "Studio";
                }
                catch (Exception ex) when (ex is not OperationCanceledException)
                {
                    AppendDebug($"Asset Viewer rig detection skipped: {ex.Message}");
                }
                await SendToFrontend("animationPreviewCatalog", new
                {
                    requestId,
                    rigType,
                    rigSource,
                    animations = scan.AssetIds.Select(id => new { id = id.ToString(), name = scan.AssetNames.GetValueOrDefault(id.ToString(), $"{assetType.TrimEnd('s')} {id}"), location = scan.AssetLocations.GetValueOrDefault(id.ToString(), "") }).ToArray()
                });
                await SendStudioConnectionStateAsync(_studioSessionManager.Snapshot).WaitAsync(ct);
                return;
            }

            var avatarUserId = 0L;
            if (command == "load")
            {
                await _studioSessionManager.EnsureConnectedAsync(ct);
            }
            JsonElement result;
            if (command == "load")
            {
                if (!long.TryParse(Read("assetId"), out var assetId) || assetId <= 0) throw new ArgumentException("Enter a valid animation asset ID.");
                result = await _studioSessionManager.Workspace.LoadAnimationPreviewAsync(assetId, Read("rigType", "R15"), avatarUserId, clipToken, ct);
                ct.ThrowIfCancellationRequested();
            }
            else if (command == "avatar")
                throw new InvalidOperationException("KAGE Asset Viewer previews animations on a Roblox R6/R15 rig.");
            else if (command == "sample")
            {
                var start = message.TryGetValue("start", out var startValue) && startValue.TryGetInt32(out var startNumber) ? startNumber : 0;
                result = await _studioSessionManager.Workspace.SampleAnimationPreviewAsync(clipToken, start, 120, ct);
            }
            else
            {
                var value = message.TryGetValue("value", out var valueElement) && valueElement.TryGetDouble(out var number) ? number : 0;
                var loop = !message.TryGetValue("loop", out var loopElement) || loopElement.ValueKind == JsonValueKind.True;
                result = await _studioSessionManager.Workspace.ControlAnimationPreviewAsync(command, clipToken, value, loop, ct);
            }
            ct.ThrowIfCancellationRequested();
            await SendToFrontend("animationPreviewResponse", new { requestId, command, success = true, result });
        }
        catch (Exception ex)
        {
            var error = deadline.IsCancellationRequested ? "KAGE Asset Viewer timed out. Check Studio and retry."
                : ex is OperationCanceledException ? "KAGE Asset Viewer cancelled." : FriendlyStudioError(ex);
            await SendToFrontend("animationPreviewResponse", new { requestId, command, success = false, error });
        }
        finally
        {
            lock (_animationPreviewRequestGate)
            {
                if (ReferenceEquals(_animationPreviewLoadCancellation, request))
                {
                    _animationPreviewLoadCancellation = null;
                    _animationPreviewLoadClip = "";
                }
                if (ReferenceEquals(_animationPreviewCatalogCancellation, request))
                    _animationPreviewCatalogCancellation = null;
                if (ReferenceEquals(_animationPreviewAvatarCancellation, request))
                    _animationPreviewAvatarCancellation = null;
            }
        }
    }
    private static string PreviewAudioMime(byte[] bytes)
    {
        if (bytes.Length >= 4 && bytes[0] == (byte)'O' && bytes[1] == (byte)'g' && bytes[2] == (byte)'g' && bytes[3] == (byte)'S') return "audio/ogg";
        if (bytes.Length >= 3 && bytes[0] == (byte)'I' && bytes[1] == (byte)'D' && bytes[2] == (byte)'3') return "audio/mpeg";
        if (bytes.Length >= 2 && bytes[0] == 0xFF && (bytes[1] & 0xE0) == 0xE0) return "audio/mpeg";
        if (bytes.Length >= 12 && bytes[0] == (byte)'R' && bytes[1] == (byte)'I' && bytes[2] == (byte)'F' && bytes[3] == (byte)'F') return "audio/wav";
        return "application/octet-stream";
    }
}
