using Kage.Core;

namespace Kage.Security
{

public enum KageBlockReason { VersionRetired, AuthorizationRejected }
public sealed class KageSupportBlock : EventArgs
{
    public KageBlockReason Reason { get; }
    public Uri DownloadUri { get; } = new("https://kage-v2-download.pages.dev/");
    public Uri RecoveryUri { get; } = new("https://kage-v2-download.pages.dev/");
    public KageSupportBlock(KageBlockReason reason) => Reason = reason;
}
public static class KageSupportPolicy
{
    public static event EventHandler<KageSupportBlock>? Blocked;
    public static KageSupportBlock? CurrentBlock => null;
    public static bool IsBlocked => false;
    public static void StartMonitoring() { }
    public static Task CheckNowAsync(CancellationToken cancellationToken = default) => Task.CompletedTask;
    internal static void ObserveVerifiedResponse(string route, System.Net.HttpStatusCode status, System.Text.Json.JsonElement body, object intent, string? bearer) { }
}
public static class LiteSessionGate
{
    internal static object CaptureSessionIntent() => new object();
    public static bool TryGetSessionTransport(out string token, out string clientChallenge) { token = string.Empty; clientChallenge = string.Empty; return false; }
}

internal interface IKageOperationAuthority
{
    Task<OperationLease> AcquireAsync(StudioJob job, CancellationToken cancellationToken);
}
internal sealed class LiteOperationAuthority : IKageOperationAuthority
{
    public Task<OperationLease> AcquireAsync(StudioJob job, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (job.Request.NormalizedAssetType != "Animations" || !job.Request.CreatorType.Equals("User", StringComparison.OrdinalIgnoreCase))
            throw new UnauthorizedAccessException("KAGE Lite supports animation reuploading for the connected Roblox account only.");
        return Task.FromResult(new OperationLease(cancellationToken));
    }
}
internal sealed class OperationLease : IAsyncDisposable
{
    private readonly CancellationTokenSource _revoked = new();
    public CancellationToken Revoked => _revoked.Token;
    public OperationLease(CancellationToken cancellationToken) { if (cancellationToken.IsCancellationRequested) _revoked.Cancel(); }
    public ValueTask DisposeAsync() { _revoked.Dispose(); return ValueTask.CompletedTask; }
}

}
