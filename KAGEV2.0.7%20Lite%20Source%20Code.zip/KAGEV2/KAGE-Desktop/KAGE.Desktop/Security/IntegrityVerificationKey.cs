using System.Security.Cryptography;
using System.Text;
using KAGE.Desktop.Updates;
namespace KAGE.Desktop;
internal static class IntegrityVerificationKey
{
    internal static string Pem
    {
        get
        {
            var encoded = ReleaseIdentity.IntegrityPublicKeyPemBase64;
            if (string.IsNullOrWhiteSpace(encoded)) throw new CryptographicException("Owner release verification key is missing.");
            try
            {
                var pem = Encoding.UTF8.GetString(Convert.FromBase64String(encoded));
                if (!pem.Contains("BEGIN PUBLIC KEY", StringComparison.Ordinal) || pem.Contains("PRIVATE KEY", StringComparison.Ordinal)) throw new CryptographicException("Public release verification key required.");
                using var key = ECDsa.Create(); key.ImportFromPem(pem);
                if (key.ExportParameters(false).Curve.Oid.Value != "1.2.840.10045.3.1.7") throw new CryptographicException("P-256 public release key required.");
                return pem;
            }
            catch (Exception ex) when (ex is FormatException or ArgumentException) { throw new CryptographicException("Invalid release verification key."); }
        }
    }
}
