using System.Buffers.Binary;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;

namespace KAGE.Desktop;

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Method | AttributeTargets.Field | AttributeTargets.Property | AttributeTargets.Event)]
internal sealed class BlackoutPreserveAttribute : Attribute
{
}

[AttributeUsage(AttributeTargets.Method)]
internal sealed class BlackoutVirtualizeAttribute : Attribute
{
}

internal static class BlackoutRuntime
{
    private static readonly byte[] ResourceMagic = new byte[] { (byte)'K', (byte)'B', (byte)'R', (byte)'2' };
    private static readonly byte[] VaultMagic = new byte[] { (byte)'K', (byte)'B', (byte)'V', (byte)'3' };
    private static readonly byte[] VmMagic = new byte[] { (byte)'K', (byte)'B', (byte)'M', (byte)'8' };
    private static readonly byte[] ResourceMapMagic = new byte[] { (byte)'K', (byte)'B', (byte)'P', (byte)'8' };
    private static readonly bool UseV9Material = MaterialMode() is 1 or 2;
    private static readonly bool UseV10Material = MaterialMode() is 2 or 3;
    private static readonly byte[] BuildSalt = BuildSaltBytes();
    private static readonly byte[] MasterSecret = BuildSecret();
    private static readonly byte[] StringKey = UseV10Material ? DeriveContext(MasterSecret,BuildSalt,"kage/string-v10") : UseV9Material ? DeriveContext(MasterSecret, BuildSalt, "kage/string-v9") : MasterSecret;
    private static readonly byte[] ResourceKey = UseV10Material ? DeriveContext(MasterSecret,BuildSalt,"kage/resource-v10") : UseV9Material ? DeriveContext(MasterSecret, BuildSalt, "kage/resource-v9") : MasterSecret;
    private static readonly byte[] VmKey = UseV10Material ? DeriveContext(MasterSecret,BuildSalt,"kage/vm-v10") : UseV9Material ? DeriveContext(MasterSecret, BuildSalt, "kage/vm-v9") : MasterSecret;
    private static readonly byte[] ResourceNameKey = UseV10Material ? DeriveContext(MasterSecret,BuildSalt,"kage/resource-name-v10") : UseV9Material ? DeriveContext(MasterSecret, BuildSalt, "kage/resource-name-v9") : MasterSecret;
    private static readonly object StringGate = new();
    private static readonly object VmGate = new();
    private static readonly object ResourceGate = new();
    private static Dictionary<int, byte[]>? _stringVault;
    private static Dictionary<int, string>? _stringCache;
    private static Dictionary<int, VmMethod>? _vmMethods;
    private static Dictionary<int, int>? _vmOpcodes;
    private static string[]? _logicalResourceNames;

    private sealed record VmMethod(int LocalCount, int[] Program);

    internal static string DecodeString(int token)
    {
        lock (StringGate)
        {
            _stringCache ??= new Dictionary<int, string>();
            if (_stringCache.TryGetValue(token, out var cached))
                return cached;

            _stringVault ??= LoadStringVault();
            if (!_stringVault.TryGetValue(token, out var payload) || payload.Length < 28)
                throw new InvalidOperationException("Protected string token is invalid.");

            var aad = UseV10Material?BlackoutPayload.StringAssociatedData(token):new byte[4];
            if(!UseV10Material)BinaryPrimitives.WriteInt32LittleEndian(aad, token);
            var key = HMACSHA256.HashData(StringKey, aad);
            var nonce = payload.AsSpan(0, 12);
            var tag = payload.AsSpan(12, 16);
            var cipher = payload.AsSpan(28);
            var plain = new byte[cipher.Length];

            try
            {
                using var aes = new AesGcm(key,16);aes.Decrypt(nonce,cipher,tag,plain,aad);
                var value=new UTF8Encoding(false,true).GetString(plain);_stringCache[token]=value;return value;
            }
            finally{CryptographicOperations.ZeroMemory(key);CryptographicOperations.ZeroMemory(plain);}
        }
    }

    internal static string ProtectedResourceName(string requestPath)
    {
        var cleanPath = (requestPath ?? string.Empty).Replace('\\', '/').TrimStart('/');
        var suffix = cleanPath.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase)
            ? ".Assets." + cleanPath[7..].Replace('/', '.')
            : ".wwwroot." + cleanPath.Replace('/', '.');
        var digest = HMACSHA256.HashData(ResourceNameKey, Encoding.UTF8.GetBytes(suffix));
        return "kbr_" + Convert.ToHexString(digest).ToLowerInvariant();
    }

    internal static string ProtectedManifestResourceName(string originalName)
    {
        var digest = HMACSHA256.HashData(ResourceNameKey, Encoding.UTF8.GetBytes(originalName));
        return "kbg_" + Convert.ToHexString(digest).ToLowerInvariant();
    }

    internal static string[] GetManifestResourceNames(Assembly assembly)
    {
        ArgumentNullException.ThrowIfNull(assembly);
        if (assembly != typeof(BlackoutRuntime).Assembly)
            return assembly.GetManifestResourceNames();

        lock (ResourceGate)
        {
            if (_logicalResourceNames is not null)
                return (string[])_logicalResourceNames.Clone();

            var real = assembly.GetManifestResourceNames();
            var logical = LoadResourceMap(assembly);
            var visible = real.Where(name => !IsBlackoutInternalResource(name))
                .Concat(logical)
                .Distinct(StringComparer.Ordinal)
                .OrderBy(name => name, StringComparer.Ordinal)
                .ToArray();
            _logicalResourceNames = visible;
            return (string[])visible.Clone();
        }
    }

    internal static Stream? OpenManifestResource(Assembly assembly, string originalName)
    {
        ArgumentNullException.ThrowIfNull(assembly);
        if (string.IsNullOrWhiteSpace(originalName))
            return null;

        var protectedName = GetProtectedNameForLogicalResource(originalName);
        var source = assembly.GetManifestResourceStream(protectedName);
        if (source is not null)
            return OpenProtectedResource(source, protectedName);

        if (UseV10Material && assembly == typeof(BlackoutRuntime).Assembly &&
            LoadResourceMap(assembly).Contains(originalName, StringComparer.Ordinal))
            throw new InvalidDataException("Protected logical resource is missing; plaintext substitution is prohibited.");

        return assembly.GetManifestResourceStream(originalName);
    }

    internal static Stream? OpenManifestResource(Assembly assembly, Type type, string name)
    {
        ArgumentNullException.ThrowIfNull(assembly);
        ArgumentNullException.ThrowIfNull(type);
        if (string.IsNullOrWhiteSpace(name))
            return null;

        var ns = type.Namespace;
        var full = string.IsNullOrWhiteSpace(ns) ? name : ns + "." + name;
        return OpenManifestResource(assembly, full) ?? assembly.GetManifestResourceStream(type, name);
    }


    private static string GetProtectedNameForLogicalResource(string originalName)
    {
        var webIndex = originalName.IndexOf(".wwwroot.", StringComparison.OrdinalIgnoreCase);
        if (webIndex >= 0)
        {
            var suffix = originalName[webIndex..];
            var digest = HMACSHA256.HashData(ResourceNameKey, Encoding.UTF8.GetBytes(suffix));
            return "kbr_" + Convert.ToHexString(digest).ToLowerInvariant();
        }

        var assetIndex = originalName.IndexOf(".Assets.", StringComparison.OrdinalIgnoreCase);
        if (assetIndex >= 0)
        {
            var suffix = originalName[assetIndex..];
            var digest = HMACSHA256.HashData(ResourceNameKey, Encoding.UTF8.GetBytes(suffix));
            return "kbr_" + Convert.ToHexString(digest).ToLowerInvariant();
        }

        return ProtectedManifestResourceName(originalName);
    }

    private static string[] LoadResourceMap(Assembly assembly)
    {
        var digest = HMACSHA256.HashData(ResourceNameKey, Encoding.UTF8.GetBytes(".blackout.resource.map"));
        var resourceName = "kbp_" + Convert.ToHexString(digest).ToLowerInvariant();
        using var raw = assembly.GetManifestResourceStream(resourceName);
        if (raw is null)
        {
            if (UseV10Material && assembly == typeof(BlackoutRuntime).Assembly)
                throw new InvalidDataException("Authenticated resource map is missing.");
            return Array.Empty<string>();
        }

        using var source = OpenProtectedResource(raw, resourceName);
        using var reader = new BinaryReader(source, Encoding.UTF8, leaveOpen: false);
        var magic = reader.ReadBytes(4);
        if (!magic.AsSpan().SequenceEqual(ResourceMapMagic))
            throw new InvalidOperationException("Protected resource map header is invalid.");

        var count = reader.ReadInt32();
        if (count is < 0 or > 100_000 || count > (source.Length-source.Position)/2)
            throw new InvalidOperationException("Protected resource map count is invalid.");

        var names = new string[count];
        for (var i = 0; i < count; i++)
        {
            var length=reader.Read7BitEncodedInt();
            if(length is <=0 or >4096 || length>source.Length-source.Position)throw new InvalidDataException("Protected resource map name length is invalid.");
            names[i]=new UTF8Encoding(false,true).GetString(reader.ReadBytes(length));
            if(i>0 && StringComparer.Ordinal.Compare(names[i-1],names[i])>=0)throw new InvalidDataException("Protected resource map is duplicated or reordered.");
        }
        if(source.Position!=source.Length)throw new InvalidDataException("Protected resource map contains trailing data.");
        return names;
    }

    private static bool IsBlackoutInternalResource(string name) =>
        name.StartsWith("kbv_", StringComparison.Ordinal) ||
        name.StartsWith("kbm_", StringComparison.Ordinal) ||
        name.StartsWith("kbp_", StringComparison.Ordinal) ||
        name.StartsWith("kbr_", StringComparison.Ordinal) ||
        name.StartsWith("kbg_", StringComparison.Ordinal);

    internal static Stream OpenProtectedResource(Stream source, string resourceName)
    {
        ArgumentNullException.ThrowIfNull(source);
        byte[] payload;
        using (source) payload = BlackoutPayload.ReadBounded(source);
        var decryptKey = resourceName.StartsWith("kbm_", StringComparison.Ordinal) ? VmKey : resourceName.StartsWith("kbv_",StringComparison.Ordinal) ? StringKey : ResourceKey;
        var plain = BlackoutPayload.Decrypt(payload,resourceName,decryptKey,BuildSalt,requireV10:UseV10Material && BlackoutPayload.IsProtectedName(resourceName));
        return new MemoryStream(plain,writable:false);
    }

    [MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]
    internal static int OpaqueState(int left, int right)
    {
        unchecked
        {
            var x = (uint)(left ^ right ^ Environment.TickCount);
            x ^= x << 13;
            x ^= x >> 17;
            x ^= x << 5;
            return (int)(x & 3u);
        }
    }

    [MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]
    internal static int ExecuteVm(int token, int[] args)
    {
        EnsureVmLoaded();
        if (_vmMethods is null || _vmOpcodes is null || !_vmMethods.TryGetValue(token, out var method))
            throw new InvalidOperationException("Protected VM method token is invalid.");

        var locals = new int[method.LocalCount];
        var stack = new int[Math.Max(32, method.Program.Length + 8)];
        var sp = 0;
        var ip = 0;
        var program = method.Program;
        var budget=100_000;

        while ((uint)ip < (uint)(program.Length / 2))
        {
            if(--budget<0)throw new InvalidDataException("Protected VM exceeded its instruction budget.");
            var baseIndex = ip * 2;
            var encodedOp = program[baseIndex];
            var operand = program[baseIndex + 1];
            if (!_vmOpcodes.TryGetValue(encodedOp, out var op))
                throw new InvalidOperationException("Protected VM opcode is invalid.");
            var need=op is >=6 and <=15 or >=18 and <=20 ? 2 : op is 5 or 16 or 17 or 22 or 23 or 24 ? 1 : 0;
            if(sp<need || (op is 2 or 3 or 4 && sp>=stack.Length))throw new InvalidDataException("Protected VM stack state is invalid.");
            if(op==3 && (uint)operand>=(uint)args.Length)throw new InvalidDataException("Protected VM argument is invalid.");

            switch (op)
            {
                case 1: ip++; break; // nop
                case 2: stack[sp++] = operand; ip++; break;
                case 3: stack[sp++] = args[operand]; ip++; break;
                case 4: stack[sp++] = locals[operand]; ip++; break;
                case 5: locals[operand] = stack[--sp]; ip++; break;
                case 6: { var b = stack[--sp]; stack[sp - 1] += b; ip++; break; }
                case 7: { var b = stack[--sp]; stack[sp - 1] -= b; ip++; break; }
                case 8: { var b = stack[--sp]; stack[sp - 1] *= b; ip++; break; }
                case 9: { var b = stack[--sp]; stack[sp - 1] /= b; ip++; break; }
                case 10: { var b = stack[--sp]; stack[sp - 1] %= b; ip++; break; }
                case 11: { var b = stack[--sp]; stack[sp - 1] &= b; ip++; break; }
                case 12: { var b = stack[--sp]; stack[sp - 1] |= b; ip++; break; }
                case 13: { var b = stack[--sp]; stack[sp - 1] ^= b; ip++; break; }
                case 14: { var b = stack[--sp]; stack[sp - 1] <<= b; ip++; break; }
                case 15: { var b = stack[--sp]; stack[sp - 1] >>= b; ip++; break; }
                case 16: stack[sp - 1] = -stack[sp - 1]; ip++; break;
                case 17: stack[sp - 1] = ~stack[sp - 1]; ip++; break;
                case 18: { var b = stack[--sp]; stack[sp - 1] = stack[sp - 1] == b ? 1 : 0; ip++; break; }
                case 19: { var b = stack[--sp]; stack[sp - 1] = stack[sp - 1] > b ? 1 : 0; ip++; break; }
                case 20: { var b = stack[--sp]; stack[sp - 1] = stack[sp - 1] < b ? 1 : 0; ip++; break; }
                case 21: ip = operand; break;
                case 22: ip = stack[--sp] != 0 ? operand : ip + 1; break;
                case 23: ip = stack[--sp] == 0 ? operand : ip + 1; break;
                case 24: if(sp!=1)throw new InvalidDataException("Protected VM return stack is invalid.");return stack[--sp];
                default: throw new InvalidOperationException("Protected VM semantic opcode is invalid.");
            }
        }

        throw new InvalidOperationException("Protected VM method terminated without return.");
    }

    private static Dictionary<int, byte[]> LoadStringVault()
    {
        var digest = HMACSHA256.HashData(ResourceNameKey, Encoding.UTF8.GetBytes(".blackout.strings.vault"));
        var resourceName = "kbv_" + Convert.ToHexString(digest).ToLowerInvariant();
        using var raw = typeof(BlackoutRuntime).Assembly.GetManifestResourceStream(resourceName)
            ?? throw new InvalidOperationException("Protected string vault is missing.");
        using var source = UseV10Material?OpenProtectedResource(raw,resourceName):raw;
        return BlackoutPayload.ReadStringVault(source);
    }

    private static void EnsureVmLoaded()
    {
        if (_vmMethods is not null && _vmOpcodes is not null)
            return;

        lock (VmGate)
        {
            if (_vmMethods is not null && _vmOpcodes is not null)
                return;

            var digest = HMACSHA256.HashData(ResourceNameKey, Encoding.UTF8.GetBytes(".blackout.vm.vault"));
            var resourceName = "kbm_" + Convert.ToHexString(digest).ToLowerInvariant();
            using var raw = typeof(BlackoutRuntime).Assembly.GetManifestResourceStream(resourceName)
                ?? throw new InvalidOperationException("Protected VM vault is missing.");
            using var source = OpenProtectedResource(raw, resourceName);
            using var reader = new BinaryReader(source, Encoding.UTF8, leaveOpen: false);
            var magic = reader.ReadBytes(4);
            if (!magic.AsSpan().SequenceEqual(VmMagic))
                throw new InvalidOperationException("Protected VM vault header is invalid.");

            var opcodeCount = reader.ReadInt32();
            if (opcodeCount != 24)
                throw new InvalidOperationException("Protected VM opcode table is invalid.");
            var opcodes = new Dictionary<int, int>(opcodeCount);
            var semantics=new HashSet<int>();
            for (var i = 0; i < opcodeCount; i++)
            {
                var semantic = reader.ReadInt32();
                var encoded = reader.ReadInt32();
                if(semantic is <1 or >24 || encoded<=0 || !semantics.Add(semantic) || !opcodes.TryAdd(encoded,semantic))throw new InvalidDataException("Protected VM opcode table is duplicated or invalid.");
            }

            var methodCount = reader.ReadInt32();
            if (methodCount is < 0 or > 10000)
                throw new InvalidOperationException("Protected VM method count is invalid.");
            var methods = new Dictionary<int, VmMethod>(methodCount);
            for (var i = 0; i < methodCount; i++)
            {
                var token = reader.ReadInt32();
                var localCount = reader.ReadInt32();
                var instructionCount = reader.ReadInt32();
                if (token==0 || methods.ContainsKey(token) || localCount is < 0 or > 4096 || instructionCount is <= 0 or > 4096 || instructionCount>(source.Length-source.Position)/8)
                    throw new InvalidOperationException("Protected VM record is invalid.");
                var program = new int[instructionCount * 2];
                for (var p = 0; p < program.Length; p++)
                    program[p] = reader.ReadInt32();
                for(var p=0;p<program.Length;p+=2)
                {
                    if(!opcodes.TryGetValue(program[p],out var op))throw new InvalidDataException("Protected VM instruction opcode is invalid.");
                    var operand=program[p+1];
                    if((op is 4 or 5 && (uint)operand>=(uint)localCount) || (op is 21 or 22 or 23 && (uint)operand>=(uint)instructionCount) || (op==3 && operand<0))throw new InvalidDataException("Protected VM instruction operand is invalid.");
                }
                methods[token] = new VmMethod(localCount, program);
            }
            if(source.Position!=source.Length)throw new InvalidDataException("Protected VM vault contains trailing data.");

            _vmOpcodes = opcodes;
            _vmMethods = methods;
        }
    }

    private static byte[] BuildSecret()
    {
        if(MaterialMode()==3)
        {
            var root=BuildLegacyKey();try{return HMACSHA256.HashData(root,BuildSalt);}finally{CryptographicOperations.ZeroMemory(root);}
        }
        if (!UseV9Material)
            return BuildLegacyKey();

        var managed = BuildManagedShare();
        try
        {
            return NativeSecurityBridge.MixBuildMaterial(managed, BuildSalt);
        }
        finally
        {
            CryptographicOperations.ZeroMemory(managed);
        }
    }

    private static byte[] BuildLegacyKey()
    {
        var key = new byte[32];
        BinaryPrimitives.WriteInt32LittleEndian(key.AsSpan(0, 4), K0A() ^ K0B());
        BinaryPrimitives.WriteInt32LittleEndian(key.AsSpan(4, 4), K1A() ^ K1B());
        BinaryPrimitives.WriteInt32LittleEndian(key.AsSpan(8, 4), K2A() ^ K2B());
        BinaryPrimitives.WriteInt32LittleEndian(key.AsSpan(12, 4), K3A() ^ K3B());
        BinaryPrimitives.WriteInt32LittleEndian(key.AsSpan(16, 4), K4A() ^ K4B());
        BinaryPrimitives.WriteInt32LittleEndian(key.AsSpan(20, 4), K5A() ^ K5B());
        BinaryPrimitives.WriteInt32LittleEndian(key.AsSpan(24, 4), K6A() ^ K6B());
        BinaryPrimitives.WriteInt32LittleEndian(key.AsSpan(28, 4), K7A() ^ K7B());
        return key;
    }

    private static byte[] BuildManagedShare()
    {
        var value = new byte[32];
        BinaryPrimitives.WriteInt32LittleEndian(value.AsSpan(0, 4), M0A() ^ M0B());
        BinaryPrimitives.WriteInt32LittleEndian(value.AsSpan(4, 4), M1A() ^ M1B());
        BinaryPrimitives.WriteInt32LittleEndian(value.AsSpan(8, 4), M2A() ^ M2B());
        BinaryPrimitives.WriteInt32LittleEndian(value.AsSpan(12, 4), M3A() ^ M3B());
        BinaryPrimitives.WriteInt32LittleEndian(value.AsSpan(16, 4), M4A() ^ M4B());
        BinaryPrimitives.WriteInt32LittleEndian(value.AsSpan(20, 4), M5A() ^ M5B());
        BinaryPrimitives.WriteInt32LittleEndian(value.AsSpan(24, 4), M6A() ^ M6B());
        BinaryPrimitives.WriteInt32LittleEndian(value.AsSpan(28, 4), M7A() ^ M7B());
        return value;
    }

    private static byte[] BuildSaltBytes()
    {
        if (!UseV9Material && !UseV10Material)
            return new byte[32];
        var value = new byte[32];
        BinaryPrimitives.WriteInt32LittleEndian(value.AsSpan(0, 4), S0A() ^ S0B());
        BinaryPrimitives.WriteInt32LittleEndian(value.AsSpan(4, 4), S1A() ^ S1B());
        BinaryPrimitives.WriteInt32LittleEndian(value.AsSpan(8, 4), S2A() ^ S2B());
        BinaryPrimitives.WriteInt32LittleEndian(value.AsSpan(12, 4), S3A() ^ S3B());
        BinaryPrimitives.WriteInt32LittleEndian(value.AsSpan(16, 4), S4A() ^ S4B());
        BinaryPrimitives.WriteInt32LittleEndian(value.AsSpan(20, 4), S5A() ^ S5B());
        BinaryPrimitives.WriteInt32LittleEndian(value.AsSpan(24, 4), S6A() ^ S6B());
        BinaryPrimitives.WriteInt32LittleEndian(value.AsSpan(28, 4), S7A() ^ S7B());
        return value;
    }

    private static byte[] DeriveContext(ReadOnlySpan<byte> ikm, ReadOnlySpan<byte> salt, string info)
    {
        var prk = HMACSHA256.HashData(salt, ikm);
        var infoBytes = Encoding.UTF8.GetBytes(info);
        try
        {
            var input = new byte[infoBytes.Length + 1];
            infoBytes.CopyTo(input, 0);
            input[^1] = 1;
            var okm = HMACSHA256.HashData(prk, input);
            CryptographicOperations.ZeroMemory(input);
            return okm;
        }
        finally
        {
            CryptographicOperations.ZeroMemory(prk);
            CryptographicOperations.ZeroMemory(infoBytes);
        }
    }

    private static int MaterialMode() => 0;

    private static int K0A() => unchecked((int)0x13579BDF); private static int K0B() => unchecked((int)0x2468ACE0);
    private static int K1A() => unchecked((int)0x10293847); private static int K1B() => unchecked((int)0x56473829);
    private static int K2A() => unchecked((int)0x7F4A7C15); private static int K2B() => unchecked((int)0x6D2B79F5);
    private static int K3A() => unchecked((int)0x31415926); private static int K3B() => unchecked((int)0x27182818);
    private static int K4A() => unchecked((int)0x5A17C3E9); private static int K4B() => unchecked((int)0x4D3B2A19);
    private static int K5A() => unchecked((int)0x6C8E9FA1); private static int K5B() => unchecked((int)0x12B4D6F8);
    private static int K6A() => unchecked((int)0x55AA33CC); private static int K6B() => unchecked((int)0x0F0E0D0C);
    private static int K7A() => unchecked((int)0x7A6B5C4D); private static int K7B() => unchecked((int)0x1A2B3C4D);

    private static int M0A() => 0; private static int M0B() => 0;
    private static int M1A() => 0; private static int M1B() => 0;
    private static int M2A() => 0; private static int M2B() => 0;
    private static int M3A() => 0; private static int M3B() => 0;
    private static int M4A() => 0; private static int M4B() => 0;
    private static int M5A() => 0; private static int M5B() => 0;
    private static int M6A() => 0; private static int M6B() => 0;
    private static int M7A() => 0; private static int M7B() => 0;

    private static int S0A() => 0; private static int S0B() => 0;
    private static int S1A() => 0; private static int S1B() => 0;
    private static int S2A() => 0; private static int S2B() => 0;
    private static int S3A() => 0; private static int S3B() => 0;
    private static int S4A() => 0; private static int S4B() => 0;
    private static int S5A() => 0; private static int S5B() => 0;
    private static int S6A() => 0; private static int S6B() => 0;
    private static int S7A() => 0; private static int S7B() => 0;
}
