# KAGE V2 Lite — 2.0.7

KAGE V2 Lite is a separate, permanently free edition of KAGE. It is not the paid Full distribution.

## Included
- Animation-only reuploading and Studio reference replacement.
- Animation-only Asset Viewer and R6/R15 preview.
- Roblox cookie and Open Cloud API key setup, stored locally using the existing Windows credential-protection layer.
- No Discord OAuth, whitelist, or paid entitlement prompt.
- Shade AI is not included in the Lite interface; it remains disabled.

## Not included
- Sound, mesh, and decal/image reupload workflows.
- Sound, mesh, and decal/image preview workflows.
- Group destination workflows.
- Shade AI assistant and automatic in-app updates; Lite updates are distributed from the website.
- Discord sign-in and whitelist authorization.

## Build
Run `build-lite.bat` on Windows with the .NET 8 SDK. It produces a self-contained x64 test build in `LiteBuild`. This is a development/test build, not a public protected release. Do not publish it as the official website download; the public Lite artifact must go through a dedicated protected release and signing pass.

## Security notes
Roblox credentials remain on the local PC and use the existing Windows credential storage. Never paste a Roblox cookie or API key into a website, Discord message, or support ticket.

This is a local-only free edition. Local feature restrictions are not tamper-proof; a determined user can patch a client they control. Paid-only functionality must remain protected by server-side authorization in the separate Full product.
