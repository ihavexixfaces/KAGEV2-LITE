using System.Collections.Concurrent;
using System.Drawing;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Net.Http.Json;
using System.Security.Cryptography;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
using Kage.Security;
using Kage.Roblox;
using Kage.Core;
using Kage.Bridge;
using Kage.Engine;
using KAGE.Desktop.Updates;
using KAGE.Desktop.Shade;

namespace KAGE.Desktop;

public partial class MainForm : Form
{// Windows API for dragging
    [DllImport("user32.dll")]
    private static extern bool ReleaseCapture();

    [DllImport("user32.dll")]
    private static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

    [DllImport("gdi32.dll")]
    private static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse);

    [DllImport("gdi32.dll")]
    private static extern bool DeleteObject(IntPtr hObject);

    private const int WM_NCLBUTTONDOWN = 0xA1;
    private const int HT_CAPTION = 0x2;
    private const int WM_NCHITTEST = 0x0084;
    private const int HTLEFT = 10;
    private const int HTRIGHT = 11;
    private const int HTTOP = 12;
    private const int HTTOPLEFT = 13;
    private const int HTTOPRIGHT = 14;
    private const int HTBOTTOM = 15;
    private const int HTBOTTOMLEFT = 16;
    private const int HTBOTTOMRIGHT = 17;
    private const int ResizeBorder = 7;

    private WebView2 _webView = null!;
    private bool _closing;
    private bool _dragging;
    private Point _dragCursor;
    private Point _dragForm;
    private CancellationTokenSource _bridgeShutdown = new();
    private readonly CancellationTokenSource _applicationShutdown = new();
    private StudioBridge? _studioBridge;
    private Task? _studioBridgeTask;
    private Task _studioBridgeRestartTask = Task.CompletedTask;
    private int _studioBridgeRestartVersion;
    private KageStudioSession? _studioSession;
    private readonly StudioRunCoordinator _studioRunCoordinator = new();
    private readonly StudioSessionManager _studioSessionManager = new();
    private readonly KageDiscordPresence _discordPresence = new();
    private readonly KageMcpService _kageMcpService;
    private readonly HttpClient _localBridgeClient = new() { BaseAddress = new Uri("http://127.0.0.1:34821") };
    private readonly UpdatedStartupContext _updatedStartupContext;
    private readonly GitHubUpdateClient _updateClient = new();
    private readonly CancellationTokenSource _updateShutdown = new();
    private AvailableUpdate? _availableUpdate;
    private string _updateChangelogSentBuildId = "";
    private bool _updateAppliedNotified;
    private readonly SemaphoreSlim _updateGate = new(1, 1);
    private bool _installingUpdate;
    private bool _shadeSidecarOpen;
    private Form? _shadePopoutWindow;
    private WebView2? _shadePopoutWebView;
    private readonly ShadeClient _shadeClient;
    private CancellationTokenSource? _shadeRequest;
    private static readonly TimeSpan ShadeFirstResponseTimeout = TimeSpan.FromSeconds(75);
    private static readonly TimeSpan ShadeStreamIdleTimeout = TimeSpan.FromSeconds(45);
    private const int TargetWindowWidth = 960;
    private const int TargetWindowHeight = 680;
    private const int MinimumWindowWidth = 760;
    private const int MinimumWindowHeight = 560;
    private readonly ConcurrentDictionary<string, StudioProjectInfo> _canonicalProjectCache = new(StringComparer.Ordinal);
    private readonly ConcurrentDictionary<string, StudioAssetScan> _lastStudioAssetScans = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, StudioProjectInfo> _studioScanProjects = new(StringComparer.OrdinalIgnoreCase);
    private readonly object _studioScanCacheSync = new();
    private readonly ConcurrentDictionary<string, StudioJob> _referenceJobs = new(StringComparer.Ordinal);
    private readonly ConcurrentDictionary<string, string> _jobStudioIds = new(StringComparer.Ordinal);
    private long _studioWorkspaceRequestVersion;
    private StudioProjectInfo? _lastResolvedStudioProject;
    private string _lastStudioWorkspaceErrorSignature = string.Empty;
    private DateTimeOffset _lastStudioWorkspaceErrorAt = DateTimeOffset.MinValue;
    private bool _showWelcomeBackOnLaunch;
    private bool _welcomeBackConsumed;
    private static readonly TimeSpan StudioBridgeRetireTimeout = TimeSpan.FromSeconds(4);
    private bool _readyToPresentRaised;
    private bool _webViewInitializationStarted;
    private bool _webViewRecoveryProfileUsed;
    private int _launchPageIntent;
    private string _detectedWebViewRuntimeVersion = string.Empty;
    private RectangleF? _titleLogoCssBounds;
    private const int EAbortHResult = unchecked((int)0x80004004);
    internal event EventHandler? ReadyToPresent;

    public MainForm(UpdatedStartupContext? updatedStartupContext = null)
    {
        _updatedStartupContext = updatedStartupContext ?? new UpdatedStartupContext(null, null);
        _updateClient.StartupContext = _updatedStartupContext;
        _kageMcpService = new KageMcpService(_studioSessionManager);
        _shadeClient = new ShadeClient();
        _studioSessionManager.Workspace.ScanProgress += OnStudioScanProgress;
        _studioSessionManager.StateChanged += OnStudioConnectionStateChanged;
        _studioSessionManager.Start();
        InitializeComponent();
        SetupWindow();

        FormClosing += (_, _) =>
        {
            _closing = true;
            _securityCountdown?.Dispose();
            try { _securityBlockWindow?.Close(); } catch { }
            _studioSessionManager.StateChanged -= OnStudioConnectionStateChanged;
            _studioSessionManager.Workspace.ScanProgress -= OnStudioScanProgress;
            try { _updateShutdown.Cancel(); } catch { }
            try { _applicationShutdown.Cancel(); } catch { }
            try { _bridgeShutdown.Cancel(); } catch { }
            try { _shadeRequest?.Cancel(); } catch { }
        };
        FormClosed += (_, _) =>
        {
            try { _shadePopoutWindow?.Close(); } catch { }
            // Closing must return immediately; callbacks may still be posting to WebView.
            _ = Task.Run(async () =>
            {
                try { await _studioSessionManager.DisposeAsync(); } catch { }
                _updateClient.Dispose();
                _localBridgeClient.Dispose();
                _shadeClient.Dispose();
                await _discordPresence.DisposeAsync();
            });
        };

        // WebView2 must not initialize from the constructor. With the transparent
        // pre-launch context the form handle is not stable yet, which can make
        // EnsureCoreWebView2Async abort with E_ABORT even when the Runtime exists.
        Shown += (_, _) => BeginInvoke(new Action(() => _ = InitializeWebViewAsync()));
    }

    private void SetupWindow()
    {
        // Professional frameless workspace. The WebView supplies the title bar while
        // WinForms keeps native resizing, maximize/minimize behavior and rounded edges.
        FormBorderStyle = FormBorderStyle.None;
        MaximizeBox = true;
        MinimizeBox = true;
        StartPosition = FormStartPosition.CenterScreen;
        TopMost = true; // Keep KAGE visible above Studio/Discord/etc. without stealing focus.
        ApplyResponsiveWindowBounds();
        MaximumSize = Size.Empty;
        BackColor = Color.FromArgb(5, 5, 5);
        Padding = new Padding(0);
        Resize += (_, _) => ApplyRoundedRegion();
        Shown += (_, _) => ApplyRoundedRegion();
        
        // Keep the window icon embedded in the executable for hardened releases.
        try
        {
            if (EmbeddedWebAssets.TryOpen("Assets/icon.ico", out var iconStream, out _))
            {
                using (iconStream)
                using (var loadedIcon = new Icon(iconStream))
                {
                    Icon = (Icon)loadedIcon.Clone();
                }
            }
        }
        catch
        {
            // Icon load failed; continue without a custom runtime icon.
        }
    }

    private void ApplyResponsiveWindowBounds()
    {
        Rectangle work = Screen.FromControl(this).WorkingArea;
        var usableWidth = Math.Max(420, work.Width - 24);
        var usableHeight = Math.Max(600, work.Height - 24);
        var width = Math.Min(TargetWindowWidth, usableWidth);
        var height = Math.Min(TargetWindowHeight, usableHeight);

        Size = new Size(width, height);
        MinimumSize = new Size(
            Math.Min(MinimumWindowWidth, width),
            Math.Min(MinimumWindowHeight, height));
        StartPosition = FormStartPosition.CenterScreen;
    }

    // Historical V2 fixed-size reference retained only for source-test context:
    // Size = new Size(1220, 780); MinimumSize = new Size(1040, 680);

    private async Task InitializeWebViewAsync()
    {
        if (_webViewInitializationStarted || _closing || IsDisposed)
            return;

        _webViewInitializationStarted = true;
        try
        {
            if (!TryGetInstalledWebView2Runtime(out _detectedWebViewRuntimeVersion))
                throw new InvalidOperationException("Microsoft Edge WebView2 Runtime was not detected.");

            await EnsurePrimaryWebViewReadyAsync();
            if (_closing || IsDisposed || _webView.CoreWebView2 is null)
                return;

            // Keep durable KAGE preferences/history in localStorage; only session-scoped state is reset.
            await _webView.CoreWebView2.ExecuteScriptAsync("sessionStorage.clear();");

            // Release builds hide browser inspection surfaces. Debug builds keep them
            // available so UI development remains practical.
#if DEBUG
            _webView.CoreWebView2.Settings.AreDefaultContextMenusEnabled = true;
            _webView.CoreWebView2.Settings.AreDevToolsEnabled = true;
#else
            _webView.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;
            _webView.CoreWebView2.Settings.AreDevToolsEnabled = false;
#endif
            _webView.CoreWebView2.Settings.AreBrowserAcceleratorKeysEnabled = false;

            // Serve the UI directly from embedded assembly resources. Release builds
            // therefore do not need a readable wwwroot folder beside KAGE.exe.
            _webView.CoreWebView2.AddWebResourceRequestedFilter(
                "https://kage.local/*",
                CoreWebView2WebResourceContext.All);
            _webView.CoreWebView2.WebResourceRequested += (_, args) =>
            {
                try
                {
                    var requestUri = new Uri(args.Request.Uri);
                    if (!EmbeddedWebAssets.TryOpen(requestUri.AbsolutePath, out var stream, out var contentType))
                    {
                        args.Response = _webView.CoreWebView2.Environment.CreateWebResourceResponse(
                            Stream.Null, 404, "Not Found", "Content-Type: text/plain");
                        return;
                    }

                    args.Response = _webView.CoreWebView2.Environment.CreateWebResourceResponse(
                        stream,
                        200,
                        "OK",
                        $"Content-Type: {contentType}\r\nCache-Control: no-store\r\nContent-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' https: data: blob:; media-src 'self' https: blob: data:; connect-src 'self' http://127.0.0.1:34821; object-src 'none'; base-uri 'none'; frame-ancestors 'none'");
                }
                catch
                {
                    args.Response = _webView.CoreWebView2.Environment.CreateWebResourceResponse(
                        Stream.Null, 500, "Internal Error", "Content-Type: text/plain");
                }
            };

            _webView.CoreWebView2.NavigationStarting += (_, args) =>
            {
                if (IsTrustedWebViewSource(args.Uri))
                    return;

                args.Cancel = true;
                TryOpenExternalUri(args.Uri);
            };
            _webView.CoreWebView2.NewWindowRequested += (_, args) =>
            {
                args.Handled = true;
                TryOpenExternalUri(args.Uri);
            };

            // Message handler for JavaScript ↔ C# communication
            _webView.CoreWebView2.WebMessageReceived += WebView_WebMessageReceived;

            AppendDebug($"WebView initialized, handler attached. Runtime={_detectedWebViewRuntimeVersion}; recoveryProfile={_webViewRecoveryProfileUsed}");
            _webView.CoreWebView2.NavigationCompleted += (_, _) =>
            {
                AppendDebug("WebView navigation completed.");
                _ = SendSecurityBlockAsync();
                if (_studioSession is { } session)
                    _ = SendToFrontend("studioBridgeSession", new { token = session.Token, sessionId = session.SessionId, expiresUtc = session.ExpiresUtc });
                _ = SendStudioConnectionStateAsync(_studioSessionManager.Snapshot);
                _ = ProbeShadeAsync();
            };

            // Welcome Back is a process-launch decision. Completing setup later in this
            // same process must enter the workspace directly instead of immediately
            // asking the newly verified user to log back in.
            // Render before potentially blocking OS vault work; support monitoring
            // and the native shutdown dialog remain independent of that work.
            NavigateToAppPage("setup.html");
            var launchPageIntent = Volatile.Read(ref _launchPageIntent);
            var launch = await Task.Run(async () =>
            {
                AccountManager.MigrateLegacyCredentialsIfNeeded();
                var credentials = HasSavedCredentials();
                var valid = credentials;
                if (credentials) StartStudioBridge();
                return (credentials, valid);
            });
            if (_closing || launchPageIntent != Volatile.Read(ref _launchPageIntent)) return;
            var hadCredentialsAtLaunch = launch.credentials;
            var hadValidSessionAtLaunch = launch.valid;
            _showWelcomeBackOnLaunch = false;
            _welcomeBackConsumed = false;
            var needsSetup = !hadCredentialsAtLaunch || !hadValidSessionAtLaunch;

            NavigateToAppPage(needsSetup ? "setup.html" : "index.html");
        }
        catch (OperationCanceledException) when (_applicationShutdown.IsCancellationRequested)
        {
            // Verified blocking owns the shutdown UI; canceled startup is expected.
        }
        catch (Exception ex)
        {
            if (_closing) return;
            AppendDebug($"WebView2 initialization failed: 0x{ex.HResult:X8} {ex.Message}");
            HandleWebViewInitializationFailure(ex);
        }
    }

    private async Task EnsurePrimaryWebViewReadyAsync()
    {
        var primaryDataFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "KAGE",
            "WebView2");
        var recoveryDataFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "KAGE",
            "WebView2-Recovery");

        Directory.CreateDirectory(primaryDataFolder);

        Exception? lastError = null;
        var attempts = new[]
        {
            (Folder: primaryDataFolder, Recovery: false, DelayMs: 0),
            (Folder: primaryDataFolder, Recovery: false, DelayMs: 350),
            (Folder: recoveryDataFolder, Recovery: true, DelayMs: 550)
        };

        foreach (var attempt in attempts)
        {
            if (_closing || IsDisposed)
                throw new OperationCanceledException("KAGE is closing while WebView2 is initializing.");

            if (attempt.DelayMs > 0)
                await Task.Delay(attempt.DelayMs);

            RecreatePrimaryWebViewControl();
            try
            {
                if (attempt.Recovery)
                    Directory.CreateDirectory(attempt.Folder);

                var environment = await CoreWebView2Environment.CreateAsync(userDataFolder: attempt.Folder);
                if (_closing || IsDisposed)
                    throw new OperationCanceledException("KAGE is closing while WebView2 is initializing.");

                await _webView.EnsureCoreWebView2Async(environment);
                _webViewRecoveryProfileUsed = attempt.Recovery;
                return;
            }
            catch (Exception ex) when (IsWebViewInitializationAbort(ex))
            {
                lastError = ex;
                AppendDebug($"WebView2 startup was aborted (0x{ex.HResult:X8}); recreating the control and retrying.");
                DisposePrimaryWebViewControl();
            }
        }

        throw lastError ?? new InvalidOperationException("WebView2 could not be initialized after retrying.");
    }

    private void RecreatePrimaryWebViewControl()
    {
        DisposePrimaryWebViewControl();
        _webView = new WebView2 { Dock = DockStyle.Fill };
        Controls.Add(_webView);
        _webView.BringToFront();
    }

    private void DisposePrimaryWebViewControl()
    {
        try
        {
            if (_webView is null)
                return;
            Controls.Remove(_webView);
            _webView.Dispose();
        }
        catch
        {
            // A failed WebView initialization can leave a half-created native control.
            // Best effort cleanup is enough before the next recreated attempt.
        }
    }

    private static bool TryGetInstalledWebView2Runtime(out string version)
    {
        version = string.Empty;
        try
        {
            version = CoreWebView2Environment.GetAvailableBrowserVersionString() ?? string.Empty;
            return !string.IsNullOrWhiteSpace(version);
        }
        catch
        {
            return false;
        }
    }

    private static bool IsWebViewInitializationAbort(Exception exception)
    {
        for (Exception? current = exception; current is not null; current = current.InnerException)
        {
            if (current.HResult == EAbortHResult)
                return true;
        }
        return false;
    }

    private void HandleWebViewInitializationFailure(Exception ex)
    {
        if (_closing || IsDisposed)
            return;

        var runtimeInstalled = TryGetInstalledWebView2Runtime(out var runtimeVersion);
        if (!runtimeInstalled)
        {
            MessageBox.Show(
                "Microsoft Edge WebView2 Runtime was not detected.\n\nInstall or repair the Evergreen WebView2 Runtime, then reopen KAGE.",
                "KAGE WebView2",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            Close();
            return;
        }

        var aborted = IsWebViewInitializationAbort(ex);
        var detail = aborted
            ? "WebView2 initialization was aborted even though the Runtime is installed. KAGE already recreated the browser control and retried with a clean recovery profile."
            : "WebView2 Runtime is installed, but its browser environment could not start.";

        var result = MessageBox.Show(
            $"{detail}\n\nRuntime: {runtimeVersion}\nError: 0x{ex.HResult:X8} ({ex.Message})\n\nPress Retry to initialize KAGE again, or Cancel to close.",
            "KAGE WebView2 startup",
            MessageBoxButtons.RetryCancel,
            MessageBoxIcon.Error);

        if (result == DialogResult.Retry && !_closing && !IsDisposed)
        {
            _webViewInitializationStarted = false;
            BeginInvoke(new Action(() => _ = InitializeWebViewAsync()));
            return;
        }

        Close();
    }

    private void SignalReadyToPresent()
    {
        if (_readyToPresentRaised || IsDisposed) return;
        _readyToPresentRaised = true;
        ReadyToPresent?.Invoke(this, EventArgs.Empty);
    }

    private void NavigateToAppPage(string page)
    {
        if (_webView?.CoreWebView2 is null)
            return;

        var safePage = page is "setup.html" ? "setup.html" : "index.html";
        var nonce = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        _webView.CoreWebView2.Navigate($"https://kage.local/{safePage}?build={UpdateBuildInfo.BuildId}&nocache={nonce}");
    }

    private void StartStudioBridge()
    {
        if (_studioBridge != null ||
            _applicationShutdown.IsCancellationRequested ||
            !AccountManager.TryGetActiveCredentials(out var cookie, out var apiKey, out _))
            return;

        var session = GetOrCreateStudioSession();
        var roblox = new RobloxOpenCloudClient(apiKey, cookie);
        var engine = new AnimationReuploadEngine(roblox, 96);
        engine.ResultCompleted += OnReuploadResultCompleted;
        _studioBridge = new StudioBridge(session, 34821, engine, roblox, _studioRunCoordinator, _bridgeShutdown.Token);
        _kageMcpService.SetReuploadProgressProvider(_studioBridge.GetJobProgress);
        _studioBridgeTask = _studioBridge.RunAsync();
        _ = ObserveStudioBridgeTaskAsync(_studioBridgeTask);
    }

    private async Task ObserveStudioBridgeTaskAsync(Task bridgeTask)
    {
        try
        {
            await bridgeTask.ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            // Normal during a credential/session restart or application shutdown.
        }
        catch (Exception ex)
        {
            AppendDebug($"Studio bridge stopped: {ex.Message}");
        }
    }

    private void OnReuploadResultCompleted(StudioJob job, AnimationResult result)
    {
        _discordPresence.ReportReupload(job.Completed, job.Total);
        _ = SendToFrontend("reuploadAssetResult", new
        {
            jobId = job.Id,
            assetType = job.Request.NormalizedAssetType,
            assetName = job.GetAssetName(result.OldId),
            oldId = result.OldId,
            newId = result.NewId,
            success = result.Success,
            errorCategory = result.ErrorCategory,
            error = result.Error,
            sequence = job.Completed,
            total = job.Total
        });

    }

    private KageStudioSession GetOrCreateStudioSession()
    {
        if (_studioSession is { IsExpired: false } current) return current;
        _studioSession = KageStudioSession.Create(TimeSpan.FromHours(12));
        return _studioSession;
    }

    private string GetOrCreateStudioPairingToken() => GetOrCreateStudioSession().Token;

    private void RestartStudioBridge()
    {
        var retiredShutdown = _bridgeShutdown;
        var retiredTask = _studioBridgeTask;
        var restartVersion = Interlocked.Increment(ref _studioBridgeRestartVersion);

        try { retiredShutdown.Cancel(); } catch { }
        _bridgeShutdown = new CancellationTokenSource();
        _studioBridge = null;
        _studioBridgeTask = null;
        _studioSession = null;

        _studioBridgeRestartTask = RestartStudioBridgeCoreAsync(restartVersion, retiredShutdown, retiredTask);
    }

    private async Task RestartStudioBridgeCoreAsync(int restartVersion, CancellationTokenSource retiredShutdown, Task? retiredTask)
    {
        await RetireStudioBridgeAsync(retiredShutdown, retiredTask).ConfigureAwait(false);
        if (_applicationShutdown.IsCancellationRequested || restartVersion != Volatile.Read(ref _studioBridgeRestartVersion)) return;

        StartStudioBridge();
        if (_studioSession is { } session)
            await SendToFrontend("studioBridgeSession", new { token = session.Token, sessionId = session.SessionId, expiresUtc = session.ExpiresUtc }).ConfigureAwait(false);
    }

    private static async Task RetireStudioBridgeAsync(CancellationTokenSource shutdown, Task? bridgeTask)
    {
        if (bridgeTask is null) return;
        try { await bridgeTask.WaitAsync(StudioBridgeRetireTimeout).ConfigureAwait(false); }
        catch { /* Shutdown was signaled; canceled job workers can finish unwinding. */ }
    }

    private static bool IsTrustedWebViewSource(string? source)
    {
        if (!Uri.TryCreate(source, UriKind.Absolute, out var uri))
            return false;
        return string.Equals(uri.Scheme, "https", StringComparison.OrdinalIgnoreCase) &&
               string.Equals(uri.Host, "kage.local", StringComparison.OrdinalIgnoreCase);
    }

    private static void TryOpenExternalUri(string? source)
    {
        if (!Uri.TryCreate(source, UriKind.Absolute, out var uri))
            return;
        if (uri.Scheme is not ("https" or "http"))
            return;
        try
        {
            Process.Start(new ProcessStartInfo(uri.AbsoluteUri) { UseShellExecute = true });
        }
        catch { }
    }

    private bool HasSavedCredentials()
    {
        try
        {
            return AccountManager.TryGetActiveCredentials(out _, out _, out _);
        }
        catch
        {
            return false;
        }
    }

    private void WebView_WebMessageReceived(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
    {
        try
        {
            if (!IsTrustedWebViewSource(e.Source))
            {
                AppendDebug("Rejected WebView message from an untrusted origin.");
                return;
            }
            // setup.js and app.js post JavaScript objects, so read the WebView2
            // payload as JSON rather than trying to convert it to a string.
            var messageJson = e.WebMessageAsJson;
            AppendDebug("WebView message received.");
            
            var message = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(messageJson);
            AppendDebug($"WebView message deserialized: {message != null}");

            if (message == null) 
            {
                AppendDebug("WebView message was null after deserialize.");
                return;
            }

            string action = message.ContainsKey("type") 
                ? message["type"].GetString() ?? ""
                : message.ContainsKey("action")
                ? message["action"].GetString() ?? ""
                : "";

            AppendDebug($"WebView action: {action}");
            if (HandleSecurityBlockAction(action)) return;
            if (action is "saveCredentials" or "completeSetup" or "resumeSavedSession" or
                "useDifferentAccount" or "logout" or "switchAccount")
                Interlocked.Increment(ref _launchPageIntent);

            switch (action)
            {
                case "uiReady":
                    SignalReadyToPresent();
                    break;

                case "titleLogoRect":
                    CaptureTitleLogoRect(message);
                    break;

                case "dragWindow":
                    Invoke(() => {
                        ReleaseCapture();
                        SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
                    });
                    break;

                case "minimize":
                    AppendDebug("Minimizing window.");
                    Invoke(() => {
                        WindowState = FormWindowState.Minimized;
                        AppendDebug("Window minimized.");
                    });
                    break;

                case "toggleMaximize":
                    Invoke(() =>
                    {
                        WindowState = WindowState == FormWindowState.Maximized
                            ? FormWindowState.Normal
                            : FormWindowState.Maximized;
                        ApplyRoundedRegion();
                    });
                    break;

                case "connectStudio":
                    HandleStudioWorkspaceRequest(message.TryGetValue("assetType", out var connectWorkspaceType) ? connectWorkspaceType.GetString() : null, allowConnect: true);
                    break;

                case "refreshStudioWorkspace":
                    HandleStudioWorkspaceRequest(message.TryGetValue("assetType", out var workspaceType) ? workspaceType.GetString() : null, allowConnect: false);
                    break;

                case "getStudioConnectionState":
                    _ = SendStudioConnectionStateAsync(_studioSessionManager.Snapshot);
                    break;

                case "getStudioJobProgress":
                    if (message.TryGetValue("jobId", out var progressJobId) &&
                        _referenceJobs.TryGetValue(progressJobId.GetString() ?? "", out var progressJob))
                        _ = SendToFrontend("studioJobProgress", progressJob.ToDto());
                    break;

                case "cancelAssetPreview":
                    CancelAssetPreviewRequests();
                    break;

                case "assetPreview":
                    HandleAssetPreviewRequest(message);
                    break;

                case "animationPreview":
                    HandleAnimationPreviewRequest(message);
                    break;

                case "disconnectStudio":
                    HandleStudioDisconnect();
                    break;

                case "getHistoryThumbnail":
                    if (message.TryGetValue("placeId", out var historyPlaceValue) && historyPlaceValue.TryGetInt64(out var historyPlaceId))
                    {
                        var knownUniverseId = message.TryGetValue("universeId", out var historyUniverseValue) && historyUniverseValue.TryGetInt64(out var historyUniverseId)
                            ? historyUniverseId : 0;
                        if (message.TryGetValue("invalidateCache", out var historyInvalidation) && historyInvalidation.ValueKind == JsonValueKind.True)
                            HistoryThumbnails.Invalidate(historyPlaceId);
                        _ = LoadHistoryThumbnailAsync(historyPlaceId, knownUniverseId);
                    }
                    break;

                case "historyThumbnailDecodeFailed":
                    if (message.TryGetValue("placeId", out var rejectedPlaceValue) && rejectedPlaceValue.TryGetInt64(out var rejectedPlaceId))
                    {
                        HistoryThumbnails.Invalidate(rejectedPlaceId);
                        AppendDebug($"History icon {rejectedPlaceId}: WebView could not load/decode the image; cached image cleared for retry.");
                    }
                    break;

                case "discordPresenceArea":
                    if (message.TryGetValue("area", out var rpcArea) && rpcArea.ValueKind == JsonValueKind.String)
                        _discordPresence.SetArea(rpcArea.GetString());
                    break;

                case "shadePrompt":
                    HandleShadePrompt(message);
                    break;

                case "setShadeSidecar":
                    SetShadeSidecar(message.TryGetValue("open", out var shadeOpen) && shadeOpen.ValueKind == JsonValueKind.True);
                    break;

                case "close":
                    AppendDebug("Closing KAGE.");
                    Invoke(() => {
                        Application.Exit();
                    });
                    break;

                case "completeSetup":
                    HandleSetupComplete(message);
                    break;

                case "saveCredentials":
                    HandleSaveCredentials(message);
                    break;

                case "getAccountInfo":
                    SendAccountInfo();
                    break;

                case "resumeSavedSession":
                    HandleResumeSavedSession();
                    break;

                case "useDifferentAccount":
                    BeginInvoke(new Action(() => NavigateToAppPage("setup.html")));
                    break;

                case "getAccounts":
                    SendAccounts();
                    break;

                case "getEligibleGroups":
                    HandleGetEligibleGroups();
                    break;

                case "addAccount":
                    HandleAddAccount(message);
                    break;

                case "switchAccount":
                    HandleSwitchAccount(message);
                    break;

                case "removeAccount":
                    HandleRemoveAccount(message);
                    break;

                case "prepareStudioRun":
                    SecurityRuntime.RequireProtectedOperation("reupload");
                    HandlePrepareStudioRun(message);
                    break;

                case "getStats":
                    SendStats();
                    break;

                

                case "openDiscord":
                    HandleOpenDiscord();
                    break;

                case "getRecentHistory":
                    SendToFrontend("recentHistoryLoaded", new { items = AppDataStore.LoadRecentHistory() });
                    break;

                case "saveRecentHistory":
                    if (message.TryGetValue("history", out var history))
                        AppDataStore.SaveRecentHistory(history);
                    break;

                case "clearRecentHistory":
                    AppDataStore.ClearRecentHistory();
                    break;

                case "checkForUpdates":
                    HandleCheckForUpdates();
                    break;

                case "dismissUpdateChangelog":
                    if (message.TryGetValue("buildId", out var dismissedBuildId) && dismissedBuildId.ValueKind == JsonValueKind.String)
                        UpdateChangelogStore.Current().Dismiss(dismissedBuildId.GetString() ?? "");
                    break;

                case "startUpdate":
                    HandleStartUpdate();
                    break;

                case "openChangelog":
                    HandleOpenChangelog();
                    break;

                case "setAlwaysOnTop":
                    if (message.TryGetValue("enabled", out var alwaysOnTopValue) &&
                        (alwaysOnTopValue.ValueKind == JsonValueKind.True || alwaysOnTopValue.ValueKind == JsonValueKind.False))
                    {
                        TopMost = alwaysOnTopValue.GetBoolean();
                    }
                    break;

                case "logout":
                    HandleLogout();
                    break;

                default:
                    Console.WriteLine($"Unknown action: {action}");
                    break;
            }
        }
        catch (SecurityBlockedException ex)
        {
            AppendDebug($"Security gate blocked {ex.OperationName}: {string.Join(",", ex.State.Codes)}");
            try
            {
                _ = SendToFrontend("studioRunError", new { message = ex.Message });
            }
            catch
            {
                // The WebView may not be available while it is navigating or closing.
            }
        }
        catch (Exception ex)
        {
            AppendDebug($"Message handler error: {ex.Message}");
            try
            {
                SendToFrontend("liteError", new
                {
                    message = "KAGE Lite could not process that request. Please restart the app and try again."
                });
            }
            catch
            {
                // The WebView may not be available while it is navigating or closing.
            }
            Console.WriteLine($"Message handler error: {ex.Message}");
        }
    }

    private void CaptureTitleLogoRect(Dictionary<string, JsonElement> message)
    {
        if (!TryFiniteNumber(message, "x", out var x) || !TryFiniteNumber(message, "y", out var y) ||
            !TryFiniteNumber(message, "width", out var width) || !TryFiniteNumber(message, "height", out var height) ||
            width <= 0f || height <= 0f || width > 256f || height > 256f)
            return;
        _titleLogoCssBounds = new RectangleF(x, y, width, height);
    }

    private static bool TryFiniteNumber(Dictionary<string, JsonElement> message, string key, out float value)
    {
        value = 0f;
        if (!message.TryGetValue(key, out var element) || element.ValueKind != JsonValueKind.Number || !element.TryGetSingle(out value))
            return false;
        return float.IsFinite(value);
    }

    internal Rectangle? GetTitleLogoScreenBounds()
    {
        if (_titleLogoCssBounds is not RectangleF css || IsDisposed || !IsHandleCreated) return null;
        var scale = Math.Max(.5f, DeviceDpi / 96f);
        var client = new Rectangle(
            (int)Math.Round(css.X * scale),
            (int)Math.Round(css.Y * scale),
            Math.Max(1, (int)Math.Round(css.Width * scale)),
            Math.Max(1, (int)Math.Round(css.Height * scale)));
        var screen = PointToScreen(client.Location);
        return new Rectangle(screen, client.Size);
    }

    private async void HandleSaveCredentials(Dictionary<string, JsonElement> message)
    {
        try
        {
            string cookie = message["cookie"].GetString() ?? "";
            string apiKey = message["apiKey"].GetString() ?? "";
            using var client = new RobloxOpenCloudClient(apiKey, cookie);
            await client.TestApiKeyAsync(_applicationShutdown.Token);
            var profile = await client.GetAuthenticatedProfileAsync(_applicationShutdown.Token)
                ?? throw new InvalidOperationException("Roblox did not return an authenticated profile.");

            var existing = AccountManager.LoadState();
            var slot = existing.Accounts.Count == 0 ? 1 : existing.ActiveSlot;
            AccountManager.SaveAccount(slot, cookie, apiKey, profile, makeActive: true);
            RestartStudioBridge();

            await SendToFrontend("credentialsSaved", new
            {
                success = true,
                message = "Connected to Roblox",
                username = profile.DisplayName
            });
            await Task.Delay(250);
            if (!_closing && !IsDisposed) Invoke(() => NavigateToAppPage("index.html"));
        }
        catch (Exception ex)
        {
            await SendToFrontend("credentialsSaveError", new { message = ex.Message });
        }
    }

    private async void HandleSetupComplete(Dictionary<string, JsonElement> message)
    {
        try
        {
            string cookie = message["cookie"].GetString() ?? "";
            string apiKey = message["apiKey"].GetString() ?? "";

            if (!AccountManager.TryGetActiveCredentials(out _, out _, out _))
            {
                using var client = new RobloxOpenCloudClient(apiKey, cookie);
                var profile = client.GetAuthenticatedProfileAsync().GetAwaiter().GetResult();
                if (profile is not null)
                    AccountManager.SaveAccount(1, cookie, apiKey, profile, makeActive: true);
            }
            RestartStudioBridge();
            
            SendToFrontend("setupComplete", new { success = true });
            
            // Reload main page
            Invoke(() =>
            {
                NavigateToAppPage("index.html");
            });
        }
        catch (Exception ex)
        {
            SendToFrontend("setupError", new { message = ex.Message });
        }
    }

    
    private async Task NotifyUpdatedStartupIfNeededAsync()
    {
        if (_updateAppliedNotified || !_updatedStartupContext.WasUpdated)
            return;

        var changelog = UpdateChangelogStore.Current();
        changelog.ConfirmStartup(_updatedStartupContext);
        if (changelog.ConfirmedIdentity() is not { } confirmed ||
            confirmed.BuildId != _updatedStartupContext.ManifestBuildId ||
            !confirmed.PackageSha256.Equals(_updatedStartupContext.PackageSha256, StringComparison.OrdinalIgnoreCase)) return;
        UpdateInstallationState.Save(confirmed.Revision, confirmed.PackageSha256, confirmed.BuildId);
        _updateAppliedNotified = true;
        AppendDebug($"Updated launch confirmed: buildId={UpdateBuildInfo.BuildId}. Sending completion modal.");
        if (changelog.Pending() is null)
            await SendToFrontend("updateApplied", new { success = true, buildId = UpdateBuildInfo.BuildId });
        _ = SelfUpdater.CleanupAfterSuccessfulStartupAsync(_updatedStartupContext);
    }

    private async Task SendPendingUpdateChangelogAsync()
    {
        if (_updateClient.PendingChangelog is { } pending && pending.BuildId != _updateChangelogSentBuildId)
        {
            await SendToFrontend("updateChangelog", new { buildId = pending.BuildId, changelog = pending.Changelog });
            _updateChangelogSentBuildId = pending.BuildId;
        }
    }

    private async void HandleCheckForUpdates()
    {
        _availableUpdate = null;
        await SendToFrontend("updateState", new
        {
            available = false,
            configured = false,
            checkFailed = false,
            message = "KAGE Lite updates are distributed from the official KAGE website."
        });
    }

    private async void HandleStartUpdate()
    {
        if (_installingUpdate) return;
        _installingUpdate = true;
        var gateHeld = false;
        try
        {
            await _updateGate.WaitAsync(_updateShutdown.Token);
            gateHeld = true;
            _availableUpdate = await _updateClient.CheckAsync(_updateShutdown.Token, AppendDebug);
            if (_availableUpdate is null)
            {
                await SendToFrontend("updateState", new { available = false, operationComplete = true, configured = UpdateRepository.IsConfigured });
                return;
            }

            long lastBytes = 0;
            long lastTotal = Math.Max(0, _availableUpdate.Manifest.Size);
            double lastRate = 0;
            double? lastEta = null;

            await SendToFrontend("updateProgress", new
            {
                status = "Preparing update...",
                bytesReceived = 0L,
                totalBytes = lastTotal,
                bytesPerSecond = 0d,
                etaSeconds = (double?)null,
                percent = 0d
            });

            var byteProgress = new Progress<UpdateDownloadProgress>(value =>
            {
                lastBytes = value.BytesReceived;
                lastTotal = value.TotalBytes;
                lastRate = value.BytesPerSecond;
                lastEta = value.EtaSeconds;
                var percent = value.TotalBytes > 0
                    ? Math.Clamp(value.BytesReceived * 100d / value.TotalBytes, 0d, 100d)
                    : 0d;
                _ = SendToFrontend("updateProgress", new
                {
                    status = "Downloading update...",
                    bytesReceived = value.BytesReceived,
                    totalBytes = value.TotalBytes,
                    bytesPerSecond = value.BytesPerSecond,
                    etaSeconds = value.EtaSeconds,
                    percent
                });
            });

            var statusProgress = new Progress<string>(status =>
            {
                var percent = lastTotal > 0
                    ? Math.Clamp(lastBytes * 100d / lastTotal, 0d, 100d)
                    : 0d;
                _ = SendToFrontend("updateProgress", new
                {
                    status,
                    bytesReceived = lastBytes,
                    totalBytes = lastTotal,
                    bytesPerSecond = lastRate,
                    etaSeconds = lastEta,
                    percent
                });
            });

            var packagePath = await _updateClient.DownloadAsync(
                _availableUpdate,
                byteProgress,
                statusProgress,
                _updateShutdown.Token);

            await SendToFrontend("updateProgress", new
            {
                status = "Applying update...",
                bytesReceived = lastTotal,
                totalBytes = lastTotal,
                bytesPerSecond = lastRate,
                etaSeconds = 0d,
                percent = 100d
            });

            var temporaryUpdater = SelfUpdater.CreateTemporaryUpdaterCopy();
            SelfUpdater.LaunchTemporaryUpdater(temporaryUpdater, packagePath, _availableUpdate);
            BeginInvoke((Action)Close);
        }
        catch (OperationCanceledException) when (_updateShutdown.IsCancellationRequested)
        {
            // KAGE is closing or the update was cancelled by shutdown.
        }
        catch (Exception ex)
        {
            AppendDebug($"Update failed: {ex}");
            await SendToFrontend("updateProgress", new
            {
                status = "Update failed",
                error = ex.Message,
                retryable = true
            });
        }
        finally
        {
            if (gateHeld) _updateGate.Release();
            _installingUpdate = false;
        }
    }

    private void HandleOpenChangelog()
    {
        try
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "https://discord.gg/rFnPGUKKNs",
                UseShellExecute = true
            });
        }
        catch (Exception ex)
        {
            _ = SendToFrontend("error", new { message = ex.Message });
        }
    }

    private async void HandleLogout()
    {
        try
        {
            CancelAssetPreviewRequests();
            CancelAnimationPreviewAvatar();
            try { await _studioSessionManager.Workspace.DisconnectAsync(); } catch { }
            AccountManager.ClearAll();
            CredentialStore.Delete("Cookie");
            CredentialStore.Delete("OpenCloudKey");
            foreach (var key in new[] { "DiscordSessionToken", "DiscordSessionExpiresAt", "DiscordClientChallenge", "DiscordUsername", "DiscordId", "DiscordAvatarUrl", "DiscordAvatarDecorationUrl", "DiscordAccessType", "DiscordAccessExpiresAt", "DiscordLinkedRobloxIdentity" })
                CredentialStore.Delete(key);
            RestartStudioBridge();
            
            // Reload setup page
            Invoke(() =>
            {
                NavigateToAppPage("setup.html");
            });
        }
        catch (Exception ex)
        {
            SendToFrontend("logoutError", new { message = ex.Message });
        }
    }

    private async void HandleAddAccount(Dictionary<string, JsonElement> message)
    {
        throw new InvalidOperationException("KAGE Lite uses one local Roblox account. Account management is not included.");
#pragma warning disable CS0162
        SecurityRuntime.RequireProtectedOperation("account-add");
        try
        {
            var slot = AccountManager.GetNextFreeSlot();
            if (slot == 0)
                throw new InvalidOperationException("KAGE supports up to two Roblox accounts. Switch or log out before adding another.");

            var cookie = message.TryGetValue("cookie", out var cookieValue) ? cookieValue.GetString() ?? "" : "";
            var apiKey = message.TryGetValue("apiKey", out var keyValue) ? keyValue.GetString() ?? "" : "";
            if (string.IsNullOrWhiteSpace(cookie) || string.IsNullOrWhiteSpace(apiKey))
                throw new InvalidOperationException("Enter both the Roblox cookie and Open Cloud API key.");

            using var client = new RobloxOpenCloudClient(apiKey, cookie);
            var profile = await client.GetAuthenticatedProfileAsync()
                ?? throw new InvalidOperationException("Roblox did not return an authenticated profile for this account.");

            AccountManager.SaveAccount(slot, cookie, apiKey, profile, makeActive: true);
            RestartStudioBridge();
            await SendToFrontend("accountAdded", new { slot, username = profile.UserName, displayName = profile.DisplayName });
            SendAccounts();
            SendAccountInfo();
        }
        catch (Exception ex)
        {
            CancelAssetPreviewRequestsIfContextChanged();
            CancelAnimationPreviewAvatarIfAccountChanged();
            await SendToFrontend("accountActionError", new { message = ex.Message });
        }
    }

    private async void HandleSwitchAccount(Dictionary<string, JsonElement> message)
    {
        SecurityRuntime.RequireProtectedOperation("account-switch");
        try
        {
            var slot = message.TryGetValue("slot", out var value) && value.TryGetInt32(out var parsed) ? parsed : 0;
            if (!AccountManager.SwitchTo(slot))
                throw new InvalidOperationException("That KAGE account slot is not configured.");

            CancelAssetPreviewRequestsIfContextChanged();
            CancelAnimationPreviewAvatar();
            RestartStudioBridge();
            await SendToFrontend("accountSwitched", new { slot });
            SendAccounts();
            SendAccountInfo();
        }
        catch (Exception ex)
        {
            CancelAssetPreviewRequestsIfContextChanged();
            CancelAnimationPreviewAvatarIfAccountChanged();
            await SendToFrontend("accountActionError", new { message = ex.Message });
        }
    }

    private async void HandleRemoveAccount(Dictionary<string, JsonElement> message)
    {
        SecurityRuntime.RequireProtectedOperation("account-remove");
        var previousActiveSlot = AccountManager.LoadState().ActiveSlot;
        try
        {
            var slot = message.TryGetValue("slot", out var value) && value.TryGetInt32(out var parsed) ? parsed : 0;
            if (!AccountManager.RemoveAccount(slot))
                throw new InvalidOperationException("Only the saved second account can be removed.");

            if (previousActiveSlot != AccountManager.LoadState().ActiveSlot) RestartStudioBridge();
            CancelAssetPreviewRequestsIfContextChanged();
            CancelAnimationPreviewAvatarIfAccountChanged();
            await SendToFrontend("accountRemoved", new { slot });
            SendAccounts();
            if (HasSavedCredentials()) SendAccountInfo();
            else NavigateToAppPage("setup.html");
        }
        catch (Exception ex)
        {
            // A partial credential-store failure can still commit the fallback to
            // slot 1. Keep the running bridge and displayed account in sync with it.
            if (previousActiveSlot != AccountManager.LoadState().ActiveSlot)
            {
                RestartStudioBridge();
                if (HasSavedCredentials()) SendAccountInfo();
                else NavigateToAppPage("setup.html");
            }
            await SendToFrontend("accountActionError", new { message = ex.Message });
            SendAccounts();
        }
    }

    private async void SendAccounts()
    {
        var state = AccountManager.LoadState();
        await SendToFrontend("accountsInfo", new
        {
            activeSlot = state.ActiveSlot,
            accounts = state.Accounts.Select(a => new
            {
                slot = a.Slot,
                id = a.UserId.ToString(),
                username = a.UserName,
                displayName = a.DisplayName,
                avatar = a.AvatarUrl ?? ""
            }).ToArray(),
            maxAccounts = 1
        });
    }

    private async void HandlePrepareStudioRun(Dictionary<string, JsonElement> message)
    {
        try
        {
            var requestedAssetType = message.TryGetValue("assetType", out var typeValue) ? typeValue.GetString() ?? "Animations" : "Animations";
            if (!requestedAssetType.Equals("Animations", StringComparison.OrdinalIgnoreCase) && !requestedAssetType.Equals("Animation", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("KAGE Lite supports animation assets only.");
            var assetType = "Animations";
            var destination = message.TryGetValue("destination", out var destValue) ? destValue.GetString() ?? "user" : "user";
            if (!destination.Equals("user", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("KAGE Lite uploads to the connected Roblox account only.");
            var concurrency = message.TryGetValue("concurrency", out var concurrencyValue) && concurrencyValue.TryGetInt32(out var c) ? c : 96;
            var preserveOriginalAssetNames = message.TryGetValue("legacyAssetNames", out var legacyNameValue) && legacyNameValue.ValueKind == JsonValueKind.True;
            long creatorId;
            string creatorType;

            creatorType = "User";
            var profile = AccountManager.GetActiveProfile();
            if (profile is null && AccountManager.TryGetActiveCredentials(out var cookie, out var apiKey, out var slot))
            {
                using var client = new RobloxOpenCloudClient(apiKey, cookie);
                var liveProfile = await client.GetAuthenticatedProfileAsync();
                if (liveProfile is not null)
                {
                    AccountManager.TryRefreshActiveProfile(slot, cookie, apiKey, liveProfile);
                    profile = AccountManager.GetActiveProfile();
                }
            }
            creatorId = profile?.UserId ?? 0;
            if (creatorId <= 0)
                throw new InvalidOperationException("KAGE could not resolve the active Roblox account.");

            var config = _studioRunCoordinator.Set(assetType, creatorType, creatorId, concurrency);
            _studioSessionManager.ReportWorkspaceActivity("Scanning Project…");
            await SendStudioConnectionStateAsync(_studioSessionManager.Snapshot);

            var project = await _kageMcpService.GetProjectInfoAsync();
            project = await ResolveCanonicalProjectAsync(project, _applicationShutdown.Token);
            _lastResolvedStudioProject = project;
            var scan = await _kageMcpService.ScanAssetReferencesAsync("Animations", _applicationShutdown.Token);
            CacheStudioAssetScan(project, scan);
            _discordPresence.SetProject(project.ProjectName);
            _discordPresence.SetAssetCount(scan.AssetIds.Count);
            if (scan.AssetIds.Count == 0)
                throw new InvalidOperationException($"No {config.AssetType.ToLowerInvariant()} references were found in the open Studio project.");

            // Selection narrows the queued job only. The existing upload engine and
            // reference replacement path receive the same StudioStartRequest shape.
            IReadOnlyList<long> requestedAssetIds = scan.AssetIds;
            if (message.TryGetValue("selectedAssetId", out var selectedValue) &&
                long.TryParse(selectedValue.ToString().Trim('"'), out var selectedId) && selectedId > 0)
            {
                if (!scan.AssetIds.Contains(selectedId))
                    throw new InvalidOperationException("The selected asset is no longer in this Studio project. Refresh Explorer and retry.");
                requestedAssetIds = new[] { selectedId };
            }

            await _studioBridgeRestartTask.WaitAsync(TimeSpan.FromSeconds(6), _applicationShutdown.Token);
            if (_studioBridge is null)
                throw new InvalidOperationException("The local KAGE Studio bridge is still restarting. Wait a moment and retry.");

            var request = new StudioStartRequest(
                project.PlaceId,
                project.UniverseId,
                project.ProjectName,
                config.CreatorType,
                config.CreatorId,
                AssetType: config.AssetType,
                AssetIds: requestedAssetIds.ToList(),
                AssetNames: scan.AssetNames.ToDictionary(x => x.Key, x => x.Value),
                PreserveOriginalAssetNames: preserveOriginalAssetNames);

            using var queueRequest = CreateLocalBridgeRequest(HttpMethod.Post, "/api/studio/jobs");
            queueRequest.Content = JsonContent.Create(request);
            using var queueResponse = await _localBridgeClient.SendAsync(queueRequest);
            var queuePayload = await queueResponse.Content.ReadAsStringAsync();
            if (!queueResponse.IsSuccessStatusCode)
                throw new InvalidOperationException(ReadBridgeError(queuePayload, $"KAGE bridge returned {(int)queueResponse.StatusCode}."));

            var queued = JsonSerializer.Deserialize<StudioStartResponse>(queuePayload, new JsonSerializerOptions { PropertyNameCaseInsensitive = true })
                ?? throw new InvalidOperationException("KAGE bridge did not return a job ID.");

            // The desktop has already validated authorization and queued this
            // job in its own bridge. Start that exact job in-process so a second
            // HTTP binding/serialization step cannot strand it after scanning.
            if (_studioBridge is null || !_studioBridge.TryGetJob(queued.JobId, out var nativeJob) ||
                !_studioBridge.StartQueuedJob(queued.JobId, config.Concurrency))
                throw new InvalidOperationException("The Studio bridge lost the queued job. Reconnect Studio and retry.");
            _discordPresence.BeginReupload(project.ProjectName, nativeJob.Total);
            _referenceJobs[queued.JobId] = nativeJob;
            _jobStudioIds[queued.JobId] = project.StudioId;

            _studioSessionManager.ReportWorkspaceActivity("Complete");
            await SendStudioConnectionStateAsync(_studioSessionManager.Snapshot);
            await SendToFrontend("studioRunPrepared", new
            {
                revision = config.Revision,
                assetType = config.AssetType,
                creatorType = config.CreatorType,
                creatorId = config.CreatorId,
                concurrency = config.Concurrency,
                jobId = queued.JobId,
                total = queued.UniqueAnimations,
                projectName = project.ProjectName,
                placeId = project.PlaceId,
                universeId = project.UniverseId
            });

            _ = MonitorAndApplyStudioMappingsAsync(queued.JobId, config.AssetType, _applicationShutdown.Token);
        }
        catch (Exception ex)
        {
            var friendly = FriendlyStudioError(ex);
            _studioSessionManager.ReportWorkspaceError(friendly);
            await SendStudioConnectionStateAsync(_studioSessionManager.Snapshot);
            await SendToFrontend("studioRunError", new { message = friendly });
        }
    }

    private static string FriendlyStudioError(Exception ex)
    {
        var message = (ex.Message ?? string.Empty).Replace('\r', ' ').Replace('\n', ' ').Trim();
        if (ex is StudioAssetScanException)
            return message.Length > 420 ? message[..420] : message;
        if (message.Contains("launcher was not found", StringComparison.OrdinalIgnoreCase) ||
            message.Contains("mcp.bat", StringComparison.OrdinalIgnoreCase) && message.Contains("not found", StringComparison.OrdinalIgnoreCase))
            return "Roblox Studio MCP could not be found. Update Studio, enable Studio as MCP server, reopen Studio, then retry.";
        if ((message.Contains("unknown tool", StringComparison.OrdinalIgnoreCase) ||
             message.Contains("tool not found", StringComparison.OrdinalIgnoreCase) ||
             message.Contains("tool is not registered", StringComparison.OrdinalIgnoreCase) ||
             message.Contains("does not expose", StringComparison.OrdinalIgnoreCase)) &&
            (message.Contains("list_roblox_studios", StringComparison.OrdinalIgnoreCase) ||
             message.Contains("execute_luau", StringComparison.OrdinalIgnoreCase)))
            return "Roblox Studio MCP accepted the connection but rejected a required tool call. KAGE refreshed the tool catalog and probed it directly; restart Studio only if this repeats.";
        if (message.Contains("No open Roblox Studio", StringComparison.OrdinalIgnoreCase) ||
            message.Contains("could not see an open Studio place", StringComparison.OrdinalIgnoreCase) ||
            message.Contains("no open Studio editor registered", StringComparison.OrdinalIgnoreCase))
            return "KAGE reached Studio MCP but the open place was not registered yet. Keep the project open, confirm Studio shows a connected MCP client, then retry.";
        return message.Length > 300 ? message[..300] : message;
    }

    private static bool SameStudioProject(StudioProjectInfo left, StudioProjectInfo right)
    {
        // StudioMCP can assign a fresh studio_id after its stdio process reconnects.
        // Place/universe identity is the stable project identity; StudioId is only a
        // transport target and must not make Explorer/Viewer forget a valid scan.
        if (left.PlaceId > 0 && right.PlaceId > 0)
            return left.PlaceId == right.PlaceId && left.UniverseId == right.UniverseId;
        return left.StudioId == right.StudioId && left.UniverseId == right.UniverseId;
    }

    private void CacheStudioAssetScan(StudioProjectInfo project, StudioAssetScan scan)
    {
        lock (_studioScanCacheSync)
        {
            _studioScanProjects[scan.AssetType] = project;
            _lastStudioAssetScans[scan.AssetType] = scan;
        }
    }

    private bool TryGetCachedStudioAssetScan(StudioProjectInfo project, string assetType, out StudioAssetScan scan)
    {
        lock (_studioScanCacheSync)
        {
            if (_studioScanProjects.TryGetValue(assetType, out var cachedProject) && SameStudioProject(project, cachedProject) &&
                _lastStudioAssetScans.TryGetValue(assetType, out scan!)) return true;
            scan = null!;
            return false;
        }
    }

    private void RemapCachedStudioAssetScan(string assetType, IReadOnlyDictionary<long, long> mapping, string studioId)
    {
        lock (_studioScanCacheSync)
        {
            // MCP can assign a new studio_id to the same open place after transport recovery.
            // The cache is already scoped by asset type + durable project identity elsewhere;
            // do not reject a valid remap solely because the transient studio_id changed.
            if (mapping.Count == 0 || !_studioScanProjects.TryGetValue(assetType, out var cachedProject) ||
                !_lastStudioAssetScans.TryGetValue(assetType, out var scan)) return;
            var remappedIds = scan.AssetIds.Select(id => mapping.TryGetValue(id, out var replacement) ? replacement : id)
                .Where(id => id > 0).Distinct().ToArray();
            var names = scan.AssetNames.ToDictionary(pair => pair.Key, pair => pair.Value, StringComparer.Ordinal);
            var locations = scan.AssetLocations.ToDictionary(pair => pair.Key, pair => pair.Value, StringComparer.Ordinal);
            foreach (var pair in mapping)
            {
                var oldKey = pair.Key.ToString();
                var newKey = pair.Value.ToString();
                if (names.Remove(oldKey, out var name)) names[newKey] = name;
                if (locations.Remove(oldKey, out var location)) locations[newKey] = location;
            }
            _lastStudioAssetScans[assetType] = new StudioAssetScan(scan.AssetType, remappedIds, names, locations);
        }
    }

    private async Task SendStudioWorkspaceSnapshotAsync(StudioProjectInfo project, StudioAssetScan scan)
    {
        if (!TryGetStudioWorkspacePresentationProject(project, out project)) return;
        var tree = StudioMcpWorkspaceService.DeriveExplorerTree(scan);
        await SendToFrontend("studioWorkspaceSnapshot", new
        {
            assetType = scan.AssetType,
            project = new { studioId = project.StudioId, name = project.ProjectName, placeId = project.PlaceId, universeId = project.UniverseId },
            tree = tree.Select(node => new { name = node.Name, className = node.ClassName, depth = node.Depth }).ToArray(),
            animations = scan.AssetIds.Select(id => new
            {
                id = id.ToString(),
                name = scan.AssetNames.TryGetValue(id.ToString(), out var name) ? name : $"{scan.AssetType.TrimEnd('s')} {id}",
                location = scan.AssetLocations.TryGetValue(id.ToString(), out var location) ? location : string.Empty
            }).ToArray()
        }).ConfigureAwait(false);
    }

    private async Task RefreshStudioWorkspaceAfterReferenceUpdateAsync(
        string assetType,
        IReadOnlyDictionary<long, long> mapping,
        StudioProjectInfo expectedProject,
        CancellationToken cancellationToken)
    {
        // Make the already-visible Explorer and Animation Preview catalog reflect the
        // verified mapping immediately; a fresh Studio scan below then reconciles it.
        var project = _studioSessionManager.Workspace.Project;
        if (project is null || !SameStudioProject(project, expectedProject)) return;
        var requestVersion = Interlocked.Increment(ref _studioWorkspaceRequestVersion);
        RemapCachedStudioAssetScan(assetType, mapping, expectedProject.StudioId);
        if (project is not null && SameStudioProject(project, expectedProject) && TryGetCachedStudioAssetScan(project, assetType, out var remapped))
            await SendStudioWorkspaceSnapshotAsync(project, remapped).ConfigureAwait(false);

        // Reconciliation is best-effort and must never hold the completion modal open.
        // It runs after final verification and has its own bounded lifetime.
        _ = Task.Run(async () =>
        {
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(_applicationShutdown.Token);
            timeout.CancelAfter(TimeSpan.FromSeconds(30));
            try
            {
                var fresh = await _kageMcpService.ScanAssetReferencesAsync(assetType, timeout.Token).ConfigureAwait(false);
                if (_applicationShutdown.IsCancellationRequested || requestVersion != Volatile.Read(ref _studioWorkspaceRequestVersion)) return;
                var currentProject = await _studioSessionManager.Workspace.ReadProjectInfoAsync(timeout.Token).ConfigureAwait(false);
                if (!SameStudioProject(expectedProject, currentProject) || requestVersion != Volatile.Read(ref _studioWorkspaceRequestVersion)) return;
                CacheStudioAssetScan(currentProject, fresh);
                await SendStudioWorkspaceSnapshotAsync(currentProject, fresh).ConfigureAwait(false);
            }
            catch (OperationCanceledException) { }
            catch (Exception ex)
            {
                AppendDebug($"Post-reference workspace refresh skipped: {ex.Message}");
            }
        }, CancellationToken.None);
    }

    private HttpRequestMessage CreateLocalBridgeRequest(HttpMethod method, string path)
    {
        if (_studioSession is { IsExpired: true }) RestartStudioBridge();
        var session = GetOrCreateStudioSession();
        var request = new HttpRequestMessage(method, path);
        request.Headers.TryAddWithoutValidation("X-Kage-Token", session.Token);
        request.Headers.TryAddWithoutValidation("X-Kage-Session", session.SessionId);
        request.Headers.TryAddWithoutValidation("X-Kage-Request-Id", Guid.NewGuid().ToString());
        return request;
    }

    private static string ReadBridgeError(string payload, string fallback)
    {
        try
        {
            using var doc = JsonDocument.Parse(payload);
            if (doc.RootElement.TryGetProperty("error", out var error) && error.ValueKind == JsonValueKind.String)
                return error.GetString() ?? fallback;
        }
        catch { }
        return fallback;
    }

    private async Task MonitorAndApplyStudioMappingsAsync(string jobId, string assetType, CancellationToken cancellationToken)
    {
        if (!_referenceJobs.TryGetValue(jobId, out var job)) return;
        var liveChanged = 0;
        var logged = new HashSet<string>(StringComparer.Ordinal);
        string ChangeKey(StudioReferenceChange change) => $"{change.OldId}:{change.NewId}:{change.Location}:{change.Kind}:{change.Count}";
        var expectedProject = new StudioProjectInfo(_jobStudioIds[jobId], job.Request.PlaceName,
            job.Request.PlaceId, job.Request.UniverseId, job.Request.CreatorType, job.Request.CreatorId);
        var coordinator = new StudioReferenceUpdateCoordinator(
            async (mapping, ct) =>
            {
                return await _kageMcpService.ApplyReferencesLiveAsync(assetType, mapping, ct, expectedProject).ConfigureAwait(false);
            },
            async (mapping, ct) =>
            {
                _studioSessionManager.ReportWorkspaceActivity("Verifying References…");
                await SendStudioConnectionStateAsync(_studioSessionManager.Snapshot).ConfigureAwait(false);
                return await _kageMcpService.ReplaceReferencesOriginalV2Async(assetType, mapping, ct, expectedProject).ConfigureAwait(false);
            },
            async applied =>
            {
                liveChanged += applied.Changed;
                foreach (var change in applied.Changes) logged.Add(ChangeKey(change));
                RemapCachedStudioAssetScan(assetType, applied.Changes.GroupBy(change => change.OldId).ToDictionary(group => group.Key, group => group.Last().NewId), _jobStudioIds[jobId]);
                await SendToFrontend("studioReferencesProgress", new
                {
                    jobId, changed = applied.Changed, totalChanged = liveChanged, synchronized = liveChanged,
                    changes = applied.Changes.Select(change => new { oldId = change.OldId, newId = change.NewId, location = change.Location, kind = change.Kind, count = change.Count }).ToArray(),
                    failures = applied.Failures.Select(failure => new { oldId = failure.OldId, newId = failure.NewId, location = failure.Location, kind = failure.Kind, reason = failure.Reason }).ToArray()
                }).ConfigureAwait(false);
            });
        try
        {
            var result = await coordinator.RunAsync(job, cancellationToken).ConfigureAwait(false);
            _discordPresence.FinishReupload();
            await RefreshStudioWorkspaceAfterReferenceUpdateAsync(assetType, job.Mapping, expectedProject, cancellationToken).ConfigureAwait(false);
            _studioSessionManager.ReportWorkspaceActivity("Complete");
            await SendStudioConnectionStateAsync(_studioSessionManager.Snapshot).ConfigureAwait(false);
            try
            {
                var accountName = AccountManager.GetActiveProfile()?.UserName ?? "the active Roblox account";
                await _studioSessionManager.Workspace.WriteCompletionOutputAsync(expectedProject, accountName, cancellationToken).ConfigureAwait(false);
            }
            catch (Exception outputError) when (!cancellationToken.IsCancellationRequested)
            {
                AppendDebug($"Studio completion output could not be written: {outputError.Message}");
            }
            await SendToFrontend("studioReferencesApplied", new
            {
                jobId, changed = result.Changed, mapped = job.Mapping.Count, mappings = job.Mapping.Count, attempts = result.Attempts,
                changes = result.Changes.Where(change => !logged.Contains(ChangeKey(change))).Select(change => new { oldId = change.OldId, newId = change.NewId, location = change.Location, kind = change.Kind, count = change.Count }).ToArray(),
                failures = result.Failures.Select(failure => new { oldId = failure.OldId, newId = failure.NewId, location = failure.Location, kind = failure.Kind, reason = failure.Reason }).ToArray()
            }).ConfigureAwait(false);
        }
        catch (StudioReferenceReplacementException ex) when (!cancellationToken.IsCancellationRequested)
        {
            _studioSessionManager.ReportWorkspaceError(ex.Message);
            await SendStudioConnectionStateAsync(_studioSessionManager.Snapshot).ConfigureAwait(false);
            _discordPresence.FinishReupload();
            await SendToFrontend("studioReferenceUpdateError", new
            {
                jobId, changed = ex.Result.Changed, message = ex.Message,
                changes = ex.Result.Changes.Where(change => !logged.Contains(ChangeKey(change))).Select(change => new { oldId = change.OldId, newId = change.NewId, location = change.Location, kind = change.Kind, count = change.Count }).ToArray(),
                failures = ex.Result.Failures.Select(failure => new { oldId = failure.OldId, newId = failure.NewId, location = failure.Location, kind = failure.Kind, reason = failure.Reason }).ToArray(),
                remainingLocations = ex.Result.RemainingLocations.ToDictionary(pair => pair.Key.ToString(), pair => pair.Value)
            }).ConfigureAwait(false);
        }
        catch (Exception ex) when (!cancellationToken.IsCancellationRequested)
        {
            job.SetReferenceProgress("Failed", liveChanged, job.Mapping.Count, ex.Message);
            _discordPresence.FinishReupload();
            await SendToFrontend("studioReferenceUpdateError", new { jobId, changed = liveChanged, message = FriendlyStudioError(ex) }).ConfigureAwait(false);
        }
        catch (Exception) when (cancellationToken.IsCancellationRequested) { }
    }

    private void ApplyRoundedRegion()
    {
        if (!IsHandleCreated) return;
        if (WindowState == FormWindowState.Maximized)
        {
            Region = null;
            return;
        }

        var regionHandle = CreateRoundRectRgn(0, 0, Width + 1, Height + 1, 24, 24);
        try { Region = System.Drawing.Region.FromHrgn(regionHandle); }
        finally { DeleteObject(regionHandle); }
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == WM_NCHITTEST && WindowState == FormWindowState.Normal)
        {
            base.WndProc(ref m);
            var cursor = PointToClient(Cursor.Position);
            var left = cursor.X <= ResizeBorder;
            var right = cursor.X >= ClientSize.Width - ResizeBorder;
            var top = cursor.Y <= ResizeBorder;
            var bottom = cursor.Y >= ClientSize.Height - ResizeBorder;
            if (left && top) { m.Result = (IntPtr)HTTOPLEFT; return; }
            if (right && top) { m.Result = (IntPtr)HTTOPRIGHT; return; }
            if (left && bottom) { m.Result = (IntPtr)HTBOTTOMLEFT; return; }
            if (right && bottom) { m.Result = (IntPtr)HTBOTTOMRIGHT; return; }
            if (left) { m.Result = (IntPtr)HTLEFT; return; }
            if (right) { m.Result = (IntPtr)HTRIGHT; return; }
            if (top) { m.Result = (IntPtr)HTTOP; return; }
            if (bottom) { m.Result = (IntPtr)HTBOTTOM; return; }
            return;
        }
        base.WndProc(ref m);
    }


    private void SetShadeSidecar(bool open)
    {
        if (InvokeRequired)
        {
            BeginInvoke(() => SetShadeSidecar(open));
            return;
        }

        if (open)
        {
            if (_shadeSidecarOpen && _shadePopoutWindow is { IsDisposed: false })
            {
                _shadePopoutWindow.Activate();
                return;
            }
            _shadeSidecarOpen = true;
            _ = OpenShadePopoutAsync();
            return;
        }

        _shadeSidecarOpen = false;
        if (_shadePopoutWindow is { IsDisposed: false }) _shadePopoutWindow.Close();
    }

    private async Task OpenShadePopoutAsync()
    {
        var panel = new Form
        {
            FormBorderStyle = FormBorderStyle.None,
            StartPosition = FormStartPosition.Manual,
            ShowInTaskbar = true,
            TopMost = TopMost,
            BackColor = Color.FromArgb(12, 12, 15),
            Size = new Size(360, Math.Min(620, Height))
        };
        if (EmbeddedWebAssets.TryOpen("Assets/shade.ico", out var shadeIconStream, out _))
        {
            using (shadeIconStream)
            using (var shadeIcon = new Icon(shadeIconStream))
                panel.Icon = (Icon)shadeIcon.Clone();
        }
        var work = Screen.FromControl(this).WorkingArea;
        panel.Location = new Point(
            Math.Min(Right + 8, work.Right - panel.Width),
            Math.Clamp(Top + (Height - panel.Height) / 2, work.Top, work.Bottom - panel.Height));
        var view = new WebView2 { Dock = DockStyle.Fill };
        panel.Controls.Add(view);
        _shadePopoutWindow = panel;
        _shadePopoutWebView = view;
        panel.FormClosed += (_, _) =>
        {
            _shadeSidecarOpen = false;
            _shadePopoutWindow = null;
            _shadePopoutWebView = null;
        };
        panel.Show(this);

        try
        {
            var environment = _webView?.CoreWebView2?.Environment
                ?? await CoreWebView2Environment.CreateAsync(userDataFolder:
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "KAGE", "WebView2"));
            if (panel.IsDisposed) return;
            await view.EnsureCoreWebView2Async(environment);
            if (panel.IsDisposed) return;
            view.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;
            view.CoreWebView2.Settings.AreDevToolsEnabled = false;
            view.CoreWebView2.Settings.AreBrowserAcceleratorKeysEnabled = false;
            view.CoreWebView2.AddWebResourceRequestedFilter("https://kage.local/*", CoreWebView2WebResourceContext.All);
            view.CoreWebView2.WebResourceRequested += (_, args) =>
            {
                try
                {
                    var requestUri = new Uri(args.Request.Uri);
                    if (!EmbeddedWebAssets.TryOpen(requestUri.AbsolutePath, out var stream, out var contentType))
                    {
                        args.Response = view.CoreWebView2.Environment.CreateWebResourceResponse(
                            Stream.Null, 404, "Not Found", "Content-Type: text/plain");
                        return;
                    }
                    args.Response = view.CoreWebView2.Environment.CreateWebResourceResponse(
                        stream, 200, "OK",
                        $"Content-Type: {contentType}\r\nCache-Control: no-store\r\nContent-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' https: data: blob:; media-src 'self' https: blob: data:; connect-src 'self' http://127.0.0.1:34821; object-src 'none'; base-uri 'none'; frame-ancestors 'none'");
                }
                catch
                {
                    args.Response = view.CoreWebView2.Environment.CreateWebResourceResponse(
                        Stream.Null, 500, "Internal Error", "Content-Type: text/plain");
                }
            };
            view.CoreWebView2.NavigationStarting += (_, args) =>
            {
                if (IsTrustedWebViewSource(args.Uri)) return;
                args.Cancel = true;
                TryOpenExternalUri(args.Uri);
            };
            view.CoreWebView2.NewWindowRequested += (_, args) =>
            {
                args.Handled = true;
                TryOpenExternalUri(args.Uri);
            };
            view.CoreWebView2.WebMessageReceived += (_, args) =>
            {
                if (!IsTrustedWebViewSource(args.Source)) return;
                Dictionary<string, JsonElement>? message;
                try { message = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(args.WebMessageAsJson); }
                catch { return; }
                var action = message is not null && message.TryGetValue("action", out var type) ? type.GetString() : null;
                if (action is "setShadeSidecar" or "closeShadePopout")
                {
                    SetShadeSidecar(false);
                    return;
                }
                if (action == "minimizeShadePopout")
                {
                    panel.WindowState = FormWindowState.Minimized;
                    return;
                }
                if (action == "dragShadeWindow")
                {
                    ReleaseCapture();
                    SendMessage(panel.Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
                    return;
                }
                WebView_WebMessageReceived(view.CoreWebView2, args);
            };
            view.CoreWebView2.NavigationCompleted += (_, _) =>
            {
                if (_studioSession is { } session)
                    _ = SendToFrontend("studioBridgeSession", new { token = session.Token, sessionId = session.SessionId, expiresUtc = session.ExpiresUtc });
                _ = ProbeShadeAsync();
            };
            view.CoreWebView2.Navigate("https://kage.local/index.html?shadePopout=1");
        }
        catch (Exception ex)
        {
            if (!panel.IsDisposed) panel.Close();
            await SendToFrontend("shadeStreamError", new { message = $"Could not open Shade: {ex.Message}" });
        }
    }

    private async void HandleStudioWorkspaceRequest(string? requestedType = null, bool allowConnect = false)
    {
        var requestVersion = Interlocked.Increment(ref _studioWorkspaceRequestVersion);
        try
        {
            var requested = string.IsNullOrWhiteSpace(requestedType) ? "Animations" : requestedType;
            if (!requested.Equals("Animations", StringComparison.OrdinalIgnoreCase) && !requested.Equals("Animation", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("KAGE Lite scans animation references only.");
            StudioProjectInfo project;
            if (allowConnect)
            {
                project = await _studioSessionManager.ConnectByUserAsync(_applicationShutdown.Token);
            }
            else
            {
                if (!_studioSessionManager.Workspace.IsConnected)
                    throw new InvalidOperationException("Connect to Studio first.");
                project = _studioSessionManager.Workspace.Project
                    ?? await _kageMcpService.GetProjectInfoAsync(_applicationShutdown.Token);
            }
            var resolvedProject = await ResolveCanonicalProjectAsync(project, _applicationShutdown.Token);
            if (requestVersion != Volatile.Read(ref _studioWorkspaceRequestVersion)) return;
            _lastResolvedStudioProject = resolvedProject;

            _lastStudioWorkspaceErrorSignature = string.Empty;
            await SendStudioConnectionStateAsync(_studioSessionManager.Snapshot with { Project = resolvedProject, Error = null });

            // Publish the connected project immediately. Explorer used to keep its literal
            // "Connect to Studio first." placeholder until a potentially long asset scan
            // completed, even though the title bar already showed the correct project.
            if (!TryGetCachedStudioAssetScan(resolvedProject, "Animations", out var warmScan))
                warmScan = new StudioAssetScan("Animations", Array.Empty<long>(), new Dictionary<string, string>(), new Dictionary<string, string>());
            await SendStudioWorkspaceSnapshotAsync(resolvedProject, warmScan);

            // Keep the last good Explorer tree visible while a refresh/reconnect scan
            // runs. Sending an empty snapshot here used to make the Explorer appear lost.
            _studioSessionManager.ReportWorkspaceActivity("Scanning Project…");
            await SendStudioConnectionStateAsync(_studioSessionManager.Snapshot);
            try
            {
                var assetType = "Animations";
                var scan = await _kageMcpService.ScanAssetReferencesAsync(assetType, _applicationShutdown.Token);
                if (requestVersion != Volatile.Read(ref _studioWorkspaceRequestVersion)) return;

                CacheStudioAssetScan(resolvedProject, scan);
                _studioSessionManager.ReportWorkspaceActivity("Ready");
                await SendStudioWorkspaceSnapshotAsync(resolvedProject, scan);
            }
            catch (Exception scanError)
            {
                if (requestVersion != Volatile.Read(ref _studioWorkspaceRequestVersion)) return;
                var friendlyScan = FriendlyStudioError(scanError);
                _studioSessionManager.ReportWorkspaceError(friendlyScan);
                await SendStudioWorkspaceErrorAsync(friendlyScan, "scan");
            }
            await SendStudioConnectionStateAsync(_studioSessionManager.Snapshot);
        }
        catch (Exception ex)
        {
            if (requestVersion != Volatile.Read(ref _studioWorkspaceRequestVersion)) return;
            var friendly = FriendlyStudioError(ex);
            await SendStudioConnectionStateAsync(_studioSessionManager.Snapshot with { Error = friendly });
            await SendStudioWorkspaceErrorAsync(friendly, "connection");
        }
    }

    private async void HandleStudioDisconnect()
    {
        try
        {
            CancelAssetPreviewRequests();
            CancelAnimationPreviewAvatar();
            Interlocked.Increment(ref _studioWorkspaceRequestVersion);
            lock (_studioScanCacheSync) { _lastStudioAssetScans.Clear(); _studioScanProjects.Clear(); }
            _lastResolvedStudioProject = null;
            await _studioSessionManager.DisconnectAsync(userInitiated: true);
            await SendToFrontend("studioWorkspaceSnapshot", new { project = (object?)null, tree = Array.Empty<object>(), animations = Array.Empty<object>() });
        }
        catch (Exception ex)
        {
            await SendStudioWorkspaceErrorAsync(FriendlyStudioError(ex), "disconnect");
        }
    }


    private static readonly HttpClient HistoryThumbnailClient = CreateHistoryThumbnailClient();
    private static readonly HistoryThumbnailService HistoryThumbnails = new(HistoryThumbnailClient);
    private static HttpClient CreateHistoryThumbnailClient()
    {
        var client = new HttpClient { Timeout = TimeSpan.FromSeconds(8) };
        client.DefaultRequestHeaders.UserAgent.ParseAdd("KAGE/2.0.7");
        return client;
    }
    private async Task LoadHistoryThumbnailAsync(long placeId, long knownUniverseId = 0)
    {
        HistoryThumbnailService.Result result;
        try { result = await HistoryThumbnails.GetAsync(placeId, knownUniverseId, detail => AppendDebug($"History icon {placeId}: {detail}")).ConfigureAwait(false); }
        catch (Exception ex)
        {
            AppendDebug($"History icon {placeId}: {ex.Message}");
            result = new(string.Empty, "Retry");
        }
        AppendDebug($"History icon {placeId}: {result.State}, transport={(result.ImageUrl.StartsWith("data:", StringComparison.Ordinal) ? "inline" : result.ImageUrl.Length > 0 ? "WebView" : "none")}");
        await SendToFrontend("historyThumbnail", new { placeId, imageUrl = result.ImageUrl, state = result.State }).ConfigureAwait(false);
    }

    private async void HandleShadePrompt(Dictionary<string, JsonElement> message)
    {
        var messages = ParseShadeMessages(message);
        if (messages.Count == 0) return;

        if (_shadeRequest is not null)
        {
            await SendToFrontend("shadeStreamError", new { message = "Shade is already responding." });
            return;
        }

        using var request = CancellationTokenSource.CreateLinkedTokenSource(_applicationShutdown.Token);
        request.CancelAfter(ShadeFirstResponseTimeout);
        _shadeRequest = request;
        try
        {
            await SendToFrontend("shadeStatus", new { state = "thinking", label = "Thinking…" });
            var chatId = message.TryGetValue("chatId", out var chatValue) && chatValue.ValueKind == JsonValueKind.String
                ? chatValue.GetString() ?? string.Empty : string.Empty;
            var userPrompt = messages.LastOrDefault(entry => entry.Role == "user")?.Content ?? string.Empty;
            await SendToFrontend("shadePromptAccepted", new { chatId, prompt = userPrompt });
            await SendToFrontend("shadeStreamStart", new { });

            var runtimeContext = await BuildShadeContextAsync(request.Token);
            var shadeMessages = AttachShadeRuntimeContext(messages, runtimeContext);
            var sawContent = false;
            var sawDone = false;
            await foreach (var item in _shadeClient.StreamChatAsync(shadeMessages, request.Token))
            {
                // Every valid stream activity item, including an SSE heartbeat, resets
                // inactivity. This avoids cancelling a healthy long model generation.
                request.CancelAfter(ShadeStreamIdleTimeout);
                switch (item.Kind)
                {
                    case "heartbeat":
                        break;
                    case "start":
                        await SendToFrontend("shadeStatus", new { state = "streaming", label = "Responding…" });
                        break;
                    case "delta":
                        if (!string.IsNullOrEmpty(item.Text))
                        {
                            sawContent = true;
                            await SendToFrontend("shadeStreamDelta", new { text = item.Text });
                        }
                        break;
                    case "done":
                        if (!sawDone)
                        {
                            sawDone = true;
                            await SendToFrontend("shadeStreamDone", new { });
                        }
                        break;
                    case "error":
                        throw new ShadeServiceException(string.IsNullOrWhiteSpace(item.Error) ? "Shade returned a streaming error." : item.Error);
                }
            }

            // A few proxies close a healthy SSE body after the final delta without
            // forwarding the terminal event. Complete that reply instead of leaving
            // the WebView permanently marked as in-flight.
            if (!sawDone && sawContent)
            {
                sawDone = true;
                await SendToFrontend("shadeStreamDone", new { });
            }
            if (!sawDone && !sawContent)
                throw new ShadeServiceException("Shade ended the response before returning a message.");

            request.CancelAfter(Timeout.InfiniteTimeSpan);
            await SendToFrontend("shadeStatus", new { state = "online", label = "Online" });
        }
        catch (OperationCanceledException) when (!_applicationShutdown.IsCancellationRequested)
        {
            await SendToFrontend("shadeStreamError", new { message = "Shade timed out. Try again." });
            await SendToFrontend("shadeStatus", new { state = "offline", label = "Unavailable" });
        }
        catch (OperationCanceledException)
        {
            await SendToFrontend("shadeStreamError", new { message = "Shade request cancelled." });
            await SendToFrontend("shadeStatus", new { state = "offline", label = "Cancelled" });
        }
        catch (ShadeAuthConfigurationException ex)
        {
            await SendToFrontend("shadeStreamError", new { message = ex.Message });
            await SendToFrontend("shadeStatus", new { state = "offline", label = "Unavailable" });
        }
        catch (ShadeAuthException ex)
        {
            await SendToFrontend("shadeStreamError", new { message = ex.Message });
            await SendToFrontend("shadeStatus", new { state = "setup", label = "Authorization required" });
        }
        catch (Exception ex)
        {
            await SendToFrontend("shadeStreamError", new { message = ex.Message });
            await SendToFrontend("shadeStatus", new { state = "offline", label = "Unavailable" });
        }
        finally
        {
            _shadeRequest = null;
        }
    }


    private static IReadOnlyList<ShadeMessage> AttachShadeRuntimeContext(IReadOnlyList<ShadeMessage> messages, string runtimeContext)
    {
        // Shade Worker v1.19 accepts only user/assistant roles and injects its own
        // system prompt. Keep KAGE's runtime identity/project context attached to
        // the newest user message instead of sending an invalid system-role entry.
        var output = messages.ToList();
        for (var index = output.Count - 1; index >= 0; index--)
        {
            if (!string.Equals(output[index].Role, "user", StringComparison.OrdinalIgnoreCase)) continue;
            var original = output[index].Content;
            var merged = $"{runtimeContext.Trim()}\n\nUser message:\n{original}";
            if (merged.Length > 11800) merged = merged[..11800];
            output[index] = new ShadeMessage("user", merged);
            return output;
        }

        return output;
    }

    private Task<string> BuildShadeContextAsync(CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();
        var discordUsername = CredentialStore.TryRead("DiscordUsername", out var savedDiscord) ? savedDiscord : string.Empty;
        var discordId = CredentialStore.TryRead("DiscordId", out var savedDiscordId) ? savedDiscordId : string.Empty;
        var profile = AccountManager.GetActiveProfile();
        var snapshotProject = _studioSessionManager.Snapshot.Project;
        StudioProjectInfo? project = _lastResolvedStudioProject;

        if (snapshotProject is not null)
        {
            var cacheKey = $"{snapshotProject.PlaceId}:{snapshotProject.UniverseId}";
            if (_canonicalProjectCache.TryGetValue(cacheKey, out var cached))
                project = cached;
            else if (project is null ||
                     project.PlaceId != snapshotProject.PlaceId ||
                     project.UniverseId != snapshotProject.UniverseId)
                project = snapshotProject;
        }

        var context = $"""
You are Shade inside KAGE V2. Give current KAGE V2 instructions only. Never tell the user to paste a bootstrap script or use the Command Bar; KAGE uses its Studio connection workflow now.
Signed-in Discord user: {discordUsername} (ID {discordId}).
Active Roblox account: {profile?.DisplayName ?? "unknown"} / @{profile?.UserName ?? "unknown"} (ID {profile?.UserId.ToString() ?? "unknown"}).
Current Studio project: {project?.ProjectName ?? "not connected"}; Place ID {project?.PlaceId.ToString() ?? "unknown"}; Universe ID {project?.UniverseId.ToString() ?? "unknown"}.
When useful, reference KAGE tabs with exactly these tokens: [[tab:Home]], [[tab:Reupload]], [[tab:AI Assistant]], [[tab:Settings]], [[tab:Watch]], [[tab:Credits]]. Do not output arbitrary navigation tokens.
""";
        return Task.FromResult(context);
    }

    private async void HandleResumeSavedSession()
    {
        try
        {
            _welcomeBackConsumed = true;
            await SendToFrontend("savedSessionValidated", new { success = true });
            SendAccountInfo();
        }
        catch (Exception ex)
        {
            await SendToFrontend("savedSessionValidated", new { success = false, error = ex.Message });
        }
    }

    private static IReadOnlyList<ShadeMessage> ParseShadeMessages(Dictionary<string, JsonElement> message)
    {
        var output = new List<ShadeMessage>();
        if (message.TryGetValue("messages", out var array) && array.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in array.EnumerateArray().TakeLast(8))
            {
                if (item.ValueKind != JsonValueKind.Object) continue;
                var role = item.TryGetProperty("role", out var roleValue) ? roleValue.GetString()?.Trim().ToLowerInvariant() : null;
                var content = item.TryGetProperty("content", out var contentValue)
                    ? contentValue.GetString()
                    : item.TryGetProperty("text", out var textValue) ? textValue.GetString() : null;
                if (role is not ("user" or "assistant") || string.IsNullOrWhiteSpace(content)) continue;
                var cleaned = content.Trim();
                if (cleaned.Length > 2200) cleaned = cleaned[..2200];
                output.Add(new ShadeMessage(role, cleaned));
            }
        }

        if (output.Count == 0 && message.TryGetValue("prompt", out var promptValue))
        {
            var prompt = promptValue.GetString()?.Trim();
            if (!string.IsNullOrWhiteSpace(prompt))
                output.Add(new ShadeMessage("user", prompt.Length > 4000 ? prompt[..4000] : prompt));
        }
        return output;
    }

    private async Task ProbeShadeAsync()
    {
        try
        {
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(_applicationShutdown.Token);
            timeout.CancelAfter(TimeSpan.FromSeconds(8));
            var health = await _shadeClient.GetHealthAsync(timeout.Token);
            var authorized = await _shadeClient.CheckAuthorizationAsync(timeout.Token);
            await SendToFrontend("shadeStatus", new
            {
                state = authorized ? "online" : "offline",
                label = authorized ? "Online" : "Authorize KAGE in Discord",
                model = health.Model
            });
        }
        catch (ShadeAuthConfigurationException ex)
        {
            await SendToFrontend("shadeStatus", new { state = "offline", label = "Unavailable", detail = ex.Message });
        }
        catch
        {
            await SendToFrontend("shadeStatus", new { state = "offline", label = "Unavailable" });
        }
    }

    private void OnStudioConnectionStateChanged(StudioConnectionSnapshot snapshot)
    {
        CancelAssetPreviewRequestsIfContextChanged();
        if (snapshot.Project is not null) _discordPresence.SetProject(snapshot.Project.ProjectName);
        else if (snapshot.State is StudioConnectionState.StudioNotRunning or StudioConnectionState.ConnectionFailed) _discordPresence.SetProject(null);
        _ = SendStudioConnectionStateAsync(snapshot);
    }

    private Task SendStudioConnectionStateAsync(StudioConnectionSnapshot snapshot)
    {
        var project = snapshot.Project;
        // Status publication must not wait on Roblox metadata: a delayed Connected
        // event could otherwise arrive after an explicit Disconnect.
        if (snapshot.State != _studioSessionManager.Snapshot.State) return Task.CompletedTask;
        if (project is not null && _canonicalProjectCache.TryGetValue($"{project.PlaceId}:{project.UniverseId}", out var canonical))
            project = project with { ProjectName = canonical.ProjectName };

        return SendToFrontend("studioConnectionState", new
        {
            state = snapshot.State.ToString(),
            status = snapshot.StatusText,
            error = snapshot.Error,
            activity = snapshot.Activity,
            activityError = snapshot.ActivityError,
            project = project is null ? null : new
            {
                studioId = project.StudioId,
                name = project.ProjectName,
                placeId = project.PlaceId,
                universeId = project.UniverseId
            }
        });
    }

    private async Task<StudioProjectInfo> ResolveCanonicalProjectAsync(StudioProjectInfo project, CancellationToken ct)
    {
        if (project.PlaceId <= 0 && project.UniverseId <= 0) return project;
        var cacheKey = $"{project.PlaceId}:{project.UniverseId}";
        if (_canonicalProjectCache.TryGetValue(cacheKey, out var cached))
        {
            return project with { ProjectName = cached.ProjectName };
        }

        if (!AccountManager.TryGetActiveCredentials(out var cookie, out var apiKey, out _))
            return project;

        try
        {
            using var roblox = new RobloxOpenCloudClient(apiKey, cookie);
            var canonical = await roblox.ResolveExperienceNameAsync(
                project.PlaceId,
                project.UniverseId,
                project.ProjectName,
                ct).ConfigureAwait(false);
            var resolvedProject = string.IsNullOrWhiteSpace(canonical) || string.Equals(canonical, project.ProjectName, StringComparison.Ordinal)
                ? project
                : project with { ProjectName = canonical };
            _canonicalProjectCache[cacheKey] = resolvedProject;
            return resolvedProject;
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested) { throw; }
        catch
        {
            return project;
        }
    }

    private Task SendStudioWorkspaceErrorAsync(string message, string scope)
    {
        var cleaned = string.IsNullOrWhiteSpace(message) ? "Studio workspace operation failed." : message.Trim();
        var signature = $"{scope}:{cleaned}";
        var now = DateTimeOffset.UtcNow;
        if (string.Equals(signature, _lastStudioWorkspaceErrorSignature, StringComparison.Ordinal) &&
            now - _lastStudioWorkspaceErrorAt < TimeSpan.FromSeconds(8))
            return Task.CompletedTask;

        _lastStudioWorkspaceErrorSignature = signature;
        _lastStudioWorkspaceErrorAt = now;
        return SendToFrontend("studioWorkspaceError", new
        {
            message = cleaned,
            scope,
            eventId = Guid.NewGuid().ToString("N")
        });
    }

    private void HandleOpenDiscord()
    {
        try
        {
            string discordUrl = "https://discord.gg/rFnPGUKKNs";
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
            {
                FileName = discordUrl,
                UseShellExecute = true
            });
        }
        catch (Exception ex)
        {
            SendToFrontend("error", new { message = ex.Message });
        }
    }

    private async void HandleGetEligibleGroups()
    {
        await SendToFrontend("eligibleGroups", new { groups = Array.Empty<object>(), error = "Group destinations are not included in KAGE Lite." });
    }

    private async void SendAccountInfo()
    {
        AppendDebug("SendAccountInfo started.");
        try
        {
            const string discordUsername = "—";
            const string discordId = "";
            var discordAccess = new { AvatarUrl = "", DecorationUrl = "", AccessType = "", AccessExpiresAt = (long?)null };

            RobloxProfile? profile = null;
            string? avatarBodyUrl = null;
            try
            {
                if (AccountManager.TryGetActiveCredentials(out var cookie, out var apiKey, out var slot))
                {
                    using var client = new RobloxOpenCloudClient(apiKey, cookie);
                    profile = await client.GetAuthenticatedProfileAsync();
                    if (profile is not null)
                        avatarBodyUrl = await client.GetAvatarBodyThumbnailAsync(profile.UserId);
                    if (profile is not null && !AccountManager.TryRefreshActiveProfile(slot, cookie, apiKey, profile))
                        profile = null;
                }
            }
            catch (Exception ex)
            {
                AppendDebug($"Roblox profile fetch failed: {ex}");
            }

            profile ??= AccountManager.GetActiveProfile() is { } stored
                ? new RobloxProfile(stored.UserId, stored.UserName, stored.DisplayName, stored.AvatarUrl)
                : null;

            await SendToFrontend("accountInfo", new
            {
                discord = new
                {
                    username = discordUsername, id = discordId,
                    avatar = discordAccess.AvatarUrl,
                    decoration = discordAccess.DecorationUrl,
                    accessType = discordAccess.AccessType,
                    accessExpiresAt = discordAccess.AccessExpiresAt
                },
                roblox = new
                {
                    displayName = profile?.DisplayName ?? "—",
                    username = profile?.UserName ?? "—",
                    id = profile?.UserId.ToString() ?? "",
                    avatar = profile?.AvatarUrl ?? "",
                    bodyAvatar = avatarBodyUrl ?? ""
                },
                linkedRoblox = (object?)null,
                activeSlot = AccountManager.LoadState().ActiveSlot,
                showWelcomeBack = _showWelcomeBackOnLaunch && !_welcomeBackConsumed
            });
        }
        catch (Exception ex)
        {
            AppendDebug($"SendAccountInfo failed: {ex}");
            await SendToFrontend("accountInfo", new
            {
                discord = new { username = "—", id = "", avatar = "", decoration = "", accessType = "", accessExpiresAt = (long?)null },
                roblox = new { displayName = "—", username = "—", id = "", avatar = "", bodyAvatar = "" },
                linkedRoblox = (object?)null,
                activeSlot = 1,
                showWelcomeBack = false
            });
        }
    }

    private static string ReadJsonString(Dictionary<string, JsonElement> values, string name)
    {
        if (!values.TryGetValue(name, out var value))
            return string.Empty;

        return value.ValueKind switch
        {
            JsonValueKind.String => value.GetString() ?? string.Empty,
            JsonValueKind.Number => value.ToString(),
            _ => string.Empty
        };
    }

    private static string DebugLogPath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "KAGE", "Logs", "debug.log");

    private static void AppendDebug(string message)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(DebugLogPath)!);
            File.AppendAllText(DebugLogPath, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {message}{Environment.NewLine}");
        }
        catch { }
        Console.WriteLine(message);
    }

    private void OnStudioScanProgress(StudioScanProgress progress)
    {
        _discordPresence.SetAssetCount(progress.Found);
        _ = SendToFrontend("studioScanProgress", new
        {
            assetType = progress.AssetType,
            processed = progress.Processed,
            total = progress.Total,
            found = progress.Found,
            done = progress.Done
        });
    }

    private void SendStats()
    {
        // TODO: Load real stats from backend
        SendToFrontend("stats", new
        {
            totalAnimations = 0,
            totalAssets = 0,
            successRate = 0.0,
            recentProject = "—"
        });
    }

    private Task SendToFrontend(string eventName, object data)
    {
        if (_closing || IsDisposed || !IsHandleCreated) return Task.CompletedTask;
        var json = JsonSerializer.Serialize(new { @event = eventName, data });
        void Post()
        {
            if (_closing || IsDisposed) return;
            try { _webView?.CoreWebView2?.PostWebMessageAsJson(json); } catch { }
            try { _shadePopoutWebView?.CoreWebView2?.PostWebMessageAsJson(json); } catch { }
        }
        try
        {
            if (InvokeRequired) BeginInvoke((Action)Post);
            else Post();
        }
        catch (InvalidOperationException) { /* The window closed before the UI update. */ }
        return Task.CompletedTask;
    }

    // Title bar drag handlers
    private void TitleBar_MouseDown(object? sender, MouseEventArgs e)
    {
        if (e.Button == MouseButtons.Left)
        {
            _dragging = true;
            _dragCursor = Cursor.Position;
            _dragForm = Location;
        }
    }

    private void TitleBar_MouseMove(object? sender, MouseEventArgs e)
    {
        if (_dragging)
        {
            Point diff = Point.Subtract(Cursor.Position, new Size(_dragCursor));
            Location = Point.Add(_dragForm, new Size(diff));
        }
    }

    private void TitleBar_MouseUp(object? sender, MouseEventArgs e)
    {
        _dragging = false;
    }

    
    private void InitializeComponent()
    {
        SuspendLayout();
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(560, 800);
        Name = "MainForm";
        Text = "KAGE";
        ResumeLayout(false);
    }
}
