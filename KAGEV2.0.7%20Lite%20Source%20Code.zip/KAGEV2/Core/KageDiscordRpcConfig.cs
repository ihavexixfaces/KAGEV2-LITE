namespace Kage.Core;

// Public Discord application ID, NOT a bot token, API secret, or user credential.
// Default is the KAGE Discord application ID; use Setup-KAGE-Discord-RPC.bat if Rich Presence uses a separate Discord application.
internal static class KageDiscordRpcConfig
{
    internal const string ApplicationId = "1512174737097228558";
}
