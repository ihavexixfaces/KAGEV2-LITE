namespace KAGE.Desktop;

// Compatibility shim retained for older call sites while v9 centralizes native work in NativeSecurityBridge.
internal static class BlackoutNativeBridge
{
    internal static bool TryValidateShape(int length, int digitCount, out bool result) =>
        NativeSecurityBridge.TryValidateTokenShape(length, digitCount, out result);
}
