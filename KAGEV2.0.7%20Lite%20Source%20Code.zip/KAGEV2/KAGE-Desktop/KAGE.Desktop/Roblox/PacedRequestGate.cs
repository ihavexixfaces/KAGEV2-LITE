using System.Diagnostics;

namespace Kage.Roblox;

/// <summary>
/// A steady, concurrency-safe request pacer. It does not reduce parallelism of the
/// surrounding pipeline; it only spaces request starts so a fixed-window service limit
/// is not consumed in a short burst followed by a long reset pause.
/// </summary>
public sealed class PacedRequestGate : IDisposable
{
    private readonly SemaphoreSlim _mutex = new(1, 1);
    private readonly TimeSpan _interval;
    private long _nextPermitTimestamp;
    private long _waitCount;
    private long _waitTicks;

    public PacedRequestGate(double requestsPerMinute)
    {
        if (double.IsNaN(requestsPerMinute) || double.IsInfinity(requestsPerMinute) || requestsPerMinute <= 0)
            throw new ArgumentOutOfRangeException(nameof(requestsPerMinute));

        _interval = TimeSpan.FromMinutes(1.0 / requestsPerMinute);
        _nextPermitTimestamp = Stopwatch.GetTimestamp();
    }

    public double RequestsPerMinute => 60.0 / _interval.TotalSeconds;
    public long WaitCount => Interlocked.Read(ref _waitCount);
    public TimeSpan TotalWait => TimeSpan.FromSeconds(
        Interlocked.Read(ref _waitTicks) / (double)Stopwatch.Frequency);

    public async Task WaitAsync(CancellationToken ct)
    {
        await _mutex.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            var now = Stopwatch.GetTimestamp();
            var due = _nextPermitTimestamp;

            if (due > now)
            {
                var ticksToWait = due - now;
                Interlocked.Increment(ref _waitCount);
                Interlocked.Add(ref _waitTicks, ticksToWait);
                var delay = TimeSpan.FromSeconds(ticksToWait / (double)Stopwatch.Frequency);
                if (delay > TimeSpan.Zero)
                    await Task.Delay(delay, ct).ConfigureAwait(false);
                now = Stopwatch.GetTimestamp();
            }

            var intervalTicks = Math.Max(1L, (long)Math.Ceiling(_interval.TotalSeconds * Stopwatch.Frequency));
            _nextPermitTimestamp = Math.Max(now, due) + intervalTicks;
        }
        finally
        {
            _mutex.Release();
        }
    }

    public void Dispose() => _mutex.Dispose();
}
