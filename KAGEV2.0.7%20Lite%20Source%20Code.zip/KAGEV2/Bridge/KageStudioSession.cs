using System.Security.Cryptography;

namespace Kage.Bridge;

public sealed record KageStudioSession(string SessionId, string Token, DateTimeOffset ExpiresUtc)
{
    public static KageStudioSession Create(TimeSpan lifetime)
    {
        var tokenBytes = RandomNumberGenerator.GetBytes(32);
        try
        {
            return new KageStudioSession(
                Guid.NewGuid().ToString("N"),
                Convert.ToHexString(tokenBytes).ToLowerInvariant(),
                DateTimeOffset.UtcNow.Add(lifetime));
        }
        finally
        {
            CryptographicOperations.ZeroMemory(tokenBytes);
        }
    }

    public bool IsExpired => DateTimeOffset.UtcNow >= ExpiresUtc;
}
