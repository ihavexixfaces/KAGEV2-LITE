(() => {
  // Windows KAGE already exposes WebView2 as window.chrome.webview.  Linux KAGE
  // uses Photino's string message bridge.  Keep the UI source identical by
  // adapting Photino to the WebView2-shaped API before app.js/setup.js load.
  if (window.chrome && window.chrome.webview) return;
  if (!window.external || typeof window.external.sendMessage !== 'function') return;

  const listeners = new Set();
  const webview = {
    postMessage(payload) {
      try {
        window.external.sendMessage(typeof payload === 'string' ? payload : JSON.stringify(payload));
      } catch (error) {
        console.error('KAGE native bridge send failed', error);
      }
    },
    addEventListener(name, handler) {
      if (name === 'message' && typeof handler === 'function') listeners.add(handler);
    },
    removeEventListener(name, handler) {
      if (name === 'message') listeners.delete(handler);
    }
  };

  Object.defineProperty(window, 'chrome', {
    configurable: true,
    enumerable: false,
    value: { webview }
  });

  if (typeof window.external.receiveMessage === 'function') {
    window.external.receiveMessage(raw => {
      let data = raw;
      if (typeof raw === 'string') {
        try { data = JSON.parse(raw); } catch { data = raw; }
      }
      for (const listener of [...listeners]) {
        try { listener({ data }); } catch (error) { console.error(error); }
      }
    });
  }
})();
