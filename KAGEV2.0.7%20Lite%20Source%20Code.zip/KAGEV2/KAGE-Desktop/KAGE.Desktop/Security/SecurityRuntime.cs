namespace KAGE.Desktop;

internal sealed class SecurityBlockedException : InvalidOperationException
{
    internal SecurityBlockedException(string operationName, SecurityState state)
        : base(BuildMessage(operationName, state))
    {
        OperationName = operationName;
        State = state;
    }

    internal string OperationName { get; }
    internal SecurityState State { get; }

    private static string BuildMessage(string operationName, SecurityState state)
    {
        var codeText = state.Codes.Count == 0 ? "integrity-check-failed" : string.Join(", ", state.Codes);
        return $"KAGE blocked {operationName} because the installed application failed an integrity check ({codeText}). Reinstall the official release and try again.";
    }
}

internal static class SecurityRuntime
{
    private static readonly SemaphoreSlim Gate = new(1, 1);
    private static SecurityState _current = SecurityState.CleanNow();
    private static bool _initialized;

    internal static SecurityState Current => Volatile.Read(ref _current);

    internal static async Task InitializeAsync(CancellationToken cancellationToken)
    {
        await Gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            if (_initialized)
                return;

            try
            {
                var next = await EvaluateStateAsync(cancellationToken).ConfigureAwait(false);
                WriteStatePreservingTamper(next);
            }
            catch
            {
                Volatile.Write(ref _current, SecurityState.Create(SecurityLevel.Tampered, new[] { "security-runtime-init-failed" }));
            }
            finally
            {
                _initialized = true;
            }
        }
        finally
        {
            Gate.Release();
        }
    }

    internal static async Task ReevaluateAsync(CancellationToken cancellationToken)
    {
        await Gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var previous = Current;
            if (previous.Level == SecurityLevel.Tampered)
                return;

            var next = await EvaluateStateAsync(cancellationToken).ConfigureAwait(false);
            WriteStatePreservingTamper(next);
        }
        finally
        {
            Gate.Release();
        }
    }

    internal static void ReplaceState(SecurityState state)
    {
        ArgumentNullException.ThrowIfNull(state);
        WriteStatePreservingTamper(state);
    }

    internal static void RequireProtectedOperation(string operationName)
    {
        if (string.IsNullOrWhiteSpace(operationName))
            throw new ArgumentException("Operation name is required.", nameof(operationName));

        var state = Current;
        if (state.Level >= SecurityLevel.Suspicious)
            throw new SecurityBlockedException(operationName, state);
    }

    private static async Task<SecurityState> EvaluateStateAsync(CancellationToken cancellationToken)
    {
        var integrity = await IntegrityMonitor.VerifyAsync(AppContext.BaseDirectory, cancellationToken).ConfigureAwait(false);
        var instrumentation = InstrumentationMonitor.Collect();
        var environment = EnvironmentRiskMonitor.Collect();
        var runtimeSignals = instrumentation.Concat(environment).Where(static signal => signal.Observed).ToArray();
        var signalLevel = runtimeSignals.Any(static signal => signal.Confidence == SignalConfidence.High)
            ? SecurityLevel.Suspicious
            : runtimeSignals.Length > 0 ? SecurityLevel.Observed : SecurityLevel.Clean;
        var signalState = SecurityState.Create(signalLevel, runtimeSignals.Select(static signal => signal.Code));
        var integrityState = SecurityState.Create(integrity.Level, integrity.Codes);

        var nativeState = SecurityState.CleanNow();
        var selfTestAvailable = NativeSecurityBridge.TrySelfTest(out var nativePassed);
        var challengeAvailable = NativeSecurityBridge.TryChallengeResponse(out var challengePassed);
#if DEBUG
        if ((selfTestAvailable && !nativePassed) || (challengeAvailable && !challengePassed))
            nativeState = SecurityState.Create(SecurityLevel.Tampered, new[] { "native-core-runtime-check-failed" });
#else
        if (!selfTestAvailable || !nativePassed || !challengeAvailable || !challengePassed)
            nativeState = SecurityState.Create(SecurityLevel.Tampered, new[] { "native-core-runtime-check-failed" });
#endif

        return SecurityState.Merge(integrityState, signalState, nativeState);
    }

    private static void WriteStatePreservingTamper(SecurityState next)
    {
        var previous = Current;
        if (previous.Level == SecurityLevel.Tampered && next.Level != SecurityLevel.Tampered)
            return;
        Volatile.Write(ref _current, next);
    }
}
