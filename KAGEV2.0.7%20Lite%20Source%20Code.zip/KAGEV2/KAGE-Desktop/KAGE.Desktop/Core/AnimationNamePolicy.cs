using System;
using System.Linq;
using System.Globalization;
using System.Net;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace Kage.Core;

public static class AnimationNamePolicy
{
    public const string ModeratedName = "Name moderated KAGE";
    public static string Format(string? originalName)
    {
        var name = new string((originalName ?? "").Where(c => !char.IsControl(c)).ToArray()).Trim();
        if (name.EndsWith(" KAGE", StringComparison.OrdinalIgnoreCase)) name = name[..^5].TrimEnd();
        var compact = Regex.Replace(name, @"\s", "");
        if ((compact.Length > 0 && compact.All(c => c == '#')) ||
            compact.Equals("[ContentDeleted]", StringComparison.OrdinalIgnoreCase) ||
            compact.Equals("ContentDeleted", StringComparison.OrdinalIgnoreCase) ||
            compact.Equals("[Deleted]", StringComparison.OrdinalIgnoreCase) ||
            compact.Equals("[Moderated]", StringComparison.OrdinalIgnoreCase)) return ModeratedName;
        if (string.IsNullOrWhiteSpace(name)) name = "Animation";
        // Reserve the suffix and preserve whole Unicode text elements.
        var end = 0;
        var elements = StringInfo.GetTextElementEnumerator(name);
        while (elements.MoveNext())
        {
            var next = elements.ElementIndex + elements.GetTextElement().Length;
            if (next > 45) break;
            end = next;
        }
        name = name[..end].TrimEnd();
        if (name.Length == 0) name = "Animation";
        return name + " KAGE";
    }

    public static bool IsNameRejection(HttpStatusCode status, string? message)
    {
        if (status is not (HttpStatusCode.BadRequest or HttpStatusCode.UnprocessableEntity) || string.IsNullOrWhiteSpace(message)) return false;
        try
        {
            using var doc = JsonDocument.Parse(message);
            return NameError(doc.RootElement);
        }
        catch (JsonException) { return NameText(message); }
    }

    private static bool NameError(JsonElement value)
    {
        if (value.ValueKind == JsonValueKind.Array) return value.EnumerateArray().Any(NameError);
        if (value.ValueKind == JsonValueKind.String) return NameText(value.GetString() ?? "");
        if (value.ValueKind != JsonValueKind.Object) return false;
        var nameField = value.EnumerateObject().Any(p => p.Name is "field" or "fieldName" && p.Value.ValueKind == JsonValueKind.String &&
            (p.Value.GetString() ?? "").Split('.').Last().Equals("displayName", StringComparison.OrdinalIgnoreCase));
        foreach (var property in value.EnumerateObject())
        {
            if (property.Value.ValueKind is JsonValueKind.Object or JsonValueKind.Array && NameError(property.Value)) return true;
            if (property.Name is not ("message" or "description" or "reason") || property.Value.ValueKind != JsonValueKind.String) continue;
            var text = property.Value.GetString() ?? "";
            if (NameText(text) || (nameField && Regex.IsMatch(text, @"inappropriate|profan|moderat|filter", RegexOptions.IgnoreCase))) return true;
        }
        return false;
    }

    private static bool NameText(string message)
    {
        const string field = @"(?:display[\s_]?name|asset\s+name|animation\s+name|\bname\b)";
        const string rejected = @"(?:inappropriate|profan|moderat|text[\s_-]?filter|filter(?:ed|ing))";
        return Regex.IsMatch(message, field + @"[^\r\n]{0,100}" + rejected + "|" + rejected + @"[^\r\n]{0,60}" + field,
            RegexOptions.IgnoreCase | RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(100));
    }
}
