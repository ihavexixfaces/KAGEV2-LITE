using Kage.Core;

namespace Kage.Bridge;

/// <summary>Turns faults before the engine's worker loop into observable job outcomes.</summary>
internal static class StudioJobExecution
{
    public static async Task RunAsync(StudioJob job, Func<Task> execute, CancellationToken ct)
    {
        try { await execute().ConfigureAwait(false); }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            job.FatalError = "The upload was cancelled.";
            job.FinishedUtc = DateTimeOffset.UtcNow;
            job.Status = "Cancelled";
        }
        catch (Exception ex)
        {
            job.FatalError = ex.Message;
            job.FinishedUtc = DateTimeOffset.UtcNow;
            job.Status = "Failed";
        }
    }
}
