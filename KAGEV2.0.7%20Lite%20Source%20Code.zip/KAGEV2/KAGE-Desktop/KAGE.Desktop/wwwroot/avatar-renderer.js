/* Roblox's rendered avatar geometry, skinned to the neutral rig exported by Studio.
   Textures contain the account's clothing/face; accessories remain meshes, not portraits. */
(() => {
  'use strict';
  const finite = values => values.every(Number.isFinite);
  const key = name => String(name).toLowerCase().replace(/[^a-z0-9]/g,'');
  function parseObj(source) {
    if(typeof source!=='string'||source.length>8*1024*1024)throw new Error('Avatar geometry is too large.');
    const vertices=[],uvs=[],normals=[],groups=[];
    let name='Player',material='',group;
    function current(){if(!group){group={name,material,positions:[],uvs:[],normals:[],hasNormals:true};groups.push(group);}return group;}
    function index(raw,array){const n=Number(raw);if(!Number.isInteger(n)||n===0)throw new Error('Avatar geometry has an invalid index.');const i=n>0?n-1:array.length+n;if(i<0||i>=array.length)throw new Error('Avatar geometry has an invalid index.');return array[i];}
    let triangles=0;
    for(const line of source.split(/\r?\n/)){
      const words=line.trim().split(/\s+/),type=words.shift();
      if(type==='v'||type==='vt'||type==='vn'){
        const size=type==='vt'?2:3,values=words.slice(0,size).map(Number);
        if(values.length!==size||!finite(values))throw new Error('Avatar geometry contains invalid coordinates.');
        const target=type==='v'?vertices:type==='vt'?uvs:normals;target.push(values);
        if(target.length>300000)throw new Error('Avatar geometry is too complex.');
      }else if(type==='g'||type==='o'){name=words.join(' ')||'Player';group=null;}
      else if(type==='usemtl'){material=words.join(' ');group=null;}
      else if(type==='f'){
        if(words.length<3||words.length>64)throw new Error('Avatar geometry contains an invalid face.');
        const corners=words.map(word=>{const [v,vt,vn]=word.split('/');return {p:index(v,vertices),uv:vt?index(vt,uvs):[0,0],n:vn?index(vn,normals):null};});
        for(let i=1;i<corners.length-1;i++){
          if(++triangles>300000)throw new Error('Avatar geometry is too complex.');
          const target=current();
          for(const corner of [corners[0],corners[i],corners[i+1]]){target.positions.push(...corner.p);target.uvs.push(...corner.uv);target.normals.push(...(corner.n||[0,0,0]));if(!corner.n)target.hasNormals=false;}
        }
      }
    }
    const result=groups.filter(g=>g.positions.length);
    if(!result.length)throw new Error('Roblox returned no avatar geometry.');
    return result;
  }
  function parseMtl(source){
    if(typeof source!=='string'||source.length>8*1024*1024)throw new Error('Avatar materials are invalid.');
    const materials=new Map();let current;
    for(const line of source.split(/\r?\n/)){
      const words=line.trim().split(/\s+/),type=words.shift();
      if(type==='newmtl'){current={color:[1,1,1],opacity:1};materials.set(words.join(' '),current);}
      else if(current&&type==='Kd'){const color=words.slice(0,3).map(Number);if(color.length===3&&finite(color))current.color=color.map(v=>Math.max(0,Math.min(1,v)));}
      else if(current&&(type==='d'||type==='Tr')){const value=Number(words[0]);if(Number.isFinite(value))current.opacity=Math.max(0,Math.min(1,type==='Tr'?1-value:value));}
      else if(current&&type==='map_Kd')current.texture=words.at(-1)?.replaceAll('\\','/').split('/').at(-1);
    }
    return materials;
  }
  function matrix(pose){return new THREE.Matrix4().compose(new THREE.Vector3(...pose.slice(0,3)),new THREE.Quaternion(...pose.slice(3)).normalize(),new THREE.Vector3(1,1,1));}
  function bounds(positions){const box=new THREE.Box3();for(let i=0;i<positions.length;i+=3)box.expandByPoint(new THREE.Vector3(positions[i],positions[i+1],positions[i+2]));return box;}
  // Roblox's body texture atlas. Named groups are preferred; UV regions narrow
  // anonymous Player groups to a limb, then neutral pose proximity picks R15 segments.
  const atlas=[['torso',0,296/568,388/916,272/568],['head',132/916,0,256/916,296/568],['leftarm',388/916,284/568,264/916,284/568],['rightarm',652/916,284/568,264/916,284/568],['leftleg',388/916,0,264/916,284/568],['rightleg',652/916,0,264/916,284/568]];
  function region(group){
    const votes=atlas.map(([name,x,y,w,h])=>({name,count:0}));
    for(let i=0;i<group.uvs.length;i+=2){const u=group.uvs[i],v=group.uvs[i+1];atlas.forEach(([,x,y,w,h],j)=>{if(u>x+.0001&&u<x+w-.0001&&v>y+.0001&&v<y+h-.0001)votes[j].count++;});}
    votes.sort((a,b)=>b.count-a.count);return votes[0].count>group.uvs.length*.32?votes[0].name:'';
  }
  const limb = name => key(name).replace(/upper|lower/g,'').replace('hand','arm').replace('foot','leg');
  function bindAvatar(appearance,bindings,textures){
    if(!window.THREE)throw new Error('KAGE could not initialize the 3D avatar renderer.');
    if(!Array.isArray(bindings)||bindings.length<6||bindings.length>150||bindings.some(b=>!b||typeof b.name!=='string'||typeof b.anchor!=='string'||!Array.isArray(b.pose)||b.pose.length!==7||!finite(b.pose)||!Array.isArray(b.size)||b.size.length!==3||!finite(b.size)||b.size.some(v=>v<=0)))throw new Error('Studio returned an invalid avatar rig.');
    const body=bindings.filter(b=>!b.accessory);
    if(body.length<6||body.length>20||new Set(body.map(b=>b.name)).size!==body.length)throw new Error('Studio returned an invalid avatar skeleton.');
    const groups=parseObj(appearance.obj),definitions=parseMtl(appearance.mtl),root=new THREE.Group(),meshes=[],materials=[];
    for(const group of groups){
      const definition=definitions.get(group.material);
      if(group.material&&!definition)throw new Error('An avatar material is missing.');
      if(definition?.texture&&!textures.has(definition.texture))throw new Error('An avatar clothing texture is missing.');
    }
    const bones=body.map(b=>{const bone=new THREE.Bone();bone.name=b.name;bone.matrixAutoUpdate=false;bone.matrix.copy(matrix(b.pose));root.add(bone);return bone;});
    const inverses=body.map(b=>matrix(b.pose).invert());
    const skeleton=new THREE.Skeleton(bones,inverses);
    const indices=new Map(body.map((b,i)=>[b.name,i]));
    const neutral=new THREE.Box3();
    body.forEach(b=>{const transform=matrix(b.pose);for(let i=0;i<8;i++)neutral.expandByPoint(new THREE.Vector3(...b.size.map((v,j)=>(i&(1<<j)?1:-1)*v/2)).applyMatrix4(transform));});
    let bodyGroups=groups.filter(g=>!/^handle/i.test(g.name));
    if(!bodyGroups.length)throw new Error('Roblox returned accessories without an avatar body.');
    const rendered=new THREE.Box3();bodyGroups.forEach(g=>rendered.union(bounds(g.positions)));
    const sourceCenter=rendered.getCenter(new THREE.Vector3()),targetCenter=neutral.getCenter(new THREE.Vector3());
    // Thumbnail OBJ positions are offset above the origin. Geometry stays in
    // Roblox studs, so only translation is removed; the account's scale is retained.
    const offset=targetCenter.sub(sourceCenter);
    function distance(point,index){const p=point.clone().applyMatrix4(inverses[index]),size=body[index].size;return Math.hypot(...size.map((s,j)=>Math.max(0,Math.abs(p.getComponent(j))-s/2)));}
    function nearest(point,candidates){return candidates.map(index=>({index,distance:distance(point,index),center:point.distanceToSquared(new THREE.Vector3(...body[index].pose.slice(0,3)))})).sort((a,b)=>a.distance-b.distance||a.center-b.center);}
    try { for(const group of groups){
      const positions=Float32Array.from(group.positions);for(let i=0;i<positions.length;i+=3){positions[i]+=offset.x;positions[i+1]+=offset.y;positions[i+2]+=offset.z;}
      const center=bounds(positions).getCenter(new THREE.Vector3());
      const normalized=key(group.name),named=body.find(b=>normalized===key(b.name)||normalized===`player${key(b.name)}`);
      const accessoryGroup=/^handle/i.test(group.name);
      let accessory;
      if(accessoryGroup){
        const accessories=bindings.filter(b=>b.accessory);
        accessory=accessories.find(b=>normalized===key(b.name)||normalized===`handle${key(b.name)}`);
        if(!accessory)accessory=accessories.slice().sort((a,b)=>center.distanceToSquared(new THREE.Vector3(...a.pose.slice(0,3)))-center.distanceToSquared(new THREE.Vector3(...b.pose.slice(0,3))))[0];
        if(!accessory||!indices.has(accessory.anchor))throw new Error('An avatar accessory could not be attached to the animation rig.');
      }
      const area=region(group),candidates=body.map((b,i)=>({b,i})).filter(({b})=>!area||limb(b.name)===area).map(({i})=>i);
      const rigid=accessory?indices.get(accessory.anchor):named?indices.get(named.name):nearest(center,candidates.length?candidates:body.map((_,i)=>i))[0].index;
      const skinIndex=new Uint16Array(positions.length/3*4),skinWeight=new Float32Array(skinIndex.length);
      for(let i=0;i<positions.length;i+=3){
        const vertex=i/3*4;
        if(accessory?.layered){
          const closest=nearest(new THREE.Vector3(positions[i],positions[i+1],positions[i+2]),body.map((_,j)=>j)).slice(0,3);
          const weights=closest.map(b=>1/Math.pow(.06+b.distance,2)),sum=weights.reduce((a,b)=>a+b,0);
          closest.forEach((b,j)=>{skinIndex[vertex+j]=b.index;skinWeight[vertex+j]=weights[j]/sum;});
        }else{skinIndex[vertex]=rigid;skinWeight[vertex]=1;}
      }
      const geometry=new THREE.BufferGeometry();
      geometry.setAttribute('position',new THREE.BufferAttribute(positions,3));
      geometry.setAttribute('uv',new THREE.Float32BufferAttribute(group.uvs,2));
      geometry.setAttribute('skinIndex',new THREE.BufferAttribute(skinIndex,4));
      geometry.setAttribute('skinWeight',new THREE.BufferAttribute(skinWeight,4));
      if(group.hasNormals)geometry.setAttribute('normal',new THREE.Float32BufferAttribute(group.normals,3));else geometry.computeVertexNormals();
      const definition=definitions.get(group.material)||{color:[1,1,1],opacity:1};
      const map=definition.texture?textures.get(definition.texture):null;
      const material=new THREE.MeshStandardMaterial({color:new THREE.Color(...definition.color),map:map||null,alphaTest:map ? .05 : 0,roughness:.84,metalness:0,side:THREE.DoubleSide,opacity:definition.opacity,transparent:definition.opacity<1,emissive:new THREE.Color(.045,.045,.052),emissiveIntensity:.72});
      materials.push(material);
      const mesh=new THREE.SkinnedMesh(geometry,material);mesh.name=group.name;mesh.frustumCulled=false;root.add(mesh);mesh.bind(skeleton,new THREE.Matrix4());meshes.push(mesh);
    }}catch(error){meshes.forEach(m=>m.geometry.dispose());materials.forEach(m=>m.dispose());skeleton.dispose();throw error;}
    root.updateMatrixWorld(true);skeleton.update();
    return {root,meshes,center:neutral.getCenter(new THREE.Vector3()),height:neutral.getSize(new THREE.Vector3()).y,
      setPose(poses){for(const {name,pose} of poses){const i=indices.get(name);if(i!==undefined)bones[i].matrix.copy(matrix(pose));}root.updateMatrixWorld(true);skeleton.update();},
      dispose(){meshes.forEach(m=>m.geometry.dispose());materials.forEach(m=>m.dispose());skeleton.dispose();}
    };
  }
  function createRenderer(canvas){
    let renderer,model,version=0,width=0,height=0;
    const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(40,1,.05,200),textures=new Map();
    scene.add(new THREE.HemisphereLight(0xffffff,0x5b5b66,2.0));
    const light=new THREE.DirectionalLight(0xffffff,2.15);light.position.set(-4,8,6);scene.add(light);
    const rim=new THREE.DirectionalLight(0xdde4ff,1.05);rim.position.set(5,3,-5);scene.add(rim);
    function clear(){version++;if(model){scene.remove(model.root);model.dispose();model=null;}new Set(textures.values()).forEach(t=>t.dispose());textures.clear();canvas.classList.add('hidden');canvas.classList.remove('is-visible');if(renderer)renderer.clear();}
    async function load(appearance,bindings){
      clear();const expected=version,loaded=new Map();
      try{
        if(!renderer){renderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true,preserveDrawingBuffer:true});renderer.outputEncoding=THREE.sRGBEncoding;renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));}
        const loader=new THREE.TextureLoader(),uris=new Map();
        for(const [name,uri] of Object.entries(appearance.textures||{})){
          if(!/^data:image\/(png|jpeg|webp|gif);base64,/i.test(uri))throw new Error('Roblox returned an invalid avatar texture.');
          if(!uris.has(uri))uris.set(uri,loader.loadAsync(uri).then(texture=>{texture.encoding=THREE.sRGBEncoding;return texture;}));
          loaded.set(name,await uris.get(uri));
        }
        if(expected!==version){new Set(loaded.values()).forEach(t=>t.dispose());return false;}
        loaded.forEach((texture,name)=>textures.set(name,texture));
        model=bindAvatar(appearance,bindings,textures);scene.add(model.root);
        canvas.classList.remove('hidden');canvas.classList.add('is-visible');return true;
      }catch(error){new Set(loaded.values()).forEach(t=>t.dispose());if(expected!==version)return false;clear();throw error;}
    }
    function draw(parts,poses,view){
      if(!model||!renderer)return;
      model.setPose(parts.map((part,i)=>({name:part.name,pose:poses[i]})));
      const rect=canvas.getBoundingClientRect(),w=Math.max(1,Math.round(rect.width)),h=Math.max(1,Math.round(rect.height));
      if(w!==width||h!==height){renderer.setSize(w,h,false);width=w;height=h;}camera.aspect=w/h;
      const target=model.center,distance=Math.max(model.height*1.3,view.distance*(model.height/5));
      // Roblox avatars face -Z. Orbit the camera around that front-facing view.
      const yaw=view.yaw+Math.PI;
      camera.position.set(target.x+Math.sin(yaw)*Math.cos(view.pitch)*distance,target.y+Math.sin(view.pitch)*distance,target.z+Math.cos(yaw)*Math.cos(view.pitch)*distance);
      camera.lookAt(target);camera.updateProjectionMatrix();renderer.render(scene,camera);
    }
    return {load,clear,draw};
  }
  window.KageAvatarModel={parseObj,parseMtl,bindAvatar,createRenderer};
})();
