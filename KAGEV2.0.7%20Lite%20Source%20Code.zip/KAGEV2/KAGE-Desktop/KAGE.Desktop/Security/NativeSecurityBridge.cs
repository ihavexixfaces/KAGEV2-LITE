using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;

namespace KAGE.Desktop;

internal static class NativeSecurityBridge
{
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    private delegate int SelfTestDelegate();

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    private delegate int ValidateTokenShapeDelegate(int length, int digitCount);

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    private delegate int VerifyDigestDelegate(
        [In] byte[] data,
        int dataLength,
        [In] byte[] expectedDigest,
        int expectedLength);

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    private delegate int ChallengeResponseDelegate(
        [In] byte[] challenge,
        int challengeLength,
        [Out] byte[] output,
        int outputLength);

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    private delegate int MixMaterialDelegate(
        [In] byte[] managedContribution,
        int managedLength,
        [In] byte[] buildSalt,
        int saltLength,
        [Out] byte[] output,
        int outputLength);

    private static readonly object Gate = new();
    private static bool _attempted;
    private static nint _library;
    private static SelfTestDelegate? _selfTest;
    private static ValidateTokenShapeDelegate? _validateTokenShape;
    private static VerifyDigestDelegate? _verifyDigest;
    private static ChallengeResponseDelegate? _challengeResponse;
    private static MixMaterialDelegate? _mixMaterial;

    internal static bool TrySelfTest(out bool passed)
    {
        EnsureLoaded();
        if (_selfTest is null)
        {
            passed = false;
            return false;
        }

        passed = _selfTest() == unchecked((int)0x424C4B39);
        return true;
    }

    internal static bool TryValidateTokenShape(int length, int digitCount, out bool valid)
    {
        EnsureLoaded();
        if (_validateTokenShape is null)
        {
            valid = false;
            return false;
        }

        valid = _validateTokenShape(length, digitCount) == 1;
        return true;
    }

    internal static bool TryVerifyDigest(ReadOnlySpan<byte> data, ReadOnlySpan<byte> expectedDigest, out bool valid)
    {
        if (expectedDigest.Length != 32)
            throw new ArgumentException("Expected SHA-256 digest must be 32 bytes.", nameof(expectedDigest));

        EnsureLoaded();
        if (_verifyDigest is null)
        {
            valid = false;
            return false;
        }

        var dataBytes = data.ToArray();
        var digestBytes = expectedDigest.ToArray();
        try
        {
            valid = _verifyDigest(dataBytes, dataBytes.Length, digestBytes, digestBytes.Length) == 1;
            return true;
        }
        finally
        {
            CryptographicOperations.ZeroMemory(dataBytes);
            CryptographicOperations.ZeroMemory(digestBytes);
        }
    }


    internal static bool TryChallengeResponse(out bool passed)
    {
        EnsureLoaded();
        if (_challengeResponse is null)
        {
            passed = false;
            return false;
        }

        var challenge = RandomNumberGenerator.GetBytes(32);
        var first = new byte[32];
        var second = new byte[32];
        try
        {
            var firstResult = _challengeResponse(challenge, challenge.Length, first, first.Length);
            var secondResult = _challengeResponse(challenge, challenge.Length, second, second.Length);
            passed = firstResult == 1 && secondResult == 1 &&
                     CryptographicOperations.FixedTimeEquals(first, second) &&
                     first.Any(static value => value != 0);
            return true;
        }
        finally
        {
            CryptographicOperations.ZeroMemory(challenge);
            CryptographicOperations.ZeroMemory(first);
            CryptographicOperations.ZeroMemory(second);
        }
    }

    internal static byte[] MixBuildMaterial(ReadOnlySpan<byte> managedContribution, ReadOnlySpan<byte> buildSalt)
    {
        if (managedContribution.Length != 32)
            throw new ArgumentException("Managed build contribution must be 32 bytes.", nameof(managedContribution));
        if (buildSalt.Length is < 16 or > 64)
            throw new ArgumentException("Build salt must be 16 to 64 bytes.", nameof(buildSalt));

        EnsureLoaded();
        if (_mixMaterial is null)
            throw new InvalidOperationException("Blackout native security core is unavailable for build-material mixing.");

        var managedBytes = managedContribution.ToArray();
        var saltBytes = buildSalt.ToArray();
        var output = new byte[32];
        try
        {
            var result = _mixMaterial(managedBytes, managedBytes.Length, saltBytes, saltBytes.Length, output, output.Length);
            if (result != 1)
            {
                CryptographicOperations.ZeroMemory(output);
                throw new InvalidOperationException($"Blackout native material mixer failed with status {result}.");
            }
            return output;
        }
        finally
        {
            CryptographicOperations.ZeroMemory(managedBytes);
            CryptographicOperations.ZeroMemory(saltBytes);
        }
    }

    private static void EnsureLoaded()
    {
        if (_attempted)
            return;

        lock (Gate)
        {
            if (_attempted)
                return;
            _attempted = true;

            try
            {
                var path = MaterializeNativeCore();
                if (path is null)
                    return;

                _library = NativeLibrary.Load(path);
                _selfTest = GetDelegate<SelfTestDelegate>("blackout_selftest");
                _validateTokenShape = GetDelegate<ValidateTokenShapeDelegate>("blackout_validate_token_shape");
                _verifyDigest = GetDelegate<VerifyDigestDelegate>("blackout_verify_digest");
                _challengeResponse = GetDelegate<ChallengeResponseDelegate>("blackout_challenge_response");
                _mixMaterial = GetDelegate<MixMaterialDelegate>("blackout_mix_material");
            }
            catch
            {
                ResetLoadedState();
            }
        }
    }

    private static T GetDelegate<T>(string exportName) where T : Delegate
    {
        var export = NativeLibrary.GetExport(_library, exportName);
        return Marshal.GetDelegateForFunctionPointer<T>(export);
    }

    private static string? MaterializeNativeCore()
    {
        const string logicalPath = "Assets/Blackout.NativeCore.dll";
        var assembly = typeof(NativeSecurityBridge).Assembly;
        Stream? raw = null;
        string? resourceName = null;

        // v9 first looks for the bootstrap resource name that can be loaded before
        // Blackout vault-key reconstruction. v8 protected-resource lookup remains a fallback.
        string? bootstrapName = null;
        foreach (var name in assembly.GetManifestResourceNames())
        {
            if (!name.EndsWith(".Assets.Blackout.NativeCore.dll", StringComparison.OrdinalIgnoreCase))
                continue;
            bootstrapName = name;
            break;
        }
        if (bootstrapName is not null)
        {
            resourceName = bootstrapName;
            raw = assembly.GetManifestResourceStream(bootstrapName);
        }

        if (raw is null)
        {
            var protectedName = BlackoutRuntime.ProtectedResourceName(logicalPath);
            resourceName = protectedName;
            raw = assembly.GetManifestResourceStream(protectedName);
        }

        if (raw is null || resourceName is null)
            return null;

        using (raw)
        using (var decoded = resourceName.StartsWith("kbr_", StringComparison.Ordinal)
                   ? BlackoutRuntime.OpenProtectedResource(raw, resourceName)
                   : raw)
        using (var memory = new MemoryStream())
        {
            decoded.CopyTo(memory);
            var bytes = memory.ToArray();
            try
            {
                if (bytes.Length < 4096)
                    return null;

                var embeddedHash = SHA256.HashData(bytes);
                var hash = Convert.ToHexString(embeddedHash).ToLowerInvariant();
                var folder = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "KAGE", "Native", hash);
                Directory.CreateDirectory(folder);
                var path = Path.Combine(folder, "Blackout.NativeCore.dll");

                var rewrite = true;
                if (File.Exists(path) && new FileInfo(path).Length == bytes.Length)
                {
                    try
                    {
                        var existingBytes = File.ReadAllBytes(path);
                        try
                        {
                            var existingHash = SHA256.HashData(existingBytes);
                            try
                            {
                                rewrite = !CryptographicOperations.FixedTimeEquals(existingHash, embeddedHash);
                            }
                            finally
                            {
                                CryptographicOperations.ZeroMemory(existingHash);
                            }
                        }
                        finally
                        {
                            CryptographicOperations.ZeroMemory(existingBytes);
                        }
                    }
                    catch
                    {
                        rewrite = true;
                    }
                }

                if (rewrite)
                    File.WriteAllBytes(path, bytes);

                CryptographicOperations.ZeroMemory(embeddedHash);
                return path;
            }
            finally
            {
                CryptographicOperations.ZeroMemory(bytes);
            }
        }
    }

    private static void ResetLoadedState()
    {
        _selfTest = null;
        _validateTokenShape = null;
        _verifyDigest = null;
        _challengeResponse = null;
        _mixMaterial = null;
        if (_library != 0)
        {
            try { NativeLibrary.Free(_library); } catch { }
            _library = 0;
        }
    }
}
