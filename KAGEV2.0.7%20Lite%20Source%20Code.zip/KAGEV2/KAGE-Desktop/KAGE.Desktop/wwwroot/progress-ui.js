// Presentation only: uploads report real totals; the renderer fills in each
// intermediate integer on a separate animation frame without inventing results.
class KageProgressView {
  constructor(root = document) {
    this.root = root;
    this.bar = root.getElementById('progress-bar-container');
    this.barFill = null;
    this.barSheen = null;
    this.completedElement = root.getElementById('progress-completed');
    this.totalElement = root.getElementById('progress-total');
    this.percentElement = root.getElementById('progress-percent');
    this.assetInfo = root.getElementById('asset-info');
    this.assetName = root.getElementById('current-asset');
    this.assetId = root.getElementById('asset-id-display');
    this.assetLocation = root.getElementById('asset-location-display');
    this.assetSequence = root.getElementById('asset-sequence-display');
    this.assetOutcome = root.getElementById('asset-outcome');
    this.successElement = root.getElementById('progress-success');
    this.failedElement = root.getElementById('progress-failed');
    this.compactCountElement = root.getElementById('progress-current-count');
    this.reset();
  }

  reset(total = 0) {
    this.stop();
    this.completed = 0;
    this.target = 0;
    this.total = -1;
    this.lastStep = null;
    this.segments = [];
    this.setTotal(total);
    this.setResultCount(this.successElement, 0);
    this.setResultCount(this.failedElement, 0);
    this.setAsset({ currentAsset: 'Waiting for first asset', currentAssetId: '', currentAssetLocation: 'Location pending', currentAssetStatus: '', completed: 0 });
    this.paint();
  }

  stop() {
    if (this.frame != null) cancelAnimationFrame(this.frame);
    this.frame = null;
    this.onSettled = null;
    this.lastStep = null;
    this.bar?.classList.remove('is-running');
    this.completedElement?.classList.remove('is-counting');
    this.compactCountElement?.classList.remove('is-counting');
  }

  setTotal(value) {
    const total = this.count(value);
    if (this.total === total) return;
    this.total = total;
    if (this.totalElement) this.totalElement.textContent = String(total);
    const digits = String(total).length;
    this.completedElement?.style.setProperty('--counter-digits', digits);
    this.totalElement?.style.setProperty('--counter-digits', digits);
    this.bar?.setAttribute('aria-valuemax', String(total));
    if (!this.bar) return;

    // Use one image-backed bar everywhere so the custom progress skin fills from 0% to 100%.
    this.bar.replaceChildren();
    this.bar.classList.add('kage-image-progress');
    const fill = this.root.createElement('div');
    fill.className = 'progress-image-fill';
    const sheen = this.root.createElement('div');
    sheen.className = 'progress-image-sheen';
    fill.appendChild(sheen);
    this.bar.appendChild(fill);
    this.barFill = fill;
    this.barSheen = sheen;
  }

  count(value) {
    const number = Number(value);
    return Number.isFinite(number) ? Math.max(0, Math.floor(number)) : 0;
  }

  setResultCount(element, value) {
    if (!element) return;
    const count = this.count(value);
    element.textContent = String(count);
    element.classList.toggle('has-results', count > 0);
  }

  setAsset(data) {
    if (data.currentAsset !== undefined && data.currentAsset !== null && this.assetName) {
      const name = String(data.currentAsset).trim() || 'Waiting for first asset';
      this.assetName.textContent = name;
      this.assetName.dataset.tooltip = name;
    }
    if (data.currentAssetLocation !== undefined && this.assetLocation) {
      const location = String(data.currentAssetLocation || '').trim() || 'Detected location';
      this.assetLocation.textContent = location;
      this.assetLocation.dataset.tooltip = location;
    }
    if (data.currentAssetId !== undefined && data.currentAssetId !== null && this.assetId) {
      const id = String(data.currentAssetId).trim();
      this.assetId.textContent = id || '—';
      this.assetId.dataset.tooltip = id;
    }
    if (data.completed !== undefined && this.assetSequence) {
      this.assetSequence.textContent = `#${this.count(data.completed)}`;
    }
    if (data.currentAssetStatus !== undefined) {
      const status = String(data.currentAssetStatus || '');
      const outcome = status === 'Success' ? 'success' : status === 'Failed' ? 'failed' : 'processing';
      if (this.assetInfo) this.assetInfo.dataset.outcome = outcome;
      if (this.assetOutcome) this.assetOutcome.textContent = status === 'Success' ? 'Reuploaded' : status === 'Failed' ? 'Failed' : status ? 'Processing' : 'Waiting';
    }
  }

  update(data) {
    if (data.total !== undefined) this.setTotal(data.total);
    if (data.success !== undefined || data.successful !== undefined) {
      this.setResultCount(this.successElement, data.success ?? data.successful);
    }
    if (data.failed !== undefined) this.setResultCount(this.failedElement, data.failed);
    this.setAsset(data);
    this.bar?.classList.add('is-running');
    if (data.completed === undefined) return;

    this.target = Math.min(this.total, Math.max(this.target, this.count(data.completed)));
    if (this.frame == null && this.completed < this.target) {
      this.completedElement?.classList.add('is-counting');
      this.frame = requestAnimationFrame(time => this.advance(time));
    }
  }

  advance(time) {
    const remaining = this.target - this.completed;
    const stepInterval = Math.min(65, Math.max(16, 220 / Math.max(1, remaining)));
    if (this.lastStep === null || time - this.lastStep >= stepInterval) {
      // Never use a bulk jump or a loop here: every integer gets a painted frame.
      this.completed = Math.min(this.target, this.completed + 1);
      this.lastStep = time;
      this.paint();
    }
    if (this.completed < this.target) {
      this.frame = requestAnimationFrame(nextTime => this.advance(nextTime));
    } else {
      this.frame = null;
      this.lastStep = null;
      this.completedElement?.classList.remove('is-counting');
    this.compactCountElement?.classList.remove('is-counting');
      const callback = this.onSettled;
      this.onSettled = null;
      callback?.();
    }
  }

  pulseCounter(element) {
    if (!element) return;
    element.classList.remove('is-counting');
    void element.offsetWidth;
    element.classList.add('is-counting');
  }

  paint() {
    if (this.completedElement) this.completedElement.textContent = String(this.completed);
    if (this.compactCountElement) this.compactCountElement.textContent = `${this.completed} / ${this.total}`;
    if (this.completed > 0) {
      this.pulseCounter(this.completedElement);
      this.pulseCounter(this.compactCountElement);
    }
    this.bar?.setAttribute('aria-valuenow', String(this.completed));
    const percent = this.total > 0 ? Math.floor(this.completed / this.total * 100) : 0;
    if (this.percentElement) this.percentElement.textContent = `${percent}%`;
    this.bar?.setAttribute('aria-valuetext', `${this.completed} of ${this.total} assets (${percent}%)`);
    this.bar?.style.setProperty('--kage-progress', `${percent}%`);
    if (this.barFill) {
      this.barFill.style.width = `${percent}%`;
      this.barFill.classList.toggle('filling', percent > 0 && percent < 100);
    }
  }

  whenSettled(callback) {
    if (this.completed === this.target && this.frame == null) callback();
    else this.onSettled = callback;
  }
}

window.KageProgressView = KageProgressView;
