// v59 — targeted UI state fixes only. No reupload/Studio/backend logic changes.
(() => {
  'use strict';
  if (new URLSearchParams(location.search).get('shadePopout') === '1') {
    // Shade popout still needs the composer state fix below, so do not return.
  }

  function cssUrl(value) {
    const raw = String(value || '').trim();
    if (!raw) return 'none';
    return `url("${raw.replace(/["\\]/g, '')}")`;
  }

  function paintSettingsRobloxAvatar(data) {
    const roblox = data?.roblox || {};
    const holder = document.getElementById('settings-roblox-avatar');
    if (!holder) return;
    const avatar = roblox.avatar || roblox.avatarUrl || '';
    holder.style.setProperty('--kage-settings-roblox-avatar', cssUrl(avatar));
    // v63 paints the avatar on a clipped inner disc via ::before. Remove the
    // legacy inline background so square image corners cannot escape the circle.
    holder.style.removeProperty('background-image');
  }

  function syncShadeSendButtons() {
    const inFlight = typeof shadeRequestInFlight !== 'undefined' && !!shadeRequestInFlight;
    for (const [inputId, buttonId] of [['shade-input-main','shade-send-main'],['shade-input-sidecar','shade-send-sidecar']]) {
      const input = document.getElementById(inputId);
      const button = document.getElementById(buttonId);
      if (!button) continue;
      const locked = inFlight || !String(input?.value || '').trim();
      button.disabled = locked;
      button.setAttribute('aria-disabled', locked ? 'true' : 'false');
      button.classList.toggle('shade-send-locked', locked);
    }
  }

  for (const id of ['shade-input-main','shade-input-sidecar']) {
    const input = document.getElementById(id);
    if (!input) continue;
    for (const eventName of ['input','change','keyup','paste','cut']) {
      input.addEventListener(eventName, () => requestAnimationFrame(syncShadeSendButtons));
    }
  }
  for (const id of ['shade-send-main','shade-send-sidecar']) {
    document.getElementById(id)?.addEventListener('click', event => {
      const inputId = id === 'shade-send-main' ? 'shade-input-main' : 'shade-input-sidecar';
      if (!String(document.getElementById(inputId)?.value || '').trim()) {
        event.preventDefault();
        event.stopImmediatePropagation();
        syncShadeSendButtons();
      }
    }, true);
  }

  try {
    window.chrome?.webview?.addEventListener?.('message', event => {
      const payload = event?.data;
      if (payload?.event === 'accountInfo') paintSettingsRobloxAvatar(payload.data);
      if (['shadeStreamStart','shadeStreamDone','shadeStreamError'].includes(payload?.event)) requestAnimationFrame(syncShadeSendButtons);
    });
  } catch { }

  const previousUpdateAccountInfo = window.updateAccountInfo;
  if (typeof previousUpdateAccountInfo === 'function' && !previousUpdateAccountInfo.__v59AvatarWrapped) {
    const wrapped = function(data) {
      previousUpdateAccountInfo(data);
      paintSettingsRobloxAvatar(data);
    };
    wrapped.__v59AvatarWrapped = true;
    window.updateAccountInfo = wrapped;
  }

  try {
    if (typeof latestAccountInfo !== 'undefined' && latestAccountInfo) paintSettingsRobloxAvatar(latestAccountInfo);
  } catch { }
  requestAnimationFrame(syncShadeSendButtons);
  window.addEventListener('focus', syncShadeSendButtons);
})();
