using Kage.Bridge;

namespace KAGE.Desktop;

public partial class MainForm
{
    private bool TryGetStudioWorkspacePresentationProject(StudioProjectInfo project, out StudioProjectInfo presented)
    {
        presented = project;
        var workspace = _studioSessionManager.Workspace;
        // A refresh from an old place, an old Studio owner, or a disconnected
        // session must not replace the current Explorer project and catalog.
        if (!workspace.IsConnected || workspace.Project is not { } current || !SameStudioProject(current, project))
            return false;

        // ReadProjectInfo refreshes game.Name, which can be the default Place1
        // even after Roblox metadata supplied the real experience name. Reuse
        // that metadata without making every scan wait on another API request.
        if ((project.PlaceId > 0 || project.UniverseId > 0) &&
            _canonicalProjectCache.TryGetValue($"{project.PlaceId}:{project.UniverseId}", out var canonical) &&
            canonical.PlaceId == project.PlaceId && canonical.UniverseId == project.UniverseId &&
            IsMeaningfulStudioProjectName(canonical.ProjectName))
        {
            presented = project with { ProjectName = canonical.ProjectName };
        }
        else if (!IsMeaningfulStudioProjectName(project.ProjectName) &&
            _lastResolvedStudioProject is { } resolved && SameStudioProject(resolved, project) &&
            IsMeaningfulStudioProjectName(resolved.ProjectName))
        {
            presented = project with { ProjectName = resolved.ProjectName };
        }

        return workspace.IsConnected && workspace.Project is { } latest && SameStudioProject(latest, project);
    }

    private static bool IsMeaningfulStudioProjectName(string? name)
    {
        if (string.IsNullOrWhiteSpace(name)) return false;
        var value = name.Trim();
        // Preserve custom names, including unsaved scenes, while rejecting the
        // numbered DataModel placeholder returned by a normal Studio refresh.
        return !value.StartsWith("Place", StringComparison.OrdinalIgnoreCase) ||
            value.Length == 5 || !value[5..].All(char.IsDigit);
    }
}
