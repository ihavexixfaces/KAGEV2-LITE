namespace Kage.Bridge;

public sealed class StudioRuntimeDirectory : IDisposable
{
    public StudioRuntimeDirectory()
    {
        Root = Path.Combine(Path.GetTempPath(), "KAGE", "Studio", Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(Root);
    }

    public string Root { get; }

    public string WriteInternalLuau(string source)
    {
        var path = Path.Combine(Root, $"bridge-{Guid.NewGuid():N}.luau");
        File.WriteAllText(path, source);
        return path;
    }

    public void Dispose()
    {
        try
        {
            if (Directory.Exists(Root)) Directory.Delete(Root, recursive: true);
        }
        catch { }
    }
}
