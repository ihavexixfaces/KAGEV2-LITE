// v69: one shared, unobtrusive temporary-access countdown on Home.
(() => {
  'use strict';
  let expiryEpoch = 0;
  let expiryKind = '';
  let timer = 0;

  const node = () => document.getElementById('home-access-expiry');

  function remainingText(totalSeconds) {
    const totalMinutes = Math.max(0, Math.floor(Number(totalSeconds) / 60));
    const days = Math.floor(totalMinutes / 1440);
    const hours = Math.floor((totalMinutes % 1440) / 60);
    const minutes = totalMinutes % 60;
    if (days > 0) return `${days}d ${hours}h ${minutes}m`;
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  }

  function paint() {
    const target = node();
    if (!target) return;
    const temporary = expiryKind === 'temporary' && Number.isFinite(expiryEpoch) && expiryEpoch > 0;
    if (!temporary) {
      target.textContent = '';
      target.classList.add('hidden');
      target.classList.remove('expired');
      target.removeAttribute('title');
      return;
    }
    const remaining = expiryEpoch - (Date.now() / 1000);
    const expired = remaining <= 0;
    target.textContent = expired ? 'Expired' : remainingText(remaining);
    target.title = `Temporary KAGE access expires ${new Date(expiryEpoch * 1000).toLocaleString([], { dateStyle:'medium', timeStyle:'short' })}`;
    target.classList.remove('hidden');
    target.classList.toggle('expired', expired);
  }

  function update(data) {
    const discord = data?.discord || {};
    expiryKind = String(discord.accessType || '').toLowerCase();
    expiryEpoch = Number(discord.accessExpiresAt || 0);
    document.getElementById('home-roblox-access-expiry')?.remove();
    document.getElementById('home-discord-access-expiry')?.remove();
    document.querySelector('#home-discord-id > .discord-expiry')?.remove();
    if (timer) clearInterval(timer);
    timer = 0;
    paint();
    if (expiryKind === 'temporary' && expiryEpoch > 0) timer = window.setInterval(paint, 30000);
  }

  // v66 wrapped updateAccountInfo first; v69 wraps the resulting function and owns final display.
  if (typeof updateAccountInfo === 'function') {
    const prior = updateAccountInfo;
    updateAccountInfo = function(data) {
      prior(data);
      update(data);
    };
  }
})();
