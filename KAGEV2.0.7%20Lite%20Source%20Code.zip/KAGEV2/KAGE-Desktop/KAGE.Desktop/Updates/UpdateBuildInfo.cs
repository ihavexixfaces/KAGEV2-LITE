namespace KAGE.Desktop.Updates;

internal static class UpdateBuildInfo
{
    public const string ReleaseVersion = "2.0.7";
    public const int ProtocolGeneration = 2;
    public static long BuildId { get; } = ReleaseIdentity.BuildId;
    public static string DistributionMode { get; } = NormalizeDistributionMode(ReleaseIdentity.DistributionMode);

    private static string NormalizeDistributionMode(string value) =>
        value.Contains("compact", StringComparison.OrdinalIgnoreCase)
            ? "maximum-compact"
            : "maximum-standalone";
}
