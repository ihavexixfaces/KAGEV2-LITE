/* KAGE Asset Viewer: Studio samples animation poses; playback stays inside KAGE. */
(() => {
  'use strict';
  const byId = id => document.getElementById(id);
  if (!byId('tab-preview') || new URLSearchParams(location.search).get('shadePopout') === '1') return;
  const math = {
    assetId(raw) {
      const text = String(raw || '').trim();
      let id = /^\d+$/.test(text) ? text : /^rbxassetid:\/\/(\d+)$/i.exec(text)?.[1];
      if (!id) {
        try {
          const url = new URL(text);
          if (url.protocol !== 'https:' || !/(^|\.)roblox\.com$/i.test(url.hostname)) return '';
          id = url.searchParams.get('id') || /^\/(?:library|catalog|asset)\/(\d+)(?:\/|$)/i.exec(url.pathname)?.[1];
        } catch { return ''; }
      }
      if (!/^\d+$/.test(id || '') || BigInt(id) <= 0n || BigInt(id) > 9223372036854775807n) return '';
      return BigInt(id).toString();
    },
    interpolate(a, b, t) {
      let dot = a[3]*b[3]+a[4]*b[4]+a[5]*b[5]+a[6]*b[6];
      const sign = dot < 0 ? -1 : 1;
      dot = Math.min(1, Math.abs(dot));
      let left = 1-t, right = t;
      if (dot < 0.9995) {
        const angle = Math.acos(dot), sine = Math.sin(angle);
        left = Math.sin((1-t)*angle)/sine; right = Math.sin(t*angle)/sine;
      }
      const q = [3,4,5,6].map(i => left*a[i]+right*b[i]*sign);
      const magnitude = Math.hypot(...q) || 1;
      return [0,1,2].map(i => a[i]+(b[i]-a[i])*t).concat(q.map(v=>v/magnitude));
    },
    rotate([x,y,z], [qx,qy,qz,qw]) {
      const tx=2*(qy*z-qz*y), ty=2*(qz*x-qx*z), tz=2*(qx*y-qy*x);
      return [x+qw*tx+qy*tz-qz*ty, y+qw*ty+qz*tx-qx*tz, z+qw*tz+qx*ty-qy*tx];
    },
    poses(clip, time) {
      const index = Math.max(0, Math.min(Math.floor(time*clip.fps), clip.frames.length-1));
      const next = Math.min(index+1, clip.frames.length-1);
      const interval = Math.min(1/clip.fps, Math.max(0.00001,clip.length-index/clip.fps));
      const t = Math.max(0, Math.min(1,(time-index/clip.fps)/interval));
      return clip.parts.map((_,i) => math.interpolate(clip.frames[index].slice(i*7,i*7+7),clip.frames[next].slice(i*7,i*7+7),t));
    }
  };
  // Pure math is exposed for behavioral tests and renderer diagnostics.
  window.KagePreviewMath = math;
  const state = { mode:'kage', generation:0, sequence:0, clip:'', loaded:false, remote:false, busy:false, playing:false,
    length:0, position:0, data:null, frames:[], parts:[], total:0, catalog:[], pending:new Map(), pollPending:false,
    catalogRequest:'', catalogDirty:true, catalogDeferred:false, catalogError:'', active:false, connected:false, projectKey:'', studioId:'',
    accountKey:'', mediaUrl:'', mediaCleanup:null, mediaRequest:'', assetType:'Animations', gameRig:'R15', detectedRig:'R15', rigMode:'AUTO', rigSource:'Studio' };
  const canvas = byId('preview-canvas');
  const context = canvas.getContext('2d');
  const camera = { yaw:-0.35, pitch:0.08, distance:10.5, targetY:0, groundY:-3, dragging:false, x:0, y:0 };
  const seconds = n => `${Math.floor(n/60)}:${(n%60).toFixed(2).padStart(5,'0')}`;
  const notice = (text,error=false) => { byId('preview-status').textContent=text; byId('preview-status').classList.toggle('is-error',error); };
  // Native delivery cancels superseded requests. A single-flight lazy queue keeps
  // that contract intact while each tile owns its decoded, context-scoped media.
  const tiles = { entries:new Map(), queue:[], flight:null, epoch:0, sound:null, bytes:0, clock:0 };
  const mediaList=byId('preview-animation-list');
  const pageSize=12;
  let catalogPage=0, pageFilter='', currentPageItems=[];
  const pagination=document.createElement('nav');pagination.className='preview-pagination';pagination.setAttribute('aria-label','Asset pages');
  const previousPage=document.createElement('button'),nextPage=document.createElement('button'),pageLabel=document.createElement('span');
  previousPage.id='preview-page-prev';previousPage.type='button';previousPage.setAttribute('aria-label','Previous asset page');
  nextPage.id='preview-page-next';nextPage.type='button';nextPage.setAttribute('aria-label','Next asset page');
  for(const [button,source] of [[previousPage,'ui-preview-prev.png'],[nextPage,'ui-preview-next.png']]){
    const image=document.createElement('img');image.src=`../Assets/${source}`;image.alt='';button.append(image);
  }
  pageLabel.id='preview-page-label';pageLabel.setAttribute('aria-live','polite');pagination.append(previousPage,pageLabel,nextPage);mediaList.after(pagination);
  function changePage(offset){
    cancelTileQueue();
    if(tiles.sound){tiles.sound.playWhenReady=false;releaseMedia();tiles.sound=null;state.loaded=false;state.busy=false;updateControls();}
    catalogPage=Math.max(0,catalogPage+offset);mediaList.scrollTop=0;renderCatalog();
  }
  previousPage.addEventListener('click',()=>changePage(-1));nextPage.addEventListener('click',()=>changePage(1));
  const observer=window.IntersectionObserver ? new IntersectionObserver(changes=>{
    for(const change of changes){
      const entry=tiles.entries.get(change.target.dataset.tileKey);
      if(!entry)continue;
      entry.visible=change.isIntersecting;
      if(entry.visible && entry.type!=='Sounds')queueTile(entry);
    }
    pumpTiles();
  },{root:mediaList,rootMargin:'160px 0px'}) : null;
  function tileKey(type,id){return `${type}:${id}`;}
  function makeTile(item,type=state.assetType){
    const id=math.assetId(item.id),key=tileKey(type,id);
    if(!id)return null;
    let entry=tiles.entries.get(key);
    if(!entry){
      const node=document.createElement('article');node.className='preview-asset-tile';node.dataset.assetId=id;node.dataset.tileKey=key;
      const visual=document.createElement('div');visual.className='preview-tile-visual';
      const icon=document.createElement('img');icon.className='preview-tile-icon';icon.alt='';icon.src=`../Assets/kage-asset-${type==='Sounds'?'sound':type==='Meshes'?'mesh':'decal'}.png`;visual.append(icon);
      const label=document.createElement('strong'),assetId=document.createElement('small'),status=document.createElement('span');
      label.className='preview-tile-name';assetId.className='preview-tile-id';assetId.textContent=id;
      status.className='preview-tile-status';status.textContent=type==='Sounds'?'Ready to play':'Waiting for preview';
      node.append(visual,label,assetId,status);
      entry={id,type,key,node,visual,label,status,icon,url:'',size:0,statusCode:'idle',visible:false,used:0,playWhenReady:false};tiles.entries.set(key,entry);
      if(type==='Sounds'){
        const play=document.createElement('button');play.type='button';play.className='preview-tile-play';
        const glyph=document.createElement('img');glyph.src='../Assets/Play_Icon.png';glyph.alt='';play.append(glyph);
        play.addEventListener('click',()=>selectSound(entry));visual.append(play);entry.play=play;entry.glyph=glyph;
        const progress=document.createElement('progress');progress.className='preview-tile-progress';progress.max=1;progress.value=0;progress.setAttribute('aria-label','Sound playback progress');node.append(progress);entry.progress=progress;
        node.dataset.playing='false';
      }else{
        const retry=document.createElement('button');retry.type='button';retry.className='preview-tile-retry';retry.textContent='Retry';retry.hidden=true;
        retry.addEventListener('click',()=>{entry.statusCode='idle';queueTile(entry,true);pumpTiles();});node.append(retry);entry.retry=retry;
      }
    }
    entry.label.textContent=(type==='Decals' && /^MeshPart$/i.test(String(item.name||''))) ? 'MeshPart texture' : (item.name || `${type.replace(/s$/,'')} ${id}`);
    entry.location=String(item.location||entry.label.textContent);
    if(!entry.error)entry.node.dataset.tooltip=entry.location;
    entry.play?.setAttribute('aria-label',`Play ${entry.label.textContent}`);
    return entry;
  }
  function paintTile(entry){
    entry.node.dataset.state=entry.statusCode;
    entry.node.setAttribute('aria-busy',String(entry.statusCode==='loading'||entry.statusCode==='queued'));
    entry.retry && (entry.retry.hidden=entry.statusCode!=='error');
    if(entry.statusCode==='error'){
      entry.status.textContent='Preview unavailable';entry.node.dataset.tooltip=entry.error;entry.node.setAttribute('aria-description',entry.error);entry.icon.hidden=false;
      entry.image?.remove();entry.image=null;return;
    }
    entry.node.removeAttribute('aria-description');entry.node.dataset.tooltip=entry.location;
    if(entry.type!=='Sounds' && entry.url){
      if(!entry.image){entry.image=document.createElement('img');entry.image.className='preview-tile-image';entry.image.alt=`${entry.label.textContent} preview`;entry.image.decoding='async';entry.visual.append(entry.image);}
      if(entry.image.getAttribute('src')!==entry.url)entry.image.src=entry.url;
      entry.icon.hidden=true;entry.status.textContent=entry.type==='Meshes'?'Mesh thumbnail':'Texture / image';
    }else entry.status.textContent=entry.statusCode==='loading'?'Loading…':entry.type==='Sounds'?'Ready to play':'Waiting for preview';
    syncSoundTile(entry);
  }
  function queueTile(entry,priority=false){
    if(!state.active||!state.connected||entry.type!==state.assetType||!['idle'].includes(entry.statusCode))return;
    entry.statusCode='queued';entry.error='';paintTile(entry);
    priority?tiles.queue.unshift(entry):tiles.queue.push(entry);
  }
  function pumpTiles(){
    if(tiles.flight||!state.active||!state.connected||state.assetType==='Animations')return;
    let entry;
    while(tiles.queue.length){
      const candidate=tiles.queue.shift();
      if(candidate.statusCode==='queued' && candidate.type===state.assetType && ((candidate.visible&&mediaList.contains(candidate.node))||candidate.playWhenReady)){entry=candidate;break;}
      if(candidate.statusCode==='queued'){candidate.statusCode='idle';paintTile(candidate);}
    }
    if(!entry)return;
    entry.statusCode='loading';paintTile(entry);
    const requestId=`tile-${++state.sequence}-${Date.now()}`;
    const timeout=setTimeout(()=>handleTileResponse({requestId,success:false,error:'Roblox media preview timed out. Retry shortly.'}),45000);
    tiles.flight={requestId,entry,epoch:tiles.epoch,timeout};
    try{window.chrome.webview.postMessage({action:'assetPreview',requestId,assetType:entry.type,assetId:entry.id});}
    catch{handleTileResponse({requestId,success:false,error:'KAGE could not request this media preview.'});}
  }
  function cancelTileQueue(){
    tiles.epoch++;
    if(tiles.flight){clearTimeout(tiles.flight.timeout);tiles.flight.entry.statusCode='idle';paintTile(tiles.flight.entry);tiles.flight=null;try{window.chrome.webview.postMessage({action:'cancelAssetPreview'});}catch{}}
    for(const entry of tiles.queue){if(entry.statusCode==='queued'){entry.statusCode='idle';paintTile(entry);}}
    tiles.queue=[];
  }
  function clearTileCache(){
    cancelTileQueue();releaseMedia();tiles.sound=null;observer?.disconnect();
    for(const entry of tiles.entries.values()){if(entry.url)URL.revokeObjectURL(entry.url);entry.node.remove();}
    tiles.entries.clear();tiles.bytes=0;catalogPage=0;pageFilter='';
  }
  function trimTileCache(){
    const cached=[...tiles.entries.values()].filter(e=>e.url).sort((a,b)=>a.used-b.used);
    let count=cached.length;
    for(const entry of cached){
      if(tiles.bytes<=24*1024*1024 && count<=24)break;
      if(entry===tiles.sound)continue;
      tiles.bytes-=entry.size;count--;URL.revokeObjectURL(entry.url);entry.url='';entry.size=0;entry.statusCode='idle';entry.image?.remove();entry.image=null;entry.icon.hidden=false;paintTile(entry);
    }
  }
  async function handleTileResponse(data){
    const flight=tiles.flight;
    if(!flight||data.requestId!==flight.requestId)return false;
    clearTimeout(flight.timeout);
    const {entry,epoch}=flight;
    try{
      if(!data.success)throw new Error(data.error||'Roblox media is unavailable.');
      const result=data.result||{},sound=entry.type==='Sounds',mime=sound?/^audio\/(?:ogg|mpeg|wav|flac|mp4)$/:/^image\/(?:png|jpeg|gif|webp)$/;
      if(String(result.assetId)!==entry.id||result.assetType!==entry.type||!mime.test(result.mimeType||'')||typeof result.base64!=='string'||!result.base64.length||result.base64.length>27962028)throw new Error('KAGE received invalid media preview content.');
      const raw=atob(result.base64),bytes=Uint8Array.from(raw,c=>c.charCodeAt(0));
      const url=URL.createObjectURL(new Blob([bytes],{type:result.mimeType}));
      if(!sound){
        const probe=new Image();probe.src=url;
        try{await Promise.race([probe.decode(),new Promise((_,reject)=>{flight.decodeTimeout=setTimeout(()=>reject(new Error('Image decoding timed out.')),20000);})]);}
        catch(error){URL.revokeObjectURL(url);throw new Error('KAGE could not decode the downloaded image.');}
        finally{clearTimeout(flight.decodeTimeout);}
      }
      if(epoch!==tiles.epoch||tiles.flight!==flight){URL.revokeObjectURL(url);return true;}
      entry.url=url;entry.size=bytes.length;entry.used=++tiles.clock;entry.statusCode='ready';entry.error='';tiles.bytes+=bytes.length;paintTile(entry);trimTileCache();
      if(sound && entry.playWhenReady)startTileSound(entry);
    }catch(error){
      if(epoch===tiles.epoch && tiles.flight===flight){entry.statusCode='error';entry.error=error.message||'Preview unavailable';entry.playWhenReady=false;paintTile(entry);if(entry===tiles.sound)notice(entry.error,true);}
    }finally{
      if(tiles.flight===flight){tiles.flight=null;pumpTiles();}
    }
    return true;
  }
  function syncSoundTile(entry){
    if(entry.type!=='Sounds')return;
    const audio=byId('preview-media-audio'),selected=tiles.sound===entry,playing=selected&&currentAudio()&&!audio.paused;
    entry.node.dataset.playing=String(playing);entry.glyph.src=`../Assets/${playing?'Pause':'Play'}_Icon.png`;
    entry.play.setAttribute('aria-label',`${playing?'Pause':'Play'} ${entry.label.textContent}`);
    if(selected&&Number.isFinite(audio.duration)&&audio.duration>0){entry.progress.max=audio.duration;entry.progress.value=audio.currentTime||0;entry.status.textContent=`${playing?'Playing · ':''}${seconds(audio.currentTime||0)} / ${seconds(audio.duration)}`;}
  }
  function selectSound(entry){
    if(!state.connected){notice('Connect to Studio first.',true);return;}
    if(tiles.sound===entry&&currentAudio()){
      const audio=byId('preview-media-audio');if(audio.paused){if(audio.ended)audio.currentTime=0;playSound();}else audio.pause();syncSoundTile(entry);return;
    }
    const old=tiles.sound;releaseMedia();state.generation++;state.loaded=false;state.playing=false;state.busy=false;tiles.sound=entry;
    if(old){old.playWhenReady=false;syncSoundTile(old);}
    entry.playWhenReady=true;byId('preview-current-name').textContent=entry.label.textContent;byId('preview-current-id').textContent=entry.id;
    if(entry.url)startTileSound(entry);
    else{entry.statusCode=entry.statusCode==='error'?'idle':entry.statusCode;queueTile(entry,true);pumpTiles();notice('Loading sound…');}
  }
  function startTileSound(entry){
    if(tiles.sound!==entry||state.assetType!=='Sounds'||!entry.url)return;
    const audio=byId('preview-media-audio');state.mediaUrl=entry.url;state.busy=true;entry.used=++tiles.clock;
    const generation=state.generation;
    const ready=()=>{
      if(generation!==state.generation||tiles.sound!==entry||audio.readyState<2||!Number.isFinite(audio.duration)||audio.duration<=0)return;
      state.mediaCleanup?.();state.mediaCleanup=null;state.loaded=true;state.busy=false;state.length=audio.duration;updateControls();syncSoundTile(entry);notice('Sound ready · press play');
      if(entry.playWhenReady){entry.playWhenReady=false;playSound();}
    };
    const failure=()=>{
      if(generation!==state.generation||tiles.sound!==entry)return;
      state.mediaCleanup?.();state.mediaCleanup=null;state.busy=false;state.loaded=false;entry.statusCode='error';entry.error='KAGE could not decode the downloaded sound. Its audio format may be unsupported.';entry.playWhenReady=false;
      if(entry.url){URL.revokeObjectURL(entry.url);tiles.bytes-=entry.size;entry.url='';entry.size=0;}
      state.mediaUrl='';audio.removeAttribute('src');paintTile(entry);notice(entry.error,true);updateControls();
    };
    const timeout=setTimeout(failure,20000);audio.addEventListener('canplay',ready);audio.addEventListener('error',failure);
    state.mediaCleanup=()=>{clearTimeout(timeout);audio.removeEventListener('canplay',ready);audio.removeEventListener('error',failure);};
    audio.loop=false;audio.src=entry.url;audio.load();ready();
  }
  function renderMediaTiles(matches){
    observer?.disconnect();
    for(const entry of tiles.entries.values())entry.visible=false;
    const retained=new Set();
    for(const item of matches){
      const entry=makeTile(item);if(!entry||retained.has(entry.node))continue;
      retained.add(entry.node);paintTile(entry);mediaList.append(entry.node);
      if(observer)observer.observe(entry.node);else entry.visible=false;
    }
    for(const node of [...mediaList.children])if(node.classList.contains('preview-asset-tile')&&!retained.has(node))node.remove();
    // Retain only a small recent-page cache; stale DOM and media cannot accumulate.
    const inactive=[...tiles.entries.values()].filter(e=>!retained.has(e.node)&&e!==tiles.sound&&e!==tiles.flight?.entry).sort((a,b)=>a.used-b.used);
    while(tiles.entries.size>36&&inactive.length){
      const entry=inactive.shift();if(entry.url){URL.revokeObjectURL(entry.url);tiles.bytes-=entry.size;}entry.node.remove();tiles.entries.delete(entry.key);
    }
    trimTileCache();
    if(!observer){
      const box=mediaList.getBoundingClientRect();
      for(const entry of tiles.entries.values())if(retained.has(entry.node)){
        const r=entry.node.getBoundingClientRect();entry.visible=r.bottom>=box.top-160&&r.top<=box.bottom+160;
        if(entry.visible&&entry.type!=='Sounds')queueTile(entry);
      }
      pumpTiles();
    }
  }
  mediaList.addEventListener('scroll',()=>{if(!observer&&state.assetType!=='Animations')renderMediaTiles(currentPageItems);},{passive:true});
  function updateControls() {
    const isAnimation = state.assetType === 'Animations';
    const isAudio = state.assetType === 'Sounds';
    const mediaAudio = byId('preview-media-audio');
    const canTransport = state.loaded && !state.busy && (isAnimation || isAudio);
    ['preview-play','preview-pause'].forEach(id=>byId(id).disabled=!canTransport);
    byId('preview-stop').disabled=!state.loaded && !state.busy;
    byId('preview-seek').disabled=!(isAnimation || isAudio) || !state.loaded || state.busy;
    if (isAudio && mediaAudio?.duration) { state.length=Number(mediaAudio.duration)||0; state.position=Number(mediaAudio.currentTime)||0; }
    byId('preview-seek').max=String(state.length);
    if (document.activeElement !== byId('preview-seek')) byId('preview-seek').value=String(state.position);
    const pct = state.length > 0 ? Math.max(0,Math.min(100,state.position/state.length*100)) : 0;
    byId('preview-seek').style.setProperty('--seek-progress',`${pct}%`);
    byId('preview-seek').parentElement.style.setProperty('--seek-progress',`${pct}%`);
    byId('preview-time').textContent=isAnimation ? `${seconds(state.position)} / ${seconds(state.length)}` : isAudio && mediaAudio?.duration ? `${seconds(mediaAudio.currentTime||0)} / ${seconds(mediaAudio.duration||0)}` : '—';
    byId('preview-stage-copy').classList.toggle('hidden',state.loaded);
    byId('preview-seek')?.closest('.preview-timeline')?.classList.toggle('hidden',!(isAnimation || isAudio));
    byId('preview-rig-control').classList.toggle('hidden',!isAnimation);
    if(tiles.sound)syncSoundTile(tiles.sound);
    if(state.catalogDeferred && state.active && state.connected && !state.remote && !state.busy)requestCatalog(true);
  }
  function send(command, extra={}, cleanup=false) {
    const requestId=`preview-${++state.sequence}-${Date.now()}`;
    const timeout=setTimeout(()=>handleResponse({requestId,success:false,error:'KAGE Asset Viewer timed out. Check Studio and retry.'}),70000);
    state.pending.set(requestId,{generation:state.generation,command,cleanup,start:extra.start,timeout});
    if(command==='catalog')state.catalogRequest=requestId;
    try { window.chrome.webview.postMessage({action:'animationPreview',command,requestId,clipToken:state.clip,...extra}); }
    catch { handleResponse({requestId,success:false,error:'KAGE Asset Viewer could not contact KAGE. Retry after reconnecting Studio.'}); }
    return requestId;
  }
  function completeRequest(requestId) {
    const request=state.pending.get(requestId);
    if(request)clearTimeout(request.timeout);
    state.pending.delete(requestId);
    return request;
  }
  function stopRemote(force=false) {
    if (state.remote || state.busy || force===true) send('stop',{},true);
    state.remote=false; state.pollPending=false;
  }
  function resetLoad() {
    state.generation++;
    releaseMedia();
    for(const [id,request] of state.pending)if(request.command!=='catalog')completeRequest(id);
    state.pollPending=false;
    state.loaded=false; state.playing=false; state.data=null; state.frames=[]; state.parts=[];
    state.position=0; state.length=0; state.busy=false; state.remote=false;
  }
  function failPreview(message) {
    if(state.assetType==='Animations')stopRemote(true); resetLoad(); hideMedia(); notice(message,true); updateControls(); draw();
  }
  function releaseMedia() {
    const hadMedia=!!state.mediaRequest || !!state.mediaUrl;
    state.mediaCleanup?.(); state.mediaCleanup=null;
    state.mediaRequest='';
    const image=byId('preview-media-image'), audio=byId('preview-media-audio');
    image?.removeAttribute('src'); image?.classList.add('hidden');
    if(audio) { audio.pause(); audio.removeAttribute('src'); audio.load(); audio.classList.add('hidden'); }
    if(state.mediaUrl && ![...tiles.entries.values()].some(entry=>entry.url===state.mediaUrl))URL.revokeObjectURL(state.mediaUrl);
    state.mediaUrl='';
    if(hadMedia)try { window.chrome.webview.postMessage({action:'cancelAssetPreview'}); } catch {}
  }
  function hideMedia() {
    byId('preview-media-image')?.classList.add('hidden');
    byId('preview-media-audio')?.classList.add('hidden');
    canvas?.classList.remove('hidden'); canvas?.classList.add('is-visible');
  }
  function currentAudio() {
    const audio=byId('preview-media-audio');
    return state.assetType==='Sounds' && state.loaded && !!state.mediaUrl && audio?.getAttribute('src')===state.mediaUrl;
  }
  function playSound() {
    if(!currentAudio())return;
    const audio=byId('preview-media-audio'), generation=state.generation;
    audio.play().then(()=>{
      if(generation!==state.generation || !currentAudio())return;
      state.playing=true; notice('Playing sound in KAGE'); updateControls();
    }).catch(error=>{
      if(generation!==state.generation || !currentAudio())return;
      state.playing=false;
      if(error?.name==='NotAllowedError')notice('Sound ready · press play');
      else failPreview('KAGE could not play the downloaded sound. Its audio format may be unsupported.');
      updateControls();
    });
  }
  function previewGenericAsset(assetId) {
    const entry=makeTile(state.catalog.find(a=>String(a.id)===assetId)||{id:assetId,name:byId('preview-current-name').textContent==='No asset loaded'?'':byId('preview-current-name').textContent});
    if(!entry)return;
    if(!state.catalog.some(a=>String(a.id)===assetId))state.catalog.unshift({id:assetId,name:entry.label.textContent});
    cancelTileQueue();byId('preview-search').value='';pageFilter=`${state.assetType}:${state.projectKey}:`;catalogPage=Math.floor(state.catalog.findIndex(a=>String(a.id)===assetId)/pageSize);
    renderCatalog();entry.visible=true;
    if(entry.type==='Sounds')selectSound(entry);else{queueTile(entry,true);pumpTiles();entry.node.scrollIntoView({block:'nearest'});}
    return;
  }
  function load() {
    if (!state.connected) { notice('Connect to Studio first.',true); return; }
    const assetId=math.assetId(byId('preview-asset-id').value);
    if (!assetId) { notice('Enter a valid asset ID or Roblox asset link.',true); return; }
    if (state.assetType !== 'Animations') { previewGenericAsset(assetId); return; }
    hideMedia(); resetLoad();
    state.busy=true; state.clip=`clip-${state.generation}-${Date.now()}`;
    byId('preview-current-name').textContent=state.catalog.find(a=>String(a.id)===assetId)?.name || 'Animation';
    byId('preview-current-id').textContent=assetId;
    notice(`Preparing ${state.gameRig} KAGE preview…`); updateControls();
    send('load',{assetId,rigType:state.gameRig});
  }
  function applyStatus(result) {
    state.length=Number(result.length)||0; state.position=Number(result.position)||0;
    state.playing=result.state==='playing';
    if (result.assetId) byId('preview-current-id').textContent=String(result.assetId);
  }
  function handleResponse(data) {
    const request=completeRequest(data.requestId);
    if (!request) return;
    if(request.command==='catalog') {
      finishCatalog(); state.catalogError=data.error || 'Studio returned no animation catalog.';
      if(state.remote || state.busy) {
        state.catalogDeferred=true;byId('preview-refresh').disabled=true;
        if(/cancelled/i.test(state.catalogError))state.catalogError='';
      }
      state.catalogDirty=true; renderCatalog();
      if(!state.busy && !state.loaded)notice(state.catalogError,true);
      return;
    }
    if (request.generation!==state.generation) return;
    if (request.command==='status') state.pollPending=false;
    if (request.cleanup) return;
    if (!data.success) {
      failPreview(data.error || 'KAGE Asset Viewer failed.'); return;
    }
    const result=data.result || {};
    if (result.state==='stale') { failPreview('This preview session ended. Load the animation again.'); return; }
    if(request.command==='load' || request.command!=='sample' && request.command!=='stop' && result.state!=='stopped') {
      const valid=['paused','playing'].includes(result.state) && Number.isFinite(result.length) && result.length>0 && result.length<=120 &&
        Number.isFinite(result.position) && result.position>=0 && result.position<=result.length;
      if(!valid) { failPreview('Studio returned an invalid animation preview status. Load again.'); return; }
    }
    if (request.command==='load') {
      state.remote=true; applyStatus(result);
      canvas.classList.remove('hidden');canvas.classList.add('is-visible');
      notice('Preparing KAGE playback…'); send('sample',{start:0});
    } else if (request.command==='sample') {
      const frames=result.frames, parts=result.parts;
      const total=Number(result.totalFrames), length=Number(result.length);
      const valid=Number.isInteger(total) && total>0 && total<=3601 && length>0 && length<=120 && result.fps===30 &&
        Array.isArray(parts) && parts.length>0 && parts.length<=32 && Array.isArray(frames) && frames.length>0 && frames.length<=120 &&
        result.start===request.start && request.start===state.frames.length && request.start+frames.length<=total &&
        parts.every(p=>p && typeof p==='object' && typeof p.name==='string' && Array.isArray(p.size)&&p.size.length===3&&p.size.every(n=>Number.isFinite(n)&&n>0)&&Array.isArray(p.color)&&p.color.length===3&&p.color.every(Number.isFinite)&&(!p.shape||['box','head','sphere'].includes(p.shape))) &&
        frames.every(frame=>Array.isArray(frame)&&frame.length===parts.length*7&&frame.every(Number.isFinite));
      if (!valid) { failPreview('Studio returned incomplete animation poses. Load again.'); return; }
      if (state.parts.length && (total!==state.total || parts.length!==state.parts.length || parts.some((p,i)=>p.name!==state.parts[i]?.name))) {
        failPreview('The animation rig changed during loading. Load again.'); return;
      }
      state.parts=parts; state.total=total; state.frames.push(...frames); state.length=length;
      if (state.frames.length<total) {
        notice(`Loading KAGE preview · ${Math.round(state.frames.length/total*100)}%`);
        send('sample',{start:state.frames.length});
      } else {
        state.data={parts:state.parts,frames:state.frames,length,fps:30};
        stopRemote();finishPlaybackLoad();
      }
    } else if (request.command==='stop' || result.state==='stopped') {
      state.loaded=false; state.remote=false; state.playing=false; state.busy=false; state.position=0; notice('Preview stopped');
    } else { applyStatus(result); notice(state.playing?'Playing in Studio':'Paused in Studio'); }
    updateControls();
  }
  function fitCameraToRig(resetAngles=false){
    if(!state.data?.frames?.length||!state.data.parts?.length)return;
    const poses=math.poses(state.data,0);
    let minY=Infinity,maxY=-Infinity,maxRadius=0;
    state.data.parts.forEach((part,index)=>{
      const pose=poses[index]; if(!pose)return;
      const halfY=(Number(part.size?.[1])||1)/2;
      minY=Math.min(minY,pose[1]-halfY);maxY=Math.max(maxY,pose[1]+halfY);
      maxRadius=Math.max(maxRadius,Math.abs(pose[0])+(Number(part.size?.[0])||1)/2,Math.abs(pose[2])+(Number(part.size?.[2])||1)/2);
    });
    if(!Number.isFinite(minY)||!Number.isFinite(maxY))return;
    const rigHeight=Math.max(4,maxY-minY), rigWidth=Math.max(2,maxRadius*2);
    camera.targetY=(minY+maxY)/2;
    camera.groundY=minY-.05;
    camera.distance=Math.max(7.6,Math.min(16,Math.max(rigHeight/0.62,rigWidth/0.82)));
    if(resetAngles){camera.yaw=-0.35;camera.pitch=0.08;}
  }
  function finishPlaybackLoad(){
    if(!state.data){notice('Preparing KAGE playback…');return;}
    state.busy=false;state.loaded=true;state.position=0;state.playing=true;
    fitCameraToRig(true);
    byId('preview-stage-copy').classList.add('hidden');notice(`Playing ${state.gameRig} in KAGE`);draw();
    startPlaybackFrames();
  }
  function chooseMode() {
    state.mode='kage';
    draw();
  }
  function catalog(data) {
    if(data.requestId) {
      const request=completeRequest(data.requestId);
      if(!request || request.command!=='catalog' || data.requestId!==state.catalogRequest)return;
      finishCatalog();
    }
    state.catalogDirty=false;state.catalogError='';
    if (data.rigType === 'R6' || data.rigType === 'R15') setDetectedRig(data.rigType, data.rigSource || 'Studio');
    state.catalog=Array.isArray(data.animations)?data.animations:Array.isArray(data.assets)?data.assets:[];
    const current=state.catalog.find(a=>String(a.id)===byId('preview-current-id').textContent);
    if(current)byId('preview-current-name').textContent=current.name || 'Asset';
    if(!state.busy && !state.loaded)notice(`${state.catalog.length} ${state.assetType.toLowerCase()} detected`);
    renderCatalog();
  }
  function finishCatalog() {
    state.catalogRequest='';state.catalogDeferred=false; byId('preview-refresh').disabled=false;
    byId('preview-animation-list').setAttribute('aria-busy','false');
  }
  function requestCatalog(refresh=false) {
    if(state.catalogRequest)return;
    if(!state.connected) { state.catalogDirty=true; state.catalogError=''; notice('Connect to Studio first.',true); renderCatalog(); return; }
    if(state.remote || state.busy) { state.catalogDirty=true;state.catalogDeferred=true;state.catalogError='';byId('preview-refresh').disabled=true;renderCatalog();return; }
    state.catalogDeferred=false; state.catalogError=''; byId('preview-refresh').disabled=true;
    byId('preview-animation-list').setAttribute('aria-busy','true');
    if(!state.busy && !state.loaded)notice(`Scanning Studio ${state.assetType.toLowerCase()}…`);
    if (state.assetType === 'Animations') send('catalog',{refresh:refresh===true});
    else {
      state.catalogRequest=`workspace-${Date.now()}`;
      window.chrome.webview.postMessage({action:'refreshStudioWorkspace',assetType:state.assetType});
      window.setTimeout(()=>{ if(state.catalogRequest?.startsWith('workspace-')) { finishCatalog(); state.catalogRequest=''; } },15000);
    }
    renderCatalog();
  }
  function connectionChanged(data) {
    if(data.state==='Connecting' || data.state==='ScanningProject') {
      // StudioMCP may refresh its transport/studio_id while the same place remains open.
      // Keep Asset Viewer logically connected to the durable project during recovery.
      if(!state.projectKey) state.connected=false;
      return;
    }
    const connected=data.state==='StudioConnected',key=connected?`${data.project?.placeId || 0}:${data.project?.universeId || 0}`:'';
    const studioId=connected?String(data.project?.studioId || ''):'';
    const projectChanged=connected && (!state.projectKey || key!==state.projectKey);
    const disconnected=['ConnectionLost','ConnectionFailed','StudioNotRunning','StudioNotInstalled','StudioDetected','Disconnected'].includes(data.state);
    // Publish the new state before refresh/load guards inspect it.
    state.connected=connected;state.projectKey=key;state.studioId=studioId;
    if(projectChanged || disconnected) {
      clearTileCache();
      if(state.catalogRequest)completeRequest(state.catalogRequest);
      finishCatalog();
      state.catalog=[];state.catalogDirty=true;state.catalogError='';
      if(state.remote || state.busy || state.assetType!=='Animations'){resetLoad();hideMedia();}
      if(disconnected && !state.loaded)notice(data.error || 'Connect to Studio first.',true);
      updateControls();renderCatalog();
      if(projectChanged && state.active)requestCatalog(true);
    }
  }
  function workspaceSnapshot(data) {
    if(data.project===null) {
      connectionChanged({state:'Disconnected',project:null});
      return;
    }
    if(!state.connected || data.assetType!==state.assetType || !Array.isArray(data.animations))return;
    const key=`${data.project?.placeId || 0}:${data.project?.universeId || 0}`;
    if(state.projectKey && key!==state.projectKey)return;
    if(state.catalogRequest && !state.catalogRequest.startsWith('workspace-'))completeRequest(state.catalogRequest);
    finishCatalog(); state.catalogRequest=''; catalog({assets:data.animations});
  }
  function renderCatalog() {
    const target=byId('preview-animation-list'), search=byId('preview-search').value.trim().toLowerCase();
    const isMedia=state.assetType!=='Animations';
    byId('tab-preview').classList.toggle('preview-tiles-mode',isMedia);
    if(!isMedia)target.replaceChildren();
    else for(const node of [...target.children])if(!node.classList.contains('preview-asset-tile'))node.remove();
    if(state.catalogDeferred) {const queued=document.createElement('p');queued.className='preview-empty';queued.textContent='Refresh queued until the current preview stops.';target.append(queued);}
    if(state.catalogError) {const error=document.createElement('p');error.className='preview-empty is-error';error.textContent=state.catalogError;target.append(error);}
    const matches=state.catalog.filter(a=>`${a.name||''} ${a.id||''} ${a.location||''}`.toLowerCase().includes(search));
    const filter=`${state.assetType}:${state.projectKey}:${search}`;
    if(pageFilter!==filter){cancelTileQueue();if(tiles.sound){tiles.sound.playWhenReady=false;releaseMedia();tiles.sound=null;state.loaded=false;state.busy=false;updateControls();}catalogPage=0;pageFilter=filter;mediaList.scrollTop=0;}
    const pages=Math.max(1,Math.ceil(matches.length/pageSize));catalogPage=Math.min(catalogPage,pages-1);
    currentPageItems=matches.slice(catalogPage*pageSize,(catalogPage+1)*pageSize);
    pageLabel.textContent=`${catalogPage+1} / ${pages} · ${matches.length} assets`;
    previousPage.disabled=catalogPage===0;nextPage.disabled=catalogPage>=pages-1;pagination.hidden=!matches.length;

    if (!matches.length && !state.catalogError) { const text=document.createElement('p'); text.className='preview-empty'; text.textContent=state.catalogRequest?`Scanning Studio ${state.assetType.toLowerCase()}…`:search?'No matching assets.':!state.connected?'Connect to Studio first.':`No ${state.assetType.toLowerCase()} detected.`; target.append(text); }
    if(isMedia){renderMediaTiles(currentPageItems);return;}
    for (const item of currentPageItems) {
      const button=document.createElement('button'); button.type='button'; button.className='preview-animation-item';
      const name=document.createElement('strong'), id=document.createElement('small');
      name.textContent=item.name || `${state.assetType.replace(/s$/,'')} ${item.id}`; id.textContent=`: ${item.id}`;
      button.dataset.tooltip=String(item.location || ''); button.append(name,id);
      button.addEventListener('click',()=>{
        byId('preview-asset-id').value=String(item.id);
        byId('preview-current-name').textContent=name.textContent;
        target.querySelectorAll('.preview-animation-item').forEach(b=>b.classList.toggle('selected',b===button));
        load();
      });
      target.append(button);
    }
  }

  function syncRigControl() {
    state.gameRig = state.rigMode === 'AUTO' ? state.detectedRig : state.rigMode;
    const hidden = byId('preview-rig');
    if (hidden) hidden.value = state.rigMode;
    const label = byId('preview-rig-label');
    if (label) label.textContent = state.rigMode === 'AUTO' ? 'Auto' : state.rigMode;
    byId('preview-rig-menu')?.querySelectorAll('[data-value]').forEach(item=>item.setAttribute('aria-selected',String(item.dataset.value===state.rigMode)));
  }
  function setDetectedRig(value, source='Studio') {
    if (value !== 'R6' && value !== 'R15') return;
    state.detectedRig=value;
    state.rigSource=String(source || 'Studio');
    syncRigControl();
  }
  function selectRigMode(value, reload=true) {
    if (!['AUTO','R6','R15'].includes(value)) return;
    state.rigMode=value;
    syncRigControl();
    const label = state.rigMode === 'AUTO' ? 'Automatic rig detection' : `${state.gameRig} override`;
    notice(label);
    const currentId = math.assetId(byId('preview-asset-id')?.value);
    if (reload && state.assetType === 'Animations' && state.connected && currentId) load();
  }
  function setAssetType(type, refresh=true) {
    if (type !== 'Animations') return false;
    if(!['Animations','Sounds','Meshes','Decals'].includes(type))return false;
    if(state.remote || state.busy)stopRemote(true);
    if(state.catalogRequest)completeRequest(state.catalogRequest);
    finishCatalog();
    // A type switch retires pending media promises even when no Studio request is running.
    cancelTileQueue();resetLoad();tiles.sound=null;
    for(const entry of tiles.entries.values()){entry.playWhenReady=false;entry.visible=false;syncSoundTile(entry);}
    hideMedia(); state.assetType=type; state.catalog=[];state.catalogDirty=true;state.catalogError='';state.loaded=false;state.data=null;
    byId('preview-type-tabs')?.querySelectorAll('[data-type]').forEach(button=>button.classList.toggle('active',button.dataset.type===type));
    byId('preview-asset-id').value=''; byId('preview-current-id').textContent='—'; byId('preview-current-name').textContent='No asset loaded';
    byId('preview-stage-description').textContent='';
    notice(state.connected?`Ready · ${type}`:'Connect to Studio first.',!state.connected); updateControls(); renderCatalog();
    if(refresh && state.active && state.connected)requestCatalog(true);
    return true;
  }

  window.chrome.webview.addEventListener('message',event=>{
    if(event.data?.event==='assetPreviewResponse') handleTileResponse(event.data.data || {});
    if(event.data?.event==='animationPreviewResponse') handleResponse(event.data.data || {});
    if(event.data?.event==='animationPreviewCatalog') catalog(event.data.data || {});
    if(event.data?.event==='studioConnectionState') connectionChanged(event.data.data || {});
    if(event.data?.event==='studioWorkspaceSnapshot') workspaceSnapshot(event.data.data || {});
    if(event.data?.event==='accountInfo') {
      const account=event.data.data || {}, roblox=account.roblox || {}, userId=String(roblox.id || '');
      const key=`${account.activeSlot || ''}:${userId}`, changed=key!==state.accountKey;
      const oldKey=state.accountKey;state.accountKey=key;
      if(changed){clearTileCache();}
      if(changed && state.assetType!=='Animations'){resetLoad();hideMedia();notice('Account changed · select the asset again.');updateControls();renderCatalog();}
      if(state.assetType==='Animations' && oldKey&&changed && (state.loaded||state.busy)) {
        stopRemote();resetLoad();notice('Account changed · load an animation again.');updateControls();
      }
      if(state.assetType==='Animations'&&!state.loaded)byId('preview-stage-title').textContent='';
    }
  });
  byId('preview-asset-id').addEventListener('keydown',e=>{if(e.key==='Enter') load();});
  byId('preview-refresh').addEventListener('click',()=>requestCatalog(true));
  let previewSearchTimer;
  byId('preview-search').addEventListener('input',()=>{clearTimeout(previewSearchTimer);previewSearchTimer=setTimeout(renderCatalog,120);});
  byId('preview-type-tabs')?.querySelectorAll('[data-type]').forEach(button=>button.addEventListener('click',()=>setAssetType('Animations',true)));
  byId('preview-play').addEventListener('click',()=>{
    if(state.assetType==='Sounds'){playSound();return;}
    if(state.position>=state.length)state.position=0; state.playing=true; notice('Playing in KAGE');startPlaybackFrames();
  });
  byId('preview-pause').addEventListener('click',()=>{if(state.assetType==='Sounds'){byId('preview-media-audio')?.pause();notice('Paused in KAGE');return;}state.playing=false;notice('Paused in KAGE');});
  byId('preview-stop').addEventListener('click',()=>{
    if(state.assetType!=='Animations' && state.busy){resetLoad();hideMedia();notice('Preview stopped');updateControls();return;}
    if(state.assetType==='Sounds'){const audio=byId('preview-media-audio');audio?.pause();if(audio&&state.loaded)audio.currentTime=0;state.position=0;state.playing=false;notice('Preview stopped');updateControls();return;}
    if(state.remote || state.busy) { stopRemote(); resetLoad(); }
    else {state.playing=false;state.position=0;draw();}
    notice('Preview stopped'); updateControls();
  });
  byId('preview-seek').addEventListener('input',()=>{
    const next=Number(byId('preview-seek').value)||0;
    if(state.assetType==='Sounds'){const audio=byId('preview-media-audio');if(audio&&Number.isFinite(audio.duration))audio.currentTime=Math.max(0,Math.min(audio.duration,next));}
    else {state.position=next;draw();}
    updateControls();
  });
  byId('preview-reset-camera').addEventListener('click',()=>{fitCameraToRig(true);draw();});
  document.querySelectorAll('.tab-btn').forEach(button=>button.addEventListener('click',()=>{
    state.active=button.dataset.tab==='preview';
    if(state.active) {
      // preview.js can load after the original connection event; explicitly request
      // the current native state every time the viewer is entered.
      try { window.chrome.webview.postMessage({action:'getStudioConnectionState'}); } catch {}
      if(state.catalogDirty && state.connected)requestCatalog();
      if(state.assetType!=='Animations'){renderCatalog();pumpTiles();}
      draw();return;
    }
    state.playing=false;
    cancelTileQueue();const sound=tiles.sound;if(sound){sound.playWhenReady=false;byId('preview-media-audio')?.pause();syncSoundTile(sound);}
    if(state.remote || state.busy){stopRemote();resetLoad();notice('Preview stopped');updateControls();}
  },true));
  document.addEventListener('visibilitychange',()=>{if(document.hidden){state.playing=false;byId('preview-media-audio')?.pause();}});
  window.addEventListener('pagehide',()=>{stopRemote();clearTileCache();});
  window.addEventListener('kageQuickPreview',event=>{
    const detail=event.detail||{}; if(!detail.id)return;
    if(!setAssetType(detail.assetType||'Animations',false))return; byId('preview-asset-id').value=String(detail.id); byId('preview-current-name').textContent=detail.name||'Asset'; load();
  });
  const audio=byId('preview-media-audio');
  // pause/load during a media switch can queue callbacks after animation sampling.
  // Those callbacks belong to sound playback and must not alter an animation.
  audio?.addEventListener('loadedmetadata',()=>{if(!currentAudio())return;state.length=Number(audio.duration)||0;state.position=Number(audio.currentTime)||0;updateControls();});
  audio?.addEventListener('timeupdate',()=>{if(!currentAudio())return;state.position=Number(audio.currentTime)||0;state.playing=!audio.paused;updateControls();});
  audio?.addEventListener('play',()=>{if(!currentAudio())return;state.playing=true;notice('Playing sound in KAGE');updateControls();});
  audio?.addEventListener('pause',()=>{if(!currentAudio())return;state.playing=false;updateControls();});
  audio?.addEventListener('ended',()=>{if(!currentAudio())return;state.playing=false;updateControls();});

  function project([x,y,z],w,h) {
    y-=camera.targetY;
    const cx=Math.cos(camera.yaw), sx=Math.sin(camera.yaw), cp=Math.cos(camera.pitch), sp=Math.sin(camera.pitch);
    const rx=x*cx-z*sx, rz=x*sx+z*cx, ry=y*cp-rz*sp, depth=y*sp+rz*cp+camera.distance;
    return [w/2+rx*h/depth,h*0.50-ry*h/depth,depth];
  }
  function signedPow(value,power){return Math.sign(value)*Math.pow(Math.abs(value),power);}
  function pushRoundedHeadFaces(faces,part,pose,w,h){
    // Sampled Studio Head proportions, with smoother classic Roblox-style rounded corners.
    const latSteps=12, lonSteps=24, exp=.78, [sx,sy,sz]=part.size.map(v=>v/2);
    const rings=[];
    for(let lat=0;lat<=latSteps;lat++){
      const v=-Math.PI/2+Math.PI*lat/latSteps, cv=Math.cos(v), sv=Math.sin(v), ring=[];
      for(let lon=0;lon<=lonSteps;lon++){
        const u=Math.PI*2*lon/lonSteps, cu=Math.cos(u), su=Math.sin(u);
        const local=[sx*signedPow(cv,exp)*signedPow(cu,exp),sy*signedPow(sv,exp),sz*signedPow(cv,exp)*signedPow(su,exp)];
        const rotated=math.rotate(local,pose.slice(3));
        ring.push({point:project(rotated.map((value,axis)=>value+pose[axis]),w,h),local});
      }
      rings.push(ring);
    }
    for(let lat=0;lat<latSteps;lat++)for(let lon=0;lon<lonSteps;lon++){
      const cells=[[rings[lat][lon],rings[lat+1][lon],rings[lat+1][lon+1]],[rings[lat][lon],rings[lat+1][lon+1],rings[lat][lon+1]]];
      for(const tri of cells){
        const points=tri.map(v=>v.point);if(points.some(point=>point[2]<=.1))continue;
        const avgZ=tri.reduce((sum,v)=>sum+v.local[2]/Math.max(.001,sz),0)/3;
        const shade=.78+Math.max(-.08,Math.min(.16,avgZ*.12));
        const color=part.color.map(value=>{
          const channel=Math.max(0,Math.min(1,value));
          return Math.round(Math.min(255, 34 + channel * 221 * (shade + .12)));
        });
        faces.push({points,depth:points.reduce((sum,point)=>sum+point[2],0)/3,color,head:true});
      }
    }
  }
  function pushClassicR6HeadFaces(faces,part,pose,w,h){
    // Classic Roblox R6: broad, flat-front/flat-top head with softly beveled
    // corners. The old superellipsoid drew an oval even in R6 mode.
    // Studio's sampled Head pose and dimensions still drive the animation.
    const half=part.size.map(value=>value/2);
    const radius=Math.max(.02,Math.min(...part.size)*.17);
    const inner=half.map(value=>Math.max(0,value-radius));
    const steps=8;
    function roundedPoint(local){
      const center=local.map((value,axis)=>Math.max(-inner[axis],Math.min(inner[axis],value)));
      const delta=local.map((value,axis)=>value-center[axis]);
      const length=Math.hypot(...delta);
      return center.map((value,axis)=>value+(length>1e-8?delta[axis]*radius/length:0));
    }
    // Each side is tessellated so only its outermost bevel bends; the center
    // remains a true plane instead of the stretched elliptical R6 head.
    for(const side of [
      {axis:0,sign:-1,u:1,v:2,shade:.85}, {axis:0,sign:1,u:1,v:2,shade:.93},
      {axis:1,sign:-1,u:0,v:2,shade:.76}, {axis:1,sign:1,u:0,v:2,shade:1.07},
      {axis:2,sign:-1,u:0,v:1,shade:.90}, {axis:2,sign:1,u:0,v:1,shade:1.0}
    ]){
      const grid=[];
      for(let row=0;row<=steps;row++){
        const line=[];
        for(let col=0;col<=steps;col++){
          const local=[0,0,0];
          local[side.axis]=side.sign*half[side.axis];
          local[side.u]=(col/steps*2-1)*half[side.u];
          local[side.v]=(row/steps*2-1)*half[side.v];
          const shape=roundedPoint(local);
          const rotated=math.rotate(shape,pose.slice(3));
          line.push(project(rotated.map((value,axis)=>value+pose[axis]),w,h));
        }
        grid.push(line);
      }
      const color=part.color.map(value=>Math.round(Math.min(255,34+Math.max(0,Math.min(1,value))*221*side.shade)));
      for(let row=0;row<steps;row++)for(let col=0;col<steps;col++){
        const a=grid[row][col],b=grid[row+1][col],c=grid[row+1][col+1],d=grid[row][col+1];
        for(const points of [[a,b,c],[a,c,d]]){
          if(points.some(point=>point[2]<=.1))continue;
          faces.push({points,depth:points.reduce((sum,point)=>sum+point[2],0)/3,color,head:true});
        }
      }
    }
  }
  function draw() {
    if(!context)return;
    const box=canvas.getBoundingClientRect(), w=Math.max(1,box.width), h=Math.max(1,box.height), dpr=Math.min(window.devicePixelRatio||1,2);
    if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);}
    context.setTransform(dpr,0,0,dpr,0,0);context.clearRect(0,0,w,h);
    context.strokeStyle='rgba(255,255,255,.055)';context.lineWidth=1;
    const ground=Number.isFinite(camera.groundY)?camera.groundY:-3;
    for(let i=-6;i<=6;i++)for(const line of [[[i,ground,-6],[i,ground,6]],[[-6,ground,i],[6,ground,i]]]){
      const a=project(line[0],w,h), b=project(line[1],w,h);context.beginPath();context.moveTo(a[0],a[1]);context.lineTo(b[0],b[1]);context.stroke();
    }
    if(!state.data)return;
    const poses=math.poses(state.data,state.position), faces=[];
    const sides=[[0,1,3,2],[4,6,7,5],[0,4,5,1],[2,3,7,6],[0,2,6,4],[1,5,7,3]];
    state.data.parts.forEach((part,index)=>{
      const pose=poses[index];
      if(!pose)return;
      if(part.name==='Head'||part.shape==='head'||part.shape==='sphere'){
        if(state.gameRig==='R6')pushClassicR6HeadFaces(faces,part,pose,w,h);
        else pushRoundedHeadFaces(faces,part,pose,w,h);
        return;
      }
      const corners=Array.from({length:8},(_,corner)=>{
        const local=part.size.map((size,axis)=>((corner&(1<<axis))?1:-1)*size/2);
        const rotated=math.rotate(local,pose.slice(3));
        return project(rotated.map((value,axis)=>value+pose[axis]),w,h);
      });
      sides.forEach((side,face)=>{
        const points=side.map(corner=>corners[corner]);
        if(points.some(point=>point[2]<=.1))return;
        const shade=[.84,.98,.78,1.08,.92,1.02][face];
        const color=part.color.map(value=>{
          const channel=Math.max(0,Math.min(1,value));
          return Math.round(Math.min(255, 32 + channel * 223 * shade));
        });
        faces.push({points,depth:points.reduce((sum,point)=>sum+point[2],0)/4,color});
      });
    });
    faces.sort((a,b)=>b.depth-a.depth);
    for(const face of faces){
      context.beginPath();context.moveTo(face.points[0][0],face.points[0][1]);
      for(const point of face.points.slice(1))context.lineTo(point[0],point[1]);
      context.closePath();context.fillStyle=`rgb(${face.color.join(',')})`;context.fill();
      // Smooth Roblox-style solids, not a triangulated wireframe mannequin.
      if (!face.head) { context.strokeStyle='rgba(255,255,255,.065)'; context.lineWidth=.5; context.stroke(); }
    }
  }

  const rigDropdown=byId('preview-rig-dropdown'), rigTrigger=byId('preview-rig-trigger'), rigMenu=byId('preview-rig-menu');
  function closeRigMenu(){rigDropdown?.classList.remove('open');rigTrigger?.setAttribute('aria-expanded','false');}
  rigTrigger?.addEventListener('click',()=>{const open=!rigDropdown?.classList.contains('open');rigDropdown?.classList.toggle('open',open);rigTrigger.setAttribute('aria-expanded',String(open));});
  rigMenu?.querySelectorAll('[data-value]').forEach(option=>option.addEventListener('click',()=>{selectRigMode(option.dataset.value || 'AUTO',true);closeRigMenu();}));
  document.addEventListener('pointerdown',event=>{
    if(rigDropdown && !rigDropdown.contains(event.target))closeRigMenu();
  });
  syncRigControl();

  for(const surface of [canvas].filter(Boolean)){
    surface.addEventListener('pointerdown',e=>{camera.dragging=true;camera.x=e.clientX;camera.y=e.clientY;surface.setPointerCapture?.(e.pointerId);});
    surface.addEventListener('pointermove',e=>{if(!camera.dragging)return;camera.yaw+=(e.clientX-camera.x)*.01;camera.pitch=Math.max(-.7,Math.min(.7,camera.pitch+(e.clientY-camera.y)*.008));camera.x=e.clientX;camera.y=e.clientY;draw();});
    surface.addEventListener('pointerup',()=>camera.dragging=false);
    surface.addEventListener('pointercancel',()=>camera.dragging=false);
    surface.addEventListener('wheel',e=>{e.preventDefault();camera.distance=Math.max(7,Math.min(24,camera.distance+e.deltaY*.01));draw();},{passive:false});
  }
  window.addEventListener('resize',draw);
  if(window.ResizeObserver)new ResizeObserver(draw).observe(byId('preview-stage'));
  let last=performance.now(), playbackFrame=0;
  function startPlaybackFrames(){
    if(playbackFrame || !state.active || document.hidden || document.body.classList.contains('settings-open') || !state.data || !state.playing)return;
    last=performance.now();
    playbackFrame=requestAnimationFrame(tick);
  }
  function tick(now){
    playbackFrame=0;
    // A frame's timestamp can precede performance.now() when playback starts
    // inside that frame. Never let the first delta move into a negative pose.
    const delta=Math.max(0,Math.min((now-last)/1000,.1));last=now;
    if(state.active && !document.hidden && state.data && state.playing && !document.body.classList.contains('settings-open') && state.length > 0){
      state.position=(state.position+delta)%state.length;
      // The preview is a secondary UI pane: 30 FPS reduces WebView2 pressure
      // while keeping playback and the progress readout responsive.
      if(!tick.lastPaint || now-tick.lastPaint>=33){
        tick.lastPaint=now;
        draw();updateControls();
      }
    }
    if(state.active && !document.hidden && state.data && state.playing && !document.body.classList.contains('settings-open'))playbackFrame=requestAnimationFrame(tick);
  }
  window.addEventListener('kageSettingsVisibility',event=>{if(!event.detail?.open)startPlaybackFrames();});
  updateControls();
  try { window.chrome.webview.postMessage({action:'getAccountInfo'}); } catch {}
})();
