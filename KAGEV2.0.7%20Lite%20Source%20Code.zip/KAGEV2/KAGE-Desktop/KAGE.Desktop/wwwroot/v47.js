// v47 presentation. Native state and authorization remain in the desktop bridge.
(() => {
  'use strict';
  // v49 keeps the top navigation flat inside its single rounded tray.
  // Do not re-parent buttons into separator groups; that created stray vertical lines.
  const home = document.getElementById('tab-home');
  if (home) {
    // v48 owns the Home composition. Keep v47's durable Discord-expiry renderer,
    // but do not re-parent Home content or create an extra footer/card layer.
    const priorUpdate = updateAccountInfo;
    updateAccountInfo = function(data) {
      priorUpdate(data);
      const discord = data?.discord || {};
      const expiry = discord.accessType === 'temporary' && Number.isFinite(Number(discord.accessExpiresAt)) && Number(discord.accessExpiresAt) > 0
        ? `Expires ${new Date(Number(discord.accessExpiresAt)*1000).toLocaleString([], {dateStyle:'medium',timeStyle:'short'})}` : '';
      for (const id of ['home-discord-id','settings-discord-id','user-discord-id']) {
        const node = document.getElementById(id);if (!node) continue;
        node.querySelector('.discord-expiry')?.remove();
        if (expiry) { const tag = document.createElement('span');tag.className='discord-expiry';tag.textContent=expiry;node.append(tag); }
      }
    };
    const close = document.querySelector('.settings-close-label');
    if (close) { close.id='settings-close-label';animateText(close.id,'Close Settings'); }
  }
  // v48 uses a native transparent pre-launch splash so the WebView never flashes behind it.
  if (new URLSearchParams(location.search).get('shadePopout') === '1' || document.body.classList.contains('shade-popout-mode')) return;
})();
