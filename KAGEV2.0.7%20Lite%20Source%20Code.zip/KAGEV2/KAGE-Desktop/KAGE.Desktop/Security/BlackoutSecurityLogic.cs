namespace KAGE.Desktop;

internal static class BlackoutSecurityLogic
{
    internal static bool IsVerificationCodeShape(int length, int digitCount)
    {
        if (NativeSecurityBridge.TryValidateTokenShape(length, digitCount, out var nativeResult))
            return nativeResult;
        return IsVerificationCodeShapeManaged(length, digitCount);
    }

    [BlackoutVirtualize]
    private static bool IsVerificationCodeShapeManaged(int length, int digitCount)
    {
        var lengthOk = (length ^ 6) == 0;
        var digitsOk = (digitCount ^ 6) == 0;
        return lengthOk & digitsOk;
    }
}
