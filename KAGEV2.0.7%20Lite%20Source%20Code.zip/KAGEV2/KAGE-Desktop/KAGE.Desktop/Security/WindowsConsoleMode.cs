using System.Runtime.InteropServices;

namespace Kage.Security;

/// <summary>Prevents accidental legacy-console QuickEdit pauses; restores the caller's mode.</summary>
public sealed class WindowsConsoleMode : IDisposable
{
    private const uint EnableQuickEditMode = 0x0040;
    private const uint EnableExtendedFlags = 0x0080;
    private readonly IntPtr _input;
    private readonly uint _originalMode;
    private bool _changed;

    private WindowsConsoleMode()
    {
        if (!OperatingSystem.IsWindows() || Console.IsInputRedirected) return;
        _input = GetStdHandle(-10);
        if (_input == IntPtr.Zero || _input == new IntPtr(-1)) return;
        if (!GetConsoleMode(_input, out var mode)) return;
        _originalMode = mode;
        _changed = SetConsoleMode(_input, (mode | EnableExtendedFlags) & ~EnableQuickEditMode);
    }

    public static WindowsConsoleMode Begin() => new();

    public void Dispose()
    {
        if (!_changed) return;
        SetConsoleMode(_input, _originalMode);
        _changed = false;
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr GetStdHandle(int handle);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetConsoleMode(IntPtr handle, out uint mode);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetConsoleMode(IntPtr handle, uint mode);
}
