using System.Reflection;

namespace Kage.Security;

/// <summary>Public release configuration. Signing secrets never belong here.</summary>
public static class KageServiceConfiguration
{
    public const string Version = "2.0.7";
    public const string Build = "1791511200";
    public const int ProtocolGeneration = 2;
    public static Uri ServiceBase { get; } = ReadOrigin();

    internal static string Metadata(string name) => typeof(KageServiceConfiguration).Assembly
        .GetCustomAttributes<AssemblyMetadataAttribute>().SingleOrDefault(x => x.Key == name)?.Value ?? "";

    private static Uri ReadOrigin()
    {
        var configured = Metadata("KagePublicGatewayOrigin");
        if (configured.Length == 0) configured = "https://harbor-entry.pages.dev";
        if (!Uri.TryCreate(configured, UriKind.Absolute, out var origin) || origin.Scheme != "https" ||
            !origin.IsDefaultPort || origin.UserInfo.Length != 0 || origin.Query.Length != 0 ||
            origin.Fragment.Length != 0 || origin.AbsolutePath != "/")
            throw new InvalidOperationException("The public service configuration is invalid.");
        return origin;
    }
}
