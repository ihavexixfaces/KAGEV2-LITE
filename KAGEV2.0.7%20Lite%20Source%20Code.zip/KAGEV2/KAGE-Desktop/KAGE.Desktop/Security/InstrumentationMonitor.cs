using System.Diagnostics;
using System.Runtime.InteropServices;

namespace KAGE.Desktop;

internal static class InstrumentationMonitor
{
    internal static IReadOnlyList<SecuritySignal> Collect()
    {
        var signals = new List<SecuritySignal>();

        if (Debugger.IsAttached)
            signals.Add(new SecuritySignal("managed-debugger-attached", SignalConfidence.High, true));

        if (OperatingSystem.IsWindows())
        {
            try
            {
                if (IsDebuggerPresent())
                    signals.Add(new SecuritySignal("native-debugger-present", SignalConfidence.High, true));
            }
            catch
            {
                // A failed observation is not itself evidence of tampering.
            }

            try
            {
                using var process = Process.GetCurrentProcess();
                var remoteDebugger = false;
                if (CheckRemoteDebuggerPresent(process.Handle, ref remoteDebugger) && remoteDebugger)
                    signals.Add(new SecuritySignal("remote-debugger-present", SignalConfidence.High, true));
            }
            catch
            {
                // Best-effort observation only.
            }
        }

        ObserveFlag(signals, "COR_ENABLE_PROFILING", "clr-profiler-enabled");
        ObserveFlag(signals, "CORECLR_ENABLE_PROFILING", "coreclr-profiler-enabled");
        ObservePresence(signals, "COR_PROFILER", "clr-profiler-configured", SignalConfidence.Medium);
        ObservePresence(signals, "CORECLR_PROFILER", "coreclr-profiler-configured", SignalConfidence.Medium);
        ObservePresence(signals, "DOTNET_STARTUP_HOOKS", "dotnet-startup-hooks-configured", SignalConfidence.Medium);
        ObservePresence(signals, "DOTNET_DiagnosticPorts", "dotnet-diagnostic-port-configured", SignalConfidence.Low);

        return signals;
    }

    private static void ObserveFlag(List<SecuritySignal> signals, string variable, string code)
    {
        var value = Environment.GetEnvironmentVariable(variable);
        if (IsTruthy(value))
            signals.Add(new SecuritySignal(code, SignalConfidence.High, true));
    }

    private static void ObservePresence(List<SecuritySignal> signals, string variable, string code, SignalConfidence confidence)
    {
        if (!string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable(variable)))
            signals.Add(new SecuritySignal(code, confidence, true));
    }

    private static bool IsTruthy(string? value) =>
        string.Equals(value, "1", StringComparison.OrdinalIgnoreCase) ||
        string.Equals(value, "true", StringComparison.OrdinalIgnoreCase) ||
        string.Equals(value, "yes", StringComparison.OrdinalIgnoreCase);

    [DllImport("kernel32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool IsDebuggerPresent();

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CheckRemoteDebuggerPresent(IntPtr processHandle, [MarshalAs(UnmanagedType.Bool)] ref bool debuggerPresent);

}
