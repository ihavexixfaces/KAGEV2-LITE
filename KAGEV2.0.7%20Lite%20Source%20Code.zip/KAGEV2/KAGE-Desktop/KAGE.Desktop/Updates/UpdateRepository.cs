using Kage.Security;

namespace KAGE.Desktop.Updates;

internal static class UpdateRepository
{
    private static string ServiceBase => KageServiceConfiguration.ServiceBase.AbsoluteUri.TrimEnd('/');

    public static bool IsConfigured => true;

    public static string LatestReleaseApiUrl =>
        $"{ServiceBase}/api/g2/releases/latest";

    public static string PackageDownloadUrl =>
        $"{ServiceBase}/api/g2/releases/download";

    public static string RepositoryPageUrl => ServiceBase;

    public static string PackageAssetName(string distributionMode) =>
        IsCompact(distributionMode) ? $"KAGE {KageServiceConfiguration.Version}.zip" : $"KAGE {KageServiceConfiguration.Version} Max.zip";

    public static string ManifestAssetName(string distributionMode) =>
        IsCompact(distributionMode) ? $"KAGE {KageServiceConfiguration.Version}.json" : $"KAGE {KageServiceConfiguration.Version} Max.json";

    public static bool IsExpectedPackageName(string distributionMode, string? packageName, string? releaseVersion = null)
    {
        if (string.IsNullOrWhiteSpace(packageName))
            return false;

        var version = releaseVersion ?? KageServiceConfiguration.Version;
        if (!UpdateReleasePolicy.TryVersion(version, out _)) return false;
        return IsCompact(distributionMode)
            ? string.Equals(packageName, $"KAGE {version}.zip", StringComparison.Ordinal)
            : string.Equals(packageName, $"KAGE {version} Max.zip", StringComparison.Ordinal);
    }

    private static bool IsCompact(string distributionMode) =>
        distributionMode.Contains("compact", StringComparison.OrdinalIgnoreCase);
}
