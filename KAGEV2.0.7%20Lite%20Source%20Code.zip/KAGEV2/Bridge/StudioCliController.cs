using System.Diagnostics;

namespace Kage.Bridge;

/// <summary>
/// Wrapper around Roblox Studio's documented command-line interface.
///
/// Important platform limitation (Roblox Creator documentation, Studio CLI):
/// --task RunScript launches a Studio RunScript task and can target a published place
/// or local place file. Roblox does not document a flag that attaches RunScript to an
/// already-running Edit session. KAGE therefore does NOT pretend this can inject into
/// the user's existing editor. The open-place workflow uses Studio's official MCP
/// server instead; RunScript remains available only for isolated CLI tasks where a
/// separate Studio task is safe and expected.
/// </summary>
public sealed class StudioCliController
{
    public string? StudioExecutablePath => StudioExecutableLocator.FindWindowsStudioExecutable();

    public async Task<StudioCliResult> RunInternalProjectProbeAsync(
        long? placeId = null,
        long? universeId = null,
        string? localPlaceFile = null,
        CancellationToken cancellationToken = default)
    {
        using var runtime = new StudioRuntimeDirectory();
        var script = runtime.WriteInternalLuau(StudioInternalLuau.BuildProjectProbe());
        return await RunScriptAsync(script, placeId, universeId, localPlaceFile, quitAfterExecution: true, cancellationToken).ConfigureAwait(false);
    }

    public async Task<StudioCliResult> RunScriptAsync(
        string scriptFile,
        long? placeId = null,
        long? universeId = null,
        string? localPlaceFile = null,
        bool quitAfterExecution = true,
        CancellationToken cancellationToken = default)
    {
        var executable = StudioExecutablePath
            ?? throw new FileNotFoundException("Roblox Studio was not found in the normal per-user installation directory.");
        if (!File.Exists(scriptFile)) throw new FileNotFoundException("The KAGE temporary Luau file was not found.", scriptFile);

        var outputFile = Path.Combine(Path.GetDirectoryName(scriptFile)!, $"studio-output-{Guid.NewGuid():N}.log");
        var start = new ProcessStartInfo
        {
            FileName = executable,
            UseShellExecute = false,
            CreateNoWindow = true
        };
        start.ArgumentList.Add("--task");
        start.ArgumentList.Add("RunScript");
        start.ArgumentList.Add("--runScriptFile");
        start.ArgumentList.Add(Path.GetFullPath(scriptFile));
        start.ArgumentList.Add("--outputFile");
        start.ArgumentList.Add(outputFile);

        if (!string.IsNullOrWhiteSpace(localPlaceFile))
        {
            start.ArgumentList.Add("--localPlaceFile");
            start.ArgumentList.Add(Path.GetFullPath(localPlaceFile));
        }
        else if (placeId is > 0 && universeId is > 0)
        {
            start.ArgumentList.Add("--placeId");
            start.ArgumentList.Add(placeId.Value.ToString());
            start.ArgumentList.Add("--universeId");
            start.ArgumentList.Add(universeId.Value.ToString());
        }

        if (quitAfterExecution) start.ArgumentList.Add("--quitAfterExecution");

        using var process = Process.Start(start) ?? throw new InvalidOperationException("Roblox Studio CLI could not be started.");
        await process.WaitForExitAsync(cancellationToken).ConfigureAwait(false);
        var output = File.Exists(outputFile) ? await File.ReadAllTextAsync(outputFile, cancellationToken).ConfigureAwait(false) : string.Empty;
        try { File.Delete(outputFile); } catch { }
        return new StudioCliResult(process.ExitCode, output);
    }
}

public sealed record StudioCliResult(int ExitCode, string Output);
