using System.Collections.Concurrent;
using System.Globalization;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Kage.Core;

namespace Kage.Roblox;

public sealed class RobloxApiException : Exception
{
    public RobloxApiException(
        string message,
        HttpStatusCode? statusCode = null,
        string? safeDetails = null,
        TimeSpan? retryAfter = null,
        string? category = null)
        : base(message)
    {
        StatusCode = statusCode;
        SafeDetails = safeDetails;
        RetryAfter = retryAfter;
        Category = category ?? Classify(statusCode);
    }

    public HttpStatusCode? StatusCode { get; }
    public string? SafeDetails { get; }
    public TimeSpan? RetryAfter { get; }
    public string Category { get; }

    private static string Classify(HttpStatusCode? code) => code switch
    {
        HttpStatusCode.TooManyRequests => "RateLimited",
        HttpStatusCode.Unauthorized => "Authentication",
        HttpStatusCode.Forbidden => "PermissionDenied",
        HttpStatusCode.NotFound => "NotFound",
        HttpStatusCode.RequestTimeout => "Transient",
        HttpStatusCode.InternalServerError => "Transient",
        HttpStatusCode.BadGateway => "Transient",
        HttpStatusCode.ServiceUnavailable => "Transient",
        HttpStatusCode.GatewayTimeout => "Transient",
        _ => "RobloxApi"
    };
}

public static class SecretUtil
{
    private static readonly Regex CookiePattern = new(
        """(?i)(\.ROBLOSECURITY\s*[=:"']?\s*)([^\s"';,&}]+)""",
        RegexOptions.CultureInvariant | RegexOptions.Compiled);
    private static readonly Regex HeaderPattern = new(
        """(?i)("?(?:x-api-key|api[_-]?key|authorization)"?\s*[:=]\s*"?)([^",\s}\r\n]+)""",
        RegexOptions.CultureInvariant | RegexOptions.Compiled);
    private static readonly Regex BearerPattern = new(
        @"(?i)(Bearer\s+)[A-Za-z0-9._~+\-/=]+",
        RegexOptions.CultureInvariant | RegexOptions.Compiled);

    public static string RedactSecrets(string text)
    {
        if (string.IsNullOrEmpty(text)) return string.Empty;
        var redacted = CookiePattern.Replace(text, "$1<redacted>");
        redacted = HeaderPattern.Replace(redacted, "$1<redacted>");
        return BearerPattern.Replace(redacted, "$1<redacted>");
    }

    public static string SafeBody(string body)
    {
        var redacted = RedactSecrets(body);
        return redacted.Length <= 1200 ? redacted : redacted[..1200];
    }
}

/// <summary>
/// Official Open Cloud asset pipeline. Download, create, operation polling, and
/// validation use separate quota gates so a busy endpoint does not freeze the
/// entire job. The optional session cookie is only used for one normal
/// authenticated download attempt; it never tries unrelated place IDs.
/// </summary>
public sealed class RobloxOpenCloudClient : IDisposable
{
    private const string ApiBase = "https://apis.roblox.com";
    private const int MaximumAssetBytes = 20 * 1024 * 1024;

    private readonly HttpClient _api;
    private readonly HttpClient _cdn;
    private readonly HttpClient? _authenticated;
    private readonly HttpClient _bulkApi;
    private readonly RateLimitCoordinator _deliveryRate = new(inFlightReserve: 24);
    private readonly RateLimitCoordinator _createRate;
    private readonly RateLimitCoordinator _operationRate = new(inFlightReserve: 64, proactiveQuotaPauses: false);
    private readonly RateLimitCoordinator _validationRate = new(inFlightReserve: 8);
    private readonly SemaphoreSlim _createSlots;
    private readonly SemaphoreSlim _operationSlots = new(32, 32);
    private readonly PacedRequestGate _createPacer;
    private readonly PacedRequestGate _operationPacer;
    private readonly ConcurrentDictionary<string, (long PlaceId, DateTimeOffset CachedAt)> _preferredPlaceByCreator = new();
    private static readonly TimeSpan PreferredPlaceTtl = TimeSpan.FromMinutes(10);

    private bool TryGetPreferredPlace(string key, out long placeId)
    {
        if (_preferredPlaceByCreator.TryGetValue(key, out var entry) &&
            DateTimeOffset.UtcNow - entry.CachedAt < PreferredPlaceTtl && entry.PlaceId > 0)
        {
            placeId = entry.PlaceId;
            return true;
        }
        placeId = 0;
        return false;
    }

    private void SetPreferredPlace(string key, long placeId)
    {
        if (placeId > 0)
            _preferredPlaceByCreator[key] = (placeId, DateTimeOffset.UtcNow);
    }
    private readonly ConcurrentDictionary<string, long[]> _creatorPlacesCache = new();
    private readonly ConcurrentDictionary<string, SemaphoreSlim> _creatorPlaceLocks = new();
    private readonly ConcurrentDictionary<long, AssetRoute> _assetRoutes = new();
    private readonly ConcurrentDictionary<long, string> _originalAssetNames = new();
    private readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web)
    {
        PropertyNameCaseInsensitive = true
    };

    private sealed record AssetRoute(Uri Location, long PlaceId);

    public RobloxOpenCloudClient(
        string apiKey,
        string? robloSecurity,
        int createRequestConcurrency = 96,
        double createRequestsPerMinute = 118,
        double operationRequestsPerMinute = 96)
    {
        if (string.IsNullOrWhiteSpace(apiKey))
            throw new ArgumentException("An Open Cloud API key is required.", nameof(apiKey));

        var boundedCreateConcurrency = Math.Clamp(createRequestConcurrency, 1, 96);
        var boundedCreateRpm = Math.Clamp(createRequestsPerMinute, 30, 119);
        var boundedOperationRpm = Math.Clamp(operationRequestsPerMinute, 30, 99);
        _createSlots = new SemaphoreSlim(boundedCreateConcurrency);
        _createRate = new RateLimitCoordinator(
            inFlightReserve: boundedCreateConcurrency,
            proactiveQuotaPauses: false);
        _createPacer = new PacedRequestGate(boundedCreateRpm);
        _operationPacer = new PacedRequestGate(boundedOperationRpm);
        _api = CreateClient(apiKey, allowRedirect: false, timeout: TimeSpan.FromSeconds(45));
        _cdn = CreateClient(null, allowRedirect: false, timeout: TimeSpan.FromSeconds(35));
        _bulkApi = CreateClient(null, allowRedirect: false, timeout: TimeSpan.FromSeconds(25));

        if (!string.IsNullOrWhiteSpace(robloSecurity))
        {
            var cookieValue = robloSecurity.Trim();
            if (cookieValue.StartsWith(".ROBLOSECURITY=", StringComparison.OrdinalIgnoreCase))
                cookieValue = cookieValue[".ROBLOSECURITY=".Length..];
            cookieValue = cookieValue.Trim().Trim('"');
            if (string.IsNullOrWhiteSpace(cookieValue) || cookieValue.Contains(';'))
                throw new ArgumentException("The Roblox cookie value is not valid.", nameof(robloSecurity));

            var cookies = new CookieContainer();
            cookies.Add(new Cookie(".ROBLOSECURITY", cookieValue, "/", ".roblox.com")
            {
                Secure = true,
                HttpOnly = true
            });

            _authenticated = CreateClient(
                null,
                allowRedirect: true,
                timeout: TimeSpan.FromSeconds(20),
                cookies: cookies);
                
        }
    }

    private string? _csrfToken;
    
    private async Task<string> GetCsrfTokenAsync(CancellationToken ct)
    {
        if (_csrfToken != null)
            return _csrfToken;
            
        if (_authenticated is null)
            throw new RobloxApiException("No Roblox session cookie configured.", category: "Authentication");
        
        // Get CSRF token by intentionally triggering a 403
        using var request = new HttpRequestMessage(HttpMethod.Post, "https://auth.roblox.com/v2/logout");
        request.Content = new StringContent("{}", Encoding.UTF8, "application/json");
        
        using var response = await _authenticated.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);
        var token = response.Headers.TryGetValues("x-csrf-token", out var values) ? values.FirstOrDefault() : null;
        
        if (string.IsNullOrWhiteSpace(token))
            throw new RobloxApiException("Failed to retrieve CSRF token from Roblox.", category: "Authentication");
        
        _csrfToken = token;
        return token;
    }

    public long RateLimitHits =>
        _deliveryRate.RateLimitHits + _createRate.RateLimitHits +
        _operationRate.RateLimitHits + _validationRate.RateLimitHits;

    public long ProactiveRatePauses =>
        _deliveryRate.ProactivePauses + _createRate.ProactivePauses +
        _operationRate.ProactivePauses + _validationRate.ProactivePauses;

    /// <summary>
    /// Returns true if a Roblox session cookie is configured, enabling the fast
    /// legacy IDE upload endpoint for private/unauthorized assets.
    /// </summary>
    public bool HasAuthenticatedSession => _authenticated is not null;

    public async Task<RobloxProfile?> GetAuthenticatedProfileAsync(CancellationToken ct = default)
    {
        if (_authenticated is null)
            return null;

        using var response = await _authenticated.GetAsync(
            "https://users.roblox.com/v1/users/authenticated",
            HttpCompletionOption.ResponseHeadersRead,
            ct);
        var body = await response.Content.ReadAsStringAsync(ct);
        if (!response.IsSuccessStatusCode)
            throw new RobloxApiException(
                $"Authenticated profile request failed with {(int)response.StatusCode} {response.ReasonPhrase}.",
                response.StatusCode,
                SecretUtil.SafeBody(body));

        using var document = JsonDocument.Parse(body);
        if (!document.RootElement.TryGetProperty("id", out var idElement) ||
            !idElement.TryGetInt64(out var userId) ||
            userId <= 0)
            throw new RobloxApiException(
                "Roblox returned an authenticated response without a valid user ID.",
                response.StatusCode,
                SecretUtil.SafeBody(body),
                category: "InvalidResponse");

        var username = document.RootElement.TryGetProperty("name", out var nameElement)
            ? nameElement.GetString() ?? string.Empty
            : string.Empty;
        var displayName = document.RootElement.TryGetProperty("displayName", out var displayElement)
            ? displayElement.GetString() ?? username
            : username;

        string? avatarUrl = null;
        using var avatarResponse = await _authenticated.GetAsync(
            $"https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds={userId}&size=150x150&format=Png&isCircular=false",
            HttpCompletionOption.ResponseHeadersRead,
            ct);
        if (avatarResponse.IsSuccessStatusCode)
        {
            var avatarBody = await avatarResponse.Content.ReadAsStringAsync(ct);
            using var avatarDocument = JsonDocument.Parse(avatarBody);
            if (avatarDocument.RootElement.TryGetProperty("data", out var data) &&
                data.ValueKind == JsonValueKind.Array &&
                data.GetArrayLength() > 0 &&
                data[0].TryGetProperty("imageUrl", out var imageUrl))
                avatarUrl = imageUrl.GetString();
        }

        return new RobloxProfile(userId, username, displayName, avatarUrl);
    }

    public async Task<string?> GetAvatarBodyThumbnailAsync(long userId, CancellationToken ct = default)
    {
        if (userId <= 0) return null;
        using var response = await _api.GetAsync(
            $"https://thumbnails.roblox.com/v1/users/avatar?userIds={userId}&size=352x352&format=Png&isCircular=false",
            HttpCompletionOption.ResponseHeadersRead,
            ct).ConfigureAwait(false);
        if (!response.IsSuccessStatusCode) return null;
        var body = await response.Content.ReadAsStringAsync(ct).ConfigureAwait(false);
        using var document = JsonDocument.Parse(body);
        if (document.RootElement.TryGetProperty("data", out var data) && data.ValueKind == JsonValueKind.Array && data.GetArrayLength() > 0 &&
            data[0].TryGetProperty("imageUrl", out var imageUrl) && imageUrl.ValueKind == JsonValueKind.String)
            return imageUrl.GetString();
        return null;
    }

    /// <summary>
    /// Resolve the published experience/place name instead of trusting Studio's
    /// local DataModel name (which is often just Game1/Game2 for opened files).
    /// Roblox's Games API is the primary source; authenticated place details are
    /// used as a fallback for sub-places. The Studio-reported name remains the
    /// final fallback so unpublished/local projects still have a label.
    /// </summary>

    public async Task<string> ResolveExperienceNameAsync(
        long placeId,
        long universeId,
        string? studioReportedName,
        CancellationToken ct = default)
    {
        static string? CleanName(string? value)
        {
            if (string.IsNullOrWhiteSpace(value)) return null;
            var trimmed = value.Trim();
            return trimmed.Length > 160 ? trimmed[..160] : trimmed;
        }

        static bool LooksLikeInvalidExperienceName(string? value)
        {
            var name = CleanName(value);
            if (name is null) return true;
            if (name.Equals("Title unavailable", StringComparison.OrdinalIgnoreCase)) return true;

            var compact = new string(name.Where(char.IsLetterOrDigit).ToArray()).ToLowerInvariant();
            if (compact is "titleunavailable" or "unavailable" or "untitled" or "unknown" or
                "game" or "place" or "studio" or "studioproject")
                return true;

            if (compact.StartsWith("game") && compact.Length > 4 && compact[4..].All(char.IsDigit))
                return true;
            if (compact.StartsWith("place") && compact.Length > 5 && compact[5..].All(char.IsDigit))
                return true;

            return false;
        }

        if (universeId > 0)
        {
            try
            {
                using var response = await _bulkApi.GetAsync(
                    $"https://games.roblox.com/v1/games?universeIds={universeId}",
                    HttpCompletionOption.ResponseHeadersRead,
                    ct);
                if (response.IsSuccessStatusCode)
                {
                    var body = await response.Content.ReadAsStringAsync(ct);
                    using var document = JsonDocument.Parse(body);
                    if (document.RootElement.TryGetProperty("data", out var data) &&
                        data.ValueKind == JsonValueKind.Array &&
                        data.GetArrayLength() > 0 &&
                        data[0].TryGetProperty("name", out var nameElement))
                    {
                        var name = CleanName(nameElement.GetString());
                        if (!LooksLikeInvalidExperienceName(name)) return name!;
                    }
                }
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                throw;
            }
            catch
            {
                // Fall through to place details / Studio name.
            }
        }

        // Open Cloud universe metadata can return the canonical display name for
        // private/owned universes when the public Games API only exposes a placeholder.
        if (universeId > 0)
        {
            try
            {
                using var response = await _api.GetAsync(
                    $"https://apis.roblox.com/cloud/v2/universes/{universeId}",
                    HttpCompletionOption.ResponseHeadersRead,
                    ct);
                if (response.IsSuccessStatusCode)
                {
                    var body = await response.Content.ReadAsStringAsync(ct);
                    using var document = JsonDocument.Parse(body);
                    if (document.RootElement.ValueKind == JsonValueKind.Object)
                    {
                        string? candidate = null;
                        if (document.RootElement.TryGetProperty("displayName", out var displayNameElement))
                            candidate = displayNameElement.GetString();
                        else if (document.RootElement.TryGetProperty("name", out var nameElement))
                            candidate = nameElement.GetString();

                        var name = CleanName(candidate);
                        if (!LooksLikeInvalidExperienceName(name)) return name!;
                    }
                }
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                throw;
            }
            catch
            {
                // Fall through to the public develop endpoint / place details.
            }
        }

        // Public universe metadata is a second source for the published experience
        // title. This catches cases where games.roblox.com returns placeholder text
        // such as "Title unavailable" even though the universe itself has a name.
        if (universeId > 0)
        {
            try
            {
                using var response = await _bulkApi.GetAsync(
                    $"https://develop.roblox.com/v1/universes/{universeId}",
                    HttpCompletionOption.ResponseHeadersRead,
                    ct);
                if (response.IsSuccessStatusCode)
                {
                    var body = await response.Content.ReadAsStringAsync(ct);
                    using var document = JsonDocument.Parse(body);
                    if (document.RootElement.ValueKind == JsonValueKind.Object)
                    {
                        string? candidate = null;
                        if (document.RootElement.TryGetProperty("name", out var nameElement))
                            candidate = nameElement.GetString();
                        else if (document.RootElement.TryGetProperty("displayName", out var displayNameElement))
                            candidate = displayNameElement.GetString();

                        var name = CleanName(candidate);
                        if (!LooksLikeInvalidExperienceName(name)) return name!;
                    }
                }
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                throw;
            }
            catch
            {
                // Fall through to authenticated place details / Studio name.
            }
        }

        if (placeId > 0 && _authenticated is not null)
        {
            try
            {
                using var response = await _authenticated.GetAsync(
                    $"https://games.roblox.com/v1/games/multiget-place-details?placeIds={placeId}",
                    HttpCompletionOption.ResponseHeadersRead,
                    ct);
                if (response.IsSuccessStatusCode)
                {
                    var body = await response.Content.ReadAsStringAsync(ct);
                    using var document = JsonDocument.Parse(body);
                    if (document.RootElement.ValueKind == JsonValueKind.Array &&
                        document.RootElement.GetArrayLength() > 0 &&
                        document.RootElement[0].TryGetProperty("name", out var nameElement))
                    {
                        var name = CleanName(nameElement.GetString());
                        if (!LooksLikeInvalidExperienceName(name)) return name!;
                    }
                    else if (document.RootElement.ValueKind == JsonValueKind.Object &&
                             document.RootElement.TryGetProperty("data", out var data) &&
                             data.ValueKind == JsonValueKind.Array &&
                             data.GetArrayLength() > 0 &&
                             data[0].TryGetProperty("name", out var dataNameElement))
                    {
                        var name = CleanName(dataNameElement.GetString());
                        if (!LooksLikeInvalidExperienceName(name)) return name!;
                    }
                }
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                throw;
            }
            catch
            {
                // Fall through to Studio name.
            }
        }

        var studioName = CleanName(studioReportedName);
        if (!LooksLikeInvalidExperienceName(studioName))
            return studioName;

        return placeId > 0 ? $"Place {placeId}" : "Studio Project";
    }

    /// <summary>
    /// Matches META/KAGE-Copy's bulk route discovery: resolve creators in chunks,
    /// then ask the batch endpoint for up to 50 assets at each creator place.
    /// </summary>
    public async Task PrepareAssetRoutesAsync(
        long[] assetIds,
        long currentPlaceId,
        CancellationToken ct = default)
    {
        if (_authenticated is null || assetIds.Length == 0)
            return;

        var metadata = new ConcurrentDictionary<long, AssetInfo>();
        var metadataTasks = assetIds
            .Distinct()
            .Chunk(50)
            .Select(async chunk =>
            {
                foreach (var asset in await GetBulkAssetInfoAsync(chunk, ct))
                {
                    metadata[asset.Id] = asset;
                    if (!string.IsNullOrWhiteSpace(asset.Name)) _originalAssetNames[asset.Id] = asset.Name;
                }
            })
            .ToArray();
        await Task.WhenAll(metadataTasks);

        var creatorAssets = metadata.Values
            .Select(asset =>
            {
                var creator = asset.Creator;
                var creatorId = creator is null ? 0 : creator.TargetId > 0 ? creator.TargetId : creator.Id;
                var creatorType = creator?.Type?.Equals("group", StringComparison.OrdinalIgnoreCase) == true
                    ? "group"
                    : "user";
                return (asset, creatorId, creatorType);
            })
            .Where(x => x.creatorId > 0)
            .GroupBy(x => $"{x.creatorType}:{x.creatorId}");

        var creatorTasks = creatorAssets.Select(async group =>
        {
            var first = group.First();
            var places = await GetCachedCreatorPlacesAsync(
                group.Key,
                first.creatorType,
                first.creatorId,
                ct);

            var candidates = new List<long>();
            if (currentPlaceId > 0)
                candidates.Add(currentPlaceId);
            candidates.AddRange(places);
            candidates.AddRange(FallbackPlaceIds);
            var candidatePlaces = candidates.Where(x => x > 0).Distinct().ToArray();
            var remaining = group.Select(x => x.asset.Id).Distinct().ToHashSet();

            foreach (var placeId in candidatePlaces)
            {
                if (remaining.Count == 0)
                    break;

                var batchIds = remaining.ToArray();
                var responses = await Task.WhenAll(batchIds.Chunk(50).Select(
                    chunk => GetAssetLocationsAsync(chunk, placeId, ct)));

                foreach (var responseBatch in responses)
                {
                    foreach (var response in responseBatch)
                    {
                        if (response.Locations is null || response.Locations.Length == 0)
                            continue;

                        var location = response.Locations
                            .Select(x => x.Location)
                            .FirstOrDefault(x => !string.IsNullOrWhiteSpace(x));
                        if (string.IsNullOrWhiteSpace(location) ||
                            !Uri.TryCreate(location, UriKind.Absolute, out var uri))
                            continue;

                        var assetId = ParseBatchAssetId(response.RequestId);
                        if (assetId <= 0 || !remaining.Remove(assetId))
                            continue;

                        _assetRoutes[assetId] = new AssetRoute(uri, placeId);
                        SetPreferredPlace(group.Key, placeId);
                    }
                }
            }
        }).ToArray();

        await Task.WhenAll(creatorTasks);
    }

    public async Task TestApiKeyAsync(CancellationToken ct = default)
    {
        using var response = await GetApiWithRetryAsync(
            $"{ApiBase}/asset-delivery-api/v1/assetId/1818",
            "Open Cloud asset-read check failed. In Creator Hub, add Assets access with Read and Write permissions for the intended creator.",
            _deliveryRate,
            ct,
            maxAttempts: 3);

        var body = await response.Content.ReadAsStringAsync(ct);
        try
        {
            var ticket = JsonSerializer.Deserialize<AssetDeliveryTicket>(body, _json);
            if (ticket is null || string.IsNullOrWhiteSpace(ticket.Location))
                throw new RobloxApiException("Open Cloud authenticated, but Asset Delivery did not return a content location.");
        }
        catch (JsonException ex)
        {
            throw new RobloxApiException($"Open Cloud returned an unexpected API-key test response: {ex.Message}");
        }
    }

    public async Task<byte[]> DownloadAssetAsync(
        long assetId,
        string assetType,
        long contextPlaceId = 0,
        CancellationToken ct = default)
    {
        if (!assetType.Equals("Animation", StringComparison.OrdinalIgnoreCase) &&
            !assetType.Equals("Animations", StringComparison.OrdinalIgnoreCase))
            throw new RobloxApiException("KAGE Lite downloads animation assets only.", category: "Unsupported");
        return await DownloadAnimationAsync(assetId, contextPlaceId, ct);
    }

    public async Task<byte[]> DownloadAnimationAsync(
        long assetId,
        long contextPlaceId = 0,
        CancellationToken ct = default)
    {
        if (_authenticated is not null &&
            _assetRoutes.TryGetValue(assetId, out var route))
        {
            try
            {
                return ValidateAssetBytes(
                    await DownloadTrustedAssetContentAsync(
                        route.Location,
                        assetId,
                        ct,
                        _authenticated,
                        route.PlaceId),
                    assetId);
            }
            catch
            {
                _assetRoutes.TryRemove(assetId, out _);
            }
        }

        // Try place-context batch API first if we have a place ID
        if (_authenticated is not null && contextPlaceId > 0)
        {
            try
            {
                var bytes = await DownloadViaPlaceAsync(assetId, contextPlaceId, ct);
                if (bytes is not null)
                    return ValidateAssetBytes(bytes, assetId);
            }
            catch
            {
                // Fall through to other methods
            }
        }

        // Try Open Cloud API
        try
        {
            using var response = await GetApiWithRetryAsync(
                $"{ApiBase}/asset-delivery-api/v1/assetId/{assetId}",
                $"Animation {assetId} could not be fetched with this Open Cloud API key.",
                _deliveryRate,
                ct,
                maxAttempts: 2);

            var body = await response.Content.ReadAsStringAsync(ct);
            var ticket = JsonSerializer.Deserialize<AssetDeliveryTicket>(body, _json);
            
            if (!string.IsNullOrWhiteSpace(ticket?.Location))
            {
                if (Uri.TryCreate(ticket.Location, UriKind.Absolute, out var uri) && uri.Scheme == Uri.UriSchemeHttps)
                {
                    var bytes = await DownloadTrustedAssetContentAsync(uri, assetId, ct);
                    return ValidateAssetBytes(bytes, assetId);
                }
            }
        }
        catch
        {
            // Fall through
        }

        // Try authenticated download
        if (_authenticated is not null)
        {
            try
            {
                var bytes = await DownloadAuthenticatedAsync(assetId, ct);
                return ValidateAssetBytes(bytes, assetId);
            }
            catch
            {
                // Fall through
            }
        }

        // Try asset version probe (versions 1-5)
        if (_authenticated is not null)
        {
            try
            {
                var versionBytes = await DownloadViaAssetVersionsAsync(assetId, ct);
                if (versionBytes is not null)
                    return ValidateAssetBytes(versionBytes, assetId);
            }
            catch
            {
                // Fall through
            }
        }

        // All methods failed - caller (engine) will try DownloadViaCreatorPlacesAsync
        throw new RobloxApiException(
            $"Animation {assetId} is not downloadable with current context.",
            category: "PermissionDenied");
    }

    public async Task<long> CreateAnimationAsync(
        byte[] bytes,
        CreatorKind creatorKind,
        long creatorId,
        string displayName,
        long contextPlaceId = 0,
        CancellationToken ct = default)
    {
        // If we have an authenticated session, use the fast legacy upload endpoint
        // which returns the asset ID immediately (no polling needed) and supports
        // private/unauthorized assets.
        if (_authenticated is not null)
        {
            var assetId = await CreateAnimationViaLegacyAsync(bytes, creatorKind, creatorId, displayName, ct);
            return assetId;
        }

        // Fall back to Open Cloud API path
        var operation = await SubmitAnimationCreateAsync(bytes, creatorKind, creatorId, displayName, contextPlaceId, ct);
        return await CompleteAnimationCreateAsync(operation, ct);
    }

    public Task<AssetOperation> SubmitAnimationCreateAsync(
        byte[] bytes,
        CreatorKind creatorKind,
        long creatorId,
        string displayName,
        long contextPlaceId,
        CancellationToken ct)
        => SubmitAssetCreateAsync(bytes, creatorKind, creatorId, displayName, "Animation", contextPlaceId, ct);

    public async Task<AssetOperation> SubmitAssetCreateAsync(
        byte[] bytes,
        CreatorKind creatorKind,
        long creatorId,
        string displayName,
        string assetType,
        long contextPlaceId,
        CancellationToken ct)
    {
        if (!assetType.Equals("Animation", StringComparison.OrdinalIgnoreCase) || creatorKind != CreatorKind.User)
            throw new RobloxApiException("KAGE Lite creates animation assets for the connected Roblox account only.", category: "Unsupported");
        assetType = "Animation";
        RobloxApiException? final = null;
        var maxAttempts = 7;
        var nameRetried = false;

        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            // Authenticated META/KAGE-Copy mode uses burst concurrency. For API-key-only
            // mode, retain the documented client-side pacing.
            if (_authenticated is null)
                await _createPacer.WaitAsync(ct);
            await _createRate.WaitAsync(ct);
            await _createSlots.WaitAsync(ct);

            HttpResponseMessage? response = null;
            string body = string.Empty;
            TimeSpan? serverDelay = null;
            try
            {
                using var request = BuildCreateAssetRequest(bytes, creatorKind, creatorId, displayName, assetType, contextPlaceId);
                response = await _api.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);
                serverDelay = _createRate.Observe(response);
                body = await response.Content.ReadAsStringAsync(ct);
            }
            catch (HttpRequestException ex)
            {
                // A create POST can be accepted even if the response is lost. Avoid a blind
                // resend that could duplicate the animation. Surface it for the report.
                throw new RobloxApiException(
                    $"The upload connection failed before KAGE received Roblox's create response: {ex.Message}",
                    category: "Network");
            }
            catch (TaskCanceledException) when (!ct.IsCancellationRequested)
            {
                throw new RobloxApiException(
                    "The upload request timed out before KAGE received Roblox's create response.",
                    category: "Timeout");
            }
            finally
            {
                _createSlots.Release();
            }

            using (response)
            {
                if (response.IsSuccessStatusCode)
                {
                    try
                    {
                        return JsonSerializer.Deserialize<AssetOperation>(body, _json)
                               ?? throw new RobloxApiException("Roblox returned an empty asset-operation response.");
                    }
                    catch (JsonException ex)
                    {
                        throw new RobloxApiException($"Roblox returned an invalid asset-operation response: {ex.Message}");
                    }
                }

                if (assetType.Equals("Animation", StringComparison.OrdinalIgnoreCase) && !nameRetried &&
                    displayName != AnimationNamePolicy.ModeratedName && AnimationNamePolicy.IsNameRejection(response.StatusCode, body))
                {
                    displayName = AnimationNamePolicy.ModeratedName;
                    nameRetried = true;
                    if (attempt == maxAttempts) maxAttempts++;
                    continue;
                }

                var apiError = BuildApiException(
                    response,
                    body,
                    $"Roblox rejected the {assetType} upload. Check that the API key has Assets Write permission and can create assets for this destination.");

                final = apiError;
                if (!IsRetryable(response.StatusCode) || attempt >= maxAttempts)
                    throw apiError;

                if (response.StatusCode == HttpStatusCode.TooManyRequests)
                {
                    // A 429 is safe to retry because Roblox rejected this create
                    // request. Keep the asset in the retry queue instead of turning
                    // a temporary window exhaustion into a terminal job failure.
                    maxAttempts = 30;
                    // Long/global pauses are allowed only when Observe() found authoritative
                    // server guidance (Retry-After or explicit remaining==0). A bare 429 uses
                    // short per-worker jittered backoff so one stability throttle cannot freeze
                    // the whole create pipeline for a minute.
                    if (serverDelay.HasValue)
                        _createRate.PauseFor(serverDelay.Value);
                    else
                        await Task.Delay(Backoff(attempt), ct);
                }
                else
                {
                    await Task.Delay(Backoff(attempt), ct);
                }
            }
        }

        throw final ?? new RobloxApiException("Roblox rejected the animation upload.");
    }

    /// <summary>
    /// Resolves an already-submitted create operation to its final asset ID. Kept separate
    /// from submission so polling never occupies a create slot or an upload worker.
    /// </summary>
    public Task<long> CompleteAssetCreateAsync(AssetOperation operation, CancellationToken ct = default)
    {
        // Legacy upload endpoint returns the asset ID immediately - no polling needed.
        // We check if the operation path indicates it was from the legacy endpoint.
        if (operation.Path?.Contains("ide/publish") == true || operation.Done)
        {
            // Already complete or from legacy endpoint - try to read the asset ID
            if (TryReadAssetId(operation, out var assetId))
                return Task.FromResult(assetId);
        }
        
        // Fall back to normal polling for Open Cloud API uploads
        return WaitForAssetIdAsync(operation, ct);
    }

    // Compatibility name retained for older animation-only call sites.
    public Task<long> CompleteAnimationCreateAsync(AssetOperation operation, CancellationToken ct = default)
        => CompleteAssetCreateAsync(operation, ct);

    /// <summary>
    /// Legacy upload endpoint - MUCH faster! Returns asset ID immediately with no polling.
    /// This is what META uses and why it's so fast.
    /// </summary>
    private async Task<long> CreateAnimationViaLegacyAsync(
        byte[] bytes,
        CreatorKind creatorKind,
        long creatorId,
        string displayName,
        CancellationToken ct)
    {
        if (_authenticated is null)
            throw new RobloxApiException("Legacy upload requires a Roblox session cookie.", category: "Authentication");

        var csrf = await GetCsrfTokenAsync(ct);
        var nameRetried = false;
        var maxAttempts = 5;
        
        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            await _createSlots.WaitAsync(ct);
            
            try
            {
                var url = "https://www.roblox.com/ide/publish/uploadnewanimation" +
                         $"?assetTypeName=Animation" +
                         $"&name={Uri.EscapeDataString(SanitizeName(displayName))}" +
                         $"&description={Uri.EscapeDataString("Animation reuploaded using KAGE")}" +
                         $"&ispublic=false" +
                         $"&allowComments=true" +
                         $"&isGamesAsset=false";
                

                using var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Content = new ByteArrayContent(bytes);
                request.Content.Headers.ContentType = new MediaTypeHeaderValue("model/x-rbxm");
                request.Headers.TryAddWithoutValidation("X-CSRF-TOKEN", csrf);
                request.Headers.TryAddWithoutValidation("User-Agent", "RobloxStudio/WinInet");
                request.Headers.TryAddWithoutValidation("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");

                using var response = await _authenticated.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);
                var bodyText = await response.Content.ReadAsStringAsync(ct);

                // Check for CSRF token refresh
                if (response.StatusCode == HttpStatusCode.Forbidden || response.StatusCode == (HttpStatusCode)403)
                {
                    var newToken = response.Headers.TryGetValues("x-csrf-token", out var values) ? values.FirstOrDefault() : null;
                    if (!string.IsNullOrWhiteSpace(newToken))
                    {
                        _csrfToken = newToken;
                        csrf = newToken;
                        await Task.Delay(100, ct); // Brief pause before retry
                        continue;
                    }
                }

                if (!response.IsSuccessStatusCode)
                {
                    // Handle moderation (name flagged)
                    if (!nameRetried && displayName != AnimationNamePolicy.ModeratedName &&
                        AnimationNamePolicy.IsNameRejection(response.StatusCode, bodyText))
                    {
                        displayName = AnimationNamePolicy.ModeratedName;
                        nameRetried = true;
                        if (attempt == maxAttempts) maxAttempts++;
                        await Task.Delay(200, ct);
                        continue;
                    }
                    
                    throw new RobloxApiException(
                        $"Legacy upload failed with status {response.StatusCode}: {bodyText.Substring(0, Math.Min(100, bodyText.Length))}",
                        response.StatusCode);
                }

                // Legacy endpoint returns just the asset ID as plain text!
                var assetIdText = bodyText.Trim();
                if (long.TryParse(assetIdText, out var assetId) && assetId > 0)
                    return assetId;

                throw new RobloxApiException($"Legacy upload returned invalid asset ID: {assetIdText}");
            }
            catch (HttpRequestException ex)
            {
                if (attempt >= maxAttempts)
                    throw new RobloxApiException($"Legacy upload connection failed: {ex.Message}", category: "Network");
                    
                await Task.Delay(Backoff(attempt), ct);
            }
            finally
            {
                _createSlots.Release();
            }
        }

        throw new RobloxApiException("Legacy upload failed after maximum retries.");
    }

    private async Task<long> WaitForAssetIdAsync(AssetOperation operation, CancellationToken ct)
    {
        var current = operation;
        var started = DateTimeOffset.UtcNow;
        var pollNumber = 0;
        var transientFailures = 0;

        while (DateTimeOffset.UtcNow - started < TimeSpan.FromMinutes(15))
        {
            if (current.Done)
            {
                if (current.Error is not null)
                    throw new RobloxApiException(
                        $"Roblox asset processing failed: {current.Error.Message ?? "Unknown error"}",
                        category: "ProcessingFailed");

                if (TryReadAssetId(current, out var assetId))
                    return assetId;

                throw new RobloxApiException("Roblox completed the operation but did not return a new asset ID.");
            }

            var operationId = current.Path?.Split('/', StringSplitOptions.RemoveEmptyEntries).LastOrDefault();
            if (string.IsNullOrWhiteSpace(operationId))
                throw new RobloxApiException("Roblox returned an invalid operation path.");

            pollNumber++;
            // Fast first checks improve worker turnover for the common short operation,
            // then the interval relaxes so long operations do not waste polling quota.
            var pollDelayMs = _authenticated is not null
                ? (pollNumber == 1 ? 150 : 250)
                : pollNumber switch
                {
                    1 => 1_000,
                    2 => 1_500,
                    3 => 2_000,
                    _ => 3_000
                };

            await Task.Delay(TimeSpan.FromMilliseconds(pollDelayMs), ct);
            if (_authenticated is null)
                await _operationPacer.WaitAsync(ct);
            await _operationRate.WaitAsync(ct);
            await _operationSlots.WaitAsync(ct);

            HttpResponseMessage? response = null;
            string body = string.Empty;
            TimeSpan? serverDelay = null;
            try
            {
                response = await _api.GetAsync(
                    $"{ApiBase}/assets/v1/operations/{Uri.EscapeDataString(operationId)}",
                    HttpCompletionOption.ResponseHeadersRead,
                    ct);
                serverDelay = _operationRate.Observe(response);
                body = await response.Content.ReadAsStringAsync(ct);
            }
            catch (HttpRequestException) when (transientFailures < 10)
            {
                transientFailures++;
                await Task.Delay(Backoff(Math.Min(transientFailures, 5)), ct);
                continue;
            }
            catch (TaskCanceledException) when (!ct.IsCancellationRequested && transientFailures < 10)
            {
                transientFailures++;
                await Task.Delay(Backoff(Math.Min(transientFailures, 5)), ct);
                continue;
            }
            finally
            {
                _operationSlots.Release();
            }

            using (response)
            {
                if (!response.IsSuccessStatusCode)
                {
                    var error = BuildApiException(response, body, "Could not poll the Roblox asset operation.");
                    if (IsTransient(error) && transientFailures < 10)
                    {
                        transientFailures++;
                        if (response.StatusCode == HttpStatusCode.TooManyRequests)
                        {
                            if (serverDelay.HasValue)
                                _operationRate.PauseFor(serverDelay.Value);
                            else
                                await Task.Delay(Backoff(Math.Min(transientFailures, 5)), ct);
                        }
                        else
                        {
                            await Task.Delay(Backoff(Math.Min(transientFailures, 5)), ct);
                        }
                        continue;
                    }
                    throw error;
                }

                transientFailures = 0;
                try
                {
                    current = JsonSerializer.Deserialize<AssetOperation>(body, _json)
                              ?? throw new RobloxApiException("Roblox returned an invalid operation response.");
                }
                catch (JsonException ex)
                {
                    throw new RobloxApiException($"Roblox returned an invalid operation response: {ex.Message}");
                }
            }
        }

        throw new TimeoutException("Roblox accepted the upload but the operation was still pending after fifteen minutes.");
    }

    public async Task ValidateAnimationAsync(long assetId, CancellationToken ct = default)
    {
        for (var attempt = 1; attempt <= 5; attempt++)
        {
            await _validationRate.WaitAsync(ct);
            using var response = await _api.GetAsync(
                $"{ApiBase}/assets/v1/assets/{assetId}",
                HttpCompletionOption.ResponseHeadersRead,
                ct);
            var serverDelay = _validationRate.Observe(response);
            if (response.IsSuccessStatusCode) return;

            var body = await response.Content.ReadAsStringAsync(ct);
            var error = BuildApiException(response, body, $"New animation {assetId} could not be verified.");
            if ((response.StatusCode == HttpStatusCode.NotFound || IsTransient(error)) && attempt < 5)
            {
                var delay = serverDelay ?? error.RetryAfter ?? Backoff(attempt);
                _validationRate.PauseFor(delay);
                continue;
            }
            throw error;
        }
    }

    private async Task<byte[]> DownloadAuthenticatedAsync(long assetId, CancellationToken ct)
    {
        if (_authenticated is null)
            throw new RobloxApiException("No Roblox account session is configured.", category: "Authentication");

        using var request = new HttpRequestMessage(HttpMethod.Get, $"https://assetdelivery.roblox.com/v2/asset?id={assetId}");
        request.Headers.TryAddWithoutValidation("User-Agent", "RobloxStudio/WinInet");
        request.Headers.TryAddWithoutValidation("Roblox-Browser-Asset-Request", "1");
        using var response = await _authenticated.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);

        if (!response.IsSuccessStatusCode)
        {
            // Fallback to v1 endpoint
            try
            {
                using var reqV1 = new HttpRequestMessage(HttpMethod.Get, $"https://assetdelivery.roblox.com/v1/asset/?id={assetId}");
                reqV1.Headers.TryAddWithoutValidation("User-Agent", "RobloxStudio/WinInet");
                using var resV1 = await _authenticated.SendAsync(reqV1, HttpCompletionOption.ResponseHeadersRead, ct);
                if (resV1.IsSuccessStatusCode)
                {
                    var v1Bytes = await resV1.Content.ReadAsByteArrayAsync(ct);
                    if (v1Bytes.Length > 0) return v1Bytes;
                }
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested) { throw; }
            catch { }

            var body = await response.Content.ReadAsStringAsync(ct);
            throw BuildApiException(response, body, $"Authenticated download failed for animation {assetId}.");
        }

        var mediaType = response.Content.Headers.ContentType?.MediaType;
        if (mediaType?.Contains("json", StringComparison.OrdinalIgnoreCase) == true)
        {
            var body = await response.Content.ReadAsStringAsync(ct);
            AssetDeliveryTicket? ticket = null;
            try { ticket = JsonSerializer.Deserialize<AssetDeliveryTicket>(body, _json); }
            catch (JsonException) { }

            if (ticket is null || string.IsNullOrWhiteSpace(ticket.Location) ||
                !Uri.TryCreate(ticket.Location, UriKind.Absolute, out var uri))
                throw new RobloxApiException($"Authenticated download returned no content for animation {assetId}.", category: "PermissionDenied");

            return await DownloadTrustedAssetContentAsync(uri, assetId, ct);
        }

        return await response.Content.ReadAsByteArrayAsync(ct);
    }

    private async Task<byte[]> DownloadTrustedAssetContentAsync(
        Uri initialUri,
        long assetId,
        CancellationToken ct,
        HttpClient? client = null,
        long contextPlaceId = 0)
    {
        client ??= _cdn;
        Exception? final = null;
        for (var attempt = 1; attempt <= 3; attempt++)
        {
            try
            {
                var current = initialUri;
                for (var redirect = 0; redirect <= 5; redirect++)
                {
                    if (current.Scheme != Uri.UriSchemeHttps || !IsTrustedAssetContentHost(current.Host))
                        throw new RobloxApiException($"Refusing unexpected asset-content host: {current.Host}", category: "Security");

                    using var request = new HttpRequestMessage(HttpMethod.Get, current);
                    request.Headers.TryAddWithoutValidation("User-Agent", "RobloxStudio/WinInet");
                    if (contextPlaceId > 0)
                        request.Headers.TryAddWithoutValidation("Roblox-Place-Id", contextPlaceId.ToString(CultureInfo.InvariantCulture));

                    using var response = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);
                    if ((int)response.StatusCode is >= 300 and < 400)
                    {
                        var location = response.Headers.Location
                            ?? throw new RobloxApiException($"Asset redirect for {assetId} had no Location header.", response.StatusCode);
                        current = location.IsAbsoluteUri ? location : new Uri(current, location);
                        continue;
                    }

                    if (!response.IsSuccessStatusCode)
                    {
                        var body = await response.Content.ReadAsStringAsync(ct);
                        var error = BuildApiException(response, body, $"Asset content download failed for {assetId}.");
                        if (IsTransient(error) && attempt < 3)
                        {
                            final = error;
                            break;
                        }
                        throw error;
                    }

                    return await response.Content.ReadAsByteArrayAsync(ct);
                }
            }
            catch (HttpRequestException ex) when (attempt < 3)
            {
                final = ex;
            }

            await Task.Delay(Backoff(attempt), ct);
        }

        throw final switch
        {
            RobloxApiException api => api,
            Exception ex => new RobloxApiException($"Asset content download failed for {assetId}: {ex.Message}", category: "Transient"),
            _ => new RobloxApiException($"Asset content download failed for {assetId}.")
        };
    }

    private async Task<HttpResponseMessage> GetApiWithRetryAsync(
        string url,
        string errorMessage,
        RateLimitCoordinator rate,
        CancellationToken ct,
        int maxAttempts)
    {
        RobloxApiException? final = null;
        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            await rate.WaitAsync(ct);
            HttpResponseMessage response;
            try
            {
                response = await _api.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, ct);
            }
            catch (HttpRequestException) when (attempt < maxAttempts)
            {
                await Task.Delay(Backoff(attempt), ct);
                continue;
            }

            var serverDelay = rate.Observe(response);
            if (response.IsSuccessStatusCode) return response;

            var body = await response.Content.ReadAsStringAsync(ct);
            var error = BuildApiException(response, body, errorMessage);
            final = error;
            if (!IsTransient(error) || attempt >= maxAttempts)
            {
                response.Dispose();
                throw error;
            }

            var retryStatus = response.StatusCode;
            response.Dispose();
            if (retryStatus == HttpStatusCode.TooManyRequests && !serverDelay.HasValue)
                await Task.Delay(Backoff(attempt), ct);
            else if (serverDelay.HasValue)
                rate.PauseFor(serverDelay.Value);
            else
                await Task.Delay(Backoff(attempt), ct);
        }

        throw final ?? new RobloxApiException(errorMessage);
    }

    private HttpRequestMessage BuildCreateAssetRequest(
        byte[] bytes,
        CreatorKind creatorKind,
        long creatorId,
        string displayName,
        string assetType,
        long contextPlaceId = 0)
    {
        if (!assetType.Equals("Animation", StringComparison.OrdinalIgnoreCase) || creatorKind != CreatorKind.User)
            throw new RobloxApiException("KAGE Lite supports animation uploads to the connected account only.", category: "Unsupported");
        const string normalizedType = "Animation";
        var creator = new Dictionary<string, string> { ["userId"] = creatorId.ToString(CultureInfo.InvariantCulture) };

        var metadata = new
        {
            assetType = normalizedType,
            displayName = SanitizeName(displayName),
            description = $"{normalizedType} reuploaded from an authorized Roblox Studio project using KAGE.",
            creationContext = new { creator }
        };

        var (mimeType, fileName) = GetCreateAssetFileMetadata(normalizedType, bytes);

        var form = new MultipartFormDataContent();
        form.Add(new StringContent(JsonSerializer.Serialize(metadata, _json), Encoding.UTF8, "application/json"), "request");
        var file = new ByteArrayContent(bytes);
        file.Headers.ContentType = new MediaTypeHeaderValue(mimeType);
        form.Add(file, "fileContent", fileName);

        var request = new HttpRequestMessage(HttpMethod.Post, $"{ApiBase}/assets/v1/assets") { Content = form };
        if (contextPlaceId > 0 && _authenticated is not null)
            request.Headers.TryAddWithoutValidation("Roblox-Place-Id", contextPlaceId.ToString(CultureInfo.InvariantCulture));

        return request;
    }

    private static HttpClient CreateClient(
        string? apiKey,
        bool allowRedirect,
        TimeSpan timeout,
        CookieContainer? cookies = null)
    {
        var handler = new SocketsHttpHandler
        {
            AutomaticDecompression = DecompressionMethods.All,
            PooledConnectionLifetime = TimeSpan.FromMinutes(10),
            PooledConnectionIdleTimeout = TimeSpan.FromMinutes(2),
            MaxConnectionsPerServer = 256,  // Increased from 96 for ultra-fast mode
            AllowAutoRedirect = allowRedirect,
            EnableMultipleHttp2Connections = true,
            ConnectTimeout = TimeSpan.FromSeconds(8),
            UseCookies = cookies is not null,
            CookieContainer = cookies ?? new CookieContainer()
        };

        var client = new HttpClient(handler)
        {
            Timeout = timeout,
            DefaultRequestVersion = HttpVersion.Version20,
            DefaultVersionPolicy = HttpVersionPolicy.RequestVersionOrLower
        };
        client.DefaultRequestHeaders.UserAgent.ParseAdd("KAGE-Studio-Bridge/2.0.4-DeferredApply");
        if (!string.IsNullOrWhiteSpace(apiKey))
            client.DefaultRequestHeaders.TryAddWithoutValidation("x-api-key", apiKey);
        return client;
    }

    private static (string MimeType, string FileName) GetCreateAssetFileMetadata(string normalizedType, byte[] bytes)
    {
        if (!normalizedType.Equals("Animation", StringComparison.OrdinalIgnoreCase))
            throw new RobloxApiException("KAGE Lite supports animation assets only.", category: "Unsupported");
        return ("model/x-rbxm", "animation.rbxm");
    }

    private static byte[] ValidateAssetBytes(byte[] bytes, long assetId)
    {
        if (bytes.Length == 0)
            throw new RobloxApiException($"Animation {assetId} returned an empty asset file.", category: "InvalidContent");
        if (bytes.Length > MaximumAssetBytes)
            throw new RobloxApiException($"Animation {assetId} exceeds the 20 MB upload limit.", category: "Unsupported");

        // Do not require an XML header here. Roblox delivery can return a
        // compressed/binary RBXM representation, and Meta passes the returned
        // bytes directly to the uploader.
        return bytes;
    }

    private static bool TryReadAssetId(AssetOperation operation, out long assetId)
    {
        if (long.TryParse(operation.Response?.AssetId, out assetId) && assetId > 0)
            return true;
        var last = operation.Response?.Path?.Split('/', StringSplitOptions.RemoveEmptyEntries).LastOrDefault();
        return long.TryParse(last, out assetId) && assetId > 0;
    }

    private static bool IsTrustedAssetContentHost(string host) =>
        host.Equals("contentdelivery.roblox.com", StringComparison.OrdinalIgnoreCase) ||
        host.Equals("assetdelivery.roblox.com", StringComparison.OrdinalIgnoreCase) ||
        host.Equals("www.roblox.com", StringComparison.OrdinalIgnoreCase) ||
        host.Equals("rbxcdn.com", StringComparison.OrdinalIgnoreCase) ||
        host.EndsWith(".rbxcdn.com", StringComparison.OrdinalIgnoreCase) ||
        host.Equals("roblox.com", StringComparison.OrdinalIgnoreCase) ||
        host.EndsWith(".roblox.com", StringComparison.OrdinalIgnoreCase);

    private static bool IsTransient(RobloxApiException ex) =>
        ex.StatusCode is HttpStatusCode.TooManyRequests or
            HttpStatusCode.RequestTimeout or
            HttpStatusCode.InternalServerError or
            HttpStatusCode.BadGateway or
            HttpStatusCode.ServiceUnavailable or
            HttpStatusCode.GatewayTimeout ||
        ex.Category == "Transient";

    private static bool IsRetryable(HttpStatusCode status) =>
        status is HttpStatusCode.TooManyRequests or
            HttpStatusCode.RequestTimeout or
            HttpStatusCode.InternalServerError or
            HttpStatusCode.BadGateway or
            HttpStatusCode.ServiceUnavailable or
            HttpStatusCode.GatewayTimeout;

    private static TimeSpan Backoff(int attempt)
    {
        var capped = Math.Clamp(attempt, 1, 6);
        // Ultra-fast backoff - we have many workers, so individual failures are fine
        var milliseconds = Math.Min(150 * Math.Pow(1.5, capped - 1), 3_000);
        return TimeSpan.FromMilliseconds(milliseconds + Random.Shared.Next(50, 150));
    }

    private static RobloxApiException BuildApiException(HttpResponseMessage response, string body, string message)
    {
        var safeBody = SecretUtil.SafeBody(body);
        var detail = string.IsNullOrWhiteSpace(safeBody)
            ? $"HTTP {(int)response.StatusCode} ({response.StatusCode})"
            : $"HTTP {(int)response.StatusCode} ({response.StatusCode}): {safeBody}";
        return new RobloxApiException(
            $"{message} {detail}",
            response.StatusCode,
            safeBody,
            RateLimitCoordinator.GetServerDelay(response));
    }

    private static string SanitizeName(string value)
    {
        var clean = new string((value ?? string.Empty).Where(c => !char.IsControl(c)).ToArray()).Trim();
        if (string.IsNullOrWhiteSpace(clean)) clean = "KAGE Animation";
        return clean.Length <= 50 ? clean : clean[..50];
    }

    private static readonly long[] FallbackPlaceIds = new[] 
    { 
        99840799534728L, 4483381587L, 606849621L, 1818L,
        6872265039L,   // Blox Fruits
        2788229376L,   // Adopt Me
        1537690962L,   // Brookhaven RP
        189747L,       // Natural Disaster Survival
        920587237L,    // Jailbreak
        3233893879L,   // Tower of Hell
        4924922222L,   // Piggy
        142823291L,    // Welcome to Bloxburg
        537413528L,    // MeepCity
        155615604L,    // Royale High
        2534724415L,   // Arsenal
        418604670L,    // Murder Mystery 2
        292439477L,    // Work at a Pizza Place
        2366396024L,   // Shindo Life
        3959853457L,   // Anime Fighters
        724919552L,    // Roblox High School 2
        2753915549L,   // Anime Dimensions
        3016661674L    // Sonic Speed Sim
    };

    /// <summary>
    /// Download via creator place search - KAGE-Copy strategy.
    /// Gets asset creator info, finds all their places + fallbacks, tries each until success.
    /// PUBLIC so AnimationReuploadEngine can call it directly as a fallback.
    /// </summary>
    public async Task<string> ResolveOriginalAssetNameAsync(long assetId, string fallback, CancellationToken ct)
    {
        if (_originalAssetNames.TryGetValue(assetId, out var cached)) return cached;
        if (_authenticated is not null)
        {
            foreach (var asset in await GetBulkAssetInfoAsync(new[] { assetId }, ct))
                if (!string.IsNullOrWhiteSpace(asset.Name)) _originalAssetNames[asset.Id] = asset.Name;
            if (_originalAssetNames.TryGetValue(assetId, out cached)) return cached;
        }
        return fallback;
    }

    public async Task<byte[]?> DownloadViaAssetVersionsAsync(long assetId, CancellationToken ct)
    {
        if (_authenticated is null) return null;
        for (var v = 1; v <= 5; v++)
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                using var req = new HttpRequestMessage(HttpMethod.Get, $"https://assetdelivery.roblox.com/v1/asset?id={assetId}&version={v}");
                req.Headers.TryAddWithoutValidation("User-Agent", "RobloxStudio/WinInet");
                using var res = await _authenticated.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);
                if (res.IsSuccessStatusCode)
                {
                    var bytes = await res.Content.ReadAsByteArrayAsync(ct);
                    if (bytes.Length > 0) return ValidateAssetBytes(bytes, assetId);
                }
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested) { throw; }
            catch { }
        }
        return null;
    }

    public async Task<byte[]?> DownloadViaCreatorPlacesAsync(long assetId, CancellationToken ct, long contextPlaceId = 0)
    {
        if (_authenticated is null)
            return null;

        try
        {
            var assetInfo = await GetBulkAssetInfoAsync(new[] { assetId }, ct);
            if (assetInfo.Length == 0 || assetInfo[0].Creator is null)
                return null;

            var creator = assetInfo[0].Creator;
            var creatorId = creator.TargetId > 0 ? creator.TargetId : creator.Id;
            if (creatorId <= 0)
                return null;
            var creatorType = creator.Type?.ToLowerInvariant() == "group" ? "group" : "user";
            var creatorKey = $"{creatorType}:{creatorId}";

            // Build candidate list: context place + creator places + fallback places
            var candidatePlaces = new List<long>();
            var seen = new HashSet<long>();

            if (contextPlaceId > 0 && seen.Add(contextPlaceId))
                candidatePlaces.Add(contextPlaceId);

            var places = await GetCachedCreatorPlacesAsync(creatorKey, creatorType, creatorId, ct);
            foreach (var placeId in places)
            {
                if (placeId > 0 && seen.Add(placeId)) candidatePlaces.Add(placeId);
            }
            
            foreach (var fallbackId in FallbackPlaceIds)
            {
                if (seen.Add(fallbackId)) candidatePlaces.Add(fallbackId);
            }

            // Try preferred place first if we have one cached
            if (TryGetPreferredPlace(creatorKey, out var preferredPlace))
            {
                if (candidatePlaces.Contains(preferredPlace))
                {
                    var preferredBytes = await DownloadViaPlaceAsync(assetId, preferredPlace, ct);
                    if (preferredBytes is not null)
                        return preferredBytes;
                    
                    candidatePlaces.Remove(preferredPlace);
                    _preferredPlaceByCreator.TryRemove(creatorKey, out _);
                }
            }

            // Parallel dispatch across candidate places in batches of 6 using Task.WhenAny
            var attemptedPlaces = 0;
            string? lastFailure = null;

            foreach (var batch in candidatePlaces.Chunk(6))
            {
                ct.ThrowIfCancellationRequested();
                using var batchCts = CancellationTokenSource.CreateLinkedTokenSource(ct);
                var tasks = batch.Select(async pid =>
                {
                    attemptedPlaces++;
                    var bytes = await DownloadViaPlaceAsync(assetId, pid, batchCts.Token);
                    return (PlaceId: pid, Bytes: bytes);
                }).ToList();

                while (tasks.Count > 0)
                {
                    var finished = await Task.WhenAny(tasks);
                    tasks.Remove(finished);
                    try
                    {
                        var res = await finished;
                        if (res.Bytes is not null && res.Bytes.Length > 0)
                        {
                            batchCts.Cancel();
                            SetPreferredPlace(creatorKey, res.PlaceId);
                            return res.Bytes;
                        }
                    }
                    catch (OperationCanceledException) when (ct.IsCancellationRequested)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        lastFailure = ex.Message;
                    }
                }
            }

            if (attemptedPlaces > 0 && !string.IsNullOrWhiteSpace(lastFailure))
            {
                throw new RobloxApiException(
                    $"Animation {assetId} could not be delivered through {attemptedPlaces} creator place(s). Last delivery error: {lastFailure}",
                    category: "PermissionDenied");
            }
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            throw;
        }
        catch (RobloxApiException ex) when (ex.Category == "PermissionDenied")
        {
            throw;
        }
        catch
        {
            // Return null so the caller can surface the original permission error.
        }

        return null;
    }

    private async Task<long[]> GetCachedCreatorPlacesAsync(
        string creatorKey,
        string creatorType,
        long creatorId,
        CancellationToken ct)
    {
        if (_creatorPlacesCache.TryGetValue(creatorKey, out var cached))
            return cached;

        var gate = _creatorPlaceLocks.GetOrAdd(creatorKey, _ => new SemaphoreSlim(1, 1));
        await gate.WaitAsync(ct);
        try
        {
            if (_creatorPlacesCache.TryGetValue(creatorKey, out cached))
                return cached;

            var places = await GetCreatorPlacesAsync(creatorType, creatorId, ct);
            if (places.Length > 0)
                _creatorPlacesCache[creatorKey] = places;
            return places;
        }
        finally
        {
            gate.Release();
        }
    }

    private async Task<byte[]?> DownloadViaPlaceAsync(long assetId, long placeId, CancellationToken ct)
    {
        if (_authenticated is null || placeId <= 0)
            return null;

        var locations = await GetAssetLocationsAsync(new[] { assetId }, placeId, ct);
        if (locations.Length > 0 && locations[0].Locations is not null && locations[0].Locations.Length > 0)
        {
            foreach (var location in locations[0].Locations)
            {
                var locationUrl = location.Location;
                if (string.IsNullOrWhiteSpace(locationUrl) ||
                    !Uri.TryCreate(locationUrl, UriKind.Absolute, out var uri))
                    continue;

                try
                {
                    return await DownloadTrustedAssetContentAsync(
                        uri,
                        assetId,
                        ct,
                        _authenticated,
                        placeId);
                }
                catch (OperationCanceledException) when (ct.IsCancellationRequested)
                {
                    throw;
                }
                catch
                {
                    // Fall through to other locations or direct endpoints
                }
            }
        }

        // Direct fallback 1: assetdelivery v2 with serverplaceid query parameter
        try
        {
            using var reqV2 = new HttpRequestMessage(HttpMethod.Get, $"https://assetdelivery.roblox.com/v2/asset?id={assetId}&serverplaceid={placeId}");
            reqV2.Headers.TryAddWithoutValidation("User-Agent", "RobloxStudio/WinInet");
            reqV2.Headers.TryAddWithoutValidation("Roblox-Place-Id", placeId.ToString(CultureInfo.InvariantCulture));
            reqV2.Headers.TryAddWithoutValidation("Roblox-Browser-Asset-Request", "1");
            using var resV2 = await _authenticated.SendAsync(reqV2, HttpCompletionOption.ResponseHeadersRead, ct);
            if (resV2.IsSuccessStatusCode)
            {
                var mediaType = resV2.Content.Headers.ContentType?.MediaType;
                if (mediaType?.Contains("json", StringComparison.OrdinalIgnoreCase) == true)
                {
                    var body = await resV2.Content.ReadAsStringAsync(ct);
                    AssetDeliveryTicket? ticket = null;
                    try { ticket = JsonSerializer.Deserialize<AssetDeliveryTicket>(body, _json); } catch { }
                    if (ticket is not null && !string.IsNullOrWhiteSpace(ticket.Location) &&
                        Uri.TryCreate(ticket.Location, UriKind.Absolute, out var uri))
                    {
                        return await DownloadTrustedAssetContentAsync(uri, assetId, ct, _authenticated, placeId);
                    }
                }
                else
                {
                    var rawBytes = await resV2.Content.ReadAsByteArrayAsync(ct);
                    if (rawBytes.Length > 0) return rawBytes;
                }
            }
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested) { throw; }
        catch { }

        // Direct fallback 2: assetdelivery v1 with serverplaceid
        try
        {
            using var reqV1 = new HttpRequestMessage(HttpMethod.Get, $"https://assetdelivery.roblox.com/v1/asset/?id={assetId}&serverplaceid={placeId}");
            reqV1.Headers.TryAddWithoutValidation("User-Agent", "RobloxStudio/WinInet");
            reqV1.Headers.TryAddWithoutValidation("Roblox-Place-Id", placeId.ToString(CultureInfo.InvariantCulture));
            using var resV1 = await _authenticated.SendAsync(reqV1, HttpCompletionOption.ResponseHeadersRead, ct);
            if (resV1.IsSuccessStatusCode)
            {
                var rawBytes = await resV1.Content.ReadAsByteArrayAsync(ct);
                if (rawBytes.Length > 0) return rawBytes;
            }
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested) { throw; }
        catch { }

        return null;
    }

    /// <summary>
    /// Get bulk asset information for multiple assets (META-style optimization)
    /// </summary>
    private async Task<AssetInfo[]> GetBulkAssetInfoAsync(long[] assetIds, CancellationToken ct)
    {
        if (assetIds.Length == 0)
            return Array.Empty<AssetInfo>();

        try
        {
            var idsParam = string.Join(",", assetIds);
            using var response = await _authenticated!.GetAsync(
                $"https://develop.roblox.com/v1/assets?assetIds={idsParam}",
                HttpCompletionOption.ResponseHeadersRead,
                ct);

            if (!response.IsSuccessStatusCode)
                return Array.Empty<AssetInfo>();

            var body = await response.Content.ReadAsStringAsync(ct);
            var result = JsonSerializer.Deserialize<BulkAssetResponse>(body, _json);
            return result?.Data ?? Array.Empty<AssetInfo>();
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested) { throw; }
        catch
        {
            return Array.Empty<AssetInfo>();
        }
    }

    /// <summary>
    /// Get place IDs from a creator (user or group) - KAGE-Copy strategy
    /// </summary>
    private async Task<long[]> GetCreatorPlacesAsync(string creatorType, long creatorId, CancellationToken ct)
    {
        var places = new List<long>();
        
        try
        {
            var maxPlaces = creatorType == "group" ? 100 : 50;
            var url = creatorType == "group"
                ? $"https://games.roblox.com/v2/groups/{creatorId}/gamesV2?limit={maxPlaces}"
                : $"https://games.roblox.com/v2/users/{creatorId}/games?sortOrder=Asc&limit={maxPlaces}";

            async Task<string?> AddGamesAsync(string gamesUrl)
            {
                using var response = await _authenticated!.GetAsync(gamesUrl, HttpCompletionOption.ResponseHeadersRead, ct);
                if (!response.IsSuccessStatusCode)
                    return null;

                var body = await response.Content.ReadAsStringAsync(ct);
                var result = JsonSerializer.Deserialize<GamesResponse>(body, _json);
                if (result?.Data != null)
                {
                    foreach (var game in result.Data)
                    {
                        if (game.RootPlace?.Id > 0)
                            places.Add(game.RootPlace.Id);
                    }
                }
                try
                {
                    using var document = JsonDocument.Parse(body);
                    return document.RootElement.TryGetProperty("nextPageCursor", out var cursor) &&
                           cursor.ValueKind == JsonValueKind.String
                        ? cursor.GetString()
                        : null;
                }
                catch (JsonException)
                {
                    return null;
                }
            }

            var firstUrl = creatorType == "group"
                ? $"https://games.roblox.com/v2/groups/{creatorId}/gamesV2?limit={maxPlaces}"
                : $"https://games.roblox.com/v2/users/{creatorId}/games?sortOrder=Asc&limit={maxPlaces}";
            var nextCursor = await AddGamesAsync(firstUrl);
            if (creatorType == "group" && !string.IsNullOrWhiteSpace(nextCursor) && places.Count < maxPlaces)
            {
                var nextUrl = $"https://games.roblox.com/v2/groups/{creatorId}/gamesV2?limit={maxPlaces}&cursor={Uri.EscapeDataString(nextCursor)}";
                await AddGamesAsync(nextUrl);
            }

            if (creatorType == "group" && places.Count == 0)
            {
                var developerUrl = $"https://develop.roblox.com/v1/groups/{creatorId}/universes?limit={Math.Min(maxPlaces, 50)}";
                using var developerResponse = await _authenticated.GetAsync(
                    developerUrl,
                    HttpCompletionOption.ResponseHeadersRead,
                    ct);
                if (developerResponse.IsSuccessStatusCode)
                {
                    var body = await developerResponse.Content.ReadAsStringAsync(ct);
                    using var document = JsonDocument.Parse(body);
                    if (document.RootElement.TryGetProperty("data", out var data))
                    {
                        foreach (var universe in data.EnumerateArray())
                        {
                            if (universe.TryGetProperty("rootPlaceId", out var rootPlaceId) &&
                                rootPlaceId.TryGetInt64(out var id) && id > 0)
                                places.Add(id);
                        }
                    }
                }
            }
        }
        catch
        {
            // Return empty array on failure
        }

        return places.ToArray();
    }

    /// <summary>
    /// Get asset locations via batch API with specific place ID (META-style)
    /// </summary>
    private async Task<AssetBatchResponse[]> GetAssetLocationsAsync(long[] assetIds, long placeId, CancellationToken ct)
    {
        if (assetIds.Length == 0)
            return Array.Empty<AssetBatchResponse>();

        try
        {
            var body = assetIds.Select(id => new { assetId = id, requestId = $"kage-{id}" }).ToArray();
            var json = JsonSerializer.Serialize(body, _json);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            using var request = new HttpRequestMessage(HttpMethod.Post, "https://assetdelivery.roblox.com/v2/assets/batch")
            {
                Content = content
            };
            request.Headers.TryAddWithoutValidation("User-Agent", "RobloxStudio/WinInet");
            request.Headers.TryAddWithoutValidation("Roblox-Place-Id", placeId.ToString(CultureInfo.InvariantCulture));
            request.Headers.TryAddWithoutValidation("Roblox-Session-Id", Guid.NewGuid().ToString());
            request.Headers.TryAddWithoutValidation("Roblox-Browser-Asset-Request", "1");

            using var response = await _authenticated!.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);
            if (!response.IsSuccessStatusCode)
                return Array.Empty<AssetBatchResponse>();

            var responseBody = await response.Content.ReadAsStringAsync(ct);
            var result = JsonSerializer.Deserialize<AssetBatchResponse[]>(responseBody, _json);
            return result ?? Array.Empty<AssetBatchResponse>();
        }
        catch
        {
            return Array.Empty<AssetBatchResponse>();
        }
    }

    private static long ParseBatchAssetId(string? requestId)
    {
        if (string.IsNullOrWhiteSpace(requestId))
            return 0;

        var digits = new string(requestId.Where(char.IsDigit).ToArray());
        return long.TryParse(digits, NumberStyles.None, CultureInfo.InvariantCulture, out var id)
            ? id
            : 0;
    }

    public void Dispose()
    {
        _api.Dispose();
        _cdn.Dispose();
        _authenticated?.Dispose();
        _bulkApi.Dispose();
        _createSlots.Dispose();
        _operationSlots.Dispose();
        _createPacer.Dispose();
        _operationPacer.Dispose();
        foreach (var gate in _creatorPlaceLocks.Values)
            gate.Dispose();
    }
}
