using System.Text.Json;
using Kage.Core;

namespace KAGE.Desktop;

internal sealed record StoredAccountProfile(
    int Slot,
    long UserId,
    string UserName,
    string DisplayName,
    string? AvatarUrl);

internal sealed record AccountState(int ActiveSlot, List<StoredAccountProfile> Accounts);

internal static class AccountManager
{
    private static readonly string DataDirectory = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "KAGE", "Data");
    private static readonly string StatePath = Path.Combine(DataDirectory, "accounts.json");
    private static readonly object Sync = new();

    public static AccountState LoadState()
    {
        lock (Sync)
        {
            try
            {
                if (File.Exists(StatePath))
                {
                    var state = JsonSerializer.Deserialize<AccountState>(File.ReadAllText(StatePath));
                    if (state is not null)
                    {
                        var clean = state.Accounts
                            .Where(a => a.Slot is 1 or 2)
                            .GroupBy(a => a.Slot)
                            .Select(g => g.Last())
                            .OrderBy(a => a.Slot)
                            .Take(2)
                            .ToList();
                        var active = clean.Any(a => a.Slot == state.ActiveSlot)
                            ? state.ActiveSlot
                            : clean.FirstOrDefault()?.Slot ?? 1;
                        return new AccountState(active, clean);
                    }
                }
            }
            catch { }
            return new AccountState(1, new List<StoredAccountProfile>());
        }
    }

    public static void MigrateLegacyCredentialsIfNeeded()
    {
        var state = LoadState();
        if (state.Accounts.Count > 0)
            return;

        if (!CredentialProtection.TryRead("Cookie", out var cookie) ||
            !CredentialProtection.TryRead("OpenCloudKey", out var apiKey))
            return;

        CredentialProtection.Save(CookieKey(1), cookie);
        CredentialProtection.Save(ApiKeyKey(1), apiKey);
        SaveState(new AccountState(1, new List<StoredAccountProfile>()));
    }

    public static bool TryGetActiveCredentials(out string cookie, out string apiKey, out int slot)
    {
        cookie = apiKey = string.Empty;
        MigrateLegacyCredentialsIfNeeded();
        var state = LoadState();
        slot = state.ActiveSlot is 1 or 2 ? state.ActiveSlot : 1;

        var hasCookie = CredentialProtection.TryRead(CookieKey(slot), out cookie);
        var hasApiKey = CredentialProtection.TryRead(ApiKeyKey(slot), out apiKey);
        return hasCookie && hasApiKey;
    }

    public static bool TryGetCredentials(int slot, out string cookie, out string apiKey)
    {
        cookie = apiKey = string.Empty;
        if (slot is not (1 or 2)) return false;
        return CredentialProtection.TryRead(CookieKey(slot), out cookie) &&
               CredentialProtection.TryRead(ApiKeyKey(slot), out apiKey);
    }

    public static StoredAccountProfile? GetActiveProfile()
    {
        var state = LoadState();
        return state.Accounts.FirstOrDefault(a => a.Slot == state.ActiveSlot);
    }

    public static IReadOnlyList<StoredAccountProfile> GetProfiles() => LoadState().Accounts;

    public static int GetNextFreeSlot()
    {
        var used = LoadState().Accounts.Select(a => a.Slot).ToHashSet();
        if (!used.Contains(1)) return 1;
        if (!used.Contains(2)) return 2;
        return 0;
    }

    public static void SaveAccount(int slot, string cookie, string apiKey, RobloxProfile profile, bool makeActive = true)
    {
        if (slot is not (1 or 2)) throw new ArgumentOutOfRangeException(nameof(slot));
        CredentialProtection.Save(CookieKey(slot), cookie);
        CredentialProtection.Save(ApiKeyKey(slot), apiKey);

        var state = LoadState();
        var accounts = state.Accounts.Where(a => a.Slot != slot).ToList();
        accounts.Add(new StoredAccountProfile(slot, profile.UserId, profile.UserName, profile.DisplayName, profile.AvatarUrl));
        accounts = accounts.OrderBy(a => a.Slot).Take(2).ToList();
        SaveState(new AccountState(makeActive ? slot : state.ActiveSlot, accounts));

        // Keep the legacy aliases in sync for code paths that have not yet migrated.
        if (makeActive)
        {
            CredentialProtection.Save("Cookie", cookie);
            CredentialProtection.Save("OpenCloudKey", apiKey);
        }
    }

    public static bool SwitchTo(int slot)
    {
        if (slot is not (1 or 2)) return false;
        var state = LoadState();
        if (!state.Accounts.Any(a => a.Slot == slot) || !TryGetCredentials(slot, out var cookie, out var apiKey))
            return false;

        SaveState(new AccountState(slot, state.Accounts));
        CredentialProtection.Save("Cookie", cookie);
        CredentialProtection.Save("OpenCloudKey", apiKey);
        return true;
    }

    public static bool TryRefreshActiveProfile(int slot, string expectedCookie, string expectedApiKey, RobloxProfile profile)
    {
        lock (Sync)
        {
            var state = LoadState();
            if (state.ActiveSlot != slot || !TryGetCredentials(slot, out var cookie, out var apiKey) ||
                cookie != expectedCookie || apiKey != expectedApiKey)
                return false;

            // A delayed HTTP response may refresh metadata only. It must never
            // restore credentials or switch back to an account removed meanwhile.
            var accounts = state.Accounts.Where(a => a.Slot != slot).ToList();
            accounts.Add(new StoredAccountProfile(slot, profile.UserId, profile.UserName, profile.DisplayName, profile.AvatarUrl));
            SaveState(new AccountState(slot, accounts.OrderBy(a => a.Slot).ToList()));
            return true;
        }
    }

    public static bool RemoveAccount(int slot)
    {
        // Slot 1 is the primary account. Only the optional second slot is removable.
        if (slot != 2) return false;
        lock (Sync)
        {
            var state = LoadState();
            if (!state.Accounts.Any(a => a.Slot == slot)) return false;
            var remaining = state.Accounts.Where(a => a.Slot != slot).ToList();
            if (state.ActiveSlot == slot)
            {
                if (remaining.Any(a => a.Slot == 1) && TryGetCredentials(1, out var cookie, out var apiKey))
                {
                    CredentialProtection.Save("Cookie", cookie);
                    CredentialProtection.Save("OpenCloudKey", apiKey);
                }
                else
                {
                    CredentialProtection.Delete("Cookie");
                    CredentialProtection.Delete("OpenCloudKey");
                }
            }
            // Retain the second row until both deletions succeed, so a Credential
            // Manager error can be retried. Move the active session to slot 1 first.
            SaveState(new AccountState(1, state.Accounts));
            CredentialProtection.Delete(CookieKey(slot));
            CredentialProtection.Delete(ApiKeyKey(slot));
            SaveState(new AccountState(1, remaining));
            return true;
        }
    }

    public static void ClearAll()
    {
        foreach (var slot in new[] { 1, 2 })
        {
            CredentialProtection.Delete(CookieKey(slot));
            CredentialProtection.Delete(ApiKeyKey(slot));
        }
        try { if (File.Exists(StatePath)) File.Delete(StatePath); } catch { }
    }

    private static string CookieKey(int slot) => $"Account{slot}/Cookie";
    private static string ApiKeyKey(int slot) => $"Account{slot}/OpenCloudKey";

    private static void SaveState(AccountState state)
    {
        lock (Sync)
        {
            Directory.CreateDirectory(DataDirectory);
            var temp = StatePath + ".tmp";
            File.WriteAllText(temp, JsonSerializer.Serialize(state));
            File.Move(temp, StatePath, true);
        }
    }
}
