using KAGE.Desktop.Updates;

namespace KAGE.Desktop;

static class Program
{
    [STAThread]
    static int Main(string[] args)
    {
        if (args.Any(arg => string.Equals(arg, "--verify-release", StringComparison.OrdinalIgnoreCase)))
        {
            return EmbeddedWebAssets.VerifyRequiredResources(out _) ? 0 : 11;
        }

        var verifyIntegrityIndex = Array.FindIndex(args, arg => string.Equals(arg, "--verify-integrity", StringComparison.OrdinalIgnoreCase));
        if (verifyIntegrityIndex >= 0)
        {
            var directory = verifyIntegrityIndex + 1 < args.Length ? args[verifyIntegrityIndex + 1] : AppContext.BaseDirectory;
            var result = IntegrityMonitor.VerifyAsync(directory, CancellationToken.None, requireDetachedManifest: true).GetAwaiter().GetResult();
            if (result.Level == SecurityLevel.Tampered)
            {
                Console.Error.WriteLine($"[KAGE] integrity verification failed: {string.Join(",", result.Codes)}");
                return 12;
            }
            return 0;
        }

        if (SelfUpdater.IsApplyMode(args))
            return SelfUpdater.RunApplyMode(args);

        var updatedStartup = SelfUpdater.ParseUpdatedStartup(args);

        SecurityRuntime.InitializeAsync(CancellationToken.None).GetAwaiter().GetResult();

        using var appLifetime = new CancellationTokenSource();
        var watchdogTask = SecurityWatchdog.Start(TimeSpan.FromSeconds(30), appLifetime.Token);

        Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
        ApplicationConfiguration.Initialize();
        try
        {
            Application.Run(new KageApplicationContext(updatedStartup));
        }
        finally
        {
            appLifetime.Cancel();
            try { watchdogTask.GetAwaiter().GetResult(); }
            catch (OperationCanceledException) { }
        }
        return 0;
    }
}
