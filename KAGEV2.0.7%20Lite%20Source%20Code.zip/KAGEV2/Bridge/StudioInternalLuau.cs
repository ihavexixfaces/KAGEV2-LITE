namespace Kage.Bridge;

/// <summary>
/// Generates tiny one-shot Luau files for documented Studio CLI RunScript tasks.
/// No Roblox cookie, Open Cloud key, Discord session, KAGE bridge token, or other
/// long-lived secret is ever embedded. The normal open-editor path does not need
/// this file because it uses Studio's official MCP execute_luau tool directly.
/// </summary>
public static class StudioInternalLuau
{
    public static string BuildProjectProbe() => """
local HttpService = game:GetService("HttpService")
print(HttpService:JSONEncode({
    ok = true,
    projectName = game.Name,
    placeId = game.PlaceId,
    universeId = game.GameId
}))
""";
}
