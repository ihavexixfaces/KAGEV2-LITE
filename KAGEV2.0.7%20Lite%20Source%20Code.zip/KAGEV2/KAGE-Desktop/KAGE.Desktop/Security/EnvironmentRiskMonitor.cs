using Microsoft.Win32;

namespace KAGE.Desktop;

internal static class EnvironmentRiskMonitor
{
    private static readonly string[] VirtualizationTokens =
    {
        "vmware", "virtualbox", "virtual machine", "qemu", "kvm", "xen", "parallels", "hyper-v"
    };

    internal static IReadOnlyList<SecuritySignal> Collect()
    {
        var signals = new List<SecuritySignal>();
        if (!OperatingSystem.IsWindows())
            return signals;

        ObserveRegistryValue(signals, "SystemManufacturer", "vm-manufacturer-observed");
        ObserveRegistryValue(signals, "SystemProductName", "vm-product-observed");
        ObserveRegistryValue(signals, "BIOSVendor", "vm-bios-observed");
        ObserveText(signals, Environment.GetEnvironmentVariable("PROCESSOR_IDENTIFIER"), "vm-cpu-observed");
        return signals;
    }

    private static void ObserveRegistryValue(List<SecuritySignal> signals, string valueName, string code)
    {
        try
        {
            var value = Registry.GetValue(@"HKEY_LOCAL_MACHINE\HARDWARE\DESCRIPTION\System\BIOS", valueName, null)?.ToString();
            ObserveText(signals, value, code);
        }
        catch
        {
            // Environment risk is low-confidence and never blocks by itself.
        }
    }

    private static void ObserveText(List<SecuritySignal> signals, string? value, string code)
    {
        if (string.IsNullOrWhiteSpace(value))
            return;

        var normalized = value.ToLowerInvariant();
        if (VirtualizationTokens.Any(normalized.Contains))
            signals.Add(new SecuritySignal(code, SignalConfidence.Low, true));
    }
}
