using System.Text.Json;
using Kage.Core;

namespace Kage.Bridge;

/// <summary>Applies ready mappings while upload workers continue, then verifies the full map.</summary>
public sealed class StudioReferenceUpdateCoordinator
{
    private readonly Func<IReadOnlyDictionary<long, long>, CancellationToken, Task<StudioReferenceApplyResult>> _live;
    private readonly Func<IReadOnlyDictionary<long, long>, CancellationToken, Task<VerifiedReferenceReplacementResult>> _finalize;
    private readonly Func<StudioReferenceApplyResult, Task>? _onLive;

    public StudioReferenceUpdateCoordinator(
        Func<IReadOnlyDictionary<long, long>, CancellationToken, Task<StudioReferenceApplyResult>> live,
        Func<IReadOnlyDictionary<long, long>, CancellationToken, Task<VerifiedReferenceReplacementResult>> finalize,
        Func<StudioReferenceApplyResult, Task>? onLive = null)
    {
        _live = live;
        _finalize = finalize;
        _onLive = onLive;
    }

    public async Task<VerifiedReferenceReplacementResult> RunAsync(StudioJob job, CancellationToken ct)
    {
        var attempted = new HashSet<long>();
        var liveRetries = new Dictionary<long, int>();
        var changes = new List<StudioReferenceChange>();
        var failures = new List<StudioReferenceFailure>();
        var changed = 0;
        var synchronized = 0;
        var attempts = 0;
        try
        {
            job.SetReferenceProgress("Waiting", 0, 0);
            while (job.Status is not ("Completed" or "Failed" or "Cancelled"))
            {
                ct.ThrowIfCancellationRequested();
                var batch = job.Mapping.Where(pair => !attempted.Contains(pair.Key)).Take(128).ToDictionary(pair => pair.Key, pair => pair.Value);
                if (batch.Count > 0)
                {
                    foreach (var id in batch.Keys) attempted.Add(id);
                    job.SetReferenceProgress("Updating", changed, synchronized);
                    using var deadline = CancellationTokenSource.CreateLinkedTokenSource(ct);
                    deadline.CancelAfter(TimeSpan.FromSeconds(45));
                    try
                    {
                        var applied = await _live(batch, deadline.Token).ConfigureAwait(false);
                        attempts++;
                        var previousChanged = changed;
                        changed = MergeChangedCount(changed, changes, applied.Changed, applied.Changes);
                        changes.AddRange(applied.Changes);
                        failures.AddRange(applied.Failures);
                        var failedIds = applied.Failures.Select(failure => failure.OldId).ToHashSet();
                        var confirmed = batch.Keys.Count(oldId => !failedIds.Contains(oldId));
                        synchronized += confirmed;
                        job.SetReferenceProgress("Updating", changed, synchronized);
                        if (_onLive is not null)
                            await _onLive(applied with { Changed = changed - previousChanged }).ConfigureAwait(false);
                    }
                    catch (Exception) when (!ct.IsCancellationRequested)
                    {
                        // A transient Studio transport drop must not stall or fail the upload.
                        // Requeue each idempotent old->new mapping several times while uploads
                        // continue; the final verified pass remains the last safety net.
                        foreach (var id in batch.Keys)
                        {
                            liveRetries.TryGetValue(id, out var retryCount);
                            if (retryCount >= 3) continue;
                            liveRetries[id] = retryCount + 1;
                            attempted.Remove(id);
                        }
                    }
                }
                await Task.Delay(60, ct).ConfigureAwait(false);
            }

            if (job.Status is "Failed" or "Cancelled")
                throw new InvalidOperationException(job.FatalError ?? "The upload stopped before reference verification.");
            var mapping = StudioJob.ReadCompletedMapping(JsonSerializer.SerializeToElement(job.ToDto()));
            job.SetReferenceProgress("Verifying", changed, synchronized);
            VerifiedReferenceReplacementResult final;
            if (mapping.Count == 0)
                final = new(0, 0, Array.Empty<long>(), Array.Empty<StudioReferenceChange>(), Array.Empty<StudioReferenceFailure>(), new Dictionary<long, IReadOnlyList<string>>());
            else
            {
                using var deadline = CancellationTokenSource.CreateLinkedTokenSource(ct);
                deadline.CancelAfter(TimeSpan.FromSeconds(250));
                final = await _finalize(mapping, deadline.Token).ConfigureAwait(false);
            }
            var result = final with
            {
                Changed = MergeChangedCount(changed, changes, final.Changed, final.Changes),
                Attempts = attempts + final.Attempts,
                Changes = changes.Concat(final.Changes).ToArray(),
                Failures = failures.Concat(final.Failures).ToArray()
            };
            job.SetReferenceProgress("Completed", result.Changed, mapping.Count);
            return result;
        }
        catch (StudioReferenceReplacementException ex)
        {
            var result = ex.Result with
            {
                Changed = MergeChangedCount(changed, changes, ex.Result.Changed, ex.Result.Changes),
                Attempts = attempts + ex.Result.Attempts,
                Changes = changes.Concat(ex.Result.Changes).ToArray(),
                Failures = failures.Concat(ex.Result.Failures).ToArray()
            };
            job.SetReferenceProgress("Failed", result.Changed, synchronized, ex.Message);
            throw new StudioReferenceReplacementException(ex.Message, result);
        }
        catch (Exception ex)
        {
            var message = ex is OperationCanceledException && !ct.IsCancellationRequested
                ? "Studio reference verification timed out. The new upload IDs are saved; reconnect Studio and retry reference updates."
                : ex.Message;
            job.SetReferenceProgress("Failed", changed, synchronized, message);
            throw new StudioReferenceReplacementException(message,
                new(changed, attempts, job.Mapping.Keys.ToArray(), changes, failures, new Dictionary<long, IReadOnlyList<string>>()));
        }
    }

    private static int MergeChangedCount(int previous, IEnumerable<StudioReferenceChange> earlier,
        int acknowledged, IReadOnlyList<StudioReferenceChange> added)
    {
        var priorInstances = StudioReferenceCounts.CountInstances(earlier);
        var addedInstances = StudioReferenceCounts.CountInstances(added);
        var combinedInstances = StudioReferenceCounts.CountInstances(earlier.Concat(added));
        // Explicit identities deduplicate repeated properties and live/final
        // rounds. Keep larger compact acknowledgments as a lower bound; when a
        // pass has no instance details, preserve the aggregate-only fallback.
        var reported = priorInstances > 0 && addedInstances > 0
            ? Math.Max(previous, acknowledged)
            : previous + Math.Max(0, acknowledged);
        return Math.Max(combinedInstances, reported);
    }
}
