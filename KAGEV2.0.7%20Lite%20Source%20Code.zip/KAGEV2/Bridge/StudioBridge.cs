using System.Net;
using System.Security.Cryptography;
using System.Collections.Concurrent;
using Kage.Core;
using Kage.Engine;
using Kage.Roblox;
using Kage.Security;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Kage.Bridge;

public sealed class StudioBridge
{
    private readonly string _token;
    private readonly string _sessionId;
    private readonly DateTimeOffset _sessionExpiresUtc;
    private readonly int _port;
    private readonly AnimationReuploadEngine _engine;
    private readonly RobloxOpenCloudClient _roblox;
    private readonly ConcurrentDictionary<string, StudioJob> _jobs = new();
    private readonly ConcurrentDictionary<string, byte> _startedJobs = new();
    private readonly CancellationToken _shutdown;
    private readonly StudioRunCoordinator _runCoordinator;
    private Task<RobloxProfile?>? _profileTask;

    public StudioBridge(KageStudioSession session, int port, AnimationReuploadEngine engine, RobloxOpenCloudClient roblox, StudioRunCoordinator runCoordinator, CancellationToken shutdown)
    {
        _token = session.Token;
        _sessionId = session.SessionId;
        _sessionExpiresUtc = session.ExpiresUtc;
        _port = port;
        _engine = engine;
        _roblox = roblox;
        _runCoordinator = runCoordinator;
        _shutdown = shutdown;
    }

    public bool TryGetJob(string id, out StudioJob job) => _jobs.TryGetValue(id, out job!);

    public object? GetJobProgress(string id)
    {
        if (string.IsNullOrWhiteSpace(id) || !_jobs.TryGetValue(id, out var job)) return null;
        var terminal = job.Status is "Completed" or "Failed" or "Cancelled";
        return job.ToDto(includeResults: terminal);
    }

    // The desktop window and bridge share this instance. Starting its own
    // freshly queued job directly avoids a second localhost HTTP binding step.
    public bool StartQueuedJob(string id, int concurrency)
    {
        if (!_jobs.TryGetValue(id, out var job)) return false;
        if (_startedJobs.TryAdd(id, 0))
        {
            _ = Task.Run(() => StudioJobExecution.RunAsync(job,
                () => _engine.RunJobAsync(job, _shutdown, Math.Clamp(concurrency, 1, 96)), _shutdown));
        }
        return true;
    }

    public async Task RunAsync()
    {
        var builder = WebApplication.CreateSlimBuilder();
        builder.WebHost.UseUrls($"http://127.0.0.1:{_port}");
        builder.Logging.ClearProviders();
        await using var app = builder.Build();

        app.Use(async (context, next) =>
        {
            if (!IPAddress.IsLoopback(context.Connection.RemoteIpAddress ?? IPAddress.None))
            {
                context.Response.StatusCode = StatusCodes.Status403Forbidden;
                return;
            }
            var origin = context.Request.Headers.Origin.ToString();
            // The Windows host serves embedded resources from https://kage.local.
            // Linux Photino serves the same embedded UI from app://kage. WebKitGTK
            // may serialize a custom-scheme request origin as "null". Only allow that
            // opaque origin on Linux: every sensitive endpoint still checks the
            // per-session token, session ID and unpredictable request ID.
            var trustedOrigin = string.Equals(origin, "https://kage.local", StringComparison.OrdinalIgnoreCase) ||
                (OperatingSystem.IsLinux() && (
                    string.Equals(origin, "app://kage", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(origin, "null", StringComparison.Ordinal)));
            if (!string.IsNullOrWhiteSpace(origin) && !trustedOrigin)
            {
                context.Response.StatusCode = StatusCodes.Status403Forbidden;
                return;
            }
            if (trustedOrigin)
                context.Response.Headers["Access-Control-Allow-Origin"] = origin;
            context.Response.Headers["Vary"] = "Origin";
            context.Response.Headers["Access-Control-Allow-Headers"] = "Content-Type, X-Kage-Token, X-Kage-Session, X-Kage-Request-Id";
            context.Response.Headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS";
            if (HttpMethods.IsOptions(context.Request.Method))
            {
                context.Response.StatusCode = StatusCodes.Status204NoContent;
                return;
            }
            await next();
        });

        app.UseDefaultFiles();
        app.UseStaticFiles();

        app.MapGet("/health", () => Results.Json(new { ok = true, service = "KAGE Studio Bridge" }));
        app.MapGet("/api/studio/config", (HttpContext context) =>
        {
            if (!Authorized(context))
                return Results.Json(new { error = "KAGE token mismatch." }, statusCode: StatusCodes.Status401Unauthorized);
            return Results.Json(_runCoordinator.Snapshot());
        });

        app.MapGet("/api/studio/ping", (HttpContext context) =>
        {
            if (!Authorized(context))
                return Results.Json(new { error = "KAGE session authentication failed." }, statusCode: StatusCodes.Status401Unauthorized);
            return Results.Json(new { ok = true, sessionId = _sessionId, expiresUtc = _sessionExpiresUtc, requestId = context.Request.Headers["X-Kage-Request-Id"].ToString() });
        });

        // The local UI is intentionally loopback-only (the middleware above enforces
        // this) and exposes only the same job DTOs used by the Studio API.
        app.MapGet("/api/ui/state", (HttpContext context) =>
        {
            if (!Authorized(context))
                return Results.Json(new { error = "KAGE token mismatch." }, statusCode: StatusCodes.Status401Unauthorized);
            _profileTask ??= LoadProfileAsync(_shutdown);
            var profile = _profileTask.IsCompletedSuccessfully ? _profileTask.Result : null;
            var jobs = _jobs.Values
                .OrderByDescending(job => job.CreatedUtc)
                .Take(50)
                .Select(job => job.ToDto(includeResults: job.Status is "Completed" or "Failed" or "Cancelled"));
            return Results.Json(new
            {
                service = "KAGE Studio Bridge",
                port = _port,
                session = new { id = _sessionId, expiresUtc = _sessionExpiresUtc },
                runConfig = _runCoordinator.Snapshot(),
                profile,
                discord = new
                {
                    username = CredentialStore.TryRead("DiscordUsername", out var username) ? username : "",
                    id = CredentialStore.TryRead("DiscordId", out var discordId) ? discordId : ""
                },
                jobs
            });
        });

        app.MapPost("/api/studio/jobs", async (HttpContext context, StudioStartRequest request) =>
        {
            if (!Authorized(context))
                return Results.Json(
                    new { error = "KAGE local session authentication failed." },
                    statusCode: StatusCodes.Status401Unauthorized);
            if (request.CreatorId <= 0) return Results.BadRequest(new { error = "Studio reported an invalid creator ID. Publish/open a real place before running KAGE." });
            if (request.EffectiveAssetIds.Count == 0)
                return Results.BadRequest(new { error = "No supported asset IDs were supplied." });

            if (request.NormalizedAssetType != "Animations" || !request.CreatorType.Equals("User", StringComparison.OrdinalIgnoreCase))
                return Results.BadRequest(new { error = "KAGE Lite supports animation assets for the connected Roblox account only." });

            var clean = request with
            {
                AssetType = "Animations",
                AssetIds = request.EffectiveAssetIds.ToList(),
                AssetNames = request.EffectiveAssetNames.ToDictionary(x => x.Key, x => x.Value),
                PlaceName = string.IsNullOrWhiteSpace(request.PlaceName) ? "Studio" : request.PlaceName
            };

            // Studio's DataModel name is frequently a generic local label such as
            // Game1/Game2. Resolve the published universe/place name through Roblox
            // before the job is exposed to the desktop UI and history.
            var resolvedPlaceName = await _roblox.ResolveExperienceNameAsync(
                clean.PlaceId,
                clean.UniverseId,
                clean.PlaceName,
                context.RequestAborted);
            clean = clean with { PlaceName = resolvedPlaceName };

            if (clean.EffectiveAssetIds.Count > 5000)
                return Results.BadRequest(new { error = "This build limits a Studio job to 5000 unique asset IDs." });

            var id = Guid.NewGuid().ToString("N");
            var job = new StudioJob(id, clean);
            if (!_jobs.TryAdd(id, job))
                return Results.StatusCode(StatusCodes.Status500InternalServerError);

            Console.WriteLine();
            Console.WriteLine($"Studio connected: {clean.PlaceName} ({clean.PlaceId})");
            Console.WriteLine($"Creator: {clean.CreatorType} {clean.CreatorId}");
            Console.WriteLine($"Asset type: {clean.NormalizedAssetType}");
            Console.WriteLine($"Unique assets: {job.Total}");
            Console.WriteLine($"Job: {id}");

            return Results.Json(new StudioStartResponse(id, job.Total));
        });

        app.MapPost("/api/studio/jobs/{id}/start", async (HttpContext context, string id, StudioJobStartRequest request) =>
        {
            if (!Authorized(context))
                return Results.Json(
                    new { error = "KAGE local session authentication failed." },
                    statusCode: StatusCodes.Status401Unauthorized);
            if (!_jobs.TryGetValue(id, out var job))
                return Results.NotFound(new { error = "Unknown KAGE job." });
            try
            {
                StartQueuedJob(id, request.Concurrency);
                return Results.Json(new { jobId = id, status = job.Status });
            }
            catch (Exception ex)
            {
                _startedJobs.TryRemove(id, out _);
                Console.Error.WriteLine($"Studio job {id} could not start: {ex}");
                return Results.Json(new { error = $"KAGE job start failed: {ex.Message}" },
                    statusCode: StatusCodes.Status500InternalServerError);
            }
        });

        app.MapGet("/api/studio/jobs/{id}", (HttpContext context, string id) =>
        {
            if (!Authorized(context))
                return Results.Json(
                    new { error = "KAGE local session authentication failed." },
                    statusCode: StatusCodes.Status401Unauthorized);
            if (!_jobs.TryGetValue(id, out var job))
                return Results.NotFound(new { error = "Unknown KAGE job." });

            // Mapping/error dictionaries are only needed once the terminal result
            // is ready. Omitting them from progress polls avoids repeatedly
            // serializing a growing 900+ item payload.
            var terminal = job.Status is "Completed" or "Failed" or "Cancelled";
            return Results.Json(job.ToDto(includeResults: terminal));
        });

        app.MapPost("/api/studio/jobs/{id}/applied", async (HttpContext context, string id) =>
        {
            if (!Authorized(context))
                return Results.Json(
                    new { error = "KAGE local session authentication failed." },
                    statusCode: StatusCodes.Status401Unauthorized);
            if (!_jobs.TryGetValue(id, out var job)) return Results.NotFound(new { error = "Unknown KAGE job." });
            using var reader = new StreamReader(context.Request.Body);
            var body = await reader.ReadToEndAsync();
            Console.WriteLine($"Studio applied replacements for job {id}. {body}");
            return Results.Json(new { ok = true, successfulMappings = job.Mapping.Count });
        });

        await app.StartAsync(_shutdown);
        var url = $"http://127.0.0.1:{_port}/";
        Console.WriteLine($"KAGE UI: {url}");
        await app.WaitForShutdownAsync(_shutdown);
    }

    private bool Authorized(HttpContext context)
    {
        if (DateTimeOffset.UtcNow >= _sessionExpiresUtc) return false;
        var supplied = context.Request.Headers["X-Kage-Token"].ToString();
        var session = context.Request.Headers["X-Kage-Session"].ToString();
        var requestId = context.Request.Headers["X-Kage-Request-Id"].ToString();
        if (string.IsNullOrWhiteSpace(requestId) || !Guid.TryParse(requestId, out _)) return false;
        if (!string.Equals(session, _sessionId, StringComparison.Ordinal)) return false;
        return supplied.Length == _token.Length && CryptographicOperations.FixedTimeEquals(
            System.Text.Encoding.UTF8.GetBytes(supplied),
            System.Text.Encoding.UTF8.GetBytes(_token));
    }

    private async Task<RobloxProfile?> LoadProfileAsync(CancellationToken ct)
    {
        try
        {
            using var deadline = CancellationTokenSource.CreateLinkedTokenSource(ct);
            deadline.CancelAfter(TimeSpan.FromSeconds(20));
            return await _roblox.GetAuthenticatedProfileAsync(deadline.Token);
        }
        catch
        {
            return null;
        }
    }
}
