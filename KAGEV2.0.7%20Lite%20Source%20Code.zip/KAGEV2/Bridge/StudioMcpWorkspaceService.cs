using System.Text;
using System.Text.Json;

namespace Kage.Bridge;

public sealed record StudioMcpInstance(string StudioId, string Name, long PlaceId, bool IsActive = false);
public sealed record StudioProjectInfo(string StudioId, string ProjectName, long PlaceId, long UniverseId, string CreatorType, long CreatorId);
public sealed record StudioAssetScan(
    string AssetType,
    IReadOnlyList<long> AssetIds,
    IReadOnlyDictionary<string, string> AssetNames,
    IReadOnlyDictionary<string, string> AssetLocations);
public sealed record StudioReferenceChange(long OldId, long NewId, string Location, string Kind, int Count, string? InstanceKey = null);
public sealed record StudioReferenceFailure(long OldId, long NewId, string Location, string Kind, string Reason);
public sealed record StudioReferenceApplyResult(
    int Changed,
    IReadOnlyList<StudioReferenceChange> Changes,
    IReadOnlyList<StudioReferenceFailure> Failures);

/// <summary>Counts changed asset instances; text occurrences remain in the detailed change log.</summary>
public static class StudioReferenceCounts
{
    public static bool IsAssetInstanceChange(StudioReferenceChange change) =>
        change.Kind is not ("ScriptSource" or "StringValue" or "IntValue" or "NumberValue") &&
        !change.Kind.StartsWith("Attribute:", StringComparison.Ordinal);

    public static int CountInstances(IEnumerable<StudioReferenceChange> changes) => changes
        .Where(IsAssetInstanceChange)
        .Select(change => string.IsNullOrWhiteSpace(change.InstanceKey) ? change.Location : change.InstanceKey)
        .Distinct(StringComparer.Ordinal)
        .Count();
}
public sealed record StudioReferenceVerification(IReadOnlyDictionary<long, IReadOnlyList<string>> RemainingLocations)
{
    public IReadOnlyList<long> UnresolvedOldIds => RemainingLocations.Keys.Order().ToArray();
}
public sealed record StudioTreeNode(string Name, string ClassName, int Depth);
public sealed class StudioAssetScanException : InvalidOperationException
{
    public StudioAssetScanException(string stage, string message)
        : base($"Studio asset scan failed during {stage}: {message}") => Stage = stage;
    public string Stage { get; }
}

public enum StudioScanStage { DirectAsset, ScriptReference }
public sealed record StudioScanIssue(string Root, StudioScanStage Stage, string Message);
public sealed record StudioScanProgress(string AssetType, int Processed, int Total, int Found, bool Done = false);

internal sealed record StudioScanPiece(
    string Root,
    StudioScanStage Stage,
    IReadOnlyList<long> AssetIds,
    IReadOnlyDictionary<string, string> AssetNames,
    IReadOnlyDictionary<string, string> AssetLocations,
    string? Error = null,
    int NextOffset = 0,
    bool Done = true,
    int Processed = 0,
    int Total = 0);

/// <summary>
/// DataModel operations for the currently-open Studio place.
/// Uses Roblox Studio's official built-in MCP server and execute_luau tool so KAGE
/// does not need a pasted Command Bar bootstrap or a Studio plugin.
/// </summary>
public sealed partial class StudioMcpWorkspaceService : IAsyncDisposable
{
    private static string ScanStageLabel(StudioScanStage stage) => stage == StudioScanStage.DirectAsset ? "direct-instances" : "scripts";
    private readonly StudioMcpClient _client = new();
    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly object _lifetimeSync = new();
    private CancellationTokenSource _operations = new();
    private int _disposed;
    private StudioMcpInstance? _active;

    private CancellationTokenSource BeginOperation(CancellationToken ct, int seconds = 60)
    {
        ObjectDisposedException.ThrowIf(Volatile.Read(ref _disposed) != 0, this);
        lock (_lifetimeSync)
        {
            var operation = CancellationTokenSource.CreateLinkedTokenSource(ct, _operations.Token);
            operation.CancelAfter(TimeSpan.FromSeconds(seconds));
            return operation;
        }
    }
    private StudioProjectInfo? _project;
    private static readonly string[] ScanRoots =
    {
        "Workspace",
        "ReplicatedStorage",
        "ReplicatedFirst",
        "ServerScriptService",
        "ServerStorage",
        "StarterGui",
        "StarterPack",
        "StarterPlayer",
        "Lighting",
        "SoundService",
        "MaterialService",
        "Teams",
        "TextChatService",
        "LocalizationService"
    };

    public bool IsConnected => _client.IsConnected && _active is not null;
    // Long Studio scans/reference operations intentionally own the workspace gate.
    // The background heartbeat must not queue a competing MCP request and time out
    // the transport while an operation is still healthy and actively producing work.
    public bool IsOperationBusy => _gate.CurrentCount == 0;
    public StudioProjectInfo? Project => _project;
    public IReadOnlyList<StudioScanIssue> LastScanErrors { get; private set; } = Array.Empty<StudioScanIssue>();
    public bool ScanHadPartialFailures => LastScanErrors.Count > 0;
    public event Action<StudioScanProgress>? ScanProgress;

    public async Task<StudioProjectInfo> ConnectAsync(CancellationToken ct = default)
    {
        ObjectDisposedException.ThrowIf(Volatile.Read(ref _disposed) != 0, this);
        lock (_lifetimeSync)
            if (_operations.IsCancellationRequested) _operations = new CancellationTokenSource();
        using var operation = BeginOperation(ct, 30);
        ct = operation.Token;
        await _client.ConnectAsync(ct).ConfigureAwait(false);
        _active = await WaitForStudioInstanceAsync(ct).ConfigureAwait(false);
        _project = await ReadProjectInfoAsync(ct).ConfigureAwait(false);
        return _project;
    }

    private async Task<StudioMcpInstance> WaitForStudioInstanceAsync(CancellationToken ct)
    {
        // Studio can take a few seconds to publish the open editor after the MCP stdio
        // process has successfully initialized. A one-shot list call made KAGE report
        // "Connection Failed" even though the user's MCP toggle was enabled.
        var deadline = DateTimeOffset.UtcNow + TimeSpan.FromSeconds(30);
        Exception? lastError = null;
        do
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                var studios = await ListStudiosAsync(ct).ConfigureAwait(false);
                var selected = SelectStudioInstance(studios, _active, _project);
                if (selected is not null) return selected;
            }
            catch (Exception ex) when (!ct.IsCancellationRequested)
            {
                lastError = ex;
            }

            await Task.Delay(TimeSpan.FromMilliseconds(450), ct).ConfigureAwait(false);
        }
        while (DateTimeOffset.UtcNow < deadline);

        throw new InvalidOperationException(
            "Roblox Studio MCP started, but no open Studio editor registered within 30 seconds. Keep the place open and verify Studio shows a connected MCP client.",
            lastError);
    }

    private static StudioMcpInstance? SelectStudioInstance(
        IReadOnlyList<StudioMcpInstance> studios,
        StudioMcpInstance? current,
        StudioProjectInfo? currentProject)
    {
        if (current is not null)
        {
            var sameId = studios.FirstOrDefault(instance => string.Equals(instance.StudioId, current.StudioId, StringComparison.Ordinal));
            if (sameId is not null) return sameId;
        }

        if (currentProject is { PlaceId: > 0 })
        {
            var samePlace = studios.FirstOrDefault(instance => instance.PlaceId == currentProject.PlaceId);
            if (samePlace is not null) return samePlace;
        }

        return studios
            .OrderByDescending(instance => instance.IsActive)
            .ThenByDescending(instance => instance.PlaceId > 0)
            .ThenBy(instance => instance.Name, StringComparer.OrdinalIgnoreCase)
            .ThenBy(instance => instance.StudioId, StringComparer.Ordinal)
            .FirstOrDefault();
    }

    public static IReadOnlyList<StudioTreeNode> DeriveExplorerTree(StudioAssetScan scan)
    {
        var root = new ExplorerNode("game", "DataModel");
        foreach (var location in scan.AssetLocations.Values.Where(value => !string.IsNullOrWhiteSpace(value)).Distinct(StringComparer.OrdinalIgnoreCase))
        {
            var parts = location.Split('/', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            var cursor = root;
            for (var index = 0; index < parts.Length; index++)
            {
                var name = parts[index];
                var isLeaf = index == parts.Length - 1;
                cursor = cursor.GetOrAdd(name, isLeaf ? GuessLeafClass(name) : GuessContainerClass(name));
            }
        }

        var output = new List<StudioTreeNode>();
        FlattenExplorer(root, output, -1);
        return output;
    }

    private static void FlattenExplorer(ExplorerNode node, List<StudioTreeNode> output, int depth)
    {
        if (depth >= 0) output.Add(new StudioTreeNode(node.Name, node.ClassName, depth));
        foreach (var child in node.Children.Values.OrderBy(value => value.Name, StringComparer.OrdinalIgnoreCase))
            FlattenExplorer(child, output, depth + 1);
    }

    private static string GuessContainerClass(string name) => name switch
    {
        "Workspace" or "ReplicatedStorage" or "ReplicatedFirst" or "ServerScriptService" or
        "ServerStorage" or "StarterGui" or "StarterPack" or "StarterPlayer" or "Players" or
        "Lighting" or "SoundService" or "TextChatService" => "Service",
        _ => "Folder"
    };

    private static string GuessLeafClass(string name) =>
        name.EndsWith("Script", StringComparison.OrdinalIgnoreCase) ? "Script" : "Animation";

    private sealed class ExplorerNode
    {
        public ExplorerNode(string name, string className) { Name = name; ClassName = className; }
        public string Name { get; }
        public string ClassName { get; private set; }
        public Dictionary<string, ExplorerNode> Children { get; } = new(StringComparer.OrdinalIgnoreCase);
        public ExplorerNode GetOrAdd(string name, string className)
        {
            if (!Children.TryGetValue(name, out var child))
            {
                child = new ExplorerNode(name, className);
                Children[name] = child;
            }
            else if (child.ClassName == "Folder" && className != "Folder") child.ClassName = className;
            return child;
        }
    }

    public async Task<IReadOnlyList<StudioMcpInstance>> ListStudiosAsync(CancellationToken ct = default)
    {
        var result = await _client.CallToolAsync("list_roblox_studios", new { }, ct).ConfigureAwait(false);
        var values = new List<StudioMcpInstance>();
        CollectStudioInstances(result, values);
        if (values.Count == 0)
        {
            foreach (var text in ExtractTextBlocks(result))
            {
                if (!TryParseAnyJson(text, out var parsed)) continue;
                using (parsed) CollectStudioInstances(parsed.RootElement, values);
            }
        }
        return values.GroupBy(x => x.StudioId, StringComparer.Ordinal).Select(g => g.First()).ToArray();
    }

    public async Task<bool> PingAsync(CancellationToken ct = default)
    {
        if (_active is null) return false;
        // A workspace operation already owns the only serialized MCP lane. Treat
        // that active work as healthy instead of queueing a heartbeat that can hit
        // its own timeout and retire the transport underneath the scan.
        if (IsOperationBusy) return true;
        try
        {
            if (_client.HasTool("get_studio_state"))
            {
                var result = await _client.CallToolAsync("get_studio_state", new { studio_id = _active.StudioId }, ct).ConfigureAwait(false);
                return result.ValueKind != JsonValueKind.Undefined;
            }

            var studios = await ListStudiosAsync(ct).ConfigureAwait(false);
            return studios.Any(instance => string.Equals(instance.StudioId, _active.StudioId, StringComparison.Ordinal));
        }
        catch
        {
            return false;
        }
    }

    public async Task<StudioProjectInfo> ReadProjectInfoAsync(CancellationToken ct = default)
    {
        using var operation = BeginOperation(ct);
        ct = operation.Token;
        var active = _active ?? throw new InvalidOperationException("No Roblox Studio instance is selected.");
        var result = await ExecuteLuauAsync(BuildProjectInfoLuau(), ct, active.StudioId).ConfigureAwait(false);
        using var doc = JsonDocument.Parse(ExtractJsonPayload(result) ?? throw new InvalidOperationException("Studio returned no project information."));
        var root = doc.RootElement;
        var project = new StudioProjectInfo(
            active.StudioId,
            GetString(root, "projectName", active.Name),
            GetLong(root, "placeId", active.PlaceId),
            GetLong(root, "universeId"),
            GetString(root, "creatorType", "User"),
            GetLong(root, "creatorId"));
        ct.ThrowIfCancellationRequested();
        if (_active?.StudioId == active.StudioId) _project = project;
        return project;
    }

    public async Task<IReadOnlyList<StudioTreeNode>> ReadWorkspaceTreeAsync(CancellationToken ct = default)
    {
        using var operation = BeginOperation(ct);
        ct = operation.Token;
        await _gate.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            if (!IsConnected) await ConnectAsync(ct).ConfigureAwait(false);
            var result = await ExecuteLuauAsync(BuildWorkspaceTreeLuau(), ct).ConfigureAwait(false);
            using var doc = JsonDocument.Parse(ExtractJsonPayload(result) ?? throw new InvalidOperationException("Studio returned no workspace tree."));
            var output = new List<StudioTreeNode>();
            if (doc.RootElement.ValueKind == JsonValueKind.Array)
            {
                foreach (var item in doc.RootElement.EnumerateArray())
                {
                    if (item.ValueKind != JsonValueKind.Object) continue;
                    var name = GetString(item, "name", "Instance");
                    var className = GetString(item, "className", "Instance");
                    var depth = GetInt(item, "depth", 0);
                    output.Add(new StudioTreeNode(name, className, Math.Clamp(depth, 0, 5)));
                }
            }
            return output;
        }
        finally { _gate.Release(); }
    }

    /// <summary>
    /// Restores the original KAGE V2 scan model: Studio itself walks the open DataModel
    /// and returns real typed properties plus the original V2-style script/config
    /// references that are locally proven to belong to the selected asset family. The
    /// old Command Bar script did this inside Studio; MCP now transports the same job
    /// through execute_luau so the user never has to paste Lua manually.
    ///
    /// Unlike the broken broad-keyword scanner, one animation/sound/etc. keyword cannot
    /// classify unrelated IDs elsewhere in the same script. Script candidates are scoped
    /// to the matching line or a matching asset table, then the normal reupload pipeline
    /// and reference replacement handle the discovered IDs.
    /// </summary>
    public Task<StudioAssetScan> ScanAssetReferencesAsync(string assetType, CancellationToken ct = default) =>
        ScanOriginalV2StyleAssetReferencesAsync(assetType, ct);

    // A scoped scan selects only IDs from matching typed instances. Uploads and
    // reference replacement continue through the already-tested Decals engine.
    public Task<StudioAssetScan> ScanScopedImageReferencesAsync(string scope, CancellationToken ct = default)
    {
        var normalized = scope?.Trim().ToLowerInvariant() switch
        {
            "ui" => "ui",
            "vfx" => "vfx",
            "textures" => "textures",
            _ => "all"
        };
        return ScanOriginalV2StyleAssetReferencesAsync("Decals", ct, normalized);
    }

    /// <summary>
    /// Explorer and Asset Viewer deliberately share the exact same original-V2-style
    /// typed catalog as Reupload so the three surfaces cannot disagree about what exists.
    /// </summary>
    public Task<StudioAssetScan> ScanDirectAssetReferencesAsync(string assetType, CancellationToken ct = default) =>
        ScanOriginalV2StyleAssetReferencesAsync(assetType, ct);

    private async Task<StudioAssetScan> ScanOriginalV2StyleAssetReferencesAsync(string assetType, CancellationToken ct, string imageScope = "all")
    {
        // v85 deliberately goes back to the ORIGINAL V2 collection model:
        // one Studio-local game:GetDescendants() snapshot, direct typed instances first,
        // then the original per-line script keyword pass. MCP is only the transport.
        //
        // Do not reintroduce service paging, editor-service source crawling, or the
        // contextual scanner here. Those changes are what made large projects drift away
        // from the original ~instant Command Bar behavior.
        using var operation = BeginOperation(ct, 45);
        ct = operation.Token;
        await _gate.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            if (!IsConnected) await ConnectAsync(ct).ConfigureAwait(false);
            var normalized = NormalizeAssetType(assetType);

            var total = 0;
            try
            {
                var countResult = await ExecuteReadOnlyLuauWithStudioRecoveryAsync(
                    BuildOriginalV2CountLuau(), ct, _project, TimeSpan.FromSeconds(6)).ConfigureAwait(false);
                total = ExtractTaggedInteger(countResult, KageCountMarker);
            }
            catch when (!ct.IsCancellationRequested)
            {
                // Count is cosmetic only. The real scan must still run if Studio omits it.
                total = 0;
            }

            ScanProgress?.Invoke(new StudioScanProgress(normalized, 0, total, 0, false));

            var result = await ExecuteReadOnlyLuauWithStudioRecoveryAsync(
                BuildExactOriginalV2McpScanLuau(normalized, imageScope),
                ct,
                _project,
                TimeSpan.FromSeconds(30)).ConfigureAwait(false);

            var piece = ParseExactOriginalV2TextScan(result, normalized);
            if (!string.IsNullOrWhiteSpace(piece.Error))
                throw new StudioAssetScanException("original-v2-mcp-scan", piece.Error);

            LastScanErrors = Array.Empty<StudioScanIssue>();
            var ordered = piece.AssetIds.Where(id => id > 0).Distinct().Order().ToArray();
            var processed = Math.Max(piece.Processed, total);
            var finalTotal = Math.Max(processed, total);
            ScanProgress?.Invoke(new StudioScanProgress(normalized, finalTotal, finalTotal, ordered.Length, true));
            return new StudioAssetScan(normalized, ordered, piece.AssetNames, piece.AssetLocations);
        }
        finally
        {
            _gate.Release();
        }
    }

    private const string KageScanMarker = "__KAGE_SCAN_V85__";
    private const string KageScanEndMarker = "__KAGE_SCAN_END_V85__";
    private const string KageCountMarker = "__KAGE_COUNT_V85__";

    private static string BuildOriginalV2CountLuau() => $$"""
local descendants = game:GetDescendants()
return "{{KageCountMarker}}" .. tostring(#descendants)
""";

    private static StudioScanPiece ParseExactOriginalV2TextScan(JsonElement result, string assetType)
    {
        var payload = ExtractTaggedText(result, KageScanMarker);
        if (string.IsNullOrWhiteSpace(payload))
        {
            // Keep one compact shape preview in the log if Roblox changes the result
            // wrapper again. Never dump script source or credentials.
            var preview = result.GetRawText().Replace('\r', ' ').Replace('\n', ' ');
            if (preview.Length > 360) preview = preview[..360] + "…";
            return EmptyScanPiece(assetType, StudioScanStage.DirectAsset,
                $"Studio executed the scan but returned no KAGE payload. MCP result shape: {preview}");
        }

        try
        {
            var normalized = DecodeEscapedMcpText(payload);
            var lines = normalized.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n', StringSplitOptions.RemoveEmptyEntries);
            if (lines.Length == 0 || !lines[0].StartsWith(KageScanMarker, StringComparison.Ordinal))
                return EmptyScanPiece(assetType, StudioScanStage.DirectAsset, "Studio returned an invalid KAGE scan header.");

            var header = lines[0].Split('\t');
            var processed = header.Length > 1 && int.TryParse(header[1], out var parsedProcessed)
                ? Math.Max(0, parsedProcessed)
                : 0;

            var ids = new List<long>();
            var names = new Dictionary<string, string>(StringComparer.Ordinal);
            var locations = new Dictionary<string, string>(StringComparer.Ordinal);

            for (var i = 1; i < lines.Length; i++)
            {
                var columns = lines[i].Split('\t');
                if (columns.Length == 0 || !long.TryParse(columns[0], out var id) || id <= 0) continue;
                ids.Add(id);
                var key = id.ToString();
                if (columns.Length > 1)
                {
                    var name = DecodeScanField(columns[1]);
                    if (!string.IsNullOrWhiteSpace(name) && !names.ContainsKey(key)) names[key] = name;
                }
                if (columns.Length > 2)
                {
                    var location = DecodeScanField(columns[2]);
                    if (!string.IsNullOrWhiteSpace(location) && !locations.ContainsKey(key)) locations[key] = location;
                }
            }

            return new StudioScanPiece(
                assetType,
                StudioScanStage.DirectAsset,
                ids.Distinct().ToArray(),
                names,
                locations,
                null,
                processed,
                true,
                processed,
                processed);
        }
        catch (Exception ex)
        {
            return EmptyScanPiece(assetType, StudioScanStage.DirectAsset, $"Studio returned an unreadable KAGE scan payload: {ex.Message}");
        }
    }

    private static int ExtractTaggedInteger(JsonElement result, string marker)
    {
        var tagged = ExtractTaggedText(result, marker);
        if (string.IsNullOrWhiteSpace(tagged)) return 0;
        tagged = DecodeEscapedMcpText(tagged);
        var start = tagged.IndexOf(marker, StringComparison.Ordinal);
        if (start < 0) return 0;
        var tail = tagged[(start + marker.Length)..];
        var digits = new string(tail.TakeWhile(char.IsDigit).ToArray());
        return int.TryParse(digits, out var value) ? Math.Max(0, value) : 0;
    }

    private static string? ExtractTaggedText(JsonElement result, string marker)
    {
        foreach (var raw in ExtractTextBlocks(result))
        {
            if (string.IsNullOrWhiteSpace(raw)) continue;
            foreach (var candidate in ExpandMcpTextVariants(raw))
            {
                var index = candidate.IndexOf(marker, StringComparison.Ordinal);
                if (index < 0) continue;
                var slice = candidate[index..];
                if (string.Equals(marker, KageScanMarker, StringComparison.Ordinal))
                {
                    var end = slice.IndexOf(KageScanEndMarker, StringComparison.Ordinal);
                    if (end >= 0) slice = slice[..end];
                }
                return slice.TrimEnd('"');
            }
        }
        return null;
    }

    private static IEnumerable<string> ExpandMcpTextVariants(string raw)
    {
        yield return raw;

        var trimmed = raw.Trim();
        if (trimmed.Length >= 2 && trimmed[0] == '"' && trimmed[^1] == '"')
        {
            string? decoded = null;
            try { decoded = JsonSerializer.Deserialize<string>(trimmed); } catch { }
            if (!string.IsNullOrWhiteSpace(decoded)) yield return decoded;
        }

        // Some StudioMCP revisions render returned strings inside a human-readable
        // text block and leave JSON-style escapes in place. This variant makes the
        // sentinel transport independent of that wrapper format.
        if (trimmed.Contains("\\n", StringComparison.Ordinal) || trimmed.Contains("\\t", StringComparison.Ordinal) || trimmed.Contains("\\\"", StringComparison.Ordinal))
            yield return DecodeEscapedMcpText(trimmed);
    }

    private static string DecodeEscapedMcpText(string value) => value
        .Replace("\\r", "\r", StringComparison.Ordinal)
        .Replace("\\n", "\n", StringComparison.Ordinal)
        .Replace("\\t", "\t", StringComparison.Ordinal)
        .Replace("\\\"", "\"", StringComparison.Ordinal)
        .Replace("\\\\", "\\", StringComparison.Ordinal);

    private static string DecodeScanField(string value) => value
        .Replace("%0D", "\r", StringComparison.OrdinalIgnoreCase)
        .Replace("%0A", "\n", StringComparison.OrdinalIgnoreCase)
        .Replace("%09", "\t", StringComparison.OrdinalIgnoreCase)
        .Replace("%25", "%", StringComparison.OrdinalIgnoreCase);

    private static string BuildExactOriginalV2McpScanLuau(string assetType, string imageScope = "all") => $$"""
-- KAGE v85: original V2 collectAssets() transported through Studio MCP.
-- The discovery rules below intentionally mirror the September original.
local TARGET_TYPE = {{JsonSerializer.Serialize(NormalizeAssetType(assetType))}}
local IMAGE_SCOPE = {{JsonSerializer.Serialize(imageScope)}}
local function imageClassAllowed(inst)
    if IMAGE_SCOPE == "all" then return true end
    if IMAGE_SCOPE == "ui" then return inst:IsA("ImageLabel") or inst:IsA("ImageButton") or inst:IsA("ScrollingFrame") or inst:IsA("ClickDetector") end
    if IMAGE_SCOPE == "vfx" then return inst:IsA("ParticleEmitter") or inst:IsA("Beam") or inst:IsA("Trail") end
    if IMAGE_SCOPE == "textures" then
        return inst:IsA("Decal") or inst:IsA("Texture") or inst:IsA("MeshPart") or
            inst:IsA("SpecialMesh") or inst:IsA("Tool") or inst:IsA("CharacterMesh") or
            inst:IsA("SurfaceAppearance") or inst:IsA("MaterialVariant") or inst:IsA("Sky") or
            inst:IsA("Shirt") or inst:IsA("Pants") or inst:IsA("ShirtGraphic")
    end
    return false
end
local descendants = game:GetDescendants()

local function extractId(value)
    if value == nil then return nil end
    local id = string.match(tostring(value), "%d+")
    return id and tonumber(id) or nil
end

local function instancePath(inst)
    local parts = {}
    local current = inst
    while current and current ~= game do
        table.insert(parts, 1, current.Name)
        current = current.Parent
    end
    return table.concat(parts, "/")
end

local ids, names, locations, seen = {}, {}, {}, {}
local function addAsset(id, name, location)
    if id and id > 0 and not seen[id] then
        seen[id] = true
        table.insert(ids, id)
        local key = tostring(id)
        if type(name) == "string" and name ~= "" then names[key] = name end
        if type(location) == "string" and location ~= "" then locations[key] = location end
    end
end

-- Pass 1 is the original V2 typed-instance scan.
for _, inst in ipairs(descendants) do
    local raw = nil
    if TARGET_TYPE == "Animations" and inst:IsA("Animation") then
        raw = inst.AnimationId
    elseif TARGET_TYPE == "Sounds" and inst:IsA("Sound") then
        raw = inst.SoundId
    elseif TARGET_TYPE == "Meshes" and (inst:IsA("MeshPart") or inst:IsA("SpecialMesh")) then
        raw = inst.MeshId
    elseif TARGET_TYPE == "Decals" and imageClassAllowed(inst) and (inst:IsA("Decal") or inst:IsA("Texture")) then
        raw = inst.Texture
    end
    if raw then addAsset(extractId(raw), inst.Name, instancePath(inst)) end

    if TARGET_TYPE == "Animations" and inst:IsA("HumanoidDescription") then
        for _, p in ipairs({"ClimbAnimation","FallAnimation","IdleAnimation","JumpAnimation","RunAnimation","SwimAnimation","WalkAnimation","MoodAnimation"}) do
            local ok, val = pcall(function() return inst[p] end)
            if ok and val then addAsset(extractId(val), inst.Name .. "." .. p, instancePath(inst)) end
        end
        local okEmotes, emotes = pcall(function() return inst:GetEmotes() end)
        if okEmotes and type(emotes) == "table" then
            for emoteName, emoteIds in pairs(emotes) do
                if type(emoteIds) == "table" then
                    for _, eId in ipairs(emoteIds) do addAsset(extractId(eId), inst.Name .. "." .. tostring(emoteName), instancePath(inst)) end
                end
            end
        end
    elseif TARGET_TYPE == "Sounds" and inst:IsA("AudioPlayer") then
        local ok, val = pcall(function() return inst.Asset end)
        if ok and val then addAsset(extractId(val), inst.Name, instancePath(inst)) end
    elseif TARGET_TYPE == "Meshes" then
        if inst:IsA("CharacterMesh") then
            local ok, val = pcall(function() return inst.MeshId end)
            if ok and val then addAsset(extractId(val), inst.Name, instancePath(inst)) end
        elseif inst:IsA("WrapLayer") then
            local ok1, val1 = pcall(function() return inst.CageMeshId end)
            if ok1 and val1 then addAsset(extractId(val1), inst.Name, instancePath(inst)) end
            local ok2, val2 = pcall(function() return inst.ReferenceMeshId end)
            if ok2 and val2 then addAsset(extractId(val2), inst.Name, instancePath(inst)) end
        elseif inst:IsA("BaseWrap") or inst:IsA("WrapTarget") then
            local ok, val = pcall(function() return inst.CageMeshId end)
            if ok and val then addAsset(extractId(val), inst.Name, instancePath(inst)) end
        end
    elseif TARGET_TYPE == "Decals" and imageClassAllowed(inst) then
        if inst:IsA("ImageLabel") or inst:IsA("ImageButton") then
            local ok, val = pcall(function() return inst.Image end)
            if ok and val then addAsset(extractId(val), inst.Name, instancePath(inst)) end
            if inst:IsA("ImageButton") then
                local okH, valH = pcall(function() return inst.HoverImage end)
                if okH and valH then addAsset(extractId(valH), inst.Name, instancePath(inst)) end
                local okP, valP = pcall(function() return inst.PressedImage end)
                if okP and valP then addAsset(extractId(valP), inst.Name, instancePath(inst)) end
            end
        elseif inst:IsA("ScrollingFrame") then
            for _, p in ipairs({"TopImage", "MidImage", "BottomImage"}) do
                local ok, val = pcall(function() return inst[p] end)
                if ok and val then addAsset(extractId(val), inst.Name, instancePath(inst)) end
            end
        elseif inst:IsA("ParticleEmitter") or inst:IsA("Beam") or inst:IsA("Trail") then
            local ok, val = pcall(function() return inst.Texture end)
            if ok and val then addAsset(extractId(val), inst.Name, instancePath(inst)) end
        elseif inst:IsA("MeshPart") then
            local ok, val = pcall(function() return inst.TextureID end)
            if ok and val then addAsset(extractId(val), inst.Name, instancePath(inst)) end
        elseif inst:IsA("SpecialMesh") or inst:IsA("Tool") then
            local ok, val = pcall(function() return inst.TextureId end)
            if ok and val then addAsset(extractId(val), inst.Name, instancePath(inst)) end
        elseif inst:IsA("CharacterMesh") then
            local ok1, val1 = pcall(function() return inst.BaseTextureId end)
            if ok1 and val1 then addAsset(extractId(val1), inst.Name, instancePath(inst)) end
            local ok2, val2 = pcall(function() return inst.OverlayTextureId end)
            if ok2 and val2 then addAsset(extractId(val2), inst.Name, instancePath(inst)) end
        elseif inst:IsA("SurfaceAppearance") or inst:IsA("MaterialVariant") then
            for _, p in ipairs({"ColorMap", "MetalnessMap", "NormalMap", "RoughnessMap"}) do
                local ok, val = pcall(function() return inst[p] end)
                if ok and val then addAsset(extractId(val), inst.Name, instancePath(inst)) end
            end
        elseif inst:IsA("Sky") then
            for _, p in ipairs({"SkyboxBk", "SkyboxDn", "SkyboxFt", "SkyboxLf", "SkyboxRt", "SkyboxUp", "SunTextureId", "MoonTextureId"}) do
                local ok, val = pcall(function() return inst[p] end)
                if ok and val then addAsset(extractId(val), inst.Name, instancePath(inst)) end
            end
        elseif inst:IsA("Shirt") then
            local ok, val = pcall(function() return inst.ShirtTemplate end)
            if ok and val then addAsset(extractId(val), inst.Name, instancePath(inst)) end
        elseif inst:IsA("Pants") then
            local ok, val = pcall(function() return inst.PantsTemplate end)
            if ok and val then addAsset(extractId(val), inst.Name, instancePath(inst)) end
        elseif inst:IsA("ShirtGraphic") then
            local ok, val = pcall(function() return inst.Graphic end)
            if ok and val then addAsset(extractId(val), inst.Name, instancePath(inst)) end
        end
    end

    if (TARGET_TYPE ~= "Decals" or IMAGE_SCOPE == "all") and (inst:IsA("StringValue") or inst:IsA("IntValue") or inst:IsA("NumberValue")) then
        local nameLower = string.lower(inst.Name)
        local valRelevant = (TARGET_TYPE == "Animations" and (nameLower:find("anim", 1, true) or nameLower:find("emote", 1, true)))
            or (TARGET_TYPE == "Sounds" and (nameLower:find("sound", 1, true) or nameLower:find("audio", 1, true)))
            or (TARGET_TYPE == "Meshes" and nameLower:find("mesh", 1, true))
            or (TARGET_TYPE == "Decals" and (nameLower:find("decal", 1, true) or nameLower:find("texture", 1, true) or nameLower:find("image", 1, true)))
        if valRelevant then
            local okVal, val = pcall(function() return inst.Value end)
            if okVal and val then addAsset(extractId(val), inst.Name, instancePath(inst)) end
        end
    end
    local okAttrs, attrs = pcall(function() return inst:GetAttributes() end)
    if (TARGET_TYPE ~= "Decals" or IMAGE_SCOPE == "all") and okAttrs and type(attrs) == "table" then
        for attrName, attrVal in pairs(attrs) do
            local attrLower = string.lower(tostring(attrName))
            local attrRelevant = (TARGET_TYPE == "Animations" and (attrLower:find("anim", 1, true) or attrLower:find("emote", 1, true)))
                or (TARGET_TYPE == "Sounds" and (attrLower:find("sound", 1, true) or attrLower:find("audio", 1, true)))
                or (TARGET_TYPE == "Meshes" and attrLower:find("mesh", 1, true))
                or (TARGET_TYPE == "Decals" and (attrLower:find("decal", 1, true) or attrLower:find("texture", 1, true) or attrLower:find("image", 1, true)))
            if attrRelevant then
                addAsset(extractId(attrVal), inst.Name .. "." .. attrName, instancePath(inst))
            end
        end
    end
end

-- Pass 2 is the original V2 script-line scan. Source is read directly exactly
-- like the Command Bar build; there is no ScriptEditorService crawl.
local keywords = {
    Animations = {"anim", "animationid", "loadanimation"},
    Sounds = {"sound", "soundid", "audio"},
    Meshes = {"mesh", "meshid"},
    Decals = {"decal", "texture", "textureid"},
}

local extraKeywords = {
    Animations = {"playanimation", "animation_id", "animid", "emote"},
    Sounds = {"sound_id", "audio_id", "playsound"},
    Meshes = {"mesh_id"},
    Decals = {"image", "imageid", "image_id", "decalid"},
}

for _, inst in ipairs(descendants) do
    if (TARGET_TYPE ~= "Decals" or IMAGE_SCOPE == "all") and inst:IsA("LuaSourceContainer") then
        local ok, src = pcall(function() return inst.Source end)
        if ok and type(src) == "string" then
            local path = nil
            for line in string.gmatch(string.lower(src), "[^\r\n]+") do
                local relevant = false
                for _, keyword in ipairs(keywords[TARGET_TYPE] or {}) do
                    if string.find(line, keyword, 1, true) then
                        relevant = true
                        break
                    end
                end
                if not relevant then
                    for _, keyword in ipairs(extraKeywords[TARGET_TYPE] or {}) do
                        if string.find(line, keyword, 1, true) then
                            relevant = true
                            break
                        end
                    end
                end
                if relevant then
                    for id in string.gmatch(line, "rbxassetid://(%d+)") do
                        if string.len(id) >= 7 then
                            if not path then path = instancePath(inst) .. " [script reference]" end
                            addAsset(tonumber(id), inst.Name, path)
                        end
                    end
                    for id in string.gmatch(line, "[?&]id=(%d+)") do
                        if string.len(id) >= 7 then
                            if not path then path = instancePath(inst) .. " [script reference]" end
                            addAsset(tonumber(id), inst.Name, path)
                        end
                    end
                    for id in string.gmatch(line, "assetid://(%d+)") do
                        if string.len(id) >= 7 then
                            if not path then path = instancePath(inst) .. " [script reference]" end
                            addAsset(tonumber(id), inst.Name, path)
                        end
                    end
                    for id in string.gmatch(line, "[%f[%d]](%d%d%d%d%d%d%d+)[%f[%D]]") do
                        if string.len(id) <= 15 then
                            if not path then path = instancePath(inst) .. " [script reference]" end
                            addAsset(tonumber(id), inst.Name, path)
                        end
                    end
                end
            end
        end
    end
end

table.sort(ids)

local function encodeField(value)
    local text = tostring(value or "")
    text = string.gsub(text, "%%", "%%25")
    text = string.gsub(text, "\r", "%%0D")
    text = string.gsub(text, "\n", "%%0A")
    text = string.gsub(text, "\t", "%%09")
    return text
end

local rows = {}
for _, id in ipairs(ids) do
    local key = tostring(id)
    table.insert(rows, key .. "\t" .. encodeField(names[key] or "") .. "\t" .. encodeField(locations[key] or ""))
end

-- Plain tagged text is intentional. It avoids depending on whichever JSON/text
-- wrapper a particular StudioMCP build uses for execute_luau return strings.
return "{{KageScanMarker}}\t" .. tostring(#descendants) .. "\n" .. table.concat(rows, "\n") .. "\n{{KageScanEndMarker}}"
""";

    // Four broad groups keep MCP round-trips low while preventing one pathological
    // service/script collection from pinning the entire scan forever.
    private static readonly string[][] StudioScanGroups =
    {
        new[] { "Workspace" },
        new[] { "ReplicatedStorage", "ReplicatedFirst" },
        new[] { "ServerScriptService", "ServerStorage" },
        new[] { "StarterGui", "StarterPack", "StarterPlayer", "Lighting", "SoundService", "MaterialService", "Teams", "TextChatService", "LocalizationService" }
    };

    private async Task<int> CountStudioScanDescendantsAsync(IReadOnlyList<string[]> groups, CancellationToken ct)
    {
        var result = await ExecuteReadOnlyLuauWithStudioRecoveryAsync(
            BuildStudioScanCountLuau(groups), ct, _project, TimeSpan.FromSeconds(8)).ConfigureAwait(false);
        var payload = ExtractJsonPayload(result);
        if (string.IsNullOrWhiteSpace(payload)) return 0;
        using var doc = JsonDocument.Parse(payload);
        return doc.RootElement.ValueKind == JsonValueKind.Object ? Math.Max(0, GetInt(doc.RootElement, "total", 0)) : 0;
    }

    private async Task<StudioScanPiece> ScanOriginalV2GroupAsync(string assetType, IReadOnlyList<string> roots, CancellationToken ct)
    {
        var label = string.Join("+", roots);
        var result = await ExecuteReadOnlyLuauWithStudioRecoveryAsync(
            BuildOriginalV2McpAssetScanLuau(assetType, roots),
            ct,
            _project,
            TimeSpan.FromSeconds(18)).ConfigureAwait(false);
        return ParseOriginalV2ScanPiece(result, label);
    }

    private static string BuildStudioScanCountLuau(IReadOnlyList<string[]> groups)
    {
        var roots = groups.SelectMany(group => group).Distinct(StringComparer.Ordinal).ToArray();
        return $$"""
local HttpService = game:GetService("HttpService")
local ROOTS = {{JsonSerializer.Serialize(roots)}}
local total = 0
for _, rootName in ipairs(ROOTS) do
    local ok, root = pcall(function() return game:GetService(rootName) end)
    if ok and root then total += #root:GetDescendants() end
end
return HttpService:JSONEncode({ ok = true, total = total })
""";
    }

    private static StudioScanPiece ParseOriginalV2ScanPiece(JsonElement result, string rootName)
    {
        var payload = ExtractJsonPayload(result);
        if (string.IsNullOrWhiteSpace(payload))
            return EmptyScanPiece(rootName, StudioScanStage.DirectAsset, "Studio returned no asset scan payload.");

        try
        {
            using var document = JsonDocument.Parse(payload);
            var root = document.RootElement;
            if (root.ValueKind != JsonValueKind.Object)
                return EmptyScanPiece(rootName, StudioScanStage.DirectAsset, "Studio returned a non-object asset scan payload.");
            if (root.TryGetProperty("ok", out var okElement) && okElement.ValueKind == JsonValueKind.False)
                return EmptyScanPiece(rootName, StudioScanStage.DirectAsset, GetString(root, "error", "Studio rejected the asset scan."));

            var ids = new List<long>();
            var names = new Dictionary<string, string>(StringComparer.Ordinal);
            var locations = new Dictionary<string, string>(StringComparer.Ordinal);

            if (root.TryGetProperty("ids", out var idsElement) && idsElement.ValueKind == JsonValueKind.Array)
                foreach (var value in idsElement.EnumerateArray())
                    if (value.TryGetInt64(out var id) && id > 0) ids.Add(id);

            if (root.TryGetProperty("names", out var namesElement) && namesElement.ValueKind == JsonValueKind.Object)
                foreach (var property in namesElement.EnumerateObject())
                    if (property.Value.ValueKind == JsonValueKind.String && property.Value.GetString() is { Length: > 0 } value)
                        names[property.Name] = value;

            if (root.TryGetProperty("locations", out var locationsElement) && locationsElement.ValueKind == JsonValueKind.Object)
                foreach (var property in locationsElement.EnumerateObject())
                    if (property.Value.ValueKind == JsonValueKind.String && property.Value.GetString() is { Length: > 0 } value)
                        locations[property.Name] = value;

            var total = Math.Max(0, GetInt(root, "totalDescendants", 0));
            return new StudioScanPiece(rootName, StudioScanStage.DirectAsset, ids.Distinct().ToArray(), names, locations, null, total, true, total, total);
        }
        catch (Exception ex)
        {
            return EmptyScanPiece(rootName, StudioScanStage.DirectAsset, $"Studio returned invalid asset scan JSON: {ex.Message}");
        }
    }

    private const int StudioScanBatchSize = 180;
    private const int StudioScanMaxPagesPerRootStage = 512;

    private async Task<StudioScanPiece> ScanRootAsync(
        string rootName,
        string assetType,
        StudioScanStage stage,
        CancellationToken ct)
    {
        var ids = new HashSet<long>();
        var names = new Dictionary<string, string>(StringComparer.Ordinal);
        var locations = new Dictionary<string, string>(StringComparer.Ordinal);
        var offset = 0;

        for (var pageNumber = 0; pageNumber < StudioScanMaxPagesPerRootStage; pageNumber++)
        {
            ct.ThrowIfCancellationRequested();
            var page = await ScanRootPageAsync(rootName, assetType, stage, offset, ct).ConfigureAwait(false);

            foreach (var id in page.AssetIds)
                if (id > 0) ids.Add(id);
            foreach (var pair in page.AssetNames)
                if (!names.ContainsKey(pair.Key)) names[pair.Key] = pair.Value;
            foreach (var pair in page.AssetLocations)
                if (!locations.ContainsKey(pair.Key)) locations[pair.Key] = pair.Value;

            if (!string.IsNullOrWhiteSpace(page.Error))
                return new StudioScanPiece(rootName, stage, ids.Order().ToArray(), names, locations, page.Error, offset, true);

            if (page.Done)
                return new StudioScanPiece(rootName, stage, ids.Order().ToArray(), names, locations);

            if (page.NextOffset <= offset)
                return new StudioScanPiece(
                    rootName,
                    stage,
                    ids.Order().ToArray(),
                    names,
                    locations,
                    $"Studio scan cursor stopped advancing at descendant offset {offset}.",
                    offset,
                    true);

            offset = page.NextOffset;
        }

        return new StudioScanPiece(
            rootName,
            stage,
            ids.Order().ToArray(),
            names,
            locations,
            $"Studio scan exceeded {StudioScanMaxPagesPerRootStage} pages for this service.",
            offset,
            true);
    }

    private async Task<StudioScanPiece> ScanRootPageAsync(
        string rootName,
        string assetType,
        StudioScanStage stage,
        int offset,
        CancellationToken ct)
    {
        try
        {
            var result = await ExecuteReadOnlyLuauWithStudioRecoveryAsync(
                BuildRootScanLuau(rootName, assetType, stage, Math.Max(0, offset), StudioScanBatchSize),
                ct, _project).ConfigureAwait(false);
            var payload = ExtractJsonPayload(result);
            if (string.IsNullOrWhiteSpace(payload))
                return EmptyScanPiece(rootName, stage, "Studio returned an empty JSON payload for this scan page.");

            using var document = JsonDocument.Parse(payload);
            var root = document.RootElement;
            if (root.ValueKind != JsonValueKind.Object)
                return EmptyScanPiece(rootName, stage, "Studio returned a non-object scan payload.");

            if (root.TryGetProperty("ok", out var okElement) && okElement.ValueKind == JsonValueKind.False)
                return EmptyScanPiece(rootName, stage, GetString(root, "error", "Studio rejected this scan page."));

            var ids = new List<long>();
            var names = new Dictionary<string, string>(StringComparer.Ordinal);
            var locations = new Dictionary<string, string>(StringComparer.Ordinal);
            if (root.TryGetProperty("ids", out var idArray) && idArray.ValueKind == JsonValueKind.Array)
            {
                foreach (var item in idArray.EnumerateArray())
                    if (item.TryGetInt64(out var id) && id > 0) ids.Add(id);
            }
            if (root.TryGetProperty("names", out var nameObject) && nameObject.ValueKind == JsonValueKind.Object)
            {
                foreach (var property in nameObject.EnumerateObject())
                    if (property.Value.ValueKind == JsonValueKind.String && property.Value.GetString() is { Length: > 0 } value)
                        names[property.Name] = value;
            }
            if (root.TryGetProperty("locations", out var locationObject) && locationObject.ValueKind == JsonValueKind.Object)
            {
                foreach (var property in locationObject.EnumerateObject())
                    if (property.Value.ValueKind == JsonValueKind.String && property.Value.GetString() is { Length: > 0 } value)
                        locations[property.Name] = value;
            }

            var nextOffset = GetInt(root, "nextOffset", Math.Max(0, offset) + StudioScanBatchSize);
            var done = root.TryGetProperty("done", out var doneElement) &&
                       doneElement.ValueKind is JsonValueKind.True or JsonValueKind.False
                ? doneElement.GetBoolean()
                : ids.Count == 0;

            return new StudioScanPiece(
                rootName,
                stage,
                ids.Distinct().ToArray(),
                names,
                locations,
                null,
                Math.Max(nextOffset, 0),
                done);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested) { throw; }
        catch (Exception ex)
        {
            return EmptyScanPiece(rootName, stage, ex.Message);
        }
    }

    private static StudioScanPiece EmptyScanPiece(string rootName, StudioScanStage stage, string error) =>
        new(rootName, stage, Array.Empty<long>(), new Dictionary<string, string>(), new Dictionary<string, string>(), error);

    public async Task<int> ApplyMappingAsync(string assetType, IReadOnlyDictionary<long, long> mapping, CancellationToken ct = default)
    {
        var result = await ApplyMappingDetailedAsync(assetType, mapping, ct).ConfigureAwait(false);
        return result.Changed;
    }

    public async Task<StudioReferenceApplyResult> ApplyMappingDetailedAsync(
        string assetType,
        IReadOnlyDictionary<long, long> mapping,
        CancellationToken ct = default)
    {
        if (mapping.Count == 0)
            return new StudioReferenceApplyResult(0, Array.Empty<StudioReferenceChange>(), Array.Empty<StudioReferenceFailure>());

        using var operation = BeginOperation(ct);
        ct = operation.Token;
        await _gate.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            if (!IsConnected) await ConnectAsync(ct).ConfigureAwait(false);
            var normalized = NormalizeAssetType(assetType);
            var changes = new List<StudioReferenceChange>();
            var failures = new List<StudioReferenceFailure>();

            foreach (var chunk in mapping.Chunk(250))
            {
                var result = await ExecuteLuauAsync(BuildApplyMappingLuau(normalized, chunk), ct).ConfigureAwait(false);
                var json = ExtractJsonPayload(result);
                if (string.IsNullOrWhiteSpace(json))
                {
                    foreach (var pair in chunk)
                        failures.Add(new StudioReferenceFailure(pair.Key, pair.Value, "Studio", "batch", "Studio returned no replacement result."));
                    continue;
                }

                using var doc = JsonDocument.Parse(json);
                var root = doc.RootElement;
                if (root.TryGetProperty("changes", out var changeArray) && changeArray.ValueKind == JsonValueKind.Array)
                {
                    foreach (var item in changeArray.EnumerateArray())
                    {
                        var oldId = GetLong(item, "oldId");
                        var newId = GetLong(item, "newId");
                        if (oldId <= 0 || newId <= 0) continue;
                        changes.Add(new StudioReferenceChange(
                            oldId,
                            newId,
                            GetString(item, "location", "Studio"),
                            GetString(item, "kind", "reference"),
                            Math.Max(1, GetInt(item, "count", 1)),
                            GetString(item, "instanceKey", "")));
                    }
                }

                if (root.TryGetProperty("failures", out var failureArray) && failureArray.ValueKind == JsonValueKind.Array)
                {
                    foreach (var item in failureArray.EnumerateArray())
                    {
                        var oldId = GetLong(item, "oldId");
                        var newId = GetLong(item, "newId");
                        if (oldId <= 0 || newId <= 0) continue;
                        failures.Add(new StudioReferenceFailure(
                            oldId,
                            newId,
                            GetString(item, "location", "Studio"),
                            GetString(item, "kind", "reference"),
                            GetString(item, "reason", "setter failed")));
                    }
                }
            }

            return new StudioReferenceApplyResult(StudioReferenceCounts.CountInstances(changes), changes, failures);
        }
        finally
        {
            _gate.Release();
        }
    }

    /// <summary>
    /// Fast live updater used while uploads are still completing. It only touches the
    /// selected asset family's concrete Roblox properties (AnimationId, SoundId, MeshId,
    /// Texture, etc.) and intentionally skips ScriptSource/attributes/value objects.
    /// The final original-V2 pass handles those text/metadata references once, avoiding
    /// dozens of expensive whole-project script crawls during a 900+ asset run.
    /// </summary>
    public async Task<StudioReferenceApplyResult> ApplyDirectInstanceMappingsAsync(
        string assetType,
        IReadOnlyDictionary<long, long> mapping,
        CancellationToken ct = default,
        StudioProjectInfo? expectedProject = null)
    {
        if (mapping.Count == 0)
            return new StudioReferenceApplyResult(0, Array.Empty<StudioReferenceChange>(), Array.Empty<StudioReferenceFailure>());

        using var operation = BeginOperation(ct, 16);
        ct = operation.Token;
        await _gate.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            if (!IsConnected) await ConnectAsync(ct).ConfigureAwait(false);
            var normalized = NormalizeAssetType(assetType);
            var code = GuardReferenceProject(BuildDirectInstanceMappingLuau(normalized, mapping), expectedProject);
            var result = await ExecuteLuauAsync(code, ct, expectedProject?.StudioId).ConfigureAwait(false);
            var json = ExtractJsonPayload(result);
            if (string.IsNullOrWhiteSpace(json))
                throw new InvalidOperationException("Studio returned no live reference replacement result.");

            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;
            if (root.ValueKind != JsonValueKind.Object)
                throw new InvalidOperationException("Studio returned an invalid live reference replacement result.");

            var changes = new List<StudioReferenceChange>();
            var failures = new List<StudioReferenceFailure>();
            if (root.TryGetProperty("changes", out var changeArray) && changeArray.ValueKind == JsonValueKind.Array)
            {
                foreach (var item in changeArray.EnumerateArray())
                {
                    var oldId = GetLong(item, "oldId");
                    var newId = GetLong(item, "newId");
                    if (oldId <= 0 || newId <= 0) continue;
                    changes.Add(new StudioReferenceChange(
                        oldId, newId,
                        GetString(item, "location", "Studio"),
                        GetString(item, "kind", "reference"),
                        Math.Max(1, GetInt(item, "count", 1)),
                        GetString(item, "instanceKey", "")));
                }
            }
            if (root.TryGetProperty("failures", out var failureArray) && failureArray.ValueKind == JsonValueKind.Array)
            {
                foreach (var item in failureArray.EnumerateArray())
                {
                    var oldId = GetLong(item, "oldId");
                    var newId = GetLong(item, "newId");
                    if (oldId <= 0 || newId <= 0) continue;
                    failures.Add(new StudioReferenceFailure(
                        oldId, newId,
                        GetString(item, "location", "Studio"),
                        GetString(item, "kind", "reference"),
                        GetString(item, "reason", "setter failed")));
                }
            }
            return new StudioReferenceApplyResult(StudioReferenceCounts.CountInstances(changes), changes, failures);
        }
        finally { _gate.Release(); }
    }

    public async Task<StudioReferenceApplyResult> ApplyOriginalV2MappingAsync(
        string assetType,
        IReadOnlyDictionary<long, long> mapping,
        CancellationToken ct = default,
        StudioProjectInfo? expectedProject = null)
    {
        if (mapping.Count == 0)
            return new StudioReferenceApplyResult(0, Array.Empty<StudioReferenceChange>(), Array.Empty<StudioReferenceFailure>());

        // old -> new replacement is idempotent because overlapping source/destination IDs
        // are rejected by KageMcpService before this method runs. That makes it safe to
        // replay the exact mutation after a transport drop or a lost MCP result payload.
        using var operation = BeginOperation(ct, 260);
        ct = operation.Token;
        await _gate.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            if (!IsConnected) await ConnectAsync(ct).ConfigureAwait(false);
            var normalized = NormalizeAssetType(assetType);
            var code = GuardReferenceProject(BuildOriginalV2MappingLuau(normalized, mapping), expectedProject);
            Exception? lastError = null;

            for (var attempt = 0; attempt < 3; attempt++)
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    var result = await ExecuteLuauAsync(
                        code, ct, expectedProject?.StudioId ?? _active?.StudioId, TimeSpan.FromSeconds(115)).ConfigureAwait(false);
                    var json = ExtractJsonPayload(result);
                    if (string.IsNullOrWhiteSpace(json))
                        throw new InvalidOperationException("Studio returned no reference replacement result.");

                    using var doc = JsonDocument.Parse(json);
                    var root = doc.RootElement;
                    if (root.ValueKind != JsonValueKind.Object ||
                        !root.TryGetProperty("changed", out var changedElement) || !changedElement.TryGetInt32(out var reportedChanged) ||
                        !root.TryGetProperty("changes", out var resultChanges) || resultChanges.ValueKind != JsonValueKind.Array ||
                        !root.TryGetProperty("failures", out var resultFailures) || resultFailures.ValueKind != JsonValueKind.Array)
                        throw new InvalidOperationException("Studio returned an invalid reference replacement result.");

                    var changes = new List<StudioReferenceChange>();
                    var failures = new List<StudioReferenceFailure>();
                    foreach (var item in resultChanges.EnumerateArray())
                    {
                        var oldId = GetLong(item, "oldId");
                        var newId = GetLong(item, "newId");
                        if (oldId <= 0 || newId <= 0) continue;
                        changes.Add(new StudioReferenceChange(
                            oldId, newId,
                            GetString(item, "location", "Studio"),
                            GetString(item, "kind", "reference"),
                            Math.Max(1, GetInt(item, "count", 1)),
                            GetString(item, "instanceKey", "")));
                    }
                    foreach (var item in resultFailures.EnumerateArray())
                    {
                        var oldId = GetLong(item, "oldId");
                        var newId = GetLong(item, "newId");
                        if (oldId <= 0 || newId <= 0) continue;
                        failures.Add(new StudioReferenceFailure(
                            oldId, newId,
                            GetString(item, "location", "Studio"),
                            GetString(item, "kind", "reference"),
                            GetString(item, "reason", "setter failed")));
                    }

                    return new StudioReferenceApplyResult(
                        Math.Max(Math.Max(0, reportedChanged), StudioReferenceCounts.CountInstances(changes)),
                        changes, failures);
                }
                catch (JsonException ex) when (!ct.IsCancellationRequested)
                {
                    lastError = ex;
                }
                catch (Exception ex) when (!ct.IsCancellationRequested && IsRecoverableMcpTransportFailure(ex))
                {
                    lastError = ex;
                }

                if (attempt >= 2) break;
                try
                {
                    await RebindStudioTargetAsync(expectedProject, ct).ConfigureAwait(false);
                }
                catch (Exception ex) when (!ct.IsCancellationRequested && IsRecoverableMcpTransportFailure(ex))
                {
                    lastError = ex;
                }
                await Task.Delay(TimeSpan.FromMilliseconds(200 * (attempt + 1)), ct).ConfigureAwait(false);
            }

            throw new InvalidOperationException(
                "Studio did not return a usable reference result after automatic reconnect/replay.",
                lastError);
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task<StudioReferenceVerification> FindRemainingMappedReferencesAsync(
        string assetType,
        IEnumerable<long> oldIds,
        CancellationToken ct = default,
        StudioProjectInfo? expectedProject = null)
    {
        var ids = oldIds.Where(id => id > 0).Distinct().Order().ToArray();
        if (ids.Length == 0)
            return new StudioReferenceVerification(new Dictionary<long, IReadOnlyList<string>>());

        using var operation = BeginOperation(ct);
        ct = operation.Token;
        await _gate.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            if (!IsConnected) await ConnectAsync(ct).ConfigureAwait(false);
            var normalized = NormalizeAssetType(assetType);
            var remaining = new Dictionary<long, HashSet<string>>();

            foreach (var chunk in ids.Chunk(1500))
            {
                var code = GuardReferenceProject(BuildVerifyMappingLuau(normalized, chunk), expectedProject);
                var result = await ExecuteReadOnlyLuauWithStudioRecoveryAsync(
                    code, ct, expectedProject, TimeSpan.FromSeconds(55)).ConfigureAwait(false);
                var json = ExtractJsonPayload(result);
                if (string.IsNullOrWhiteSpace(json))
                    throw new InvalidOperationException("Studio returned no reference verification result.");

                using var doc = JsonDocument.Parse(json);
                var root = doc.RootElement;
                if (root.ValueKind != JsonValueKind.Object || !root.TryGetProperty("remaining", out var remainingObject))
                    throw new InvalidOperationException("Studio returned an invalid reference verification result.");
                // Diagnostic errors from unreadable or locked scripts do not invalidate verified locations.
                // Roblox encodes an empty Luau table as an empty JSON array.
                if (remainingObject.ValueKind == JsonValueKind.Array && remainingObject.GetArrayLength() == 0) continue;
                if (remainingObject.ValueKind != JsonValueKind.Object)
                    throw new InvalidOperationException("Studio returned invalid remaining reference locations.");

                foreach (var property in remainingObject.EnumerateObject())
                {
                    if (!long.TryParse(property.Name, out var id) || id <= 0) continue;
                    if (!remaining.TryGetValue(id, out var locations)) remaining[id] = locations = new HashSet<string>(StringComparer.Ordinal);
                    if (property.Value.ValueKind != JsonValueKind.Array) continue;
                    foreach (var location in property.Value.EnumerateArray())
                        if (location.ValueKind == JsonValueKind.String && location.GetString() is { Length: > 0 } value) locations.Add(value);
                }
            }

            return new StudioReferenceVerification(remaining.ToDictionary(
                pair => pair.Key,
                pair => (IReadOnlyList<string>)pair.Value.OrderBy(value => value, StringComparer.Ordinal).ToArray()));
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task DisconnectAsync()
    {
        if (IsConnected && Volatile.Read(ref _disposed) == 0)
        {
            using var cleanup = new CancellationTokenSource(TimeSpan.FromSeconds(1));
            try { await StopAnimationPreviewAsync(cleanup.Token).ConfigureAwait(false); } catch { }
        }
        lock (_lifetimeSync) _operations.Cancel();
        _active = null;
        _project = null;
        await _client.DisconnectAsync().ConfigureAwait(false);
    }

    public async Task WriteCompletionOutputAsync(StudioProjectInfo expectedProject, string username, CancellationToken ct = default)
    {
        using var operation = BeginOperation(ct, 10);
        ct = operation.Token;
        await _gate.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            var projectName = string.IsNullOrWhiteSpace(expectedProject.ProjectName) ? "Studio Project" : expectedProject.ProjectName.Trim();
            var accountName = string.IsNullOrWhiteSpace(username) ? "the active Roblox account" : username.Trim();
            var message = $"KAGE has successfully reuploaded and remapped all the assets in this project \"{projectName}\" for {accountName}.";
            var code = GuardReferenceProject($"print({JsonSerializer.Serialize(message)})", expectedProject);
            _ = await ExecuteLuauAsync(code, ct, expectedProject.StudioId).ConfigureAwait(false);
        }
        finally { _gate.Release(); }
    }

    private static string GuardReferenceProject(string code, StudioProjectInfo? project)
    {
        if (project is null) return code;
        return $"if game.PlaceId ~= {project.PlaceId} or game.GameId ~= {project.UniverseId} then error(\"The Studio project changed during this run. Reference updates stopped.\") end\n" + code;
    }

    private static bool IsStudioTargetUnavailable(Exception ex)
    {
        var message = ex.Message ?? string.Empty;
        return message.Contains("No Roblox Studio instances are connected", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("previously active Studio instance has disconnected", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("no Roblox Studio instance is selected", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("Studio instance", StringComparison.OrdinalIgnoreCase) &&
                   (message.Contains("not found", StringComparison.OrdinalIgnoreCase) ||
                    message.Contains("disconnected", StringComparison.OrdinalIgnoreCase) ||
                    message.Contains("not connected", StringComparison.OrdinalIgnoreCase));
    }

    internal static bool IsRecoverableMcpTransportFailure(Exception ex)
    {
        if (ex is TimeoutException or IOException) return true;
        if (ex.InnerException is not null && IsRecoverableMcpTransportFailure(ex.InnerException)) return true;
        var message = ex.Message ?? string.Empty;
        return IsStudioTargetUnavailable(ex) ||
               message.Contains("connection closed", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("closed its output stream", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("disconnected during the request", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("did not respond", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("returned no result", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("returned no reference", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("returned an invalid reference", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("tool not found", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("unknown tool", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("tool unavailable", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("tool is not registered", StringComparison.OrdinalIgnoreCase);
    }

    private async Task RebindStudioTargetAsync(StudioProjectInfo? expectedProject, CancellationToken ct)
    {
        var previousProject = expectedProject ?? _project;
        var previousActive = _active;

        // Force a fresh StudioMCP stdio process. Roblox Studio can leave an MCP
        // process with a stale editor registration; keeping that process alive only
        // repeats the same "no Studio instances" response.
        await _client.DisconnectAsync().ConfigureAwait(false);
        await _client.ConnectAsync(ct).ConfigureAwait(false);

        var deadline = DateTimeOffset.UtcNow + TimeSpan.FromSeconds(25);
        Exception? lastError = null;
        while (DateTimeOffset.UtcNow < deadline)
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                var studios = await ListStudiosAsync(ct).ConfigureAwait(false);
                StudioMcpInstance? selected = null;
                if (previousProject is { PlaceId: > 0 })
                    selected = studios.FirstOrDefault(instance => instance.PlaceId == previousProject.PlaceId);
                selected ??= SelectStudioInstance(studios, previousActive, previousProject);
                if (selected is not null)
                {
                    _active = selected;
                    var project = await ReadProjectInfoAsync(ct).ConfigureAwait(false);
                    if (previousProject is { PlaceId: > 0 } && project.PlaceId != previousProject.PlaceId)
                        throw new InvalidOperationException("Studio MCP reconnected to a different place. Reopen the intended project and reconnect KAGE.");
                    _project = project;
                    return;
                }
            }
            catch (Exception ex) when (!ct.IsCancellationRequested)
            {
                lastError = ex;
            }
            await Task.Delay(TimeSpan.FromMilliseconds(400), ct).ConfigureAwait(false);
        }

        throw new InvalidOperationException(
            "KAGE restarted the Studio MCP connection, but the open place did not register again within 25 seconds.",
            lastError);
    }

    private async Task<JsonElement> ExecuteReadOnlyLuauWithStudioRecoveryAsync(
        string code,
        CancellationToken ct,
        StudioProjectInfo? expectedProject = null,
        TimeSpan? timeout = null)
    {
        Exception? lastError = null;
        for (var attempt = 0; attempt < 3; attempt++)
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                return await ExecuteLuauAsync(code, ct, expectedProject?.StudioId ?? _active?.StudioId, timeout).ConfigureAwait(false);
            }
            catch (Exception ex) when (!ct.IsCancellationRequested && IsRecoverableMcpTransportFailure(ex))
            {
                lastError = ex;
                if (attempt >= 2) break;
                try
                {
                    await RebindStudioTargetAsync(expectedProject, ct).ConfigureAwait(false);
                }
                catch (Exception rebindError) when (!ct.IsCancellationRequested && IsRecoverableMcpTransportFailure(rebindError))
                {
                    lastError = rebindError;
                }
                await Task.Delay(TimeSpan.FromMilliseconds(200 * (attempt + 1)), ct).ConfigureAwait(false);
            }
        }

        throw new InvalidOperationException(
            "Studio connection recovery was exhausted while reading the open project.",
            lastError);
    }

    private Task<JsonElement> ExecuteLuauAsync(
        string code,
        CancellationToken ct,
        string? expectedStudioId = null,
        TimeSpan? timeout = null)
    {
        if (_active is null) throw new InvalidOperationException("No Roblox Studio instance is selected.");
        var args = new
        {
            studio_id = expectedStudioId ?? _active.StudioId,
            datamodel_type = "Edit",
            code
        };
        return timeout.HasValue
            ? _client.CallToolAsync("execute_luau", args, timeout.Value, ct)
            : _client.CallToolAsync("execute_luau", args, ct);
    }

    private static string NormalizeAssetType(string? value)
    {
        var normalized = value?.Trim().ToLowerInvariant();
        if (string.IsNullOrEmpty(normalized) || normalized is "animation" or "animations") return "Animations";
        throw new InvalidOperationException("KAGE Lite supports animation references only.");
    }


    private static string BuildProjectInfoLuau() => """
local HttpService = game:GetService("HttpService")
return HttpService:JSONEncode({
    projectName = game.Name,
    placeId = game.PlaceId,
    universeId = game.GameId,
    creatorId = game.CreatorId,
    creatorType = tostring(game.CreatorType):gsub("Enum.CreatorType.", "")
})
""";

    private static string BuildWorkspaceTreeLuau() => """
local HttpService = game:GetService("HttpService")
local nodes = {}
local maxNodes = 320
local maxDepth = 3
local function visit(parent, depth)
    if depth > maxDepth or #nodes >= maxNodes then return end
    local children = parent:GetChildren()
    table.sort(children, function(a, b) return a.Name:lower() < b.Name:lower() end)
    for _, child in ipairs(children) do
        if #nodes >= maxNodes then break end
        table.insert(nodes, { name = child.Name, className = child.ClassName, depth = depth })
        visit(child, depth + 1)
    end
end
visit(game, 0)
return HttpService:JSONEncode(nodes)
""";

    private const string AssetPropertyListLuau = """
local function withoutKagePreviews(instances)
    for i = #instances, 1, -1 do
        local current = instances[i]
        while current and current ~= game do
            local ok, marker = pcall(function() return current:GetAttribute("KagePreviewTransient") end)
            if ok and marker == true then table.remove(instances, i); break end
            current = current.Parent
        end
    end
    return instances
end
local referenceInstanceKeys = {}
local function referenceInstanceKey(inst)
    if referenceInstanceKeys[inst] then return referenceInstanceKeys[inst] end
    local ok, debugId = pcall(function() return inst:GetDebugId(32) end)
    local key
    if ok and type(debugId) == "string" and debugId ~= "" then
        key = "debug:" .. debugId
    else
        -- A name path cannot distinguish siblings with the same name. This
        -- fallback uses their hierarchy positions without writing attributes.
        local parts, current = {}, inst
        while current and current ~= game do
            local parent, index = current.Parent, 0
            if parent then
                for siblingIndex, sibling in ipairs(parent:GetChildren()) do
                    if sibling == current then index = siblingIndex; break end
                end
            end
            table.insert(parts, 1, tostring(index))
            current = parent
        end
        key = "tree:" .. table.concat(parts, "/")
    end
    referenceInstanceKeys[inst] = key
    return key
end
local function assetProperties(inst, kind)
    if kind == "Animations" then
        if inst:IsA("Animation") then return {"AnimationId"} end
        if inst:IsA("HumanoidDescription") then return {"ClimbAnimation", "FallAnimation", "IdleAnimation", "JumpAnimation", "RunAnimation", "SwimAnimation", "WalkAnimation", "MoodAnimation"} end
    elseif kind == "Sounds" then
        if inst:IsA("Sound") then return {"SoundId"} end
        if inst:IsA("AudioPlayer") then return {"Asset"} end
    elseif kind == "Meshes" then
        if inst:IsA("MeshPart") or inst:IsA("SpecialMesh") or inst:IsA("CharacterMesh") then return {"MeshId"} end
        if inst:IsA("WrapLayer") then return {"CageMeshId", "ReferenceMeshId"} end
        if inst:IsA("BaseWrap") or inst:IsA("WrapTarget") then return {"CageMeshId"} end
    elseif kind == "Decals" then
        if inst:IsA("Decal") or inst:IsA("Texture") then return {"Texture", "ColorMapContent", "NormalMapContent", "NormalMap", "MetalnessMapContent", "MetalnessMap", "RoughnessMapContent", "RoughnessMap"} end
        if inst:IsA("ParticleEmitter") or inst:IsA("Beam") or inst:IsA("Trail") then return {"Texture"} end
        if inst:IsA("ImageButton") then return {"Image", "HoverImage", "PressedImage"} end
        if inst:IsA("ImageLabel") then return {"Image"} end
        if inst:IsA("ScrollingFrame") then return {"TopImage", "MidImage", "BottomImage"} end
        if inst:IsA("MeshPart") then return {"TextureID"} end
        if inst:IsA("SpecialMesh") or inst:IsA("Tool") then return {"TextureId"} end
        if inst:IsA("CharacterMesh") then return {"BaseTextureId", "OverlayTextureId"} end
        if inst:IsA("SurfaceAppearance") or inst:IsA("MaterialVariant") then return {"ColorMap", "MetalnessMap", "NormalMap", "RoughnessMap"} end
        if inst:IsA("Sky") then return {"SkyboxBk", "SkyboxDn", "SkyboxFt", "SkyboxLf", "SkyboxRt", "SkyboxUp", "SunTextureId", "MoonTextureId"} end
        if inst:IsA("Shirt") then return {"ShirtTemplate"} end
        if inst:IsA("Pants") then return {"PantsTemplate"} end
        if inst:IsA("ShirtGraphic") then return {"Graphic"} end
        if inst:IsA("ClickDetector") then return {"CursorIcon"} end
    end
    return {}
end

local optionalProperties = { ColorMapContent=true, NormalMapContent=true, NormalMap=true, MetalnessMapContent=true, MetalnessMap=true, RoughnessMapContent=true, RoughnessMap=true, MoodAnimation=true }
local function readAssetProperty(inst, prop)
    local ok, value = pcall(function() return inst[prop] end)
    if not ok and optionalProperties[prop] and tostring(value):find("not a valid member", 1, true) then
        return true, nil
    end
    return ok, value
end

local function contentUri(value)
    if typeof and typeof(value) == "Content" then
        return value.Uri or ""
    end
    return value
end

local function readStudioSource(inst, hasEditor, editor)
    if hasEditor and editor then
        local ok, source = pcall(function() return editor:GetEditorSource(inst) end)
        if ok and type(source) == "string" then return true, source end
        local documentOk, document = pcall(function() return editor:FindScriptDocument(inst) end)
        if not documentOk or document then
            return false, "Cannot read current editor source: " .. tostring(source)
        end
    end
    return pcall(function() return inst.Source end)
end
""";

    private static string BuildOriginalV2McpAssetScanLuau(string assetType, IReadOnlyList<string> rootNames) => $$"""
local HttpService = game:GetService("HttpService")
local TARGET_TYPE = {{JsonSerializer.Serialize(NormalizeAssetType(assetType))}}
local ROOTS = {{JsonSerializer.Serialize(rootNames)}}
local hasEditor, ScriptEditorService = pcall(function() return game:GetService("ScriptEditorService") end)

local function isValidId(id)
    local num = tonumber(id)
    if not num or num <= 0 or num % 1 ~= 0 then return false end
    local len = string.len(tostring(math.floor(num)))
    return len >= 7 and len <= 15
end

local function extractId(value)
    if value == nil then return nil end
    if typeof and typeof(value) == "Content" then value = value.Uri or "" end
    if type(value) == "number" then return isValidId(value) and math.floor(value) or nil end
    local raw = tostring(value)
    local id = raw:match("rbxassetid://(%d+)") or raw:match("[?&]id=(%d+)") or raw:match("^%s*(%d+)%s*$")
    return id and isValidId(id) and tonumber(id) or nil
end

local function getInstancePath(inst)
    local parts, current = {}, inst
    while current and current ~= game do
        table.insert(parts, 1, current.Name)
        current = current.Parent
    end
    return table.concat(parts, "/")
end

local function readSource(inst)
    if hasEditor and ScriptEditorService then
        local ok, source = pcall(function() return ScriptEditorService:GetEditorSource(inst) end)
        if ok and type(source) == "string" then return source end
    end
    local ok, source = pcall(function() return inst.Source end)
    if ok and type(source) == "string" then return source end
    return nil
end

local function stripComments(code)
    if not code or code == "" then return "" end
    local clean = string.gsub(code, "%-%-%[%[.-%]%]", "")
    clean = string.gsub(clean, "%-%-[^\n\r]*", "")
    return clean
end

local function typeWord(text)
    local lower = string.lower(tostring(text or ""))
    if TARGET_TYPE == "Animations" then
        return lower:find("animation", 1, true) ~= nil or lower:find("anim", 1, true) ~= nil or lower:find("emote", 1, true) ~= nil
    elseif TARGET_TYPE == "Sounds" then
        return lower:find("sound", 1, true) ~= nil or lower:find("audio", 1, true) ~= nil
    elseif TARGET_TYPE == "Meshes" then
        return lower:find("mesh", 1, true) ~= nil
    elseif TARGET_TYPE == "Decals" then
        return lower:find("decal", 1, true) ~= nil or lower:find("texture", 1, true) ~= nil or lower:find("image", 1, true) ~= nil
    end
    return false
end

local ids, names, locations, seen = {}, {}, {}, {}
local function add(id, name, location)
    if not id or not isValidId(id) then return end
    id = tonumber(id)
    if seen[id] then return end
    seen[id] = true
    table.insert(ids, id)
    local key = tostring(id)
    names[key] = tostring(name or (string.gsub(TARGET_TYPE, "s$", "") .. " " .. key))
    locations[key] = tostring(location or "")
end

local function addProperty(inst, property)
    local ok, value = pcall(function() return inst[property] end)
    if ok then add(extractId(value), inst.Name, getInstancePath(inst)) end
end

local function scanDirect(inst)
    if TARGET_TYPE == "Animations" then
        if inst:IsA("Animation") then addProperty(inst, "AnimationId")
        elseif inst:IsA("HumanoidDescription") then
            for _, p in ipairs({"ClimbAnimation","FallAnimation","IdleAnimation","JumpAnimation","RunAnimation","SwimAnimation","WalkAnimation","MoodAnimation"}) do addProperty(inst, p) end
        end
    elseif TARGET_TYPE == "Sounds" then
        if inst:IsA("Sound") then addProperty(inst, "SoundId")
        elseif inst:IsA("AudioPlayer") then addProperty(inst, "Asset") end
    elseif TARGET_TYPE == "Meshes" then
        if inst:IsA("MeshPart") or inst:IsA("SpecialMesh") or inst:IsA("CharacterMesh") then addProperty(inst, "MeshId")
        elseif inst:IsA("WrapLayer") then addProperty(inst, "CageMeshId"); addProperty(inst, "ReferenceMeshId")
        elseif inst:IsA("BaseWrap") or inst:IsA("WrapTarget") then addProperty(inst, "CageMeshId") end
    elseif TARGET_TYPE == "Decals" then
        if inst:IsA("Decal") or inst:IsA("Texture") then addProperty(inst, "Texture")
        elseif inst:IsA("ImageLabel") or inst:IsA("ImageButton") then addProperty(inst, "Image")
        elseif inst:IsA("ParticleEmitter") or inst:IsA("Beam") or inst:IsA("Trail") then addProperty(inst, "Texture")
        elseif inst:IsA("MeshPart") then addProperty(inst, "TextureID")
        elseif inst:IsA("SpecialMesh") or inst:IsA("Tool") then addProperty(inst, "TextureId")
        elseif inst:IsA("SurfaceAppearance") or inst:IsA("MaterialVariant") then
            for _, p in ipairs({"ColorMap","MetalnessMap","NormalMap","RoughnessMap"}) do addProperty(inst, p) end
        elseif inst:IsA("Sky") then
            for _, p in ipairs({"SkyboxBk","SkyboxDn","SkyboxFt","SkyboxLf","SkyboxRt","SkyboxUp","SunTextureId","MoonTextureId"}) do addProperty(inst, p) end
        elseif inst:IsA("Shirt") then addProperty(inst, "ShirtTemplate")
        elseif inst:IsA("Pants") then addProperty(inst, "PantsTemplate")
        elseif inst:IsA("ShirtGraphic") then addProperty(inst, "Graphic") end
    end
end

local function scanNamedValue(inst)
    if not typeWord(inst.Name) then return end
    if inst:IsA("StringValue") or inst:IsA("IntValue") or inst:IsA("NumberValue") then
        add(extractId(inst.Value), inst.Name, getInstancePath(inst))
    end
end

local function scanScript(inst)
    if not inst:IsA("LuaSourceContainer") then return end
    local source = readSource(inst)
    if not source or source == "" then return end
    source = stripComments(source)
    local path = getInstancePath(inst)
    local scriptTyped = typeWord(inst.Name) or typeWord(path)

    -- Exact URI references are accepted when the line itself is typed, or when
    -- the script/folder is clearly dedicated to the selected asset family.
    local typedBlockDepth = 0
    for line in string.gmatch(source, "[^\r\n]+") do
        local opens = select(2, string.gsub(line, "{", ""))
        local closes = select(2, string.gsub(line, "}", ""))
        local startsTypedBlock = typeWord(line) and opens > closes
        if startsTypedBlock then typedBlockDepth = typedBlockDepth + (opens - closes) end
        local lineTyped = typeWord(line) or scriptTyped or typedBlockDepth > 0
        if lineTyped then
            for id in string.gmatch(line, "rbxassetid://(%d+)") do
                if isValidId(id) then
                    local keyName = line:match("([%a_][%w_]*)%s*[:=]") or inst.Name
                    add(tonumber(id), keyName, path .. " [script reference]")
                end
            end
            for id in string.gmatch(line, "[?&]id=(%d+)") do
                if isValidId(id) then add(tonumber(id), inst.Name, path .. " [script reference]") end
            end

            -- Preserve old V2's numeric-table support, but only inside a typed
            -- script/path/line/table. This catches Config.Animations = { Walk = 123... }
            -- without turning unrelated place/product/timing numbers into animations.
            local lhs, bare = line:match("^%s*([%a_][%w_%.]*)%s*[:=]%s*(%d%d%d%d%d%d%d+)")
            if not bare then lhs, bare = line:match("^%s*([%a_][%w_%.]*)%s*[:=]%s*[\"'](%d%d%d%d%d%d%d+)[\"']") end
            if bare and isValidId(bare) then add(tonumber(bare), lhs or inst.Name, path .. " [script reference]") end

            if scriptTyped or typedBlockDepth > 0 then
                for id in string.gmatch(line, "[%f[%d]](%d%d%d%d%d%d%d+)[%f[%D]]") do
                    if isValidId(id) then add(tonumber(id), inst.Name, path .. " [script reference]") end
                end
            end
        end
        if typedBlockDepth > 0 and not startsTypedBlock then
            typedBlockDepth = math.max(0, typedBlockDepth + opens - closes)
        end
    end
end

local processed = 0
for _, rootName in ipairs(ROOTS) do
    local ok, root = pcall(function() return game:GetService(rootName) end)
    if ok and root then
        local descendants = root:GetDescendants()
        processed += #descendants
        for _, inst in ipairs(descendants) do
            scanDirect(inst)
            scanNamedValue(inst)
            scanScript(inst)
        end
    end
end

table.sort(ids)
return HttpService:JSONEncode({ ok=true, ids=ids, names=names, locations=locations, totalDescendants=processed })
""";

    private static string BuildRootScanLuau(string rootName, string assetType, StudioScanStage stage, int offset, int batchSize) => $$"""
{{AssetPropertyListLuau}}
local HttpService = game:GetService("HttpService")
local hasEditor, ScriptEditorService = pcall(function() return game:GetService("ScriptEditorService") end)
local rootName = {{JsonSerializer.Serialize(rootName)}}
local assetType = {{JsonSerializer.Serialize(assetType)}}
local stage = {{JsonSerializer.Serialize(stage.ToString())}}
local okRoot, root = pcall(function() return game:GetService(rootName) end)
if not okRoot or not root then
    return HttpService:JSONEncode({ ok = false, root = rootName, stage = stage, error = "Studio service is unavailable" })
end

local ids, names, locations, seen = {}, {}, {}, {}
local function extractId(value)
    value = contentUri(value)
    if type(value) == "number" then return value > 0 and value % 1 == 0 and value or nil end
    local raw = string.lower(tostring(value or ""))
    local id = raw:match("^rbxassetid://(%d+)") or raw:match("[?&]id=(%d+)") or raw:match("^%s*(%d+)%s*$")
    return id and tonumber(id) or nil
end
local function readSource(inst)
    return readStudioSource(inst, hasEditor, ScriptEditorService)
end
local function instancePath(inst)
    local parts = {}
    local current = inst
    while current and current ~= game do
        table.insert(parts, 1, current.Name)
        current = current.Parent
    end
    return table.concat(parts, "/")
end
local function add(id, name, location)
    if not id or id <= 0 then return end
    local key = tostring(id)
    if not seen[id] then seen[id] = true; table.insert(ids, id) end
    if type(name) == "string" and name ~= "" and not names[key] then names[key] = name end
    if type(location) == "string" and location ~= "" and not locations[key] then locations[key] = location end
end

-- Typed names are safe reference containers. Do not treat every number/string in
-- the project as the currently selected asset type.
local function nameMatchesAssetType(name)
    local lower = string.lower(tostring(name or ""))
    if assetType == "Animations" then
        return string.find(lower, "animation", 1, true) ~= nil or
               string.find(lower, "animid", 1, true) ~= nil or
               string.find(lower, "anim_id", 1, true) ~= nil or
               string.match(lower, "^anim[_%-]") ~= nil or
               string.match(lower, "[_%-]anim$") ~= nil
    elseif assetType == "Sounds" then
        return string.find(lower, "sound", 1, true) ~= nil or string.find(lower, "audio", 1, true) ~= nil
    elseif assetType == "Meshes" then
        return string.find(lower, "mesh", 1, true) ~= nil
    elseif assetType == "Decals" then
        return string.find(lower, "decal", 1, true) ~= nil or
               string.find(lower, "texture", 1, true) ~= nil or
               string.find(lower, "image", 1, true) ~= nil
    end
    return false
end

-- Script references must prove their type close to the ID. The old scanner first
-- searched the ENTIRE script for a broad word such as "anim" and then queued every
-- rbxassetid:// value in that script. That is why Controller/Shop/Event modules were
-- being uploaded as animations and Roblox answered "Asset content is invalid".
local function contextMatchesAssetType(text)
    local lower = string.lower(tostring(text or ""))
    if assetType == "Animations" then
        return string.find(lower, "animationid", 1, true) ~= nil or
               string.find(lower, "animation_id", 1, true) ~= nil or
               string.find(lower, "animid", 1, true) ~= nil or
               string.find(lower, "anim_id", 1, true) ~= nil or
               string.find(lower, "animations", 1, true) ~= nil or
               string.match(lower, "[%w_]*animation[%w_]*%s*[:=]") ~= nil or
               string.find(lower, "instance.new(\"animation\"", 1, true) ~= nil or
               string.find(lower, "instance.new('animation'", 1, true) ~= nil
    elseif assetType == "Sounds" then
        return string.find(lower, "soundid", 1, true) ~= nil or
               string.find(lower, "audioid", 1, true) ~= nil or
               string.find(lower, "sounds", 1, true) ~= nil or
               string.match(lower, "[%w_]*sound[%w_]*%s*[:=]") ~= nil or
               string.match(lower, "[%w_]*audio[%w_]*%s*[:=]") ~= nil or
               string.find(lower, "instance.new(\"sound\"", 1, true) ~= nil or
               string.find(lower, "instance.new('sound'", 1, true) ~= nil
    elseif assetType == "Meshes" then
        return string.find(lower, "meshid", 1, true) ~= nil or
               string.find(lower, "mesh_id", 1, true) ~= nil or
               string.find(lower, "meshes", 1, true) ~= nil or
               string.match(lower, "[%w_]*mesh[%w_]*%s*[:=]") ~= nil or
               string.find(lower, "meshpart", 1, true) ~= nil or
               string.find(lower, "specialmesh", 1, true) ~= nil
    elseif assetType == "Decals" then
        return string.find(lower, "textureid", 1, true) ~= nil or
               string.find(lower, "texture_id", 1, true) ~= nil or
               string.find(lower, "decal", 1, true) ~= nil or
               string.find(lower, "imageid", 1, true) ~= nil or
               string.find(lower, "image_id", 1, true) ~= nil or
               string.match(lower, "[%w_]*texture[%w_]*%s*[:=]") ~= nil or
               string.match(lower, "[%w_]*decal[%w_]*%s*[:=]") ~= nil or
               string.match(lower, "[%w_]*image[%w_]*%s*[:=]") ~= nil or
               string.find(lower, "surfaceappearance", 1, true) ~= nil
    end
    return false
end

local function scanScriptSource(source, inst)
    local lower = string.lower(source)
    local path = instancePath(inst)

    local function scanPattern(pattern)
        local cursor = 1
        while true do
            local first, last, id = string.find(lower, pattern, cursor)
            if not first then break end
            local left = math.max(1, first - 128)
            local right = math.min(#lower, last + 128)
            if id and string.len(id) >= 7 and contextMatchesAssetType(string.sub(lower, left, right)) then
                local before = string.sub(source, math.max(1, first - 96), first - 1)
                local referenceName = string.match(before, "([%a_][%w_]*)%s*[:=]%s*[\"']?%s*$") or inst.Name
                add(tonumber(id), referenceName, path .. " [script reference]")
            end
            cursor = math.max(last + 1, cursor + 1)
        end
    end

    scanPattern("rbxassetid://(%d+)")
    scanPattern("[?&]id=(%d+)")

    -- Also support strongly-typed bare numeric assignments such as
    -- IdleAnimation = 123456789 without accepting unrelated place/product IDs.
    for line in string.gmatch(source, "[^\r\n]+") do
        local lowerLine = string.lower(line)
        if contextMatchesAssetType(lowerLine) then
            local rhs = string.match(line, "[:=]%s*(.+)$")
            if rhs then
                local cleaned = string.gsub(rhs, "^%s*", "")
                cleaned = string.gsub(cleaned, "^[\"']", "")
                local id = string.match(string.lower(cleaned), "^rbxassetid://(%d+)") or
                           string.match(string.lower(cleaned), "^[^%s\"']*[?&]id=(%d+)") or
                           string.match(cleaned, "^(%d%d%d%d%d%d%d%d*)")
                if id then
                    local lhs = string.match(line, "^%s*([%w_%.]+)%s*[:=]")
                    local referenceName = lhs and string.match(lhs, "([%w_]+)$") or inst.Name
                    add(tonumber(id), referenceName, path .. " [script reference]")
                end
            end
        end
    end
end

local descendants = withoutKagePreviews(root:GetDescendants())
local offset = {{offset}}
local batchSize = {{batchSize}}
local totalDescendants = #descendants
local startIndex = math.min(offset + 1, totalDescendants + 1)
local endLimit = math.min(totalDescendants, offset + batchSize)
local processedEnd = offset
local maxIdsPerPage = 72

if stage == "DirectAsset" then
    local ok, err = xpcall(function()
        for index = startIndex, endLimit do
            local inst = descendants[index]
            local path = instancePath(inst)
            for _, prop in ipairs(assetProperties(inst, assetType)) do
                local readable, raw = readAssetProperty(inst, prop)
                if readable and raw then add(extractId(raw), inst.Name, path) end
            end
            if assetType == "Animations" and inst:IsA("HumanoidDescription") then
                local okEmotes, emotes = pcall(function() return inst:GetEmotes() end)
                if okEmotes then
                    for name, emoteIds in pairs(emotes) do
                        for _, id in ipairs(emoteIds) do add(extractId(id), name, path .. "/Emotes") end
                    end
                end
            end

            -- Some projects keep typed asset IDs in configuration Values/attributes
            -- rather than concrete Animation/Sound/etc. instances. Include only names
            -- that identify the selected asset type; generic numeric values are ignored.
            if (inst:IsA("StringValue") or inst:IsA("IntValue") or inst:IsA("NumberValue")) and nameMatchesAssetType(inst.Name) then
                local okValue, value = pcall(function() return inst.Value end)
                if okValue then add(extractId(value), inst.Name, path) end
            end
            local okAttributes, attributes = pcall(function() return inst:GetAttributes() end)
            if okAttributes and type(attributes) == "table" then
                for attributeName, value in pairs(attributes) do
                    if nameMatchesAssetType(attributeName) then
                        add(extractId(value), inst.Name .. "." .. attributeName, path .. "/@" .. attributeName)
                    end
                end
            end

            processedEnd = index
            if #ids >= maxIdsPerPage then break end
        end
    end, function(message) return tostring(message) end)
    if not ok then return HttpService:JSONEncode({ ok = false, root = rootName, stage = stage, error = err }) end
else
    for index = startIndex, endLimit do
        local inst = descendants[index]
        if inst:IsA("LuaSourceContainer") then
            local readable, source = readSource(inst)
            if readable and type(source) == "string" then
                scanScriptSource(source, inst)
            end
        end
        processedEnd = index
        if #ids >= maxIdsPerPage then break end
    end
end

table.sort(ids)
local done = processedEnd >= totalDescendants
return HttpService:JSONEncode({
    ok = true,
    root = rootName,
    stage = stage,
    ids = ids,
    names = names,
    locations = locations,
    nextOffset = processedEnd,
    done = done,
    totalDescendants = totalDescendants
})
""";

    private static string BuildApplyMappingLuau(string assetType, IEnumerable<KeyValuePair<long, long>> entries)
    {
        var builder = new StringBuilder("local mapping = {\n");
        foreach (var pair in entries)
            builder.Append("  [\"").Append(pair.Key).Append("\"] = \"").Append(pair.Value).Append("\",\n");
        builder.Append("}\nlocal assetType = ").Append(JsonSerializer.Serialize(assetType)).Append('\n');
        builder.Append(AssetPropertyListLuau).Append('\n');
        builder.Append("""
local HttpService = game:GetService("HttpService")
local okScriptEditor, ScriptEditorService = pcall(function() return game:GetService("ScriptEditorService") end)
local changed = 0
local changes = {}
local failures = {}

local function instancePath(inst)
    local parts = {}
    local current = inst
    while current and current ~= game do
        table.insert(parts, 1, current.Name)
        current = current.Parent
    end
    return table.concat(parts, "/")
end

local function extractId(value)
    return string.match(tostring(value or ""), "%d+")
end

local function addChange(oldId, newId, inst, kind, count)
    table.insert(changes, { oldId = tonumber(oldId), newId = tonumber(newId), location = instancePath(inst), kind = kind, count = count or 1, instanceKey = referenceInstanceKey(inst) })
end

local function addFailure(oldId, newId, location, kind, reason)
    table.insert(failures, { oldId = tonumber(oldId), newId = tonumber(newId), location = location, kind = kind, reason = tostring(reason or "setter failed") })
end

local meshTemplates = {}
local function writeAssetProperty(inst, prop, nextValue)
    local ok, err = pcall(function() inst[prop] = nextValue end)
    if ok then return true end
    if prop ~= "MeshId" or not inst:IsA("MeshPart") then return false, err end
    local key = nextValue .. ":" .. tostring(inst.CollisionFidelity) .. ":" .. tostring(inst.RenderFidelity) .. ":" .. tostring(inst.FluidFidelity)
    local template = meshTemplates[key]
    if not template then
        local createOk, created = pcall(function()
            return game:GetService("AssetService"):CreateMeshPartAsync(Content.fromUri(nextValue), {
                CollisionFidelity = inst.CollisionFidelity,
                RenderFidelity = inst.RenderFidelity,
                FluidFidelity = inst.FluidFidelity
            })
        end)
        if not createOk then return false, created end
        template = created
        meshTemplates[key] = template
    end
    local texture, size = inst.TextureID, inst.Size
    local contentOk, textureContent = pcall(function() return inst.TextureContent end)
    local applyOk, applyErr = pcall(function()
        inst:ApplyMesh(template)
        if contentOk and textureContent ~= nil then inst.TextureContent = textureContent else inst.TextureID = texture end
        inst.Size = size
    end)
    return applyOk, applyErr
end

for _, inst in ipairs(withoutKagePreviews(game:GetDescendants())) do
    for _, prop in ipairs(assetProperties(inst, assetType)) do
        local readable, value = readAssetProperty(inst, prop)
        if readable then
            local oldId = extractId(value)
            local newId = oldId and mapping[oldId]
            if newId and newId ~= oldId then
                local nextValue
                if typeof and typeof(value) == "Content" then nextValue = Content.fromUri("rbxassetid://" .. newId)
                elseif type(value) == "number" then nextValue = tonumber(newId)
                else nextValue = "rbxassetid://" .. newId end
                local ok, err = writeAssetProperty(inst, prop, nextValue)
                local location = instancePath(inst)
                if ok then
                    changed += 1
                    addChange(oldId, newId, inst, prop, 1)
                else
                    addFailure(oldId, newId, location, prop, "setter failed: " .. tostring(err))
                end
            end
        end
    end

    if assetType == "Animations" and inst:IsA("HumanoidDescription") then
        local ok, emotes = pcall(function() return inst:GetEmotes() end)
        if ok and type(emotes) == "table" then
            local updated, touched = {}, {}
            for name, ids in pairs(emotes) do
                updated[name] = {}
                for index, id in ipairs(ids) do
                    local oldId = extractId(id)
                    local newId = oldId and mapping[oldId]
                    updated[name][index] = newId and tonumber(newId) or id
                    if newId and newId ~= oldId then touched[oldId] = (touched[oldId] or 0) + 1 end
                end
            end
            if next(touched) then
                local writeOk, err = pcall(function() inst:SetEmotes(updated) end)
                local location = instancePath(inst)
                for oldId, count in pairs(touched) do
                    if writeOk then
                        changed += 1
                        addChange(oldId, mapping[oldId], inst, "Emotes", count)
                    else
                        addFailure(oldId, mapping[oldId], location, "Emotes", err)
                    end
                end
            end
        end
    end

    if inst:IsA("StringValue") or inst:IsA("IntValue") or inst:IsA("NumberValue") then
        local oldId = extractId(inst.Value)
        local newId = oldId and mapping[oldId]
        if newId and newId ~= oldId then
            local nextVal = (inst:IsA("IntValue") or inst:IsA("NumberValue")) and tonumber(newId) or ("rbxassetid://" .. newId)
            local ok, err = pcall(function() inst.Value = nextVal end)
            local location = instancePath(inst)
            if ok then
                changed += 1
                addChange(oldId, newId, inst, inst.ClassName, 1)
            else
                addFailure(oldId, newId, location, inst.ClassName, err)
            end
        end
    end

    local attributesOk, attributes = pcall(function() return inst:GetAttributes() end)
    if attributesOk and type(attributes) == "table" then
        for attrName, attrVal in pairs(attributes) do
            local oldId = extractId(attrVal)
            local newId = oldId and mapping[oldId]
            if newId and newId ~= oldId then
                local nextVal = type(attrVal) == "number" and tonumber(newId) or ("rbxassetid://" .. newId)
                local ok, err = pcall(function() inst:SetAttribute(attrName, nextVal) end)
                local location = instancePath(inst)
                if ok then
                    changed += 1
                    addChange(oldId, newId, inst, "Attribute:" .. attrName, 1)
                else
                    addFailure(oldId, newId, location, "Attribute:" .. attrName, err)
                end
            end
        end
    end
end

for _, inst in ipairs(withoutKagePreviews(game:GetDescendants())) do
    if inst:IsA("LuaSourceContainer") then
        local readable, sourceOrError = pcall(function() return inst.Source end)
        if readable and type(sourceOrError) == "string" then
            local original = sourceOrError
            local src = original
            local pending = {}
            local totalOccurrences = 0

            for oldId, newId in pairs(mapping) do
                -- Frontier boundaries do not consume the comma/quote between IDs.
                -- Consuming separators used to skip every other adjacent occurrence.
                local replaced, count = string.gsub(src, "%f[%d]" .. oldId .. "%f[%D]", function() return newId end)
                if count > 0 then
                    src = replaced
                    totalOccurrences += count
                    table.insert(pending, { oldId = oldId, newId = newId, count = count })
                end
            end

            if totalOccurrences > 0 and src ~= original then
                local location = instancePath(inst)
                local writeOk, writeErr = false, nil

                if okScriptEditor and ScriptEditorService then
                    writeOk, writeErr = pcall(function()
                        ScriptEditorService:UpdateSourceAsync(inst, function(_oldSource)
                            return src
                        end)
                    end)
                end

                if not writeOk then
                    -- Fallback for Studio versions/contexts where ScriptEditorService is unavailable.
                    local fallbackOk, fallbackErr = pcall(function() inst.Source = src end)
                    if fallbackOk then
                        writeOk = true
                    else
                        writeErr = "ScriptEditorService: " .. tostring(writeErr) .. " | fallback Source setter: " .. tostring(fallbackErr)
                    end
                end

                if writeOk then
                    for _, entry in ipairs(pending) do
                        addChange(entry.oldId, entry.newId, inst, "ScriptSource", entry.count)
                    end
                else
                    for _, entry in ipairs(pending) do
                        addFailure(entry.oldId, entry.newId, location, "ScriptSource", "setter failed: " .. tostring(writeErr))
                    end
                end
            end
        end
    end
end

for _, template in pairs(meshTemplates) do pcall(function() template:Destroy() end) end
return HttpService:JSONEncode({ changed = changed, changes = changes, failures = failures })
""");
        return builder.ToString();
    }

    private static string BuildDirectInstanceMappingLuau(string assetType, IReadOnlyDictionary<long, long> mapping)
    {
        var builder = new StringBuilder("local mapping = {\n");
        foreach (var pair in mapping.Where(pair => pair.Key > 0 && pair.Value > 0))
            builder.Append("  [\"").Append(pair.Key).Append("\"] = \"").Append(pair.Value).Append("\",\n");
        builder.Append("}\nlocal TARGET_TYPE = ").Append(JsonSerializer.Serialize(assetType)).Append('\n');
        builder.Append(AssetPropertyListLuau).Append('\n');
        builder.Append("""
local HttpService = game:GetService("HttpService")
local changes, failures = {}, {}
local meshTemplates = {}

local function instancePath(inst)
    local parts = {}
    local current = inst
    while current and current ~= game do
        table.insert(parts, 1, current.Name)
        current = current.Parent
    end
    return table.concat(parts, "/")
end

local function extractId(value)
    value = contentUri(value)
    if type(value) == "number" then
        if value <= 0 or value % 1 ~= 0 then return nil end
        return string.format("%.0f", value)
    end
    local raw = string.lower(tostring(value or ""))
    return raw:match("^rbxassetid://(%d+)") or raw:match("[?&]id=(%d+)") or raw:match("^%s*(%d+)%s*$")
end

local function writeAssetProperty(inst, prop, nextValue)
    local ok, err = pcall(function() inst[prop] = nextValue end)
    if ok then return true end
    if prop ~= "MeshId" or not inst:IsA("MeshPart") then return false, err end
    local key = nextValue .. ":" .. tostring(inst.CollisionFidelity) .. ":" .. tostring(inst.RenderFidelity) .. ":" .. tostring(inst.FluidFidelity)
    local template = meshTemplates[key]
    if not template then
        local createOk, created = pcall(function()
            return game:GetService("AssetService"):CreateMeshPartAsync(Content.fromUri(nextValue), {
                CollisionFidelity = inst.CollisionFidelity,
                RenderFidelity = inst.RenderFidelity,
                FluidFidelity = inst.FluidFidelity
            })
        end)
        if not createOk then return false, created end
        template = created
        meshTemplates[key] = template
    end
    local texture, size = inst.TextureID, inst.Size
    local contentOk, textureContent = pcall(function() return inst.TextureContent end)
    local applyOk, applyErr = pcall(function()
        inst:ApplyMesh(template)
        if contentOk and textureContent ~= nil then inst.TextureContent = textureContent else inst.TextureID = texture end
        inst.Size = size
    end)
    return applyOk, applyErr
end

local function recordChange(oldId, newId, inst, prop)
    table.insert(changes, {
        oldId = tonumber(oldId), newId = tonumber(newId), location = instancePath(inst),
        kind = prop, count = 1, instanceKey = referenceInstanceKey(inst)
    })
end

for _, inst in ipairs(withoutKagePreviews(game:GetDescendants())) do
    for _, prop in ipairs(assetProperties(inst, TARGET_TYPE)) do
        local readable, value = readAssetProperty(inst, prop)
        if readable then
            local oldId = extractId(value)
            local newId = oldId and mapping[oldId]
            if newId and newId ~= oldId then
                local nextValue
                if typeof and typeof(value) == "Content" then nextValue = Content.fromUri("rbxassetid://" .. newId)
                elseif type(value) == "number" then nextValue = tonumber(newId)
                else nextValue = "rbxassetid://" .. newId end
                local ok, err = writeAssetProperty(inst, prop, nextValue)
                if ok then recordChange(oldId, newId, inst, prop)
                else table.insert(failures, { oldId = tonumber(oldId), newId = tonumber(newId), location = instancePath(inst), kind = prop, reason = tostring(err or "setter failed") }) end
            end
        end
    end
end

for _, template in pairs(meshTemplates) do pcall(function() template:Destroy() end) end
return HttpService:JSONEncode({ changed = #changes, changes = changes, failures = failures })
""");
        return builder.ToString();
    }

    private static string BuildOriginalV2MappingLuau(string assetType, IReadOnlyDictionary<long, long> mapping)
    {
        var builder = new StringBuilder("local mapping = {\n");
        foreach (var pair in mapping.Where(pair => pair.Key > 0 && pair.Value > 0))
            builder.Append("  [\"").Append(pair.Key).Append("\"] = \"").Append(pair.Value).Append("\",\n");

        builder.Append("}\nlocal TARGET_TYPE = ").Append(JsonSerializer.Serialize(assetType)).Append('\n');
        builder.Append(AssetPropertyListLuau).Append('\n');
        builder.Append("""
local HttpService = game:GetService("HttpService")
local CHS = game:GetService("ChangeHistoryService")
local hasEditor, ScriptEditorService = pcall(function() return game:GetService("ScriptEditorService") end)
local changes, failures = {}, {}
local changed = 0
local changedInstances = {}
local meshTemplates = {}
-- Keep MCP output small on 1,000+ asset projects. Verification is a separate
-- pass, so the complete per-reference detail list is not required here.
local MAX_CHANGE_DETAILS = 256
local MAX_FAILURE_DETAILS = 128
local omittedChanges, omittedFailures = 0, 0

local function instancePath(inst)
    if inst == game then return "game" end
    local parts = {}
    local current = inst
    while current and current ~= game do
        table.insert(parts, 1, current.Name)
        current = current.Parent
    end
    return table.concat(parts, "/")
end

local function addChange(oldId, newId, inst, kind, count, isAssetInstance)
    count = count or 1
    if isAssetInstance and not changedInstances[inst] then
        changedInstances[inst] = true
        changed += 1
    end
    if #changes < MAX_CHANGE_DETAILS then
        table.insert(changes, { oldId = tonumber(oldId), newId = tonumber(newId), location = instancePath(inst), kind = kind, count = count, instanceKey = referenceInstanceKey(inst) })
    else
        omittedChanges += 1
    end
end

local function addFailure(oldId, newId, inst, kind, reason)
    if #failures < MAX_FAILURE_DETAILS then
        table.insert(failures, { oldId = tonumber(oldId), newId = tonumber(newId), location = instancePath(inst), kind = kind, reason = tostring(reason or "setter failed") })
    else
        omittedFailures += 1
    end
end

local function extractId(value)
    value = contentUri(value)
    if type(value) == "number" then
        if value <= 0 or value % 1 ~= 0 then return nil end
        return string.format("%.0f", value)
    end
    local raw = string.lower(tostring(value or ""))
    return raw:match("^rbxassetid://(%d+)") or raw:match("[?&]id=(%d+)") or raw:match("^%s*(%d+)%s*$")
end

-- A single pass over the ORIGINAL text avoids replacing new IDs again when
-- one of them also appears as an old ID elsewhere in this mapping.
local function replaceText(text)
    local touched = {}
    local result = string.gsub(text, "%f[%d]%d+%f[%D]", function(oldId)
        local newId = mapping[oldId]
        if newId and newId ~= oldId then
            touched[oldId] = (touched[oldId] or 0) + 1
            return newId
        end
        return oldId
    end)
    return result, touched
end

local function readSource(inst)
    return readStudioSource(inst, hasEditor, ScriptEditorService)
end

local function writeAssetProperty(inst, prop, nextValue)
    local ok, err = pcall(function() inst[prop] = nextValue end)
    if ok then return end
    if prop ~= "MeshId" or not inst:IsA("MeshPart") then error(err) end

    -- MeshPart.MeshId cannot be assigned directly. Apply the downloaded mesh
    -- to the existing part so children, joints and references keep their identity.
    local key = nextValue .. ":" .. tostring(inst.CollisionFidelity) .. ":" .. tostring(inst.RenderFidelity) .. ":" .. tostring(inst.FluidFidelity)
    local template = meshTemplates[key]
    if not template then
        local createOk, created = pcall(function()
            return game:GetService("AssetService"):CreateMeshPartAsync(Content.fromUri(nextValue), {
                CollisionFidelity = inst.CollisionFidelity,
                RenderFidelity = inst.RenderFidelity,
                FluidFidelity = inst.FluidFidelity
            })
        end)
        if not createOk then error(created) end
        template = created
        meshTemplates[key] = template
    end
    local texture, size = inst.TextureID, inst.Size
    local contentOk, textureContent = pcall(function() return inst.TextureContent end)
    local applyOk, applyErr = pcall(function()
        inst:ApplyMesh(template)
        if contentOk and textureContent ~= nil then inst.TextureContent = textureContent
        else inst.TextureID = texture end
        inst.Size = size
    end)
    if not applyOk then error(applyErr) end
end

local function updateValue(inst, kind, current, setter, isAssetProperty)
    local value, touched = current, {}
    if isAssetProperty then
        local oldId = extractId(current)
        local newId = oldId and mapping[oldId]
        if newId and newId ~= oldId then
            if typeof and typeof(current) == "Content" then value = Content.fromUri("rbxassetid://" .. newId)
            else value = type(current) == "number" and tonumber(newId) or "rbxassetid://" .. newId end
            touched[oldId] = 1
        end
    elseif type(current) == "string" then
        value, touched = replaceText(current)
    elseif type(current) == "number" then
        local oldId = extractId(current)
        if mapping[oldId] and mapping[oldId] ~= oldId then
            value = tonumber(mapping[oldId])
            touched[oldId] = 1
        end
    end
    if value == current then return end
    local ok, err = pcall(setter, value)
    for oldId, count in pairs(touched) do
        if ok then addChange(oldId, mapping[oldId], inst, kind, count, isAssetProperty)
        else addFailure(oldId, mapping[oldId], inst, kind, err) end
    end
end

pcall(function() CHS:SetWaypoint("Before KAGE") end)

local instances = withoutKagePreviews(game:GetDescendants())
table.insert(instances, 1, game)
for _, inst in ipairs(instances) do
    for _, prop in ipairs(assetProperties(inst, TARGET_TYPE)) do
        local readable, value = readAssetProperty(inst, prop)
        if readable then
            updateValue(inst, prop, value, function(nextValue) writeAssetProperty(inst, prop, nextValue) end, true)
        end
    end

    if TARGET_TYPE == "Animations" and inst:IsA("HumanoidDescription") then
        local ok, emotes = pcall(function() return inst:GetEmotes() end)
        if ok and type(emotes) == "table" then
            local updated, touched = {}, {}
            for name, ids in pairs(emotes) do
                updated[name] = {}
                for index, id in ipairs(ids) do
                    local oldId = extractId(id)
                    local newId = oldId and mapping[oldId]
                    updated[name][index] = newId and tonumber(newId) or id
                    if newId and newId ~= oldId then touched[oldId] = (touched[oldId] or 0) + 1 end
                end
            end
            if next(touched) then
                local writeOk, err = pcall(function() inst:SetEmotes(updated) end)
                for oldId, count in pairs(touched) do
                    if writeOk then addChange(oldId, mapping[oldId], inst, "Emotes", count, true)
                    else addFailure(oldId, mapping[oldId], inst, "Emotes", err) end
                end
            end
        end
    end

    if inst:IsA("StringValue") or inst:IsA("IntValue") or inst:IsA("NumberValue") then
        updateValue(inst, inst.ClassName, inst.Value, function(nextValue) inst.Value = nextValue end, false)
    end

    local attributesOk, attributes = pcall(function() return inst:GetAttributes() end)
    if attributesOk then
        for name, value in pairs(attributes) do
            updateValue(inst, "Attribute:" .. name, value, function(nextValue) inst:SetAttribute(name, nextValue) end, false)
        end
    end

    if inst:IsA("LuaSourceContainer") then
        local readable, source = readSource(inst)
        if readable and type(source) == "string" then
            local nextSource, touched = replaceText(source)
            if nextSource ~= source then
                local writeOk, writeErr = false, nil
                if hasEditor and ScriptEditorService then
                    writeOk, writeErr = pcall(function()
                        ScriptEditorService:UpdateSourceAsync(inst, function(latestSource)
                            -- Studio may invoke this callback again after an editor
                            -- edit; recompute from that latest source every time.
                            local updated
                            updated, touched = replaceText(latestSource)
                            return updated
                        end)
                    end)
                end
                if not writeOk then
                    writeOk, writeErr = pcall(function()
                        local currentSource = inst.Source
                        nextSource, touched = replaceText(currentSource)
                        inst.Source = nextSource
                    end)
                end
                for oldId, count in pairs(touched) do
                    if writeOk then addChange(oldId, mapping[oldId], inst, "ScriptSource", count)
                    else addFailure(oldId, mapping[oldId], inst, "ScriptSource", writeErr) end
                end
            end
        end
    end
end

for _, template in pairs(meshTemplates) do pcall(function() template:Destroy() end) end
pcall(function() CHS:SetWaypoint("After KAGE") end)
return HttpService:JSONEncode({
    changed = changed,
    changes = changes,
    failures = failures,
    omittedChanges = omittedChanges,
    omittedFailures = omittedFailures
})
""");
        return builder.ToString();
    }

    private static string BuildVerifyMappingLuau(string assetType, IEnumerable<long> oldIds)
    {
        var builder = new StringBuilder("local targets = {\n");
        foreach (var id in oldIds)
            builder.Append("  [\"").Append(id).Append("\"] = true,\n");
        builder.Append("}\nlocal assetType = ").Append(JsonSerializer.Serialize(assetType)).Append('\n');
        builder.Append(AssetPropertyListLuau).Append('\n');
        builder.Append("""
local HttpService = game:GetService("HttpService")
local hasEditor, ScriptEditorService = pcall(function() return game:GetService("ScriptEditorService") end)
local remaining, locations, errors = {}, {}, {}

local function instancePath(inst)
    if inst == game then return "game" end
    local parts = {}
    local current = inst
    while current and current ~= game do
        table.insert(parts, 1, current.Name)
        current = current.Parent
    end
    return table.concat(parts, "/")
end

local function add(id, location, kind)
    if not id or not targets[id] then return end
    if not remaining[id] then remaining[id] = {} end
    local label = location .. " [" .. kind .. "]"
    for _, existing in ipairs(remaining[id]) do if existing == label then return end end
    table.insert(remaining[id], label)
end

local function extractId(value)
    value = contentUri(value)
    if type(value) == "number" then
        if value <= 0 or value % 1 ~= 0 then return nil end
        return string.format("%.0f", value)
    end
    local raw = string.lower(tostring(value or ""))
    return raw:match("^rbxassetid://(%d+)") or raw:match("[?&]id=(%d+)") or raw:match("^%s*(%d+)%s*$")
end

local function inspect(value, location, kind)
    if type(value) == "number" then add(extractId(value), location, kind)
    elseif type(value) == "string" then
        for id in string.gmatch(value, "%f[%d]%d+%f[%D]") do add(id, location, kind) end
    end
end

local instances = withoutKagePreviews(game:GetDescendants())
table.insert(instances, 1, game)
for _, inst in ipairs(instances) do
    local location = instancePath(inst)
    for _, prop in ipairs(assetProperties(inst, assetType)) do
        local ok, value = readAssetProperty(inst, prop)
        if ok then add(extractId(value), location, prop)
        else table.insert(errors, location .. " [" .. prop .. "]: " .. tostring(value)) end
    end
    if assetType == "Animations" and inst:IsA("HumanoidDescription") then
        local ok, emotes = pcall(function() return inst:GetEmotes() end)
        if ok and type(emotes) == "table" then
            for name, ids in pairs(emotes) do
                for _, id in ipairs(ids) do add(extractId(id), location, "Emotes:" .. name) end
            end
        else
            table.insert(errors, location .. " [Emotes]: " .. tostring(emotes))
        end
    end
    if inst:IsA("StringValue") or inst:IsA("IntValue") or inst:IsA("NumberValue") then
        inspect(inst.Value, location, inst.ClassName)
    end
    local attributesOk, attributes = pcall(function() return inst:GetAttributes() end)
    if attributesOk then
        for name, value in pairs(attributes) do inspect(value, location, "Attribute:" .. name) end
    else
        table.insert(errors, location .. " [Attributes]: " .. tostring(attributes))
    end
    if inst:IsA("LuaSourceContainer") then
        local readable, source = readStudioSource(inst, hasEditor, ScriptEditorService)
        if readable and type(source) == "string" then inspect(source, location, "ScriptSource")
        else table.insert(errors, location .. " [ScriptSource]: " .. tostring(source)) end
    end
end

return HttpService:JSONEncode({ remaining = remaining, locations = locations, errors = errors })
""");
        return builder.ToString();
    }

    private static IEnumerable<string> ExtractTextBlocks(JsonElement element)
    {
        if (element.ValueKind == JsonValueKind.String && element.GetString() is { } text) yield return text;
        if (element.ValueKind == JsonValueKind.Object)
            foreach (var property in element.EnumerateObject()) foreach (var value in ExtractTextBlocks(property.Value)) yield return value;
        else if (element.ValueKind == JsonValueKind.Array)
            foreach (var item in element.EnumerateArray()) foreach (var value in ExtractTextBlocks(item)) yield return value;
    }

    private static string? ExtractJsonPayload(JsonElement result)
    {
        // Studio MCP versions can return execute_luau output either as text content,
        // a direct structuredContent payload, or a wrapper such as
        // { structuredContent: { result: "{...}" } }. Normalize all supported
        // forms before the KAGE workspace layer attempts to parse the Luau JSON.
        if (result.ValueKind == JsonValueKind.Object &&
            result.TryGetProperty("structuredContent", out var structured) &&
            structured.ValueKind != JsonValueKind.Null)
        {
            var structuredJson = ExtractStructuredJsonPayload(structured);
            if (!string.IsNullOrWhiteSpace(structuredJson)) return structuredJson;
        }

        foreach (var raw in ExtractTextBlocks(result))
        {
            var normalized = NormalizeJsonCandidate(raw);
            if (!string.IsNullOrWhiteSpace(normalized)) return normalized;
        }
        return null;
    }

    private static string? ExtractStructuredJsonPayload(JsonElement element)
    {
        if (element.ValueKind == JsonValueKind.String)
            return NormalizeJsonCandidate(element.GetString());

        if (element.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in element.EnumerateArray())
            {
                var nested = ExtractStructuredJsonPayload(item);
                if (!string.IsNullOrWhiteSpace(nested)) return nested;
            }
            return null;
        }

        if (element.ValueKind != JsonValueKind.Object) return null;

        // Common MCP result wrappers. Prefer these before treating structuredContent
        // itself as KAGE's payload so wrapper metadata never masquerades as project data.
        foreach (var name in new[] { "result", "output", "value", "text" })
        {
            if (!element.TryGetProperty(name, out var wrapped)) continue;
            var nested = ExtractStructuredJsonPayload(wrapped);
            if (!string.IsNullOrWhiteSpace(nested)) return nested;
        }

        // These keys identify payloads generated by KAGE's own Studio-side snippets.
        var isKagePayload =
            element.TryGetProperty("projectName", out _) ||
            element.TryGetProperty("placeId", out _) ||
            element.TryGetProperty("universeId", out _) ||
            element.TryGetProperty("ids", out _) ||
            element.TryGetProperty("names", out _) ||
            element.TryGetProperty("locations", out _) ||
            element.TryGetProperty("changed", out _) ||
            element.TryGetProperty("scriptsChanged", out _) ||
            element.TryGetProperty("ok", out _) ||
            element.TryGetProperty("stage", out _) ||
            element.TryGetProperty("state", out _) ||
            (element.TryGetProperty("frames", out _) && element.TryGetProperty("parts", out _)) ||
            element.TryGetProperty("error", out _);
        if (isKagePayload) return element.GetRawText();

        // Fall back to nested values such as content/result blocks used by some MCP revisions.
        foreach (var property in element.EnumerateObject())
        {
            var nested = ExtractStructuredJsonPayload(property.Value);
            if (!string.IsNullOrWhiteSpace(nested)) return nested;
        }
        return null;
    }

    private static string? NormalizeJsonCandidate(string? raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return null;
        var text = raw.Trim();
        if (TryNormalizeJson(text, out var normalized)) return normalized;

        var firstObject = text.IndexOf('{');
        var firstArray = text.IndexOf('[');
        var first = firstObject < 0 ? firstArray : firstArray < 0 ? firstObject : Math.Min(firstObject, firstArray);
        var last = Math.Max(text.LastIndexOf('}'), text.LastIndexOf(']'));
        if (first >= 0 && last > first && TryNormalizeJson(text[first..(last + 1)], out normalized))
            return normalized;
        return null;
    }

    private static bool TryNormalizeJson(string text, out string normalized)
    {
        normalized = text;
        try
        {
            using var doc = JsonDocument.Parse(text);
            if (doc.RootElement.ValueKind == JsonValueKind.String && doc.RootElement.GetString() is { } inner)
            {
                using var innerDoc = JsonDocument.Parse(inner);
                normalized = innerDoc.RootElement.GetRawText();
            }
            else normalized = doc.RootElement.GetRawText();
            return true;
        }
        catch { return false; }
    }

    private static bool TryParseAnyJson(string text, out JsonDocument document)
    {
        document = null!;
        var trimmed = text.Trim();
        try { document = JsonDocument.Parse(trimmed); return true; } catch { }
        var firstObject = trimmed.IndexOf('{');
        var firstArray = trimmed.IndexOf('[');
        var first = firstObject < 0 ? firstArray : firstArray < 0 ? firstObject : Math.Min(firstObject, firstArray);
        var last = Math.Max(trimmed.LastIndexOf('}'), trimmed.LastIndexOf(']'));
        if (first < 0 || last <= first) return false;
        try { document = JsonDocument.Parse(trimmed[first..(last + 1)]); return true; } catch { return false; }
    }

    private static void CollectStudioInstances(JsonElement element, List<StudioMcpInstance> output)
    {
        if (element.ValueKind == JsonValueKind.Object)
        {
            var id = TryGetString(element, "studio_id") ?? TryGetString(element, "studioId") ?? TryGetString(element, "id");
            if (!string.IsNullOrWhiteSpace(id))
            {
                var name = TryGetString(element, "name") ?? TryGetString(element, "place_name") ?? TryGetString(element, "placeName") ?? "Roblox Studio";
                var placeId = TryGetLong(element, "place_id") ?? TryGetLong(element, "placeId") ?? 0;
                var active = TryGetBool(element, "active") ?? TryGetBool(element, "isActive") ?? TryGetBool(element, "is_active") ?? false;
                output.Add(new StudioMcpInstance(id, name, placeId, active));
            }
            foreach (var property in element.EnumerateObject()) CollectStudioInstances(property.Value, output);
        }
        else if (element.ValueKind == JsonValueKind.Array)
            foreach (var item in element.EnumerateArray()) CollectStudioInstances(item, output);
    }

    private static string GetString(JsonElement e, string name, string fallback = "") => TryGetString(e, name) ?? fallback;
    private static string? TryGetString(JsonElement e, string name) => e.ValueKind == JsonValueKind.Object && e.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;
    private static long GetLong(JsonElement e, string name, long fallback = 0) => TryGetLong(e, name) ?? fallback;
    private static long? TryGetLong(JsonElement e, string name)
    {
        if (e.ValueKind != JsonValueKind.Object || !e.TryGetProperty(name, out var v)) return null;
        if (v.ValueKind == JsonValueKind.Number && v.TryGetInt64(out var n)) return n;
        if (v.ValueKind == JsonValueKind.String && long.TryParse(v.GetString(), out n)) return n;
        return null;
    }
    private static bool? TryGetBool(JsonElement e, string name)
    {
        if (e.ValueKind != JsonValueKind.Object || !e.TryGetProperty(name, out var v)) return null;
        if (v.ValueKind is JsonValueKind.True or JsonValueKind.False) return v.GetBoolean();
        if (v.ValueKind == JsonValueKind.String && bool.TryParse(v.GetString(), out var value)) return value;
        return null;
    }

    private static int GetInt(JsonElement e, string name, int fallback = 0)
    {
        if (e.ValueKind != JsonValueKind.Object || !e.TryGetProperty(name, out var v)) return fallback;
        if (v.ValueKind == JsonValueKind.Number && v.TryGetInt32(out var n)) return n;
        if (v.ValueKind == JsonValueKind.String && int.TryParse(v.GetString(), out n)) return n;
        return fallback;
    }

    public async ValueTask DisposeAsync()
    {
        if (Interlocked.Exchange(ref _disposed, 1) != 0) return;
        await DisconnectAsync().ConfigureAwait(false);
        await _client.DisposeAsync().ConfigureAwait(false);
        // In-flight canceled operations retain their token/gate until they unwind.
    }
}
