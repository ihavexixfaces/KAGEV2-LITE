// ========== C# ↔ JavaScript Bridge ==========
const isShadePopout = new URLSearchParams(location.search).get('shadePopout') === '1';
const bridge = {
  send(action, data = {}) {
    window.chrome.webview.postMessage({ action, ...data });
  },
  onMessage(callback) {
    window.chrome.webview.addEventListener('message', (e) => {
      callback(e.data);
    });
  }
};

let studioBridgeSession = { token: '', sessionId: '' };
function studioBridgeHeaders(extra = {}) {
  if (!studioBridgeSession.token || !studioBridgeSession.sessionId) return { ...extra };
  const requestId = (globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random()}`).toString();
  return {
    ...extra,
    'X-Kage-Token': studioBridgeSession.token,
    'X-Kage-Session': studioBridgeSession.sessionId,
    'X-Kage-Request-Id': requestId
  };
}

// ========== Local UI State ==========
const SETTINGS_KEY = 'kage_reupload_settings_v2';
const HISTORY_KEY = 'kage_recent_history_v2';
const ROBLOX_ROLE_TAGS = Object.freeze({
  '5633106571': '[Owner/Developer]',
  '2220008255': '[Co - Owner/Developer]'
});
const defaultUiSettings = {
  concurrency: 96,
  manualStart: true,
  smoothMotion: true,
  notifications: true,
  saveHistory: true,
  showAssetDetails: true,
  alwaysOnTop: true,
  legacyAssetNames: false
};

// ========== Global KAGE interaction sounds ==========
const globalHoverSound = new Audio('../Assets/immersivecontrol-hover.mp3');
// v102: bundle the exact v87 click MP3 directly. Protected WebView assets can
// fail to resolve from a relative ../Assets URL even when the UI loads.
const kageOriginalClickMp3 = 'data:audio/mpeg;base64,//vQZAAABzd+UK0/AAJwTlpfoJwAX8HhXdmsAAI2Nyx/ELAAMAAF94pT3w8Q9Rs8e9452AXDOUHDcoGCNDDc41GLoRVHgCCMyDUgzCQ0isPzTD13sTYexNnblv/G5ZY5Xp6enz7+FJSUnM89U9vPedenzqRuX9wpMP/Cnp88888//PPv6www/DD95559wp6enp8889Ukbl9vv7zzzsYUlJSUljDD//9YYc3SWMP///mffzzp6e3qnz/D86e3Ujcv7hhvPtI/8Py/PPPPtJG43b7/515XDkYsbzzzz/8KSGH8ch/JZXdiHLH6pIxLMYxYm4bf+X9wwzp5XG43G5fcdhd7E2vw/fqUlJyArQqIhgAWooEgAABLNgAAAAEBannn899/PzG/zzzz3M0MMM/PP/+v/qeef///555///MMM/+YYZTPf/qe88+YYY1TDDGzDDBuNxufQwxTDGPG43G5Nzzz36njQaDQaDQaDRhuAwHAkEHB/gBkcf/4AETJGCsgAQAAAAIQwAACOYhPEoNKwWPiAugoAlYCjmfADCM2pUiLFUcYYIZ0EcUiCpYyoodcoz0KIAoplgIIxKis1L9Go0UGRoQrWFpY9FsPsz67X6WozpptmMzuUNWbvxikbeZh92ICnLWNLe39nms6enjEgf+/F5jdNKp6lq0ty1jll+vrSCfvRegl3OY67lu7blFJnrC3PtYdqjlOee6TcboaaWQ5jDdPSS7GpAcvgCPT2sasdbO1yIzt7upRBEOyKHo/KpVuYrV7ER1Z/cp19X//945d///////9//15dcgF9XilrLYev25ZD1ND2v////////3z94zWQltLU8Igu5CCCJgBuYiENogAAALjkRza+4jsuDKb/Muq+676j/+2TM/3FWyj5rNH/jr//b3x/fx//9X8Pe2d7mGkn4+aY9dnNjsA4PggRuHc+K5uEEyaePmhxh86cHwtOmzW5PDAtJJbF5xY+aWfOS5jEpVOvSPXtb8e6W/////pM0y4yBLJZZwjDUm/x7RcYgAEFAAJCYLLcTMABnfmojyZqqZjAfrZ/E5w2zYSDL8hUEc83i1GVYEiBbfLZmAqHMBEbgQSbQvVWy6RCf/70mQeAAhZe06uc2ACgWq6K8PEACEeKSO52oACPqWmfw9AAICPi2hARAgNWBYgnV+/2NDpdohAV2AUDUyZc3Wu/u+f/kQ6jKkc7JaIsjDOO6J9Zj//X+g68sur1WWCwNLtZZ2qX/////BAOCRomEzCjM1ovYo3Gow6rejsSa1ItxFnP/////4YMmChAwamKhxkSKZIGlomgjgGspib7QNEZTcjspqWsu///////6dMZmJO+riu+/z/v69Ldou/W635ZVrVXuOO8cd8//////////lkdlEzaqU1NNNJiV9yaj/Rr////////98y/WXcf/63hUgAAAAAAAAgAAuFSm4Ll8sf5sRiKs3TMX+YGqJGmX9GYl5PX/PHydUcLP/5ROmZEER2i4jropGSZd/ihw2EMZC4gwiAbBlisQ9FRRIcQY7jG/8OTGcEEiwQoaMKcNoSkXxyjZGpZwyNjFbf/KZDjpjMyaLxeSc8QCn/+oieeSWwCuVDwMYkEotG4cBAAAAAiokABjiTxncfoWKM5DMkFAXeMQR0MlBENsUZNjVpz9R1M83xMkiGfAOBY0wOPSQDfi+5MEPGTA0kIgM9AIDMKb8uFUSmcA02SwMiAcDJpPAaK/w6cvkAizwAR6BksngZNEIEjOBigYfn2NiCGx0LeARBEDDIbAOD5aDIf9MzL7mJHC4B3iiCE42waAQB5TA0aWUSbJ9Apm/AAAgGEgQXQSAQEgoYH0GA0YZgBj6DYIBgXAzmewMnhECwHGPJv/9Ror6EQXHcPJSHAaIizxZZ5f///1podZuZkXNycJtMnEbmBcmX////u1////zRbmkoEQFxlk3TJs+RAvpAAAAKxK8AwhKj4VhBAAAAc8wj3KCZ4EBqAYEaEWwzAwqEDEkO5FzAXALLIt5ODLiyz4yAeoYE583oJIANBAyGGMwxmIX/rTpyfPkAKhByD//rN02MzcWoAQMAcMUs+5g3JokT4y4lNXCwAXXFaAYwsBkkwDCAcxaf///kDIOfDCz5///LnEygAg/////5RxO2oDgcCgUjMZAoABkWFQcySVBMYM/JmdnfVGYWGUviptG2aQuWyZgUJAxCAMWQDZxxhZGGqwxq//vSZBuACGmIVO5qQAKMSysNwUQAXum5HJnMgAJFtqU3HxABJ4AupaDCYsYss2C0YTcFow4hPpbLwsgPkGwkJ7GaFmimCTCcCkM4QARsZlAWQYEiILDll8cI55FxCQvm5BByxUyoVGSFnEcSRVJkpIIF0ritwFxH5MdhqKQFsBEQ9j5NxWpER1EmWjqKQp4YvGEf3MkCiKoUAQMvlcuk0XzMtDLJORx8yY+1FkEmImcJxOxot6BqXlrUZual4mjN3ZN2TdVBqNCXCcLi1myZufM5mZEwRUvFExNDc2LpkZGZOF0vf////bbdBv//zExMDc2RSMjM0NUsYY3AAA7P68P0/6qZH0/u6AQW83+tJVdFExSNzXYuk6VjqL1VZueSPpmrNoqTSTQTda00DArl8n0i4QEmCJDlDu6BTHeOFy8K0IQClDlSIGJkkuiynWbFoRoaN1IjmkFKq1ekZIosiTEuIWoKkARJ9Gs0Ol9aiZPE0ovHXROUtb9/80Wbz+p70MxxLLripSjrLACDADIlNjCIdMShMwsWTTd2BAjEQJMAAiYP4GgxuKRYAGJSRXtvG8QVIDDuZrMoAAu3ZQf/+BGYPIZDphNjzBmsf/83ztOYKwcOBhQAaiZ3/5+Gty/NKtDJo4yM6TZ////96q3/vAwUGCrEZWuZ6RGN//9aMRTn7wkIBFJiFKm/R5LmsMW3alqE6wtNe/P//98QrSJh1O7p+6Qya+4Ds1E9UqXQVljTk/////h///P1Mcw1Y1wQjICmXv4ymDEGVbXYbu7UMoIlKnL///////////8P3///91/+8DsxJEFSl2GjxqGUtlbn/bJjaZD///yjr2ACIUSiWXi8OCIhAAAAQdf9jZk99R4aREW/S6jGOJfE5k4MqMqRk3dIQkIIJeOcOSGLvWaOsjhOwN0RNocr9lTSKSKQzQrpdMv00jRmTHJICaFkmTy/cdA4PJQB0DwoqW5dHUOUWRaki4h+wcmOyhQzI2UZJl0xQSMk///eptBFS9JJ661t////+kktWYo15kkWAIFACI5BYAS2oYBph4kpxwx5rSSBnAWxiMAJhEIRhQIBgUBimAGAEaD8wBANwGtI9DRhc7D/+9JkGogITXvFN3dAApHqCS3n4ABcjU0CTmTTwemn4WSMC8gm7hYAvHKddCZqtVYBAsDx3kRh6KS6UxyM1aX3ZgeMX4dftyL8BOVGmkwZTbt1L6zG2o8qsel+t/hEoBdWBakDz8AyqvcYhBCNjKTGDBw2ZdoYCqbw2AmrLlMaWT2V3FqTAJTVGDzjgAUaC+LkMkfiWRnLtaq/2tYY58rWda+1e7vH9YRq79NLpbZh6dq7qZ2YBd6OxiIyqQ09/f36+OGWW9/lM2d4/+X61//+t54/+VXHLv5Vefvn/zPlNS75jjvn/+W+613dnla3Y/9a7ul1//29aFAAAK4NyRANj/1e4Ys3reyuhqEV5MmSukuU9bPr9m/+fIGuRt5e26Wl1L6lWkl8snrWpbPc/C72zq3LZVV5/M9v9f3vC1j+tfj3mefP1+FT8qrO3ZUvQcCLKComubXw1dlEbgEyVLmPK69Sks57t7/HdmzlzPnN97y7Ytbx5//l+/mre61nuX1rVqtPWb9JX65tgJAAXWWAyIAQYnF5iw0GsTobArpxQGHB6kbKOJhkmGNRIY5Jhk8gGJwM1V9GXN0AIGSCcl/WFFtoPfZmS1npLUoUsiXU/1/OMzu4zSO1FqrlRtYVptBPOC6sqmIaf6LfEpdTQE1mMRaU2cdZynOzjytKmtP1M331YasKkK5kWFTDtqJGjfAbRiwWBZQ0OceuflMlYs2hhjBSE5hwKoBjUvUNYKYcu53rWN1/QmcZ5kkSJJeq+PjUSs0iVIKpI2e1M8LRFBRpGtkidnS3EqeoSwVRljwlBY0eaeHDxoKgJ5Zwi2nX36AAAEoA7REipACx4Ng+c2pWJFriaFh6qVKkocSKq0mw0wLNQs5qwcscqvxZLTyKqv8FCzB0DYf7xxuOEu5L5XwiCBhLJbMxtpjJozh9uGWtSl0E7wU0EuCJOCtpFJrzvUeOq1LgBGMcvm3/1KhtH/mVBQKwVypX/2eIqi6RhEJJjAXZrA+pwozZlsHxlSVhkiORiyJxhkHphwF5hIDZgsCZgcA5ZktqnSylBMWaLxJFLGWGUGca1Vhl/X9ltLKZbh9WMwy5Lkzsql3JVLu6yrRqmxpaWf/70mQtD/f5fTUDukTyj6om1SMl8gIwCgAPe8AgCgBAAbAABEwzLdZ8lNmajVqVRq1+8ddlLkuS/r+xp/nKcpnSwxdYskAQRZVEw0MA5r4z4Br4AFmKEmONmTQGxbBjs10M3isygcuysViLWmvOVFu5U1NKpTDIAEAKHsCxzVszWwsLCoqgdA2OkkVaV9hoKQ9yRUVFRUcHQNhUVFa9RUVtRWmb/YWOJFa2+GYWaakk2L/ygbD1Vfb/2v+LJFVi5aaZr/yjhoqbhQQABkVIAGBc68zIch6oqHIeg8HqqtM4qpQsCoFx0khyDU4kVqVpr9VVVVWb4Zr5VV2+YZmZhYWFsebxpYZclyVKQaEZ7BslFQk1EzMJMgcDCoBW2CiJ0ZnMWqgW2RSWMzp2X9f2My2lxxxyy8xjFKUrfmqVv6lQPFK2gDAY4NA0+Ia3S0iJTpJQNSp1n+GuSOsTpcyd9IDUtmbNopoI2IUcTgbiTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//vSZAAP8AAAAAAAAAgAAA0gAAABAAABpAAAACAAADSAAAAETEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+9JkAA/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAARMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqg==';
const globalClickSound = new Audio(kageOriginalClickMp3);
const tabClickSound = new Audio(kageOriginalClickMp3);
tabClickSound.preload = 'auto';
globalHoverSound.volume = 0.16;
globalClickSound.volume = 0.28;
tabClickSound.volume = 0.28;

function playUiSound(source) {
  try {
    source.currentTime = 0;
    const promise = source.play();
    if (promise && typeof promise.catch === 'function') promise.catch(() => {});
  } catch {}
}

function initializeBuildIdentity() {
  const build = new URLSearchParams(location.search).get('build') || 'DEV';
  animateText('settings-build-id', `Build: ${build}`);
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initializeBuildIdentity, { once: true });
else initializeBuildIdentity();

const KageUiToneContext = window.AudioContext || window.webkitAudioContext;
let kageUiToneContext = null;
function ensureKageUiToneAudio() {
  if (!KageUiToneContext) return null;
  if (!kageUiToneContext) kageUiToneContext = new KageUiToneContext();
  if (kageUiToneContext.state === 'suspended') kageUiToneContext.resume().catch(() => {});
  return kageUiToneContext.state === 'closed' ? null : kageUiToneContext;
}

function playKageTone(frequency, startOffset = 0, duration = .18, volume = .035, type = 'sine', endFrequency = null) {
  const ctx = ensureKageUiToneAudio();
  if (!ctx) return;
  const start = ctx.currentTime + .01 + startOffset;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(Math.max(45, frequency), start);
  if (endFrequency) osc.frequency.exponentialRampToValueAtTime(Math.max(45, endFrequency), start + duration);
  gain.gain.setValueAtTime(.0001, start);
  gain.gain.exponentialRampToValueAtTime(Math.max(.001, volume), start + Math.min(.018, duration * .2));
  gain.gain.exponentialRampToValueAtTime(.0001, start + duration);
  osc.connect(gain); gain.connect(ctx.destination);
  osc.start(start); osc.stop(start + duration + .025);
}
function playStudioConnectionSuccess() {
  playUiSound(globalClickSound);
  window.setTimeout(() => playUiSound(globalHoverSound), 14);
}
function playStudioConnectionFailure() {
  playKageTone(246.94, 0, .24, .035, 'triangle', 174.61);
  playKageTone(155.56, .09, .3, .026, 'sine', 116.54);
}
function playConcurrencySnap(value = 4) {
  const normalized = Math.max(0, Math.min(1, (Number(value) - 4) / 92));
  const base = 175 + normalized * 155;
  playKageTone(base, 0, .045, .012 + normalized * .006, 'square', base * 1.035);
}
window.addEventListener('pointerdown', ensureKageUiToneAudio, { passive: true });
window.addEventListener('keydown', ensureKageUiToneAudio, { passive: true });


const interactiveSelector = [
  'button', '.tab-btn', '.discord-logo-btn', '.update-button', '.update-changelog-button',
  '.btn-generate', '.btn-reupload', '.asset-toggle', '.dest-toggle', '.btn-cancel',
  '.btn-logout', '.btn-settings', '.settings-choice', '.settings-step', '.confirm-btn',
  '.settings-account-button', '.settings-account-remove', '.settings-close', '.activity-item', '.kage-interactive'
].join(',');

function bindKageInteraction(el) {
  if (!el || el.dataset?.kageFxBound === '1') return;
  if (el.dataset) el.dataset.kageFxBound = '1';
  el.classList?.add('kage-interactive');
  let pointerFrame = 0;
  let pointerPosition = null;
  const resetPointerFeedback = () => {
    if (pointerFrame) cancelAnimationFrame(pointerFrame);
    pointerFrame = 0;
    pointerPosition = null;
    el.style.setProperty('--button-mouse-x', '50%');
    el.style.setProperty('--button-mouse-y', '50%');
    el.style.setProperty('--follow-x', '0px');
    el.style.setProperty('--follow-y', '0px');
  };
  resetPointerFeedback();
  // Every button gets the original bounded follow effect, including Settings and Shade.
  el.addEventListener?.('pointermove', event => {
    pointerPosition = { x: event.clientX, y: event.clientY };
    if (pointerFrame) return;
    pointerFrame = requestAnimationFrame(() => {
      pointerFrame = 0;
      if (!pointerPosition || el.disabled || document.body.classList.contains('reduce-motion')) {
        resetPointerFeedback();
        return;
      }
      const rect = el.getBoundingClientRect();
      const x = Math.max(0, Math.min(100, ((pointerPosition.x - rect.left) / Math.max(rect.width, 1)) * 100));
      const y = Math.max(0, Math.min(100, ((pointerPosition.y - rect.top) / Math.max(rect.height, 1)) * 100));
      const intensity = el.closest?.('#settings-drawer,#account-manager-modal') ? .8 : el.classList?.contains('tab-btn') ? 3.1 : 3.65;
      el.style.setProperty('--button-mouse-x', `${x}%`);
      el.style.setProperty('--button-mouse-y', `${y}%`);
      el.style.setProperty('--follow-x', `${((x - 50) / 50) * intensity}px`);
      el.style.setProperty('--follow-y', `${((y - 50) / 50) * intensity}px`);
    });
  });
  el.addEventListener?.('pointerleave', resetPointerFeedback);
}

function bindAllKageInteractions(root = document) {
  // Dynamic history/catalog updates bind only their own new controls.
  root.querySelectorAll?.('button,.kage-interactive').forEach(bindKageInteraction);
}

const kageInteractionObserver = new MutationObserver(records => {
  for (const record of records) for (const node of record.addedNodes) {
    if (node.nodeType !== Node.ELEMENT_NODE) continue;
    bindKageInteraction(node.matches?.('button,.kage-interactive') ? node : null);
    node.querySelectorAll?.('button,.kage-interactive').forEach(bindKageInteraction);
  }
});

document.addEventListener('pointerover', event => {
  const target = event.target.closest?.(interactiveSelector);
  if (!target) return;
  if (event.relatedTarget && target.contains(event.relatedTarget)) return;
  playUiSound(globalHoverSound);
});

// v102: play inside the physical gesture (before navigation re-renders), not
// the bubbled click. This also avoids synthetic .click() navigation sounds.
document.addEventListener('pointerdown', event => {
  const tab = event.target.closest?.('.top-icon-nav .tab-btn');
  if (tab && !tab.disabled && event.button === 0) playUiSound(tabClickSound);
}, { capture: true, passive: true });
document.addEventListener('keydown', event => {
  const tab = event.target.closest?.('.top-icon-nav .tab-btn');
  if (tab && !tab.disabled && !event.repeat && (event.key === 'Enter' || event.key === ' '))
    playUiSound(tabClickSound);
}, { capture: true });
document.addEventListener('click', event => {
  // Top navigation already sounded at pointerdown or keydown; no duplicate.
  if (event.target.closest?.('.top-icon-nav .tab-btn')) return;
  if (event.target.closest?.(interactiveSelector)) playUiSound(globalClickSound);
});

function readJsonStorage(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? { ...fallback, ...JSON.parse(raw) } : { ...fallback };
  } catch (error) {
    console.warn(`Could not read ${key}:`, error);
    return { ...fallback };
  }
}

let uiSettings = readJsonStorage(SETTINGS_KEY, defaultUiSettings);
// v41 migration: earlier regression builds could persist motion as disabled while
// the UI effects themselves were broken. Restore motion once for this build;
// after this migration the user's KAGE Motion toggle remains authoritative.
const MOTION_RESTORE_KEY = 'kage_motion_restore_v41';
try {
  if (localStorage.getItem(MOTION_RESTORE_KEY) !== '1') {
    uiSettings.smoothMotion = true;
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(uiSettings));
    localStorage.setItem(MOTION_RESTORE_KEY, '1');
  }
} catch {}
let recentHistory = [];
try {
  const savedHistory = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
  recentHistory = Array.isArray(savedHistory) ? savedHistory : [];
} catch {
  recentHistory = [];
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[char]));
}

// ========== Animated Letters for User Bar ==========
function animateText(elementId, text) {
  const element = document.getElementById(elementId);
  const value = String(text ?? '');
  if (element && value && element.dataset.animatedText !== value) {
    element.dataset.animatedText = value;
    const letters = Array.from(value).map((char, index) =>
      `<span class="animated-letter" style="--letter-index:${index};animation-delay:${index * 0.065}s">${char === ' ' ? '&nbsp;' : escapeHtml(char)}</span>`
    ).join('');
    element.innerHTML = letters;
  }

}

function animateTextBlue(elementId, text) {
  const element = document.getElementById(elementId);
  if (!element) return;
  const value = String(text ?? '');
  if (element.dataset.animatedText === value) return;
  element.dataset.animatedText = value;
  const letters = Array.from(value).map((char, index) =>
    `<span class="animated-letter game-name-letter" style="--letter-index:${index};animation-delay:${index * 0.06}s">${char === ' ' ? '&nbsp;' : escapeHtml(char)}</span>`
  ).join('');
  element.innerHTML = letters;
}
function formatClock(seconds) {
  const total = Math.max(0, Math.ceil(Number(seconds) || 0));
  return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
}
function currentRunDurationText() {
  if (!reuploadStartTime) return '--:--';
  return formatClock((Date.now() - reuploadStartTime) / 1000);
}

function animateCountValue(element, target, { duration = 620, formatter = value => String(Math.round(value)) } = {}) {
  if (!element) return Promise.resolve();

  const end = Math.max(0, Number(target) || 0);
  const start = performance.now();
  let lastTick = -1;
  element.classList.remove('completion-count-bounce');
  element.classList.add('completion-counting');
  element.textContent = formatter(0);

  return new Promise(resolve => {
    const frame = now => {
      const progress = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      const value = end * eased;
      const whole = Math.round(value);

      element.textContent = formatter(value);

      if (whole !== lastTick && progress < 1) {
        lastTick = whole;
      }

      if (progress < 1) {
        requestAnimationFrame(frame);
        return;
      }

      element.textContent = formatter(end);
      element.classList.remove('completion-counting');
      element.classList.add('completion-count-bounce');
      setTimeout(() => element.classList.remove('completion-count-bounce'), 420);
      resolve();
    };

    requestAnimationFrame(frame);
  });
}

async function animateCompletionStats(data = {}) {
  const elapsedText = currentRunDurationText();
  const elapsedMatch = /^(\d+):(\d{2})$/.exec(elapsedText);
  const elapsedSeconds = elapsedMatch ? (Number(elapsedMatch[1]) * 60 + Number(elapsedMatch[2])) : 0;

  const metrics = [
    ['complete-total-assets', Number(data.total) || 0],
    ['complete-successful', Number(data.success ?? data.successful) || 0],
    ['complete-failed', Number(data.failed) || 0],
    ['complete-references-swapped', Number(data.referencesSwapped) || 0]
  ];

  for (const [id] of metrics) updateMetricText(id, 0);
  updateMetricText('complete-eta', '00:00');

  await Promise.all(metrics.map(([id, value], index) =>
    animateCountValue(document.getElementById(id), value, { duration: 500 + index * 70 })
  ));

  await animateCountValue(document.getElementById('complete-eta'), elapsedSeconds, {
    duration: 650,
    formatter: value => formatClock(value)
  });
}

function animateDiscordId(text) {
  const element = document.getElementById('user-discord-id');
  if (!element) return;
  element.style.display = text ? 'block' : 'none';
  if (text) animateText('user-discord-id', String(text));
}

function animateRobloxId(text) {
  const element = document.getElementById('user-roblox-id');
  if (!element) return;
  element.style.display = text ? 'block' : 'none';
  if (text) animateText('user-roblox-id', String(text));
}

function getRobloxRoleTag(userId) {
  return ROBLOX_ROLE_TAGS[String(userId || '')] || '';
}

function updateOwnerRoleBadges(robloxUserId) {
  const roleTag = getRobloxRoleTag(robloxUserId);
  ['home-owner-role', 'settings-owner-role'].forEach(id => {
    const tag = document.getElementById(id);
    if (!tag) return;
    tag.textContent = roleTag;
    tag.classList.toggle('visible', Boolean(roleTag));
    tag.setAttribute('aria-hidden', roleTag ? 'false' : 'true');
  });
}

// Hover shine uses CSS transforms; no whole-page geometry reads on mousemove.

// ========== Smooth Mouse Follow Movement (KAGE-Copy Style) ==========
function setupSmoothMouseFollow() {
  // Mouse-follow is applied by bindKageInteraction so dynamic controls receive it too.
  bindAllKageInteractions(document);
}

// Initialize smooth mouse follow
document.addEventListener('DOMContentLoaded', () => {
  setupSmoothMouseFollow();
  bindAllKageInteractions();
  if (document.body) kageInteractionObserver.observe(document.body, { childList: true, subtree: true });
});

// ========== Tab Navigation with Smooth Shake ==========
const tabButtons = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.tab-content');

function alignExplorerWithConnector() {
  const tab = document.getElementById('tab-reupload');
  const layout = document.querySelector('#tab-reupload .reupload-layout');
  const connector = document.querySelector('#tab-reupload .reupload-command-card');
  const explorer = document.querySelector('#tab-reupload .explorer-panel');
  if (!tab || !layout || !connector || !explorer) return;

  if (window.innerWidth <= 720) {
    layout.style.setProperty('--explorer-connector-offset', '0px');
    layout.style.removeProperty('--explorer-visible-height');
    return;
  }

  const tabRect = tab.getBoundingClientRect();
  const layoutRect = layout.getBoundingClientRect();
  const connectorRect = connector.getBoundingClientRect();
  if (!layoutRect.width || !connectorRect.width || !tabRect.height) return;

  // Keep the explorer's top edge aligned to the Studio connect/connected box,
  // not the lower Destination / Asset Type row. Cap its height to the visible
  // Reupload viewport so Studio state changes can never push it below the GUI.
  const offset = Math.max(0, connectorRect.top - layoutRect.top);
  const bottomInset = 16;
  const availableHeight = Math.max(180, Math.floor(tabRect.bottom - connectorRect.top - bottomInset));
  layout.style.setProperty('--explorer-connector-offset', `${Math.round(offset)}px`);
  layout.style.setProperty('--explorer-visible-height', `${availableHeight}px`);
}

function scheduleExplorerAlignment() {
  requestAnimationFrame(() => requestAnimationFrame(alignExplorerWithConnector));
}

window.addEventListener('resize', scheduleExplorerAlignment);

// Home quick actions use the existing navigation path; no duplicate workflow logic.
document.querySelectorAll('[data-home-tab]').forEach(button => {
  button.addEventListener('click', () => {
    const tab = String(button.dataset.homeTab || '').trim();
    if (!tab) return;
    document.querySelector(`.tab-btn[data-tab="${tab}"]`)?.click();
  });
});

document.querySelector('.tab-btn[data-tab="reupload"]')?.addEventListener('click', scheduleExplorerAlignment);
if (typeof ResizeObserver !== 'undefined') {
  const connector = document.querySelector('#tab-reupload .reupload-command-card');
  const reuploadTab = document.getElementById('tab-reupload');
  const observer = new ResizeObserver(scheduleExplorerAlignment);
  if (connector) observer.observe(connector);
  if (reuploadTab) observer.observe(reuploadTab);
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', scheduleExplorerAlignment, { once: true });
else scheduleExplorerAlignment();

tabButtons.forEach(btn => {
  btn.addEventListener('click', () => {
    const targetTab = btn.dataset.tab;

    tabButtons.forEach(b => b.classList.remove('active'));
    tabContents.forEach(c => c.classList.remove('active'));

    btn.classList.add('active');
    document.getElementById(`tab-${targetTab}`)?.classList.add('active');
    bridge.send('discordPresenceArea', { area: targetTab });
    if (targetTab === 'ai') requestAnimationFrame(() => renderShadeConversation({ force: true, settle: true }));
  }, { capture: true });
});

// ========== Asset Type Toggles ==========
const assetToggles = document.querySelectorAll('.asset-toggle');
assetToggles.forEach(toggle => {
  toggle.addEventListener('click', () => {
    assetToggles.forEach(t => t.classList.remove('active'));
    toggle.classList.add('active');
  });
});

// ========== Destination Toggles ==========
const destToggles = document.querySelectorAll('.dest-toggle');
let selectedExplorerAssetId = null;
let selectedExplorerAssetType = null;
const groupIdField = document.getElementById('group-id-field');

function animateReuploadSurfaceChange(...targets) {
  const elements = targets.flatMap(target => {
    if (!target) return [];
    if (typeof target === 'string') return [...document.querySelectorAll(target)];
    return [target];
  }).filter(Boolean);
  for (const element of elements) {
    element.classList.remove('reupload-surface-enter');
    void element.offsetWidth;
    element.classList.add('reupload-surface-enter');
    window.setTimeout(() => element.classList.remove('reupload-surface-enter'), 620);
  }
}

destToggles.forEach(toggle => {
  toggle.addEventListener('click', () => {
    const dest = toggle.dataset.dest;
    if (dest === 'group') {
      requestEligibleGroups();
      return;
    }
    destToggles.forEach(t => t.classList.remove('active'));
    toggle.classList.add('active');
    groupSelector.selected = null;
    const groupInput = document.getElementById('input-groupid');
    if (groupInput) groupInput.value = '';
    document.getElementById('selected-group-preview')?.classList.add('hidden');
    groupIdField?.classList.add('hidden');
    animateReuploadSurfaceChange('.destination-card', '#destination-account-card');
  });
});

function showToastNotification(message, plain = false, force = false) {
  if (!force && uiSettings.notifications === false) return;
  // Create toast element
  const toast = document.createElement('div');
  toast.className = 'toast-notification';
  if (plain) toast.classList.add('plain');
  toast.textContent = message;
  document.body.appendChild(toast);

  // Trigger animation
  setTimeout(() => {
    toast.classList.add('show');
  }, 10);

  // Remove after 4 seconds
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => {
      toast.remove();
    }, 400);
  }, 4000);
}

// ========== Reupload Progress Presentation ==========
const progressView = new window.KageProgressView();

// ========== Reupload Controls ==========
const btnStart = document.getElementById('btn-start');
const btnCancel = document.getElementById('btn-cancel');
const modalOverlay = document.getElementById('modal-overlay');
const progressPanel = document.getElementById('progress-panel');

btnStart?.addEventListener('click', () => {
  startReupload();
});

btnCancel?.addEventListener('click', () => {
  stopReupload();
});

let reuploadStartTime = null;
let bridgePoll = null;
let activeJobId = null;
let pollGeneration = 0;
let completionTimer = null;
let finishingReupload = false;
let awaitingReferenceApply = false;
let pendingTerminalJob = null;
const completedReferenceResults = new Map();
let activeReuploadAssetType = 'Animations';
let liveReuploadResultSequence = 0;
let lastReuploadResult = null;
const processingAssetLogKeys = new Set();
const pendingReuploadAssetResults = new Map();

function getSelectedAssetType() { return "Animations"; }

function getSelectedDestination() {
  return document.querySelector('.dest-toggle.active')?.dataset.dest || 'user';
}

let pendingStudioPreparation = null;
function waitForPreparedStudioJob(timeoutMs = 120000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      pendingStudioPreparation = null;
      reject(new Error('Studio took too long to prepare the job. Check the Studio connection and retry.'));
    }, timeoutMs);
    pendingStudioPreparation = {
      resolve: data => { clearTimeout(timer); pendingStudioPreparation = null; resolve(data); },
      reject: error => { clearTimeout(timer); pendingStudioPreparation = null; reject(error); }
    };
  });
}

async function startReupload() {
  if (activeJobId || btnStart?.disabled) return;
  if (!requireStudioConnection()) return;
  if (btnStart) btnStart.disabled = true;
  try {
    const assetType = 'Animations';
    activeReuploadAssetType = assetType;
    liveReuploadResultSequence = 0;
    lastReuploadResult = null;
    pendingReuploadAssetResults.clear();
    processingAssetLogKeys.clear();
    const destination = getSelectedDestination();
    const groupId = document.getElementById('input-groupid')?.value?.trim() || '';
    const concurrency = Number(uiSettings.concurrency) || Number(document.getElementById('setting-concurrency')?.value) || 96;

    const prepared = waitForPreparedStudioJob();
    progressView.reset(0);
    progressPanel?.classList.remove('hidden');
    modalOverlay?.classList.add('active');
    document.getElementById('progress-stage').textContent = 'Scanning Studio project…';
    document.getElementById('progress-status').textContent = 'Finding assets in the open project';
    const legacyAssetNames = uiSettings.legacyAssetNames === true;
    if (selectedExplorerAssetId) bridge.send('prepareStudioRun', { assetType, destination, groupId, concurrency, legacyAssetNames, selectedAssetId: selectedExplorerAssetId });
    else bridge.send('prepareStudioRun', { assetType, destination, groupId, concurrency, legacyAssetNames });
    selectedExplorerAssetId = null;
    selectedExplorerAssetType = null;
    showToastNotification(`Preparing ${assetType.toLowerCase()} in Studio...`, true);
    appendLog('INFO', `Starting ${assetType.toLowerCase()} reupload / destination ${destination}${groupId ? ` / group ${groupId}` : ''} / concurrency ${concurrency}`);
    const job = await prepared;

    clearTimeout(bridgePoll);
    clearTimeout(completionTimer);
    activeJobId = job.jobId;
    finishingReupload = false;
    awaitingReferenceApply = false;
    const generation = ++pollGeneration;
    progressView.reset(job.total);
    document.getElementById('progress-stage').textContent = `Preparing ${assetType}...`;
    document.getElementById('progress-status').textContent = 'Preparing Roblox uploads…';
    document.getElementById('progress-eta').textContent = '--:--';
    reuploadStartTime = Date.now();
    flushPendingReuploadAssetResults(job.jobId);
    await pollStudioJob(generation);
  } catch (error) {
    if (!activeJobId) {
      document.getElementById('progress-stage').textContent = 'Could not start reupload';
      document.getElementById('progress-status').textContent = error?.message || 'Studio could not prepare the job.';
    }
    console.error('Could not start Studio job:', error);
    showToastNotification(error?.message || 'KAGE could not reach the local bridge.', true);
  } finally {
    if (!activeJobId && btnStart) btnStart.disabled = false;
  }
}

function handleStudioJobSnapshot(job) {
  if (!activeJobId || String(job?.jobId || '') !== String(activeJobId)) return;
  updateProgress({
    jobId: job.jobId, total: job.total, completed: job.completed,
    success: job.successful, failed: job.failed,
    currentAsset: job.currentAsset, currentAssetId: job.currentAssetId,
    currentAssetStatus: job.currentAssetStatus, etaSeconds: job.etaSeconds,
    status: job.fatalError || (job.currentAssetStatus || (job.status === 'Processing' ? 'Preparing Roblox uploads…' : job.status)),
    stage: job.status === 'Processing' ? 'Reuploading assets…' : job.status
  });
  if (job.status === 'Completed') {
    pendingTerminalJob = {
      jobId: job.jobId, success: job.successful, failed: job.failed,
      completed: job.completed, total: job.total, status: job.status,
      fatalError: job.fatalError, assetType: job.assetType || activeReuploadAssetType,
      referencesSwapped: Math.max(0, Number(job.referencesSwapped) || 0),
      elapsedSeconds: reuploadStartTime ? ((Date.now() - reuploadStartTime) / 1000) : 0
    };
    awaitingReferenceApply = true;
    progressView.stop();
    document.getElementById('progress-stage').textContent = 'Verifying Studio references…';
    document.getElementById('progress-status').textContent = 'Finishing remaining ID swaps and checking the project';
    document.getElementById('progress-eta').textContent = '00:00';
    // Reference outcomes persist on the job, so losing a WebView event cannot leave
    // the modal open forever. Early events remain available for older bridge jobs.
    const savedReferenceResult = job.referenceStatus === 'Completed'
      ? { referencesSwapped: pendingTerminalJob.referencesSwapped }
      : job.referenceStatus === 'Failed'
        ? { status: 'Failed', referencesSwapped: pendingTerminalJob.referencesSwapped, fatalError: job.referenceError || 'Reference update failed.' }
        : completedReferenceResults.get(String(job.jobId));
    if (savedReferenceResult) {
      completedReferenceResults.delete(String(job.jobId));
      const finished = { ...pendingTerminalJob, ...savedReferenceResult };
      pendingTerminalJob = null;
      handleReuploadComplete(finished);
    }
  } else if (['Failed', 'Cancelled'].includes(job.status)) {
    handleReuploadComplete({
      jobId: job.jobId, success: job.successful, failed: job.failed,
      completed: job.completed, total: job.total, status: job.status,
      fatalError: job.fatalError, assetType: job.assetType || activeReuploadAssetType,
      referencesSwapped: Math.max(0, Number(job.referencesSwapped) || 0)
    });
  }
}

async function pollStudioJob(generation = pollGeneration) {
  if (generation !== pollGeneration || !activeJobId) return;
  const jobId = String(activeJobId);
  const controller = new AbortController();
  const deadline = setTimeout(() => controller.abort(), 6000);
  try {
    const response = await fetch(`http://127.0.0.1:34821/api/studio/jobs/${encodeURIComponent(jobId)}`, {
      cache: 'no-store', headers: studioBridgeHeaders(), signal: controller.signal
    });
    if (!response.ok) throw new Error(`Bridge returned ${response.status}`);
    const job = await response.json();
    if (generation !== pollGeneration || jobId !== String(activeJobId || '')) return;
    handleStudioJobSnapshot(job);
  } catch (error) {
    if (generation !== pollGeneration || jobId !== String(activeJobId || '')) return;
    console.warn('Progress connection interrupted:', error);
    document.getElementById('progress-status').textContent = 'Recovering job progress…';
    // The native window retains this job even if its localhost bridge restarts.
    bridge.send('getStudioJobProgress', { jobId });
  } finally {
    clearTimeout(deadline);
    if (generation === pollGeneration && activeJobId && !finishingReupload) {
      bridgePoll = setTimeout(() => pollStudioJob(generation), 250);
    }
  }
}

function dismissReupload() {
  ++pollGeneration;
  clearTimeout(bridgePoll);
  clearTimeout(completionTimer);
  bridgePoll = null;
  completionTimer = null;
  activeJobId = null;
  pendingTerminalJob = null;
  awaitingReferenceApply = false;
  lastReuploadResult = null;
  liveReuploadResultSequence = 0;
  progressView.stop();
  modalOverlay?.classList.remove('active');
  progressPanel?.classList.add('hidden');
  if (btnStart) btnStart.disabled = false;
}

function stopReupload() {
  bridge.send('stopReupload');
  dismissReupload();
}

function calculateETA(completed, total) {
  if (!reuploadStartTime || completed === 0) return '--:--';

  const elapsed = (Date.now() - reuploadStartTime) / 1000; // seconds
  const rate = completed / elapsed;
  const remaining = total - completed;
  const eta = remaining / rate;

  const minutes = Math.floor(eta / 60);
  const seconds = Math.floor(eta % 60);

  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

// ========== Discord Logo Click ==========
document.getElementById('btn-join-discord')?.addEventListener('click', () => {
  bridge.send('openDiscord');
});

// ========== GitHub Self-Update UI ==========
const updateNotice = document.getElementById('update-notice');
const updateProgressView = document.getElementById('update-progress-view');
const updateProgressBar = document.getElementById('update-progress-bar');
const updateStatus = document.getElementById('update-status');
const updateEta = document.getElementById('update-eta');
const updateTransfer = document.getElementById('update-transfer');
const updateButton = document.getElementById('btn-update');
const updateAppliedModal = document.getElementById('update-applied-modal');
const updateAppliedBuildId = document.getElementById('update-applied-build-id');
const updateAppliedClose = document.getElementById('update-applied-close');
const updateChangelogButton = document.getElementById('btn-update-changelog');
let updateProgressFill = null;
let updateInProgress = false;
let updateAvailableConfirmed = false;
const updateDownloadModal = document.getElementById('update-download-modal');
const updateDownloadClose = document.getElementById('update-download-close');
const updateDownloadRetry = document.getElementById('update-download-retry');
const updateDownloadHint = document.getElementById('update-download-hint');
let updateDownloadReturnFocus = null;

function openUpdateDownloadModal() {
  if (!updateDownloadModal || !updateDownloadModal.classList.contains('hidden')) return;
  closeAccountManager();
  closeSettings();
  updateDownloadReturnFocus = document.activeElement;
  updateDownloadModal.classList.remove('hidden');
  updateDownloadModal.setAttribute('aria-hidden', 'false');
  document.body.classList.add('update-open');
  document.getElementById('kage-main-shell').inert = true;
  updateDownloadModal.querySelector('.update-download-content')?.focus({ preventScroll: true });
}
function closeUpdateDownloadModal() {
  if (!updateDownloadModal || updateDownloadModal.classList.contains('hidden')) return;
  updateDownloadModal.classList.add('hidden');
  updateDownloadModal.setAttribute('aria-hidden', 'true');
  updateProgressView?.classList.add('hidden');
  document.body.classList.remove('update-open');
  document.getElementById('kage-main-shell').inert = false;
  updateDownloadReturnFocus?.focus?.({ preventScroll: true });
}

const updateRecovery = document.getElementById('update-recovery');
const UPDATE_CHECK_INTERVAL_MS = 120000;
let lastUpdateCheckAt = 0;

function requestUpdateCheck(force = false) {
  if (updateInProgress) return;
  const now = Date.now();
  if (!force && now - lastUpdateCheckAt < UPDATE_CHECK_INTERVAL_MS) return;
  lastUpdateCheckAt = now;
  bridge.send('checkForUpdates');
}

function ensureUpdateProgressBar() {
  if (!updateProgressBar) return;
  if (updateProgressFill?.isConnected) return;
  updateProgressBar.innerHTML = '';
  updateProgressBar.classList.add('kage-image-progress');
  updateProgressFill = document.createElement('span');
  updateProgressFill.className = 'update-progress-fill';
  const sheen = document.createElement('span');
  sheen.className = 'update-progress-sheen';
  updateProgressFill.appendChild(sheen);
  updateProgressBar.appendChild(updateProgressFill);
}

function setUpdateProgressPercent(value) {
  ensureUpdateProgressBar();
  const percent = Math.max(0, Math.min(100, Number(value) || 0));
  updateProgressBar?.style.setProperty('--kage-progress', `${percent}%`);
  if (updateProgressFill) {
    updateProgressFill.style.width = `${percent}%`;
    updateProgressFill.classList.toggle('filling', percent > 0 && percent < 100);
  }
  updateProgressBar?.setAttribute('aria-valuenow', String(Math.round(percent)));
}

function formatUpdateBytes(value) {
  const bytes = Math.max(0, Number(value) || 0);
  if (bytes < 1024) return `${bytes.toFixed(0)} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function formatUpdateEta(value) {
  if (!Number.isFinite(Number(value)) || Number(value) < 0) return '--:--';
  const seconds = Math.max(0, Math.ceil(Number(value)));
  return `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
}

function showUpdateAvailable(data = {}) {
  if (updateInProgress && !data.operationComplete) return;
  if (data.operationComplete) { updateInProgress = false; closeUpdateDownloadModal(); }
  // Home shows one action only after the native, authenticated release check
  // confirms a newer build. A failed check is not a "no update" result.
  updateNotice?.classList.add('hidden');
  if (updateNotice) {
    updateNotice.textContent = '';
    updateNotice.removeAttribute('title');
    updateNotice.removeAttribute('aria-label');
  }
  updateRecovery?.classList.add('hidden');
  updateAvailableConfirmed = !data.checkFailed && data.available === true;
  updateButton?.classList.toggle('hidden', !updateAvailableConfirmed);
  updateProgressView?.classList.add('hidden');
  closeUpdateDownloadModal();
  if (updateAvailableConfirmed && updateButton) {
    updateButton.disabled = false;
    updateButton.setAttribute('aria-label', 'Download update');
    updateButton.dataset.tooltip = 'Download update';
  }
}

function showUpdateProgress(data = {}) {
  if (!updateNotice) return;
  updateInProgress = !data.error;
  openUpdateDownloadModal();
  updateDownloadModal?.setAttribute('aria-busy', String(updateInProgress));
  updateDownloadClose?.classList.toggle('hidden', updateInProgress);
  updateDownloadRetry?.classList.toggle('hidden', updateInProgress || !updateAvailableConfirmed || data.retryable === false);
  if (updateDownloadHint) updateDownloadHint.textContent = data.error ? 'You can close this message and try again.' : 'KAGE will restart when the update is ready.';
  updateNotice.classList.add('hidden');
  updateButton?.classList.add('hidden');
  updateProgressView?.classList.remove('hidden');

  if (updateStatus && data.status) updateStatus.textContent = data.status;
  if (updateEta) updateEta.textContent = `ETA: ${formatUpdateEta(data.etaSeconds)}`;
  if (typeof data.percent === 'number') setUpdateProgressPercent(data.percent);

  if (updateTransfer) {
    const received = formatUpdateBytes(data.bytesReceived);
    const total = formatUpdateBytes(data.totalBytes);
    const speed = Number(data.bytesPerSecond) > 0 ? `${formatUpdateBytes(data.bytesPerSecond)}/s` : '—';
    updateTransfer.textContent = Number(data.totalBytes) > 0
      ? `${received} / ${total} · ${speed}`
      : speed;
  }

  if (data.error) {
    updateNotice.textContent = 'Update failed';
    updateTransfer.textContent = data.error;
    if (updateEta) updateEta.textContent = 'ETA: --:--';
    updateDownloadRetry?.focus({ preventScroll: true });
  }
}

let displayedUpdateBuildId = '';
const dismissedUpdateBuildIds = new Set();
function showUpdateApplied(data = {}) {
  updateInProgress = false;
  updateAvailableConfirmed = false;
  closeUpdateDownloadModal();
  updateNotice?.classList.add('hidden');
  updateButton?.classList.add('hidden');
  updateProgressView?.classList.add('hidden');
  // Signed build identifiers remain strings: converting them loses precision.
  const buildId = typeof data.buildId === 'string' ? data.buildId : String(data.buildId ?? '');
  if (dismissedUpdateBuildIds.has(buildId)) return;
  displayedUpdateBuildId = buildId;
  if (updateAppliedBuildId) updateAppliedBuildId.textContent = `Build ID: ${buildId || '—'}`;
  const notes = document.getElementById('update-applied-notes');
  if (notes) notes.textContent = typeof data.changelog === 'string' ? data.changelog : '';
  updateChangelogButton?.classList.toggle('hidden', !!data.changelog);
  updateAppliedModal?.classList.remove('hidden');
  updateAppliedModal?.setAttribute('aria-hidden', 'false');
}
function dismissUpdateApplied() {
  if (displayedUpdateBuildId) {
    dismissedUpdateBuildIds.add(displayedUpdateBuildId);
    bridge.send('dismissUpdateChangelog', { buildId: displayedUpdateBuildId });
  }
  updateAppliedModal?.classList.add('hidden');
  updateAppliedModal?.setAttribute('aria-hidden', 'true');
}
function startUpdateDownload() {
  if (!updateAvailableConfirmed || updateInProgress) return;
  if (updateButton) updateButton.disabled = true;
  showUpdateProgress({ status: 'Preparing update...', percent: 0 });
  bridge.send('startUpdate');
}
function dismissUpdateError() {
  if (updateInProgress) return;
  closeUpdateDownloadModal();
  if (updateAvailableConfirmed) { showUpdateAvailable({ available: true }); updateButton?.focus({ preventScroll: true }); }
}
updateButton?.addEventListener('click', startUpdateDownload);
updateDownloadRetry?.addEventListener('click', startUpdateDownload);
updateDownloadClose?.addEventListener('click', dismissUpdateError);
document.addEventListener('keydown', event => {
  if (!updateDownloadModal || updateDownloadModal.classList.contains('hidden')) return;
  if (event.key === 'Escape') { event.preventDefault(); dismissUpdateError(); }
  if (event.key === 'Tab') {
    const controls = [...updateDownloadModal.querySelectorAll('button')].filter(el => !el.classList.contains('hidden') && !el.disabled);
    if (!controls.length) { event.preventDefault(); return; }
    const first = controls[0], last = controls[controls.length - 1];
    if (event.shiftKey && (document.activeElement === first || !controls.includes(document.activeElement))) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && (document.activeElement === last || !controls.includes(document.activeElement))) { event.preventDefault(); first.focus(); }
  }
});
updateChangelogButton?.addEventListener('click', () => { bridge.send('openChangelog'); dismissUpdateApplied(); });
updateAppliedClose?.addEventListener('click', dismissUpdateApplied);
document.getElementById('update-applied-done')?.addEventListener('click', dismissUpdateApplied);
updateAppliedModal?.addEventListener('click', event => { if (event.target === updateAppliedModal) dismissUpdateApplied(); });
document.addEventListener('keydown', event => { if (event.key === 'Escape' && !updateAppliedModal?.classList.contains('hidden')) dismissUpdateApplied(); });

// ========== Recent History + Settings ==========
const btnSettings = document.getElementById('btn-settings');
const settingsDrawer = document.getElementById('settings-drawer');
const settingsOverlay = document.getElementById('settings-overlay');
const settingsClose = document.getElementById('settings-close');
const concurrencySetting = document.getElementById('setting-concurrency');
const concurrencyValue = document.getElementById('setting-concurrency-value');
const activityList = document.getElementById('activity-list');
let bridgeStateTimer = null;
let autoStartGuard = false;
let settingsReturnFocus = null;

function openSettings() {
  if (!settingsDrawer || settingsDrawer.classList.contains('active')) return;
  settingsReturnFocus = document.activeElement;
  settingsDrawer.inert = false;
  settingsDrawer.setAttribute('aria-hidden', 'false');
  settingsDrawer?.classList.add('active');
  document.body.classList.add('settings-open');
  window.dispatchEvent(new CustomEvent('kageSettingsVisibility', { detail: { open: true } }));
  bridge.send('discordPresenceArea', { area: 'settings' });
  document.getElementById('kage-main-shell').inert = true;
  btnSettings?.setAttribute('aria-expanded', 'true');
  settingsClose?.focus({ preventScroll: true });
}

function closeSettings() {
  if (!settingsDrawer?.classList.contains('active')) return;
  settingsDrawer?.classList.remove('active');
  settingsDrawer.inert = true;
  settingsDrawer.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('settings-open');
  window.dispatchEvent(new CustomEvent('kageSettingsVisibility', { detail: { open: false } }));
  bridge.send('discordPresenceArea', { area: document.querySelector('.tab-btn.active')?.dataset.tab || 'home' });
  document.getElementById('kage-main-shell').inert = false;
  btnSettings?.setAttribute('aria-expanded', 'false');
  if (settingsReturnFocus?.isConnected) settingsReturnFocus.focus({ preventScroll: true });
  settingsReturnFocus = null;
}

btnSettings?.addEventListener('click', openSettings);
settingsClose?.addEventListener('click', closeSettings);
settingsOverlay?.addEventListener('click', closeSettings);
document.addEventListener('keydown', event => {
  if (event.key !== 'Escape' || !settingsDrawer?.classList.contains('active')) return;
  // Let the account dialog handle Escape before returning to Settings.
  if (!document.getElementById('account-manager-modal')?.classList.contains('hidden')) return;
  event.preventDefault();
  closeSettings();
});

function saveUiSettings() {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(uiSettings));
  } catch (error) {
    console.warn('Could not save KAGE settings:', error);
  }
}

let lastPersistedHistory = null;
function persistHistory() {
  if (uiSettings.saveHistory === false) return;
  const durableHistory = recentHistory.slice(0, 12);
  const serialized = JSON.stringify(durableHistory);
  if (serialized === lastPersistedHistory) return;
  if (typeof localStorage !== 'undefined') {
    try {
      localStorage.setItem(HISTORY_KEY, serialized);
    } catch (error) {
      console.warn('Could not save KAGE history:', error);
    }
  }
  bridge.send('saveRecentHistory', { history: durableHistory });
  lastPersistedHistory = serialized;
}

const CONCURRENCY_SNAP = 4;
let lastConcurrencySnap = null;
function clampConcurrency(value) {
  return Math.min(96, Math.max(1, Math.round(Number(value) || 96)));
}
function snapConcurrency(value) {
  return Math.min(96, Math.max(4, Math.round(clampConcurrency(value) / CONCURRENCY_SNAP) * CONCURRENCY_SNAP));
}
function updateConcurrencyPresentation(value) {
  const exact = clampConcurrency(value);
  const percent = Math.max(0, Math.min(100, ((exact - 1) / 95) * 100));
  const power = percent / 100;
  const box = document.getElementById('concurrency-control-box');
  if (concurrencyValue) {
    concurrencyValue.value = String(exact);
    concurrencyValue.textContent = String(exact);
    concurrencyValue.setAttribute('aria-valuenow', String(exact));
  }
  if (concurrencySetting) {
    const snapped = snapConcurrency(exact);
    concurrencySetting.value = String(snapped);
    concurrencySetting.style.setProperty('--concurrency-fill', `${percent}%`);
    concurrencySetting.style.setProperty('--concurrency-power', power.toFixed(3));
  }
  box?.style.setProperty('--concurrency-fill', `${percent}%`);
  box?.style.setProperty('--concurrency-power', power.toFixed(3));
  box?.classList.toggle('concurrency-hot', exact >= 72);
}

function applyUiSettings() {
  const concurrency = clampConcurrency(uiSettings.concurrency);
  uiSettings.concurrency = concurrency;
  updateConcurrencyPresentation(concurrency);

  document.querySelectorAll('.settings-choice[data-setting]').forEach(button => {
    const key = button.dataset.setting;
    const enabled = uiSettings[key] !== false;
    button.classList.toggle('active', enabled);
    button.setAttribute('aria-pressed', enabled ? 'true' : 'false');
    button.dataset.state = enabled ? 'on' : 'off';
    const switchControl = button.querySelector('.kage-setting-check');
    switchControl?.setAttribute('aria-label', enabled ? 'On' : 'Off');
  });

  document.body.classList.toggle('reduce-motion', uiSettings.smoothMotion === false);
  document.body.classList.toggle('asset-details-hidden', uiSettings.showAssetDetails === false);
  bridge.send('setAlwaysOnTop', { enabled: uiSettings.alwaysOnTop !== false });
}

function setConcurrency(value) {
  const previous = clampConcurrency(uiSettings.concurrency);
  const snapped = snapConcurrency(value);
  uiSettings.concurrency = Math.min(96, Math.max(1, Number(snapped) || 96));
  saveUiSettings();
  updateConcurrencyPresentation(uiSettings.concurrency);
  if (uiSettings.concurrency !== previous && uiSettings.concurrency !== lastConcurrencySnap) {
    playConcurrencySnap(uiSettings.concurrency);
    lastConcurrencySnap = uiSettings.concurrency;
  }
}
function setConcurrencyExact(value) {
  const previous = clampConcurrency(uiSettings.concurrency);
  uiSettings.concurrency = Math.min(96, Math.max(1, Number(value) || 96));
  saveUiSettings();
  updateConcurrencyPresentation(uiSettings.concurrency);
  if (uiSettings.concurrency !== previous) playConcurrencySnap(uiSettings.concurrency);
}

concurrencySetting?.addEventListener('input', () => setConcurrency(concurrencySetting.value));
concurrencySetting?.addEventListener('change', () => { lastConcurrencySnap = null; });
document.getElementById('concurrency-down')?.addEventListener('click', () => setConcurrency((Number(uiSettings.concurrency) || 96) - CONCURRENCY_SNAP));
document.getElementById('concurrency-up')?.addEventListener('click', () => setConcurrency((Number(uiSettings.concurrency) || 96) + CONCURRENCY_SNAP));

function selectConcurrencyText() {
  if (!concurrencyValue) return;
  const range = document.createRange();
  range.selectNodeContents(concurrencyValue);
  const selection = window.getSelection();
  selection?.removeAllRanges(); selection?.addRange(range);
}
function commitManualConcurrency() {
  if (!concurrencyValue) return;
  const raw = String(concurrencyValue.textContent || '').replace(/[^0-9]/g, '');
  const parsed = Number(raw);
  if (!Number.isFinite(parsed) || parsed < 1) {
    updateConcurrencyPresentation(uiSettings.concurrency);
    return;
  }
  setConcurrencyExact(parsed);
}
concurrencyValue?.addEventListener('focus', selectConcurrencyText);
concurrencyValue?.addEventListener('keydown', event => {
  if (event.key === 'Enter') { event.preventDefault(); concurrencyValue.blur(); }
  if (!/[0-9]/.test(event.key) && !['Backspace','Delete','ArrowLeft','ArrowRight','Home','End','Tab'].includes(event.key)) event.preventDefault();
});
concurrencyValue?.addEventListener('blur', commitManualConcurrency);

document.querySelectorAll('.settings-choice[data-setting]').forEach(button => {
  button.addEventListener('click', () => {
    const key = button.dataset.setting;
    if (!key) return;
    uiSettings[key] = uiSettings[key] === false;
    saveUiSettings();

    if (key === 'saveHistory') {
      lastPersistedHistory = null;
      if (uiSettings.saveHistory === false) localStorage.removeItem(HISTORY_KEY);
      else persistHistory();
    }

    applyUiSettings();
    if (key === 'manualStart' && uiSettings.manualStart === false) {
      refreshBridgeState(true);
    }
  });
});

function formatHistoryTime(value) {
  if (!value) return 'Recently';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Recently';
  const seconds = Math.max(0, Math.floor((Date.now() - date.getTime()) / 1000));
  if (seconds < 60) return 'Just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;
  return date.toLocaleDateString();
}

function isInvalidHistoryPlaceName(value) {
  const raw = String(value || '').trim();
  if (!raw) return true;
  if (raw.toLowerCase() === 'title unavailable') return true;
  const compact = raw.replace(/[^a-z0-9]/gi, '').toLowerCase();
  if (['titleunavailable', 'unavailable', 'untitled', 'unknown', 'game', 'place', 'studio', 'studioproject'].includes(compact)) return true;
  return /^game\d+$/.test(compact) || /^place\d+$/.test(compact);
}

function normalizeHistoryPlaceName(job) {
  const raw = String(job?.placeName || '').trim();
  if (!isInvalidHistoryPlaceName(raw)) return raw;
  const placeId = Number(job?.placeId) || 0;
  return placeId ? `Place ${placeId}` : 'Studio Project';
}

function formatHistoryDuration(value) {
  const seconds = Math.max(0, Number(value) || 0);
  if (seconds < 60) return seconds < 10 ? `${seconds.toFixed(1)}s` : `${Math.round(seconds)}s`;
  if (seconds < 3600) {
    const minutes = Math.floor(seconds / 60);
    return `${minutes}m ${String(Math.round(seconds % 60)).padStart(2, '0')}s`;
  }
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.round(seconds % 60);
  return `${hours}h ${String(minutes).padStart(2, '0')}m ${String(secs).padStart(2, '0')}s`;
}

function historyKey(job) {
  return job.jobId || `${job.placeId || 0}:${job.createdUtc || job.finishedUtc || ''}`;
}

function normalizeHistoryJob(job) {
  const successful = Math.max(0, Number(job.successful) || 0);
  const total = Math.max(0, Number(job.total) || 0);
  return {
    jobId: job.jobId || '',
    placeId: Number(job.placeId) || 0,
    universeId: Number(job.universeId) || 0,
    placeName: normalizeHistoryPlaceName(job),
    successful,
    assetType: String(job.assetType || 'Animations'),
    failed: Math.max(0, Number(job.failed) || 0),
    total,
    status: String(job.status || 'Unknown'),
    createdUtc: job.createdUtc || null,
    startedUtc: job.startedUtc || null,
    finishedUtc: job.finishedUtc || null,
    elapsedSeconds: Math.max(0, Number(job.elapsedSeconds) || 0)
  };
}

function mergeRecentJobs(jobs) {
  if (!Array.isArray(jobs)) return;
  const merged = new Map(recentHistory.map(item => [historyKey(item), item]));
  for (const job of jobs) {
    const normalized = normalizeHistoryJob(job);
    const previous = merged.get(historyKey(normalized));
    // A late queued/running snapshot must never regress a completed job's final totals.
    if (['Completed','Failed','Cancelled'].includes(previous?.status) && ['Queued','Running','Processing'].includes(normalized.status)) continue;
    if (previous?.status === 'Completed' && normalized.status === 'Completed') {
      normalized.successful = Math.max(normalized.successful, Number(previous.successful) || 0);
      normalized.total = Math.max(normalized.total, Number(previous.total) || 0);
      normalized.failed = Math.max(normalized.failed, Number(previous.failed) || 0);
      normalized.finishedUtc = previous.finishedUtc || normalized.finishedUtc;
      normalized.elapsedSeconds = Math.max(normalized.elapsedSeconds, Number(previous.elapsedSeconds) || 0);
    }
    // Older Studio bridge history records omit universeId; retain any previous
    // mapping instead of overwriting it with zero on every background refresh.
    normalized.universeId ||= Number(previous?.universeId) || 0;
    merged.set(historyKey(normalized), { ...(previous || {}), ...normalized });
  }
  recentHistory = [...merged.values()]
    .sort((a, b) => new Date(b.finishedUtc || b.createdUtc || 0) - new Date(a.finishedUtc || a.createdUtc || 0))
    .slice(0, 12);
  persistHistory();
  renderRecentHistory();
  updateHomeStatistics();
}

function updateHomeStatistics() {
  const completed = recentHistory.filter(job => job.status === 'Completed');
  const count = jobs => jobs.reduce((sum, job) => sum + Math.max(0, Number(job.successful) || 0), 0);
  updateMetricText('home-stat-animations', count(completed.filter(job => job.assetType === 'Animations')).toLocaleString());
  updateMetricText('home-stat-assets', count(completed).toLocaleString());
  updateMetricText('home-stat-runs', completed.length.toLocaleString());
}

function renderRecentHistory() {
  if (!activityList) return;
  const visible = recentHistory.slice(0, 12);
  if (visible.length === 0) {
    activityList.innerHTML = '<div class="activity-empty">No recent spoof history yet</div>';
    return;
  }

  const scrollTop = activityList.scrollTop;
  const markup = visible.map(item => {
    const status = String(item.status || 'Unknown');
    const placeName = normalizeHistoryPlaceName(item);
    const running = ['Queued', 'Processing', 'Running'].includes(status);
    const count = Math.max(0, Number(item.successful) || 0);
    const total = Math.max(0, Number(item.total) || 0);
    const metaTime = formatHistoryTime(item.finishedUtc || item.createdUtc);
    const durationText = Number(item.elapsedSeconds) > 0
      ? ` · ${formatHistoryDuration(item.elapsedSeconds)}`
      : '';
    const statusText = running
      ? `${Math.max(0, Number(item.successful) || 0)} / ${total}`
      : `${status}${durationText}`;
    const tooltip = `${placeName}${item.placeId ? ` · Place ${item.placeId}` : ''}`;
    return `
      <div class="activity-item" data-status="${escapeHtml(status.toLowerCase())}">
        <div class="activity-place">
          <div class="activity-name" data-tooltip="${escapeHtml(tooltip)}">${escapeHtml(placeName)}</div>
          <div class="activity-meta">${escapeHtml(statusText)} · ${escapeHtml(metaTime)}</div>
        </div>
        <div class="activity-count">
          <strong>${count.toLocaleString()}</strong>
          <span>assets</span>
        </div>
      </div>`;
  }).join('');
  // Bridge state refreshes every two seconds. Keep the entry the user scrolled
  // to visible instead of jumping back to the newest run on every refresh.
  if (activityList.innerHTML !== markup) {
    activityList.innerHTML = markup;
    activityList.scrollTop = scrollTop;
  }
}

let bridgeStateRequestPending = false;
async function refreshBridgeState(allowAutoStart = false) {
  if (bridgeStateRequestPending) return;
  bridgeStateRequestPending = true;
  const controller = new AbortController();
  const deadline = setTimeout(() => controller.abort(), 6000);
  try {
    const response = await fetch('http://127.0.0.1:34821/api/ui/state', { cache: 'no-store', headers: studioBridgeHeaders(), signal: controller.signal });
    if (!response.ok) return;
    const state = await response.json();
    mergeRecentJobs(state.jobs || []);

    if ((allowAutoStart || uiSettings.manualStart === false) && uiSettings.manualStart === false && !activeJobId && !autoStartGuard) {
      const queued = (state.jobs || []).find(job => job.status === 'Queued');
      if (queued) {
        autoStartGuard = true;
        try {
          await startReupload();
        } finally {
          setTimeout(() => { autoStartGuard = false; }, 700);
        }
      }
    }
  } catch {
    // Studio bridge may not be ready yet. The next interval will retry.
  } finally {
    clearTimeout(deadline);
    bridgeStateRequestPending = false;
  }
}

document.getElementById('clear-history')?.addEventListener('click', () => {
  showConfirmModal('Clear Recent History', 'Remove all saved recent KAGE runs from this PC?', () => {
    recentHistory = [];
    lastPersistedHistory = null;
    localStorage.removeItem(HISTORY_KEY);
    bridge.send('clearRecentHistory');
    renderRecentHistory();
    showToastNotification('Recent history cleared.');
  });
});

function renderLoadingLetters(element, text) {
  if (!element) return;
  element.textContent = '';
  String(text || '').split('').forEach((letter, index) => {
    const span = document.createElement('span');
    const displayLetter = letter === ' ' ? '\u00A0' : letter;
    span.textContent = displayLetter;
    span.setAttribute('data-letter', displayLetter);
    span.style.setProperty('--letter-delay', `${index * 0.11}s`);
    element.appendChild(span);
  });
}

function showLogoutLoading() {
  const overlay = document.getElementById('logout-loading-overlay');
  const title = document.getElementById('logout-loading-title');
  const button = document.getElementById('btn-logout');
  renderLoadingLetters(title, 'LOGGING OUT');
  button?.setAttribute('disabled', 'disabled');
  overlay?.classList.add('active');
  overlay?.setAttribute('aria-hidden', 'false');
}

function hideLogoutLoading() {
  const overlay = document.getElementById('logout-loading-overlay');
  const button = document.getElementById('btn-logout');
  overlay?.classList.remove('active');
  overlay?.setAttribute('aria-hidden', 'true');
  button?.removeAttribute('disabled');
}

document.getElementById('btn-logout')?.addEventListener('click', () => {
  showConfirmModal('Log Out', 'Are you sure you want to log out? You will need to reconnect your accounts.', () => {
    showLogoutLoading();
    bridge.send('logout');
  });
});

applyUiSettings();
renderRecentHistory();

// ========== Custom Confirmation Modal ==========
function showConfirmModal(title, message, onConfirm) {
  const modal = document.getElementById('confirm-modal');
  const titleEl = document.getElementById('confirm-title');
  const messageEl = document.getElementById('confirm-message');
  const cancelBtn = document.getElementById('confirm-cancel');
  const confirmBtn = document.getElementById('confirm-confirm');

  titleEl.textContent = title;
  messageEl.textContent = message;
  // Shared confirm dialog: the door icon appears only when confirming logout.
  const isLogout = title === 'Log Out';
  confirmBtn.classList.toggle('logout-confirm', isLogout);
  confirmBtn.textContent = isLogout ? '' : 'Confirm';
  confirmBtn.setAttribute('aria-label', isLogout ? 'Log out' : 'Confirm');
  if (title === 'Log Out') {
    const glyph = document.createElement('img');
    glyph.src = '../Assets/kage-logout.png';
    glyph.alt = '';
    glyph.className = 'kage-logout-glyph';
    confirmBtn.prepend(glyph);
  }
  modal.classList.add('active');

  const closeModal = () => {
    modal.classList.remove('active');
    cancelBtn.removeEventListener('click', closeModal);
    confirmBtn.removeEventListener('click', handleConfirm);
    modal.removeEventListener('click', handleBackdrop);
  };

  const handleConfirm = () => {
    onConfirm();
    closeModal();
  };

  cancelBtn.addEventListener('click', closeModal);
  confirmBtn.addEventListener('click', handleConfirm);

  const handleBackdrop = event => { if (event.target === modal) closeModal(); };
  modal.addEventListener('click', handleBackdrop);
}

// ========== Automatic Studio Connection ==========
// ========== Load Account Info ==========
function loadAccountInfo() {
  bridge.send('getAccountInfo');
  bridge.send('getAccounts');
}

const settingsAddAccount = document.getElementById('settings-add-account');
const settingsSwitchAccount = document.getElementById('settings-switch-account');
const settingsAccountPanel = document.getElementById('settings-add-account-panel');
const settingsAccountList = document.getElementById('settings-account-list');
const accountManagerModal = document.getElementById('account-manager-modal');
const accountManagerClose = document.getElementById('account-manager-close');
const accountManagerBackdrop = document.getElementById('account-manager-backdrop');
const accountManagerShowAccounts = document.getElementById('account-manager-show-accounts');
const accountManagerShowAdd = document.getElementById('account-manager-show-add');
let savedAccountsCount = 0;
let accountManagerReturnFocus = null;
const accountSecretInputs = ['settings-account-cookie', 'settings-account-api-key']
  .map(id => document.getElementById(id)).filter(Boolean);
function setAccountSecretVisible(input, visible = false) {
  const toggle = accountManagerModal?.querySelector(`[aria-controls="${input.id}"]`);
  const name = input.id.endsWith('cookie') ? 'Roblox cookie' : 'Open Cloud API key';
  input.type = visible ? 'text' : 'password';
  input.style.webkitTextSecurity = visible ? 'none' : 'disc';
  toggle?.setAttribute('aria-pressed', String(visible));
  toggle?.setAttribute('aria-label', `${visible ? 'Hide' : 'Show'} ${name}`);
  if (toggle) toggle.title = `${visible ? 'Hide' : 'Show'} ${name}`;
}
function concealAccountSecrets() {
  accountSecretInputs.forEach(input => setAccountSecretVisible(input, false));
}
for (const input of accountSecretInputs) {
  const toggle = accountManagerModal?.querySelector(`[aria-controls="${input.id}"]`);
  setAccountSecretVisible(input, false);
  toggle?.addEventListener('click', () => {
    setAccountSecretVisible(input, input.type === 'password');
    input.focus({ preventScroll: true });
    input.setSelectionRange(input.value.length, input.value.length);
  });
}


function setAccountManagerMode(mode = 'accounts') {
  const adding = mode === 'add';
  concealAccountSecrets();
  accountManagerShowAdd?.setAttribute('aria-pressed', String(adding));
  accountManagerShowAccounts?.setAttribute('aria-pressed', String(!adding));
  settingsAccountPanel?.classList.toggle('hidden', !adding);
  settingsAccountList?.classList.toggle('hidden', adding);
  accountManagerShowAdd?.classList.toggle('active', adding);
  accountManagerShowAccounts?.classList.toggle('active', !adding);
  if (!adding) bridge.send('getAccounts');
  else requestAnimationFrame(() => {
    if (!accountManagerModal?.classList.contains('hidden') && !settingsAccountPanel?.classList.contains('hidden'))
      document.getElementById('settings-account-cookie')?.focus({ preventScroll: true });
  });
}

function openAccountManager(mode = 'accounts') {
  if (!accountManagerModal) return;
  if (accountManagerModal.classList.contains('hidden')) accountManagerReturnFocus = document.activeElement;
  accountManagerModal.classList.remove('hidden');
  accountManagerModal.setAttribute('aria-hidden', 'false');
  setAccountManagerMode(mode);
  bindAllKageInteractions(accountManagerModal);
}

function closeAccountManager() {
  concealAccountSecrets();
  if (!accountManagerModal || accountManagerModal.classList.contains('hidden')) return;
  accountManagerModal.classList.add('hidden');
  accountManagerModal.setAttribute('aria-hidden', 'true');
  accountManagerReturnFocus?.focus?.({ preventScroll: true });
  accountManagerReturnFocus = null;
}

settingsAddAccount?.addEventListener('click', () => openAccountManager('add'));
settingsSwitchAccount?.addEventListener('click', () => openAccountManager('accounts'));
document.getElementById('settings-open-account-manager')?.addEventListener('click', () => openAccountManager('accounts'));
accountManagerShowAccounts?.addEventListener('click', () => setAccountManagerMode('accounts'));
accountManagerShowAdd?.addEventListener('click', () => setAccountManagerMode('add'));
accountManagerClose?.addEventListener('click', closeAccountManager);
accountManagerBackdrop?.addEventListener('click', closeAccountManager);
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && accountManagerModal && !accountManagerModal.classList.contains('hidden')) closeAccountManager();
});

document.getElementById('settings-save-account')?.addEventListener('click', () => {
  const cookie = document.getElementById('settings-account-cookie')?.value?.trim() || '';
  const apiKey = document.getElementById('settings-account-api-key')?.value?.trim() || '';
  if (!cookie || !apiKey) {
    showToastNotification('Enter both the Roblox cookie and API key.', true);
    return;
  }
  bridge.send('addAccount', { cookie, apiKey });
});

function renderAccountsInfo(data) {
  if (!settingsAccountList) return;
  const accounts = Array.isArray(data?.accounts) ? data.accounts : [];
  savedAccountsCount = accounts.length;
  const bySlot = new Map(accounts.map(account => [Number(account.slot), account]));
  const activeSlot = Number(data?.activeSlot) || 1;
  const cards = [1, 2].map(slot => {
    const account = bySlot.get(slot);
    if (!account) {
      return `<div class="account-slot-card empty" data-slot="${slot}">
        <div class="account-slot-avatar empty-avatar"><span>+</span></div>
        <strong>Account ${slot}</strong>
        <small>No account added</small>
        <button class="account-slot-action settings-account-button" type="button" data-add-slot="${slot}">Add account<span class="interaction-shine"></span></button>
      </div>`;
    }
    const username = account.username || account.displayName || `Account ${slot}`;
    const display = account.displayName && account.displayName !== username ? account.displayName : '';
    const isActive = activeSlot === slot;
    const avatarStyle = account.avatar ? ` style="background-image:url('${escapeHtml(account.avatar)}')"` : '';
    return `<div class="account-slot-card ${isActive ? 'active' : ''}" data-slot="${slot}">
      <div class="account-slot-avatar"${avatarStyle}></div>
      <strong>${escapeHtml(display || username)}</strong>
      <small>@${escapeHtml(username)}${account.id ? ` · ID ${escapeHtml(account.id)}` : ''}</small>
      <button class="account-slot-action settings-account-button" type="button" data-switch-slot="${slot}" ${isActive ? 'disabled' : ''}>${isActive ? 'ACTIVE' : `Switch to ${escapeHtml(username)}`}<span class="interaction-shine"></span></button>
      ${slot === 2 ? '<button class="account-slot-remove" type="button" data-remove-slot="2" aria-label="Remove second account" data-tooltip="Remove second account">Remove</button>' : ''}
    </div>`;
  });
  settingsAccountList.innerHTML = cards.join('');
  settingsAccountList.querySelectorAll('[data-switch-slot]').forEach(button => {
    bindKageInteraction(button);
    button.addEventListener('click', () => {
      const slot = Number(button.dataset.switchSlot);
      if (slot && slot !== activeSlot) bridge.send('switchAccount', { slot });
    });
  });
  settingsAccountList.querySelectorAll('[data-add-slot]').forEach(button => {
    bindKageInteraction(button);
    button.addEventListener('click', () => setAccountManagerMode('add'));
  });
  settingsAccountList.querySelectorAll('[data-remove-slot]').forEach(button => {
    button.addEventListener('click', event => {
      event.currentTarget.disabled = true;
      bridge.send('removeAccount', { slot: Number(event.currentTarget.dataset.removeSlot) || 2 });
    });
  });
}

// ========== Handle Messages from C# ==========
const seenStudioWorkspaceEvents = new Set();
bridge.onMessage((message) => {
  const { event, data } = message;

  switch (event) {
    case 'studioBridgeSession':
      studioBridgeSession = {
        token: String(data?.token || ''),
        sessionId: String(data?.sessionId || '')
      };
      break;
    case 'studioConnectionState':
      updateStudioConnectionState(data);
      break;
    case 'accountInfo':
      updateAccountInfo(data);
      break;
    case 'accountsInfo':
      renderAccountsInfo(data);
      break;
    case 'accountAdded':
      settingsAccountPanel?.classList.add('hidden');
      closeAccountManager();
      document.getElementById('settings-account-cookie').value = '';
      document.getElementById('settings-account-api-key').value = '';
      showToastNotification(`Added ${data?.displayName || data?.username || 'Roblox account'}.`, true);
      bridge.send('getAccounts');
      break;
    case 'accountRemoved':
      document.getElementById('settings-account-cookie').value = '';
      document.getElementById('settings-account-api-key').value = '';
      showToastNotification('Second account removed.', true);
      bridge.send('getAccounts');
      break;
    case 'accountSwitched':
      settingsAccountList?.classList.add('hidden');
      closeAccountManager();
      animateReuploadSurfaceChange('.destination-card', '#destination-account-card');
      showToastNotification('Roblox account switched.', true);
      break;
    case 'accountActionError':
      showToastNotification(data?.message || 'Account action failed.', true);
      break;
    case 'studioRunError':
      if (pendingStudioPreparation) pendingStudioPreparation.reject(new Error(data?.message || 'Studio could not prepare the run.'));
      else showToastNotification(data?.message || 'Studio could not prepare the run.', true);
      break;
    case 'studioJobProgress':
      handleStudioJobSnapshot(data);
      break;
    case 'studioRunPrepared':
      pendingStudioPreparation?.resolve({ jobId: data?.jobId, total: data?.total });
      break;
    case 'logoutError':
      hideLogoutLoading();
      showToastNotification(data?.message || 'KAGE could not log out. Please try again.', true);
      break;
    case 'recentHistoryLoaded':
      mergeRecentJobs(data?.items || []);
      break;
    case 'historyThumbnail': {
      const id = Number(data?.placeId) || 0;
      if (id) {
        historyThumbnailPending.delete(id);
        const thumbnail = typeof data?.imageUrl === 'string' ? data.imageUrl : '';
        if (thumbnail && isHistoryThumbnailUrl(thumbnail)) {
          historyThumbnailCache.set(id, thumbnail);
          historyThumbnailFailedAt.delete(id);
          historyThumbnailUnavailable.delete(id);
          // A CDN response can have an image header but still be corrupt.
          // Let Chromium decode it and restore the fallback if decoding fails.
          const image = new Image();
          image.onerror = () => {
            if (historyThumbnailCache.get(id) !== thumbnail) return;
            historyThumbnailCache.delete(id);
            historyThumbnailInvalid.add(id);
            bridge.send('historyThumbnailDecodeFailed', { placeId: id });
            historyThumbnailFailedAt.set(id, Date.now());
            applyHistoryThumbnails();
          };
          image.onload = () => historyThumbnailInvalid.delete(id);
          image.src = thumbnail;
        } else if (data?.state === 'Unavailable') {
          historyThumbnailUnavailable.add(id);
          historyThumbnailFailedAt.set(id, Date.now());
        } else {
          // Failed external requests are temporary, not permanent cache hits.
          historyThumbnailFailedAt.set(id, Date.now());
        }
        applyHistoryThumbnails();
      }
      break;
    }
    case 'updateState':
      showUpdateAvailable(data);
      break;
    case 'updateProgress':
      showUpdateProgress(data);
      break;
    case 'updateChangelog':
    case 'updateApplied':
      showUpdateApplied(data);
      break;
    case 'progressUpdate':
      updateProgress(data);
      break;
    case 'reuploadComplete':
      handleReuploadComplete(data);
      break;
    case 'studioReferencesProgress': {
      const referenceJobId = String(data?.jobId || activeJobId || '');
      const changes = Array.isArray(data?.changes) ? data.changes : [];
      const failures = Array.isArray(data?.failures) ? data.failures : [];
      for (const change of changes) {
        appendLog('SUCCESS', describeStudioReferenceChange(change));
      }
      for (const failure of failures) {
        appendLog('WARN', `SWAP RETRY / ${failure?.oldId || '—'} → ${failure?.newId || '—'} / ${failure?.location || 'Studio'} / final verification will retry`);
      }
      if (referenceJobId && referenceJobId === String(activeJobId || '')) {
        const totalChanged = Math.max(0, Number(data?.totalChanged) || 0);
        const status = document.getElementById('progress-status');
        if (status && totalChanged > 0) status.textContent = `${totalChanged} Studio instance${totalChanged === 1 ? '' : 's'} updated while uploading`;
      }
      break;
    }
    case 'studioReferencesApplied': {
      const referenceJobId = String(data?.jobId || activeJobId || '');
      const changes = Array.isArray(data?.changes) ? data.changes : [];
      const failures = Array.isArray(data?.failures) ? data.failures : [];
      for (const change of changes) {
        appendLog('SUCCESS', describeStudioReferenceChange(change));
      }
      for (const failure of failures) {
        appendLog('ERROR', `SWAP FAILED / ${failure?.oldId || '—'} → ${failure?.newId || '—'} / ${failure?.location || 'Studio'} / ${failure?.reason || 'setter failed'}`);
      }
      const result = { referencesSwapped: Number(data?.mapped ?? data?.changed) || 0 };
      if (pendingTerminalJob && (!referenceJobId || referenceJobId === String(activeJobId || ''))) {
        const finished = { ...pendingTerminalJob, ...result };
        pendingTerminalJob = null;
        handleReuploadComplete(finished);
      } else if (referenceJobId) {
        completedReferenceResults.set(referenceJobId, result);
      }
      break;
    }
    case 'studioReferenceUpdateError': {
      showToastNotification(data?.message || 'KAGE could not update Studio references.', true);
      const changes = Array.isArray(data?.changes) ? data.changes : [];
      const failures = Array.isArray(data?.failures) ? data.failures : [];
      for (const change of changes) {
        appendLog('SUCCESS', describeStudioReferenceChange(change));
      }
      for (const failure of failures) {
        appendLog('ERROR', `SWAP FAILED / ${failure?.oldId || '—'} → ${failure?.newId || '—'} / ${failure?.location || 'Studio'} / ${failure?.reason || 'setter failed'}`);
      }
      const remaining = data?.remainingLocations && typeof data.remainingLocations === 'object' ? data.remainingLocations : {};
      for (const [oldId, locations] of Object.entries(remaining)) {
        const list = Array.isArray(locations) ? locations : [];
        if (!list.length) appendLog('ERROR', `SWAP FAILED / ${oldId} / old reference still exists`);
        else for (const location of list.slice(0, 6)) appendLog('ERROR', `SWAP FAILED / ${oldId} / ${location} / old reference still exists`);
      }
      const referenceJobId = String(data?.jobId || activeJobId || '');
      const referencesSwapped = Number.isFinite(Number(data?.changed))
        ? Math.max(0, Number(data.changed))
        : Math.max(0, Number(pendingTerminalJob?.referencesSwapped) || 0);
      const result = { status: 'Failed', referencesSwapped, fatalError: data?.message || 'Reference update failed.' };
      if (pendingTerminalJob && (!referenceJobId || referenceJobId === String(activeJobId || ''))) {
        const failed = { ...pendingTerminalJob, ...result };
        pendingTerminalJob = null;
        handleReuploadComplete(failed);
      } else if (referenceJobId) {
        completedReferenceResults.set(referenceJobId, result);
      }
      break;
    }
    case 'studioWorkspaceSnapshot':
      renderStudioWorkspace(data || {});
      break;
    case 'studioWorkspaceError': {
      const eventId = String(data?.eventId || `${data?.scope || 'workspace'}:${data?.message || ''}`);
      if (!seenStudioWorkspaceEvents.has(eventId)) {
        seenStudioWorkspaceEvents.add(eventId);
        if (seenStudioWorkspaceEvents.size > 80) seenStudioWorkspaceEvents.delete(seenStudioWorkspaceEvents.values().next().value);
        appendLog('ERROR', data?.message || 'Studio workspace operation failed.');
      }
      break;
    }
    case 'eligibleGroups':
      renderGroupSelector(data || {});
      break;
    case 'savedSessionValidated':
      if (data?.success) {
        sessionStorage.setItem('kageWelcomeBackPassed', '1');
        finishWelcomeBackDismiss();
        requestUpdateCheck(true);
      } else {
        showToastNotification(data?.error || 'Saved KAGE authorization expired.', true);
        showWelcomeBackGate();
      }
      break;
    case 'shadeReply':
      typeShadeAssistantMessage(data?.message || '');
      break;
    case 'shadeStatus':
      setShadeStatus(data?.label || 'Online', data?.state || 'online');
      break;
    case 'shadePromptAccepted': {
      const chatId = String(data?.chatId || '');
      const prompt = String(data?.prompt || '');
      if (chatId && chatId !== currentShadeChatId) {
        currentShadeChatId = chatId;
        const known = shadeChats.find(chat => chat.id === chatId);
        if (!known) shadeChats.unshift({ id: chatId, title: 'New chat', messages: [], updated: Date.now() });
        shadeConversation.splice(0, shadeConversation.length, ...(known?.messages || []).map(item => ({ role: item.role, text: item.text })));
      }
      if (prompt && (shadeConversation.at(-1)?.role !== 'user' || shadeConversation.at(-1)?.text !== prompt)) addShadeMessage('user', prompt);
      break;
    }
    case 'shadeStreamStart':
      shadeRequestInFlight = true;
      showShadeLoadingPlaceholder();
      updateShadeSendButtons();
      break;
    case 'shadeStreamDelta':
      appendShadeDelta(data?.text || '');
      break;
    case 'shadeStreamDone':
      finishShadeStream(); setShadeStatus('Online', 'online');
      break;
    case 'shadeStreamError':
      shadeQueue.length = 0;
      removeShadeLoadingPlaceholder();
      finishShadeStream();
      addShadeMessage('assistant', data?.message || 'Shade is unavailable right now.');
      setShadeStatus('Unavailable', 'offline');
      break;
    case 'reuploadAssetResult':
      handleReuploadAssetResult(data || {});
      break;
    default:
      console.log('Unknown event:', event);
  }
});

function updateAccountInfo(data) {
  console.log('Account info received:', data);

  if (data.discord) {
    const discordText = `${data.discord.username}`;
    animateText('user-discord', discordText);
    const settingsDiscordName = document.getElementById('settings-discord-username');
    const settingsDiscordId = document.getElementById('settings-discord-id');
    if (settingsDiscordName) animateText('settings-discord-username', data.discord.username || '—');
    if (settingsDiscordId) animateText('settings-discord-id', data.discord.id ? `ID ${data.discord.id}` : '—');
    const homeDiscordName = document.getElementById('home-discord-username');
    const homeDiscordId = document.getElementById('home-discord-id');
    if (homeDiscordName) animateText('home-discord-username', data.discord.username || 'Discord Account');
    if (homeDiscordId) animateText('home-discord-id', data.discord.id ? `ID: ${data.discord.id}` : 'ID: —');

    // Paint the authenticated Discord avatar and avatar-decoration in the primary
    // accountInfo handler. Version-side wrappers can miss the first native event
    // because uiReady is emitted before later version scripts finish loading.
    const settingsDiscordAvatar = document.getElementById('settings-discord-avatar');
    const settingsDiscordAvatarImage = document.getElementById('settings-discord-avatar-image');
    const settingsDiscordDecoration = document.getElementById('settings-discord-decoration');
    const discordAvatarUrl = String(data.discord.avatar || data.discord.avatarUrl || '').trim();
    const discordDecorationUrl = String(data.discord.decoration || data.discord.decorationUrl || '').trim();
    if (settingsDiscordAvatar) {
      settingsDiscordAvatar.style.backgroundImage = discordAvatarUrl ? `url("${discordAvatarUrl.replace(/["\\]/g, '')}")` : 'none';
      settingsDiscordAvatar.style.backgroundPosition = 'center';
      settingsDiscordAvatar.style.backgroundRepeat = 'no-repeat';
    }
    if (settingsDiscordAvatarImage) {
      if (discordAvatarUrl) { settingsDiscordAvatarImage.src = discordAvatarUrl; settingsDiscordAvatarImage.style.display = 'block'; }
      else { settingsDiscordAvatarImage.removeAttribute('src'); settingsDiscordAvatarImage.style.display = 'none'; }
    }
    if (settingsDiscordDecoration) {
      if (discordDecorationUrl) { settingsDiscordDecoration.src = discordDecorationUrl; settingsDiscordDecoration.style.display = 'block'; }
      else { settingsDiscordDecoration.removeAttribute('src'); settingsDiscordDecoration.style.display = 'none'; }
    }

    // Welcome Back uses the same authenticated Discord media. Keep the base
    // avatar and optional decoration as separate layers so decoration scale
    // never changes identity alignment.
    const welcomeDiscordAvatarImage = document.getElementById('welcome-discord-avatar-image');
    const welcomeDiscordDecoration = document.getElementById('welcome-discord-decoration');
    const welcomeDiscordHolder = document.getElementById('welcome-discord-avatar');
    if (welcomeDiscordHolder) welcomeDiscordHolder.style.backgroundImage = 'none';
    if (welcomeDiscordAvatarImage) {
      if (discordAvatarUrl) { welcomeDiscordAvatarImage.src = discordAvatarUrl; welcomeDiscordAvatarImage.style.display = 'block'; }
      else { welcomeDiscordAvatarImage.removeAttribute('src'); welcomeDiscordAvatarImage.style.display = 'none'; }
    }
    if (welcomeDiscordDecoration) {
      if (discordDecorationUrl) { welcomeDiscordDecoration.src = discordDecorationUrl; welcomeDiscordDecoration.style.display = 'block'; }
      else { welcomeDiscordDecoration.removeAttribute('src'); welcomeDiscordDecoration.style.display = 'none'; }
    }
    const welcomeDiscordName = document.getElementById('welcome-discord-name');
    const welcomeDiscordId = document.getElementById('welcome-discord-id');
    if (welcomeDiscordName) animateText('welcome-discord-name', data.discord.username || 'Discord Account');
    if (welcomeDiscordId) animateText('welcome-discord-id', data.discord.id ? `ID: ${data.discord.id}` : 'ID: —');

    // Show Discord ID under username
    const discordIdEl = document.getElementById('user-discord-id');
    console.log('Discord ID element:', discordIdEl, 'Discord ID value:', data.discord.id);
    if (discordIdEl) {
      if (data.discord.id && data.discord.id !== '') {
        animateDiscordId(`ID: ${data.discord.id}`);
      } else {
        discordIdEl.style.display = 'none';
      }
    }
  }

  if (data.roblox) {
    updateOwnerRoleBadges(data.roblox.id);
    const robloxText = `${data.roblox.username || data.roblox.displayName}`;
    animateText('user-roblox', robloxText);
    animateRobloxId(data.roblox.id ? `ID: ${data.roblox.id}` : '');
    const settingsRobloxUsername = document.getElementById('settings-roblox-username');
    const settingsRobloxDisplay = document.getElementById('settings-roblox-display');
    if (settingsRobloxUsername) animateText('settings-roblox-username', data.roblox.username || data.roblox.displayName || '—');
    if (settingsRobloxDisplay) animateText('settings-roblox-display', data.roblox.id ? `ID ${data.roblox.id}` : '—');

    // Set Roblox avatar everywhere the authenticated identity is shown.
    const robloxAvatarUrl = String(data.roblox.avatar || '').trim();
    const settingsAvatar = document.getElementById('settings-avatar');
    if (settingsAvatar) {
      settingsAvatar.innerHTML = robloxAvatarUrl ? `<img src="${robloxAvatarUrl}" alt="Avatar">` : '';
    }
    const settingsRobloxAvatar = document.getElementById('settings-roblox-avatar');
    if (settingsRobloxAvatar) {
      settingsRobloxAvatar.style.backgroundImage = robloxAvatarUrl ? `url("${robloxAvatarUrl.replace(/["\\]/g, '')}")` : 'none';
    }
    const homeAvatar = document.getElementById('home-profile-avatar');
    if (homeAvatar) {
      homeAvatar.style.backgroundImage = robloxAvatarUrl ? `url("${robloxAvatarUrl.replace(/["\\]/g, '')}")` : 'none';
    }

    const settingsAvatarName = document.getElementById('settings-avatar-name');
    if (settingsAvatarName) animateText('settings-avatar-name', data.roblox.displayName || data.roblox.username || 'Roblox Account');
    const homeName = document.getElementById('home-profile-name');
    const homeId = document.getElementById('home-profile-id');
    if (homeName) animateText('home-profile-name', data.roblox.displayName || data.roblox.username || 'Roblox account');
    if (homeId) animateText('home-profile-id', data.roblox.id ? `ID: ${data.roblox.id}` : 'ID: —');

    // Show Roblox User ID under display name in settings
    const settingsAvatarId = document.getElementById('settings-avatar-id');
    console.log('Roblox ID element:', settingsAvatarId, 'Roblox ID value:', data.roblox.id);
    if (settingsAvatarId) {
      if (data.roblox.id && data.roblox.id !== '') {
        animateText('settings-avatar-id', `ID: ${data.roblox.id}`);
        settingsAvatarId.style.display = 'block';
      } else {
        settingsAvatarId.style.display = 'none';
      }
    }
  } else {
    updateOwnerRoleBadges('');
  }
}

function logProcessingAsset(data = {}) {
  const oldId = String(data.currentAssetId || data.oldId || '').trim();
  if (!oldId) return;

  const jobKey = String(data.jobId || activeJobId || 'run');
  const dedupeKey = `${jobKey}:${oldId}`;
  if (processingAssetLogKeys.has(dedupeKey)) return;
  processingAssetLogKeys.add(dedupeKey);

  const asset = (currentWorkspaceSnapshot?.animations || []).find(item => String(item.id || '') === oldId);
  const assetType = String(data.assetType || activeReuploadAssetType || 'Assets').replace(/s$/i, '');
  const name = String(data.currentAsset || data.assetName || asset?.name || `${assetType} ${oldId}`).trim();
  const location = String(data.currentAssetLocation || asset?.location || 'Detected location').trim();
  const sequence = Math.max(1, (Number(data.completed) || 0) + 1);

  appendLog('INFO', `PROCESSING / ${assetType} / ${name} / ${location} / ID ${oldId} / #${sequence}`);
}

function updateProgress(data) {
  logProcessingAsset(data);
  const progressStage = document.getElementById('progress-stage');
  const progressStatus = document.getElementById('progress-status');
  const progressEta = document.getElementById('progress-eta');
  if (data.stage && progressStage) progressStage.textContent = data.stage;
  if (data.status && progressStatus) progressStatus.textContent = data.status;
  progressView.update(data);

  if (progressEta && data.completed !== undefined && data.total !== undefined) {
    const etaText = (typeof data.etaSeconds === 'number' && Number.isFinite(data.etaSeconds))
      ? formatClock(data.etaSeconds)
      : calculateETA(data.completed, data.total);
    progressEta.textContent = etaText;
  }
}

function showReuploadCompleteModal(data = {}) {
  const modal = document.getElementById('reupload-complete-modal');
  updateMetricText('complete-total-assets', 0);
  updateMetricText('complete-successful', 0);
  updateMetricText('complete-failed', 0);
  updateMetricText('complete-references-swapped', 0);
  updateMetricText('complete-eta', '00:00');

  const title = document.getElementById('reupload-complete-title');
  if (title) title.textContent = data.status === 'Completed' ? 'Finished' : `KAGE ${String(data.status || 'finished').toLowerCase()}`;

  const message = document.getElementById('reupload-complete-message');
  if (message) {
    message.textContent = data.fatalError || '';
    message.hidden = !data.fatalError;
  }
  modal?.classList.remove('hidden');
  modal?.setAttribute('aria-hidden', 'false');

  requestAnimationFrame(() => {
    requestAnimationFrame(() => animateCompletionStats(data));
  });
}
function closeReuploadCompleteModal() {
  const modal = document.getElementById('reupload-complete-modal');
  modal?.classList.add('hidden');
  modal?.setAttribute('aria-hidden', 'true');
}
function handleReuploadComplete(data) {
  if (data?.jobId) pendingReuploadAssetResults.delete(String(data.jobId));
  if (finishingReupload && !awaitingReferenceApply) return;
  finishingReupload = true;
  awaitingReferenceApply = false;
  clearTimeout(completionTimer);
  completionTimer = null;
  clearTimeout(bridgePoll);
  bridgePoll = null;
  progressView.stop();
  const summary = {
    ...data,
    completed: data.completed ?? ((Number(data.success) || 0) + (Number(data.failed) || 0)),
    total: Number(data.total) || 0,
    success: Number(data.success ?? data.successful) || 0,
    failed: Number(data.failed) || 0,
    referencesSwapped: Number(data.referencesSwapped) || 0
  };
  // The completion modal is the authoritative final result for this run.
  if (summary.jobId) {
    const previous = recentHistory.find(item => String(item.jobId) === String(summary.jobId));
    const project = currentWorkspaceSnapshot?.project || {};
    const finalHistory = normalizeHistoryJob({
      ...previous,
      jobId: summary.jobId,
      placeId: previous?.placeId || project.placeId,
      universeId: previous?.universeId || project.universeId,
      placeName: previous?.placeName || project.name,
      assetType: summary.assetType || previous?.assetType || activeReuploadAssetType,
      successful: summary.success,
      failed: summary.failed,
      total: summary.total,
      status: summary.status,
      elapsedSeconds: summary.elapsedSeconds || ((Date.now() - reuploadStartTime) / 1000),
      finishedUtc: new Date().toISOString()
    });
    const index = recentHistory.findIndex(item => String(item.jobId) === String(summary.jobId));
    if (index >= 0) recentHistory[index] = finalHistory;
    else recentHistory.unshift(finalHistory);
    recentHistory = recentHistory.slice(0, 12);
    persistHistory(); renderRecentHistory(); updateHomeStatistics();
  }
  refreshBridgeState();
  dismissReupload();
  showReuploadCompleteModal(summary);
  appendLog(summary.status === 'Completed' ? 'SUCCESS' : 'ERROR', `Reupload ${summary.status === 'Completed' ? 'finished' : 'incomplete'} / total ${summary.total} / success ${summary.success} / failed ${summary.failed} / instances updated ${summary.referencesSwapped} / ETA ${currentRunDurationText()}`);
  finishingReupload = false;
}
document.getElementById('reupload-complete-close')?.addEventListener('click', closeReuploadCompleteModal);
document.getElementById('reupload-complete-done')?.addEventListener('click', closeReuploadCompleteModal);
document.getElementById('reupload-complete-modal')?.addEventListener('click', event => { if (event.target?.id === 'reupload-complete-modal') closeReuploadCompleteModal(); });

function updateStudioConnectionState(data = {}) {
  const status = document.getElementById('studio-status-text');
  const card = document.getElementById('studio-connection-status');
  const project = document.getElementById('studio-project-meta');
  if (status) status.textContent = data.status || 'Studio Not Running';
  if (card) {
    card.dataset.state = String(data.state || 'StudioNotRunning');
    card.classList.toggle('connected', data.state === 'StudioConnected');
    card.classList.toggle('error', ['ConnectionFailed', 'ConnectionLost', 'StudioNotInstalled'].includes(data.state));
    card.classList.toggle('busy', ['Connecting', 'ScanningProject'].includes(data.state));
  }
  if (project) {
    const info = data.project;
    project.textContent = info?.name
      ? `${info.name} · Place ${info.placeId || '—'} · Universe ${info.universeId || '—'}`
      : (data.error || '');
  }
}

// ========== KAGE Custom Scrollbars ==========
let customScrollbarsInitialized = false;
function initCustomScrollbars() {
  if (customScrollbarsInitialized) return;
  customScrollbarsInitialized = true;
  const targets = [...document.querySelectorAll('.custom-scroll')];
  const entries = [];
  let scrollFrame = 0;
  const scheduleSync = () => {
    if (scrollFrame) return;
    scrollFrame = requestAnimationFrame(() => {
      scrollFrame = 0;
      // Read all geometry before any writes: never force layout per scrollbar.
      const measurements = entries.map(entry => [entry, entry.measure()]);
      for (const [entry, measurement] of measurements) entry.paint(measurement);
    });
  };

  for (const target of targets) {
    if (target.dataset.customScrollbarBound === '1') continue;
    target.dataset.customScrollbarBound = '1';
    const track = document.createElement('div');
    track.className = 'custom-scrollbar custom-scrollbar-live';
    track.dataset.scrollTarget = target.id || '';
    if (target.classList.contains('activity-list')) track.classList.add('history-scrollbar-live');
    const thumb = document.createElement('i');
    track.appendChild(thumb);
    document.body.appendChild(track);
    const entry = { target, track, thumb, dragging: false, grabOffset: 0 };
    entries.push(entry);

    entry.measure = () => {
      if (document.hidden || target.closest('[inert],.tab-content:not(.active),#settings-drawer:not(.active)')) return { visible: false };
      const rect = target.getBoundingClientRect();
      const overflow = target.scrollHeight - target.clientHeight;
      const visible = rect.width > 0 && rect.height > 0 && overflow > 2 && getComputedStyle(target).visibility !== 'hidden';
      if (!visible) return { visible: false };
      const trackHeight = Math.max(20, rect.height - 8);
      const thumbHeight = Math.max(28, trackHeight * (target.clientHeight / target.scrollHeight));
      const maxThumbTop = Math.max(0, trackHeight - thumbHeight);
      const ratio = overflow > 0 ? target.scrollTop / overflow : 0;
      return { visible, rect, trackHeight, thumbHeight, thumbTop: maxThumbTop * ratio };
    };
    entry.paint = ({ visible, rect, trackHeight, thumbHeight, thumbTop }) => {
      track.classList.toggle('visible', visible);
      if (!visible) return;
      track.style.left = `${Math.max(0, rect.right - 7)}px`;
      track.style.top = `${rect.top + 4}px`;
      track.style.height = `${trackHeight}px`;
      thumb.style.height = `${thumbHeight}px`;
      thumb.style.transform = `translateY(${thumbTop}px)`;
    };

    entry.sync = scheduleSync;
    target.addEventListener('scroll', scheduleSync, { passive: true });
    track.addEventListener('pointerdown', event => {
      if (event.target === thumb) return;
      const rect = track.getBoundingClientRect();
      const ratio = Math.max(0, Math.min(1, (event.clientY - rect.top) / Math.max(1, rect.height)));
      target.scrollTop = ratio * Math.max(0, target.scrollHeight - target.clientHeight);
    });
    thumb.addEventListener('pointerdown', event => {
      event.preventDefault();
      entry.dragging = true;
      entry.grabOffset = event.clientY - thumb.getBoundingClientRect().top;
      thumb.setPointerCapture?.(event.pointerId);
    });
    thumb.addEventListener('pointermove', event => {
      if (!entry.dragging) return;
      const rect = track.getBoundingClientRect();
      const thumbHeight = thumb.getBoundingClientRect().height;
      const maxThumbTop = Math.max(1, rect.height - thumbHeight);
      const thumbTop = Math.max(0, Math.min(maxThumbTop, event.clientY - rect.top - entry.grabOffset));
      target.scrollTop = (thumbTop / maxThumbTop) * Math.max(0, target.scrollHeight - target.clientHeight);
    });
    const stopDrag = event => { entry.dragging = false; try { thumb.releasePointerCapture?.(event.pointerId); } catch {} };
    thumb.addEventListener('pointerup', stopDrag);
    thumb.addEventListener('pointercancel', stopDrag);
    new ResizeObserver(scheduleSync).observe(target);
    new MutationObserver(scheduleSync).observe(target, { childList: true, characterData: true, subtree: true });
  }

  const paneObserver = new MutationObserver(scheduleSync);
  document.querySelectorAll('.tab-content,#settings-drawer,#account-manager-modal,#shade-sidecar,#kage-main-shell').forEach(pane =>
    paneObserver.observe(pane, { attributes: true, attributeFilter: ['class', 'inert'] }));
  window.addEventListener('resize', scheduleSync);
  document.addEventListener('transitionend', scheduleSync);
  document.addEventListener('visibilitychange', scheduleSync);
  scheduleSync();
}

// ========== Initialize ==========
document.addEventListener('DOMContentLoaded', () => {
  loadAccountInfo();
  applyUiSettings();
  renderRecentHistory();
  initCustomScrollbars();
  bridge.send('getRecentHistory');
  requestUpdateCheck(true);
  setInterval(() => requestUpdateCheck(), UPDATE_CHECK_INTERVAL_MS);
  refreshBridgeState(true);
  clearInterval(bridgeStateTimer);
  bridgeStateTimer = setInterval(() => refreshBridgeState(), 2000);

  // Show a warning if account info failed to load after 3 seconds
  setTimeout(() => {
    const robloxDisplay = document.getElementById('user-roblox');
    if (robloxDisplay && robloxDisplay.textContent.includes('—')) {
      showToastNotification('⚠️ Failed to load Roblox account. Your cookie may be expired. Try logging out and back in.');
    }
  }, 3000);
});

window.addEventListener('focus', () => requestUpdateCheck());
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) requestUpdateCheck();
});

// ========== Professional Workspace Shell ==========
const kageLogs = [];
function appendLogTextWithGlow(code, text) {
  const pieces = String(text || '').split(/(\b\d+(?:\.\d+)*\b)/g);
  for (const piece of pieces) {
    if (!piece) continue;
    if (/^\d+(?:\.\d+)*$/.test(piece)) {
      const number = document.createElement('span');
      number.className = 'log-number';
      number.textContent = piece;
      code.append(number);
    } else code.append(document.createTextNode(piece));
  }
}
function describeStudioReferenceChange(change) {
  const kind = String(change?.kind || '');
  const script = kind === 'ScriptSource';
  const metadata = kind.startsWith('Attribute:') || ['StringValue', 'IntValue', 'NumberValue'].includes(kind);
  const label = script ? 'SCRIPT UPDATED' : metadata ? 'METADATA UPDATED' : 'INSTANCE UPDATED';
  const count = Math.max(1, Number(change?.count) || 1);
  const details = script || metadata ? ` / ${count} occurrence${count === 1 ? '' : 's'}` : '';
  return `${label} / ${change?.oldId || '—'} → ${change?.newId || '—'} / ${change?.location || 'Studio'}${details}`;
}

function appendLog(level, message) {
  const normalized = String(level || 'INFO').toUpperCase();
  const text = String(message || '').trim();
  if (!text) return;
  const stamp = new Date().toLocaleTimeString([], { hour12: false });
  kageLogs.push({ level: normalized, text, stamp });
  if (kageLogs.length > 500) kageLogs.shift();
  const consoleEl = document.getElementById('logs-console');
  if (!consoleEl) return;
  const row = document.createElement('div');
  row.className = 'log-row';
  row.dataset.level = normalized;
  const time = document.createElement('time');
  time.textContent = stamp;
  const badge = document.createElement('span');
  badge.className = 'log-level';
  badge.textContent = normalized;
  const code = document.createElement('code');
  appendLogTextWithGlow(code, text);
  row.append(time, badge, code);
  consoleEl.appendChild(row);
  consoleEl.scrollTop = consoleEl.scrollHeight;
}

function renderStudioWorkspace(snapshot = {}) {
  const project = snapshot.project || null;
  const animations = Array.isArray(snapshot.animations) ? snapshot.animations : [];
  const tree = Array.isArray(snapshot.tree) ? snapshot.tree : [];
  const treeEl = document.getElementById('studio-workspace-tree');
  const listEl = document.getElementById('studio-animation-list');
  const countEl = document.getElementById('workspace-animation-count');
  if (countEl) countEl.textContent = String(animations.length);
  if (treeEl) {
    treeEl.innerHTML = tree.length ? tree.map(node => {
      const depth = Math.max(0, Math.min(5, Number(node.depth) || 0));
      return `<div class="tree-node" style="padding-left:${8 + depth * 13}px"><span class="tree-icon">${escapeHtml(String(node.className || 'I').slice(0,1))}</span><span>${escapeHtml(node.name || 'Instance')}</span><span class="tree-depth">${escapeHtml(node.className || '')}</span></div>`;
    }).join('') : '<div class="workspace-empty">No workspace objects returned yet.</div>';
  }
  if (listEl) {
    listEl.innerHTML = animations.length ? animations.map(item => `<div class="animation-row"><strong>${escapeHtml(item.name || `Animation ${item.id}`)}</strong><code>${escapeHtml(item.id)}</code></div>`).join('') : '<div class="workspace-empty">No animation references detected.</div>';
  }
  if (project) {
    const label = document.getElementById('reupload-project-label');
    if (label) label.textContent = project.name || 'Open Studio Project';
    appendLog('COUNT', `Workspace synced: ${tree.length} objects, ${animations.length} animation references.`);
  }
}

let lastStudioConnectionAudioState = '';
let isStudioConnectedForUi = false;
let studioConnectUiState = 'idle';
function paintStudioConnectControl(state = 'idle') {
  studioConnectUiState = state;
  const button = document.getElementById('connect-studio-button');
  const orb = document.getElementById('studio-connect-orb');
  const label = document.getElementById('studio-connect-state');
  const caption = document.getElementById('studio-connect-caption');
  const reconnect = document.getElementById('reconnect-studio-button');
  const connecting = state === 'connecting';
  const connected = state === 'connected';
  if (button) {
    button.disabled = connecting || connected;
    button.classList.toggle('studio-connect-locked', connecting || connected);
    button.classList.toggle('connected', connected);
    button.classList.toggle('connecting', connecting);
    button.setAttribute('aria-busy', connecting ? 'true' : 'false');
    button.setAttribute('aria-label', connected ? 'Connected to Roblox Studio' : connecting ? 'Connecting to Roblox Studio' : 'Connect to Roblox Studio');
  }
  orb?.classList.toggle('connected', connected);
  orb?.classList.toggle('connecting', connecting);
  if (label) label.textContent = connected ? 'Connected' : connecting ? 'Connecting' : 'Connect';
  if (caption) caption.textContent = connected ? 'Connected to Studio' : connecting ? 'Connecting to Studio…' : 'Connect to Studio';
  reconnect?.classList.toggle('hidden', !connected);
  if (reconnect) reconnect.disabled = connecting;
}

function connectStudioFromUi() {
  if (studioConnectUiState === 'connecting') return;
  paintStudioConnectControl('connecting');
  appendLog('INFO', 'Checking Roblox Studio and establishing the KAGE workspace session.');
  try {
    bridge.send('connectStudio');
  } catch (error) {
    paintStudioConnectControl('idle');
    appendLog('ERROR', `Could not request the Studio connection: ${error.message || error}`);
    showToastNotification('Could not connect to Studio. Please try again.', true, true);
  }
}

function requireStudioConnection(message = 'Connect to Studio first.') {
  if (isStudioConnectedForUi) return true;
  showToastNotification(message, true, true);
  appendLog('WARN', message);
  return false;
}
function refreshStudioWorkspaceFromUi() {
  if (!requireStudioConnection()) return;
  appendLog('INFO', 'Refreshing Studio workspace snapshot.');
  bridge.send('refreshStudioWorkspace', { assetType: getSelectedAssetType() });
}

(function initializeProfessionalShell() {
  const drag = document.getElementById('window-drag-region');
  drag?.addEventListener('mousedown', event => {
    if (event.button === 0 && !event.target.closest('button')) bridge.send('dragWindow');
  });
  document.querySelectorAll('[data-window-action]').forEach(button => {
    button.addEventListener('click', () => bridge.send(button.dataset.windowAction));
  });
  document.addEventListener('click', event => {
    const button = event.target.closest('button');
    if (!button) return;
    button.classList.add('clicked');
    setTimeout(() => button.classList.remove('clicked'), 470);
  });
  document.querySelectorAll('.tab-btn').forEach(button => {
    button.addEventListener('click', () => {
      const label = document.getElementById('active-view-label');
      if (label) label.textContent = button.dataset.tab === 'reupload' ? 'Reupload Workspace' : (button.dataset.tab || 'Home').replace(/^./, c => c.toUpperCase());
    });
  });
  document.getElementById('connect-studio-button')?.addEventListener('click', connectStudioFromUi);
  document.getElementById('reconnect-studio-button')?.addEventListener('click', connectStudioFromUi);
  document.getElementById('reupload-ai-assist')?.addEventListener('click', () => {
    document.querySelector('.tab-btn[data-tab="ai"]')?.click();
    document.getElementById('input-shade')?.focus();
  });
  document.getElementById('workspace-refresh')?.addEventListener('click', refreshStudioWorkspaceFromUi);
  document.getElementById('clear-log-view')?.addEventListener('click', () => {
    const consoleEl = document.getElementById('logs-console');
    if (consoleEl) consoleEl.innerHTML = '';
  });
  appendLog('INFO', 'KAGE professional workspace initialized.');
})();

let lastWorkspaceProjectKey = "";
let lastStudioLogIdentity = "";
const originalUpdateStudioConnectionState = updateStudioConnectionState;
updateStudioConnectionState = function(data = {}) {
  originalUpdateStudioConnectionState(data);
  const connected = data.state === 'StudioConnected';
  const busy = ['Connecting', 'ScanningProject'].includes(data.state);
  const statusText = data.status || 'Studio Offline';
  const titleState = document.getElementById('title-studio-state');
  const reuploadStatus = document.getElementById('reupload-studio-status');
  if (titleState) titleState.textContent = statusText;
  if (reuploadStatus) reuploadStatus.textContent = statusText;
  paintStudioConnectControl(connected ? 'connected' : busy ? 'connecting' : 'idle');
  const info = data.project;
  const name = document.getElementById('studio-project-name');
  const place = document.getElementById('studio-place-id');
  const universe = document.getElementById('studio-universe-id');
  if (name) name.textContent = info?.name || '—';
  if (place) place.textContent = info?.placeId || '—';
  if (universe) universe.textContent = info?.universeId || '—';
  if (data.error) appendLog('ERROR', data.error);
  else if (connected) {
    const studioIdentity = `${info?.name || 'Unknown project'}:${info?.placeId || ''}:${info?.universeId || ''}`;
    if (studioIdentity !== lastStudioLogIdentity) {
      appendLog('SUCCESS', `STUDIO CONNECTED / ${info?.name || 'Unknown project'} / Place ${info?.placeId || '—'} / Universe ${info?.universeId || '—'}`);
      lastStudioLogIdentity = studioIdentity;
    }
    const projectKey = `${info?.placeId || ''}:${info?.universeId || ''}`;
    if (projectKey && projectKey !== lastWorkspaceProjectKey) {
      lastWorkspaceProjectKey = projectKey;
      window.setTimeout(refreshStudioWorkspaceFromUi, 180);
    }
  } else if (busy) appendLog('INFO', statusText);
  else if (['ConnectionLost','StudioNotRunning','ConnectionFailed'].includes(data.state)) {
    if (lastStudioLogIdentity) appendLog('WARN', `STUDIO DISCONNECTED / ${data.status || data.state}`);
    lastWorkspaceProjectKey = ''; lastStudioLogIdentity = '';
  }
};

// ===== KAGE professional navigation / filtered explorer / synced Shade UI =====
let currentWorkspaceSnapshot = { project: null, animations: [] };
const shadeConversation = [];
let shadeStreamingIndex = -1;
const SHADE_RENDER_LIMIT = 16;
const SHADE_HISTORY_LIMIT = 48;

function updateMetricText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = String(value);
}

function buildFilteredExplorerTree(animations = []) {
  const root = {};
  for (const item of animations) {
    const raw = String(item.location || '').replace(/^game[.\/]?/i, '').replace(/\./g, '/');
    const parts = raw.split('/').map(x => x.trim()).filter(Boolean);
    if (!parts.length) parts.push('Detected References');
    let cursor = root;
    for (const part of parts) cursor = cursor[part] ||= {};
  }
  return root;
}

function renderExplorerBranch(branch, depth = 0) {
  return Object.entries(branch).sort(([a],[b]) => a.localeCompare(b)).map(([name, child]) => {
    const hasChildren = Object.keys(child).length > 0;
    const icon = `<img class="tree-folder-icon" src="../Assets/${hasChildren ? 'nav-explorer.png' : 'kage-asset-animation.png'}" alt="">`;
    const label = `<span class="tree-label">${escapeHtml(name)}</span>`;
    return hasChildren
      ? `<details class="explorer-folder" open><summary class="tree-node folder-hit">${icon}${label}</summary><div class="explorer-children">${renderExplorerBranch(child, depth + 1)}</div></details>`
      : `<div class="tree-node">${icon}${label}</div>`;
  }).join('');
}

function filteredAnimations() {
  const term = String(document.getElementById('animation-search-input')?.value || '').trim().toLowerCase();
  const explorerTerm = String(document.getElementById('explorer-search-input')?.value || '').trim().toLowerCase();
  const termToUse = term || explorerTerm;
  if (!termToUse) return currentWorkspaceSnapshot.animations || [];
  return (currentWorkspaceSnapshot.animations || []).filter(item =>
    `${item.name || ''} ${item.location || ''} ${item.id || ''}`.toLowerCase().includes(termToUse));
}

renderStudioWorkspace = function(snapshot = {}) {
  const project = snapshot.project || null;
  const animations = Array.isArray(snapshot.animations) ? snapshot.animations : [];
  currentWorkspaceSnapshot = { project, animations };

  const visible = filteredAnimations();
  const treeEl = document.getElementById('studio-workspace-tree');
  const listEl = document.getElementById('studio-animation-list');
  const tree = buildFilteredExplorerTree(visible);
  if (treeEl) treeEl.innerHTML = Object.keys(tree).length
    ? renderExplorerBranch(tree)
    : '<div class="workspace-empty">No detected asset locations match this filter.</div>';
  updateMetricText('explorer-result-count', visible.length);

  if (listEl) {
    listEl.innerHTML = visible.length ? visible.map((item, index) => `
      <div class="animation-row">
        <span>${index + 1}</span>
        <strong data-tooltip="${escapeHtml(item.name || `Animation ${item.id}`)}">${escapeHtml(item.name || `Animation ${item.id}`)}</strong>
        <span class="animation-location" data-tooltip="${escapeHtml(item.location || 'Detected reference')}">${escapeHtml(item.location || 'Detected reference')}</span>
        <code>rbxassetid://${escapeHtml(item.id)}</code>
        <span class="animation-status">Ready</span>
      </div>`).join('') : '<div class="workspace-empty">No animation references detected.</div>';
  }

  updateMetricText('workspace-animation-count', animations.length);
  const projectName = project?.name || '—';
  for (const id of ['reupload-project-label','reupload-info-project']) updateMetricText(id, projectName);
  updateMetricText('studio-side-place-id', project?.placeId || '—');
  updateMetricText('studio-side-universe-id', project?.universeId || '—');
  if (project) appendLog('COUNT', `Project scan completed: ${animations.length} relevant animation references.`);
};

function makeShadeName() {
  const name = document.createElement('div');
  name.className = 'assistant-name';
  name.setAttribute('aria-label', 'Shade');
  for (const [index, letter] of Array.from('Shade').entries()) {
    const span = document.createElement('span');
    span.className = 'assistant-name-letter';
    span.style.setProperty('--letter-index', index);
    span.setAttribute('aria-hidden', 'true');
    span.textContent = letter;
    name.append(span);
  }
  return name;
}

function shadeTokenClass(raw) {
  if (/^KAGE$/i.test(raw)) return 'kage-wordmark';
  if (/^`[\s\S]*`$/.test(raw)) return 'message-command';
  if (/^[A-Za-z]:\\/.test(raw)) return 'message-path';
  if (/^\*\*[\s\S]*\*\*$/.test(raw)) return 'message-strong';
  return '';
}

function shadeTokenVisibleText(raw) {
  if (/^`[\s\S]*`$/.test(raw)) return raw.slice(1, -1);
  if (/^\*\*[\s\S]*\*\*$/.test(raw)) return raw.slice(2, -2);
  return raw;
}

function appendShadeCharacters(parent, text, state, animateFrom, extraClass = '') {
  if (!text) return;
  let stable = '';
  const flushStable = () => {
    if (!stable) return;
    parent.append(document.createTextNode(stable));
    stable = '';
  };
  for (const ch of text) {
    const shouldAnimate = state.index >= animateFrom && !/\s/.test(ch);
    if (shouldAnimate) {
      flushStable();
      const span = document.createElement('span');
      span.className = `shade-char${extraClass ? ` ${extraClass}` : ''}`;
      span.style.setProperty('--char-delay', `${Math.min(state.animated, 24) * 18}ms`);
      span.textContent = ch;
      parent.append(span);
      state.animated++;
    } else stable += ch;
    state.index++;
  }
  flushStable();
}

function appendShadeTokenizedText(parent, text, state, animateFrom) {
  const re = /(\*\*[^*\n]+\*\*|`[^`\n]+`|\bKAGE\b|[A-Za-z]:\\[^\s]+)/gi;
  let cursor = 0;
  let match;
  while ((match = re.exec(text))) {
    appendShadeCharacters(parent, text.slice(cursor, match.index), state, animateFrom);
    const raw = match[0];
    const cls = shadeTokenClass(raw);
    const visible = shadeTokenVisibleText(raw);
    const span = document.createElement('span');
    if (cls) span.className = cls;
    appendShadeCharacters(span, visible, state, animateFrom, cls === 'kage-wordmark' ? 'kage-letter' : '');
    parent.append(span);
    cursor = match.index + raw.length;
  }
  appendShadeCharacters(parent, text.slice(cursor), state, animateFrom);
}

function shadeBlock(className) {
  const el = document.createElement('div');
  el.className = className;
  return el;
}

const allowedShadeTabs = new Map([
  ['home', 'home'], ['reupload', 'reupload'], ['preview', 'preview'], ['asset viewer', 'preview'], ['kage asset viewer', 'preview'], ['ai assistant', 'ai'], ['ai', 'ai'], ['settings', 'settings'], ['watch', 'watch'], ['logs', 'watch']
]);
function normalizeShadeTabLabel(label) {
  const cleaned = String(label || '')
    .replace(/^\[+|\]+$/g, '')
    .replace(/^tab\s*:/i, '')
    .trim()
    .replace(/\s+/g, ' ');
  const target = allowedShadeTabs.get(cleaned.toLowerCase());
  return target ? { label: cleaned, target } : null;
}

function createShadeTabLink(label) {
  const visible = String(label || '').trim();
  const canonical = typeof normalizeShadeTabLabel === 'function' ? normalizeShadeTabLabel(visible) : null;
  const target = canonical?.target || allowedShadeTabs.get(visible.toLowerCase());
  if (!target) return document.createTextNode(visible);
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'shade-tab-link kage-interactive';
  button.dataset.kageTab = target;
  button.setAttribute('data-kage-tab', target);
  button.textContent = canonical?.label || visible;
  button.addEventListener('click', event => {
    event.preventDefault();
    event.stopPropagation();
    if (target === 'settings') document.getElementById('btn-settings')?.click();
    else activateWorkspaceTab(target);
  });
  return button;
}

// Ported from the Shade v1.19 renderer so KAGE uses Shade's real text formatting and letter motion.
function renderShadeAssistantMessage(row, rawText, animateFrom = Number.MAX_SAFE_INTEGER) {
  const content = row.querySelector('.content');
  if (!content) return 0;
  content.replaceChildren();
  const state = { index: 0, animated: 0 };
  const lines = String(rawText || '').replace(/\r\n/g, '\n').split('\n');
  let inFence = false;
  let codeBlock = null;
  for (const line of lines) {
    if (/^\s*```/.test(line)) {
      inFence = !inFence;
      if (inFence) {
        codeBlock = document.createElement('pre');
        codeBlock.className = 'message-code';
        content.append(codeBlock);
      } else codeBlock = null;
      continue;
    }
    if (inFence) {
      if (codeBlock?.childNodes.length) appendShadeCharacters(codeBlock, '\n', state, animateFrom);
      if (codeBlock) appendShadeCharacters(codeBlock, line, state, animateFrom);
      continue;
    }
    if (!line.trim()) {
      content.append(shadeBlock('message-spacer'));
      state.index++;
      continue;
    }
    let match;
    let block;
    if (allowedShadeTabs.has(line.trim().toLowerCase())) {
      block = shadeBlock('message-line');
      block.append(createShadeTabLink(line.trim()));
    } else if ((match = line.match(/^\s*#{1,3}\s+(.+)$/))) {
      block = shadeBlock('message-heading');
      appendShadeTokenizedText(block, match[1], state, animateFrom);
    } else if ((match = line.match(/^\s*[-*]\s+(.+)$/))) {
      block = shadeBlock('message-bullet');
      const bullet = document.createElement('span');
      bullet.className = 'message-bullet-mark';
      bullet.textContent = '›';
      const body = document.createElement('span');
      appendShadeTokenizedText(body, match[1], state, animateFrom);
      block.append(bullet, body);
    } else if ((match = line.match(/^\s*>\s?(.+)$/))) {
      block = shadeBlock('message-quote');
      appendShadeTokenizedText(block, match[1], state, animateFrom);
    } else if ((match = line.match(/^\s*(Warning|Error|Careful)\s*:\s*(.*)$/i))) {
      block = shadeBlock('message-callout message-warning');
      const label = document.createElement('span');
      label.className = 'message-label';
      label.textContent = `${match[1].toUpperCase()} `;
      block.append(label);
      appendShadeTokenizedText(block, match[2], state, animateFrom);
    } else if ((match = line.match(/^\s*(Success|Done|Fixed|Ready)\s*:\s*(.*)$/i))) {
      block = shadeBlock('message-callout message-success');
      const label = document.createElement('span');
      label.className = 'message-label';
      label.textContent = `${match[1].toUpperCase()} `;
      block.append(label);
      appendShadeTokenizedText(block, match[2], state, animateFrom);
    } else if ((match = line.match(/^\s*(Tip|Note)\s*:\s*(.*)$/i))) {
      block = shadeBlock('message-callout message-note');
      const label = document.createElement('span');
      label.className = 'message-label';
      label.textContent = `${match[1].toUpperCase()} `;
      block.append(label);
      appendShadeTokenizedText(block, match[2], state, animateFrom);
    } else {
      block = shadeBlock('message-line');
      appendShadeTokenizedText(block, line, state, animateFrom);
    }
    content.append(block);
    state.index++;
  }
  upgradeShadeTabTokens(content);
  return state.index;
}

function upgradeShadeTabTokens(root) {
  if (!root) return;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const nodes = [];
  while (walker.nextNode()) {
    const node = walker.currentNode;
    const parent = node.parentElement;
    if (!parent || parent.closest('button,pre,code,.shade-tab-link')) continue;
    if (/\[{0,2}\s*tab\s*:\s*(Home|Reupload|Preview|Asset Viewer|KAGE Asset Viewer|AI Assistant|AI|Settings|Watch|Logs)\s*\]{0,2}/i.test(node.nodeValue || '')) nodes.push(node);
  }
  for (const node of nodes) {
    const text = node.nodeValue || '';
    const re = /\[{0,2}\s*tab\s*:\s*(Home|Reupload|Preview|Asset Viewer|KAGE Asset Viewer|AI Assistant|AI|Settings|Watch|Logs)\s*\]{0,2}/gi;
    const frag = document.createDocumentFragment(); let last = 0, match;
    while ((match = re.exec(text))) {
      if (match.index > last) frag.append(document.createTextNode(text.slice(last, match.index)));
      const link = createShadeTabLink(match[1]);
      if (link?.nodeType) frag.append(link);
      last = match.index + match[0].length;
    }
    if (last < text.length) frag.append(document.createTextNode(text.slice(last)));
    node.replaceWith(frag);
  }
}

function createShadeEntry(item) {
  const messageId = shadeMessageId(item);
  const alreadyAnimated = item.animationPlayed === true || shadeMessageAnimationState.has(messageId);
  const animateFrom = alreadyAnimated ? Number.MAX_SAFE_INTEGER : Number.isFinite(item.animateFrom) ? item.animateFrom : Number.MAX_SAFE_INTEGER;
  const row = document.createElement('div');
  row.className = `shade-entry ${item.role === 'user' ? 'user' : 'assistant'}`;
  row.dataset.shadeMessageId = messageId;
  row.classList.toggle('shade-message-static', alreadyAnimated);
  shadeMessageAnimationState.set(messageId, true);
  item.animationPlayed = true;
  if (item.thinking) row.classList.add('thinking');
  if (item.complete) row.classList.add('complete');

  if (item.role === 'user') {
    const who = document.createElement('div');
    who.className = 'who';
    who.textContent = 'you>';
    const content = document.createElement('pre');
    content.className = 'content';
    appendShadeCharacters(content, String(item.text || ''), { index: 0, animated: 0 }, animateFrom);
    row.append(who, content);
    return row;
  }

  const avatarWrap = document.createElement('div');
  avatarWrap.className = 'assistant-avatar-wrap';
  const avatar = document.createElement('img');
  avatar.className = 'assistant-avatar';
  avatar.src = '../Assets/Shade_Icon.png';
  avatar.alt = 'Shade';
  avatarWrap.append(avatar);

  const body = document.createElement('div');
  body.className = 'assistant-body';
  const content = document.createElement('div');
  content.className = 'content';
  body.append(makeShadeName(), content);
  row.append(avatarWrap, body);
  renderShadeAssistantMessage(row, item.text || '', animateFrom);
  return row;
}

function shadeThreadIsVisible(id) {
  if (id === 'shade-thread-sidecar') return isShadePopout || document.getElementById('shade-sidecar')?.classList.contains('open');
  return document.getElementById('tab-ai')?.classList.contains('active');
}
// A Shade message retains its own DOM identity across subsequent replies.
// Previously, appending one message rebuilt *every* row and restarted the old
// letter / name animations (also replaying dialogue blips).
const shadeMessageIds = new WeakMap();
const shadeMessageAnimationState = new Map();
let shadeNextMessageId = 0;
function shadeMessageId(item) {
  if (!shadeMessageIds.has(item)) {
    item.id = String(item.id || `shade-${Date.now()}-${++shadeNextMessageId}-${Math.random().toString(36).slice(2, 8)}`);
    shadeMessageIds.set(item, item.id);
  }
  return shadeMessageIds.get(item);
}
function restoreShadeMessage(item) {
  const restored = { id: item.id, role: item.role, text: String(item.text || ''), animationPlayed: true };
  restored.animateFrom = restored.text.length;
  shadeMessageAnimationState.set(shadeMessageId(restored), true);
  return restored;
}
function shadeConversationRenderKey(items) {
  return items.map(item => [
    shadeMessageId(item), item.role || '', String(item.text || ''),
    item.thinking ? '1' : '0'
  ].join('\u001f')).join('\u001e');
}

function settleShadeConversationAnimation(items = shadeConversation) {
  // Anything that already exists in history is considered read. If Shade
  // finished while its tab was hidden, returning to the tab should show the
  // accumulated message immediately rather than replaying its typing effect.
  for (const item of items) {
    if (typeof shadeStreamingIndex === 'number' && shadeStreamingIndex >= 0 && shadeConversation[shadeStreamingIndex] === item) continue;
    item.animateFrom = String(item.text || '').length;
    item.animationPlayed = true;
    shadeMessageAnimationState.set(shadeMessageId(item), true);
  }
}

function renderShadeConversation({ force = false, settle = false, rebuild = false } = {}) {
  const visibleItems = shadeConversation.slice(-SHADE_RENDER_LIMIT);
  if (settle) settleShadeConversationAnimation(visibleItems);
  const renderKey = shadeConversationRenderKey(visibleItems);
  for (const id of ['shade-thread-main', 'shade-thread-sidecar']) {
    const thread = document.getElementById(id);
    if (!thread || (!force && !shadeThreadIsVisible(id))) continue;

    // force means "render even if this surface was previously hidden". It no
    // longer means "destroy and recreate an unchanged conversation".
    if (!rebuild && !settle && thread.dataset.shadeConversationKey === renderKey && thread.childNodes.length) {
      thread.scrollTop = thread.scrollHeight;
      continue;
    }

    // Reconcile rows in place. In particular, do not detach/reinsert an older
    // reply when a new prompt arrives: that restarts WebView CSS animations.
    const wanted = new Set();
    for (let index = 0; index < visibleItems.length; index++) {
      const item = visibleItems[index];
      const messageId = shadeMessageId(item);
      const streaming = typeof shadeStreamingIndex === 'number' && shadeStreamingIndex >= 0 && shadeConversation[shadeStreamingIndex] === item;
      wanted.add(messageId);
      let row = Array.from(thread.children).find(node => node.dataset?.shadeMessageId === messageId);
      if (!row) {
        row = createShadeEntry(streaming ? { ...item, text: shadeStreamDisplayedText, animateFrom: Number.MAX_SAFE_INTEGER, animationPlayed: true } : item);
        row.dataset.shadeMessageId = messageId;
        row.shadeDisplayedText = streaming ? shadeStreamDisplayedText : String(item.text || '');
      } else if (!streaming && row.shadeDisplayedText !== String(item.text || '')) {
        // A restored/updated message can be re-rendered, but never animated.
        if (item.role === 'assistant') renderShadeAssistantMessage(row, item.text || '', Number.MAX_SAFE_INTEGER);
        else {
          const content = row.querySelector('.content');
          if (content) content.textContent = String(item.text || '');
        }
        row.shadeDisplayedText = String(item.text || '');
      }
      if (settle && !streaming) row.classList.toggle('shade-message-static', true);
      if (streaming) shadeActiveMessageNode[id === 'shade-thread-main' ? 'main' : 'sidecar'] = row;
      row.classList.toggle('thinking', !!item.thinking);
      const atPosition = thread.children[index] || null;
      if (atPosition !== row) thread.insertBefore(row, atPosition);
    }
    for (const row of Array.from(thread.children)) {
      if (!wanted.has(row.dataset?.shadeMessageId)) row.remove();
    }
    thread.dataset.shadeConversationKey = renderKey;
    thread.scrollTop = thread.scrollHeight;
  }
  for (const item of visibleItems) {
    item.animateFrom = String(item.text || '').length;
    item.complete = false;
  }
}

function addShadeMessage(role, text) {
  if (!text) return;
  shadeConversation.push({ role, text: String(text), animateFrom: 0 });
  if (shadeConversation.length > SHADE_HISTORY_LIMIT) shadeConversation.splice(0, shadeConversation.length - SHADE_HISTORY_LIMIT);
  renderShadeConversation();
}

function setShadeStatus(label, state = 'online') {
  const thinking = state === 'thinking' || state === 'streaming';
  document.querySelectorAll('.shade-avatar').forEach(avatar => avatar.classList.toggle('thinking', thinking));
  for (const id of ['shade-status-main', 'shade-status-sidecar']) {
    const el = document.getElementById(id);
    if (!el) continue;
    const dot = el.querySelector('i')?.outerHTML || '<i></i>';
    el.innerHTML = `${dot}${escapeHtml(label || 'Online')}`;
    el.dataset.state = state;
  }
}

function typeShadeAssistantMessage(text) {
  const value = String(text || '');
  if (!value) return;
  startShadeStream();
  let index = 0;
  const timer = setInterval(() => {
    const chunk = value.slice(index, Math.min(value.length, index + 2));
    index += chunk.length;
    appendShadeDelta(chunk);
    if (index >= value.length) {
      clearInterval(timer);
      finishShadeStream();
    }
  }, 14);
}

function closeShadeSidecar() {
  const sidecar = document.getElementById('shade-sidecar');
  if (!sidecar) return;
  sidecar.classList.remove('open');
  sidecar.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('shade-sidecar-open');
  bridge.send('setShadeSidecar', { open: false });
}

toggleShadeDrawer = function(force) {
  const sidecar = document.getElementById('shade-sidecar');
  if (!sidecar) return;
  const open = typeof force === 'boolean' ? force : !sidecar.classList.contains('open');
  if (!open) { closeShadeSidecar(); return; }
  sidecar.classList.add('open');
  sidecar.setAttribute('aria-hidden', 'false');
  document.body.classList.add('shade-sidecar-open');
  bridge.send('setShadeSidecar', { open: true });
  renderShadeConversation();
};

function sendShadeFrom(inputId) {
  const input = document.getElementById(inputId);
  const prompt = input?.value?.trim();
  if (!prompt) return;
  addShadeMessage('user', prompt);
  for (const id of ['shade-input-main','shade-input-sidecar']) {
    const el = document.getElementById(id);
    if (el) el.value = '';
  }
  setShadeStatus('Thinking…', 'thinking');
  bridge.send('shadePrompt', {
    prompt,
    chatId: currentShadeChatId,
    messages: shadeConversation.slice(-6).map(item => ({ role: item.role, content: String(item.text || '').slice(0, 1200) }))
  });
}

const originalRenderRecentHistory = renderRecentHistory;
renderRecentHistory = function() {
  originalRenderRecentHistory();
  document.querySelectorAll('.activity-count span').forEach(el => { el.textContent = 'assets'; });
};

function bindShadeInput(inputId, buttonId) {
  const input = document.getElementById(inputId);
  document.getElementById(buttonId)?.addEventListener('click', () => sendShadeFrom(inputId));
  input?.addEventListener('keydown', event => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      sendShadeFrom(inputId);
    }
  });
}

function activateWorkspaceTab(tab) {
  document.querySelector(`.tab-btn[data-tab="${tab}"]`)?.click();
}

for (const id of ['animation-search-input','explorer-search-input']) {
  document.getElementById(id)?.addEventListener('input', () => renderStudioWorkspace(currentWorkspaceSnapshot));
}
for (const id of ['btn-shade','btn-shade-secondary']) document.getElementById(id)?.addEventListener('click', () => toggleShadeDrawer(true));
document.getElementById('btn-shade-popout')?.addEventListener('click', () => toggleShadeDrawer(true));
document.getElementById('shade-sidecar-close')?.addEventListener('click', closeShadeSidecar);
document.getElementById('shade-sidecar-minimize')?.addEventListener('click', () => bridge.send('minimizeShadePopout'));
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeShadeSidecar(); });
document.getElementById('home-go-reupload')?.addEventListener('click', () => activateWorkspaceTab('reupload'));
document.getElementById('home-open-shade')?.addEventListener('click', () => activateWorkspaceTab('ai'));
bindShadeInput('shade-input-main','shade-send-main');
bindShadeInput('shade-input-sidecar','shade-send-sidecar');
renderShadeConversation();

// Extend the Studio renderer only with project/reupload details that still exist.
const kageUpdateStudioConnectionState = updateStudioConnectionState;
updateStudioConnectionState = function(data = {}) {
  kageUpdateStudioConnectionState(data);
  const connected = data.state === 'StudioConnected';
  const info = data.project || {};
  updateMetricText('reupload-info-sync', connected ? 'Active' : (data.state === 'ScanningProject' ? 'Scanning' : 'Offline'));
  updateMetricText('studio-side-place-id', info.placeId || '—');
  updateMetricText('studio-side-universe-id', info.universeId || '—');
  const title = document.getElementById('reupload-card-title');
  const copy = document.getElementById('reupload-card-copy');
  if (title) title.textContent = connected ? 'Connected to Roblox Studio' : (data.state === 'Connecting' ? 'Connecting to Roblox Studio…' : 'Connect to Roblox Studio');
  if (copy) copy.textContent = data.error || (connected ? 'KAGE is reading the open project through Studio MCP.' : 'Enable Studio MCP once, then KAGE handles the connection automatically.');
};

// Icon-only tabs stay uncluttered; this compact strip provides context.
document.querySelectorAll('.tab-btn').forEach(button => button.addEventListener('click', () => {
  const subtitles = {
    home: 'KAGE workspace', watch: 'Logs', reupload: 'Main reupload workspace',
    ai: 'Shade conversation'
  };
  const label = document.getElementById('active-view-label');
  const sub = document.getElementById('view-subtitle');
  const tab = button.dataset.tab || 'home';
  if (label) label.textContent = tab === 'ai' ? 'AI Assistant' : tab[0].toUpperCase() + tab.slice(1);
  if (sub) sub.textContent = subtitles[tab] || '';
}));

// ============================================================================
// Approved 2026-09-22 Studio/UX/Shade execution overrides
// ============================================================================
let latestAccountInfo = null;
let shadeActiveMessageNode = { main: null, sidecar: null };
let shadeLoadingNodes = { main: null, sidecar: null };
let shadeRequestInFlight = false;
let shadeMessagePopPlayed = false;
let groupSelector = { groups: [], selected: null };
const ShadeAudioContext = window.AudioContext || window.webkitAudioContext;
let shadeAudioContext = null;
let shadeDialogueQueueAt = 0;
let shadeSfxEnabled = localStorage.getItem('shade:sfx') !== 'off';

function ensureShadeAudio() {
  if (!shadeSfxEnabled || !ShadeAudioContext) return null;
  if (!shadeAudioContext) shadeAudioContext = new ShadeAudioContext();
  if (shadeAudioContext.state === 'suspended') shadeAudioContext.resume().catch(() => {});
  return shadeAudioContext.state === 'closed' ? null : shadeAudioContext;
}
function shadeTone(ctx, type, startHz, endHz, startAt, duration, volume) {
  const osc = ctx.createOscillator(), gain = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(startHz, startAt);
  osc.frequency.exponentialRampToValueAtTime(Math.max(40, endHz), startAt + duration);
  gain.gain.setValueAtTime(.0001, startAt);
  gain.gain.exponentialRampToValueAtTime(volume, startAt + .008);
  gain.gain.exponentialRampToValueAtTime(.0001, startAt + duration);
  osc.connect(gain); gain.connect(ctx.destination); osc.start(startAt); osc.stop(startAt + duration + .012);
}
function playShadeMessagePop() {
  const ctx = ensureShadeAudio(); if (!ctx) return;
  const now = ctx.currentTime + .008;
  shadeTone(ctx, 'sine', 310, 520, now, .11, .075);
  shadeTone(ctx, 'triangle', 690, 930, now + .014, .085, .04);
}
function playShadeDialogueBlip(ch, delayMs = 0) {
  if (!shadeSfxEnabled || /\s/.test(ch)) return;
  const nowMs = performance.now();
  if (/[.!?]/.test(ch)) { shadeDialogueQueueAt = Math.max(shadeDialogueQueueAt, nowMs) + 92; return; }
  if (/[,;:]/.test(ch)) { shadeDialogueQueueAt = Math.max(shadeDialogueQueueAt, nowMs) + 52; return; }
  const target = Math.max(nowMs + delayMs, shadeDialogueQueueAt);
  if (target - nowMs > 390) return;
  shadeDialogueQueueAt = target + 24;
  const fire = () => {
    const ctx = ensureShadeAudio(); if (!ctx) return;
    const code = ch.codePointAt(0) || 0;
    const base = 182 + (code % 5) * 17 + Math.floor(Math.random() * 9);
    const now = ctx.currentTime + .004;
    shadeTone(ctx, 'square', base, base * .94, now, .036, .014);
    shadeTone(ctx, 'triangle', base * 2.01, base * 1.86, now + .002, .029, .006);
  };
  const wait = Math.max(0, target - performance.now());
  if (wait > 2) setTimeout(fire, wait); else fire();
}
window.addEventListener('pointerdown', ensureShadeAudio, { passive: true });
window.addEventListener('keydown', ensureShadeAudio, { passive: true });

// Restore Shade v1.19 per-character animation + synthesized dialogue blips.
appendShadeCharacters = function(parent, text, state, animateFrom, extraClass = '') {
  if (!text) return;
  let stable = '';
  const flushStable = () => { if (stable) { parent.append(document.createTextNode(stable)); stable = ''; } };
  for (const ch of text) {
    const shouldAnimate = state.index >= animateFrom && !/\s/.test(ch);
    if (shouldAnimate) {
      flushStable();
      const span = document.createElement('span');
      span.className = `shade-char${extraClass ? ` ${extraClass}` : ''}`;
      span.style.setProperty('--char-delay', `${Math.min(state.animated, 24) * 18}ms`);
      span.textContent = ch;
      parent.append(span);
      playShadeDialogueBlip(ch, Math.min(state.animated, 24) * 18);
      state.animated++;
    } else stable += ch;
    state.index++;
  }
  flushStable();
};

appendShadeTokenizedText = function(parent, text, state, animateFrom) {
  // Accept [[tab:Home]], [tab:Home], and bare tab:Home so model punctuation never breaks the control.
  const re = /((?:\[{1,2}\s*)?tab\s*:\s*(Home|Reupload|Preview|Asset Viewer|KAGE Asset Viewer|AI Assistant|AI|Settings|Watch|Logs)(?:\s*\]{1,2})?|\*\*[^*\n]+\*\*|`[^`\n]+`|\bKAGE\b|[A-Za-z]:\\[^\s]+)/gi;
  let cursor = 0, match;
  while ((match = re.exec(text))) {
    appendShadeCharacters(parent, text.slice(cursor, match.index), state, animateFrom);
    const raw = match[0];
    const tabToken = normalizeShadeTabLabel(raw);
    if (tabToken) {
      const button = createShadeTabLink(tabToken.label);
      if (button?.dataset) {
        button.dataset.kageTab = tabToken.target;
        button.setAttribute('data-kage-tab', tabToken.target);
      }
      parent.append(button);
    } else {
      const span = document.createElement('span');
      const cls = shadeTokenClass(raw);
      if (cls) span.className = cls;
      appendShadeCharacters(span, shadeTokenVisibleText(raw), state, animateFrom, cls === 'kage-wordmark' ? 'kage-letter' : '');
      parent.append(span);
    }
    cursor = match.index + raw.length;
  }
  appendShadeCharacters(parent, text.slice(cursor), state, animateFrom);
};
document.addEventListener('click', event => {
  const link = event.target.closest?.('[data-kage-tab]');
  if (!link) return;
  const tab = link.dataset.kageTab;
  if (tab === 'settings') document.getElementById('btn-settings')?.click();
  else activateWorkspaceTab(tab);
});

function syncShadeThreadsAfterStaticChange() {
  renderShadeConversation({ force: true });
  bindAllKageInteractions(document);
}

// Incremental streaming: update only the active assistant nodes so the whole
// transcript does not jitter/reflow on every SSE delta.
function showShadeLoadingPlaceholder() {
  removeShadeLoadingPlaceholder();
  for (const [key, id] of [['main','shade-thread-main'], ['sidecar','shade-thread-sidecar']]) {
    const thread = document.getElementById(id);
    if (!thread || !shadeThreadIsVisible(id)) continue;
    thread.classList.remove('hidden');
    const row = createShadeEntry({ role: 'assistant', text: '', thinking: true });
    row.classList.add('thinking', 'shade-loading-row');
    const content = row.querySelector('.content');
    if (content) {
      content.replaceChildren();
      const label = document.createElement('span');
      label.className = 'shade-loading-text';
      Array.from('Thinking').forEach((letter, index) => { const span = document.createElement('span'); span.textContent = letter; span.style.setProperty('--jump-index', index); label.append(span); });
      const bars = document.createElement('span');
      bars.className = 'shade-loading-dots jumping-dots';
      bars.setAttribute('aria-hidden', 'true');
      bars.innerHTML = '<i></i><i></i><i></i>';
      content.append(label, bars);
    }
    thread.append(row);
    shadeLoadingNodes[key] = row;
    thread.scrollTop = thread.scrollHeight;
  }
  for (const id of ['shade-empty-main','shade-empty-sidecar']) document.getElementById(id)?.classList.add('hidden');
}

function removeShadeLoadingPlaceholder() {
  for (const row of Object.values(shadeLoadingNodes)) row?.remove?.();
  shadeLoadingNodes = { main: null, sidecar: null };
}

function startShadeStream() {
  removeShadeLoadingPlaceholder();
  const item = { role: 'assistant', text: '', thinking: true, animateFrom: 0 };
  shadeConversation.push(item);
  shadeStreamingIndex = shadeConversation.length - 1;
  shadeActiveMessageNode = { main: null, sidecar: null };
  shadeStreamDisplayedText = '';
  shadeMessagePopPlayed = false;
  for (const [key, id] of [['main','shade-thread-main'], ['sidecar','shade-thread-sidecar']]) {
    const thread = document.getElementById(id);
    if (!thread || !shadeThreadIsVisible(id)) continue;
    const row = createShadeEntry(item);
    row.shadeDisplayedText = '';
    row.classList.add('thinking');
    thread.append(row);
    shadeActiveMessageNode[key] = row;
    thread.scrollTop = thread.scrollHeight;
  }
}
// v96: character-paced typewriter irrespective of streaming chunk boundaries.
let shadeQueue = [];
let shadePaintFrame = 0;
let shadeLastFrame = 0;
let shadeTypingCredit = 0;
let shadePendingDone = false;
let shadeStreamDisplayedText = '';
const SHADE_CHARS_PER_SECOND = 95;
function appendShadeDeltaToActiveNodes(text) {
  shadeQueue.push(...Array.from(String(text || '')));
  if (!shadePaintFrame) shadePaintFrame = requestAnimationFrame(flushShadeStreamText);
}
function flushShadeStreamText(now = performance.now()) {
  shadePaintFrame = 0;
  const elapsed = shadeLastFrame ? Math.max(0, Math.min(100, now - shadeLastFrame)) : 16;
  shadeLastFrame = now;
  shadeTypingCredit += elapsed * SHADE_CHARS_PER_SECOND / 1000;
  // Cap frame DOM work even after the tab is hidden or a large message is received.
  const amount = Math.min(5, shadeQueue.length, Math.max(1, Math.floor(shadeTypingCredit)));
  shadeTypingCredit = Math.max(0, shadeTypingCredit - amount);
  const slice = shadeQueue.splice(0, amount).join('');
  if (slice) {
    shadeStreamDisplayedText += slice;
    for (const [key, id] of [['main','shade-thread-main'], ['sidecar','shade-thread-sidecar']]) {
      const row = shadeActiveMessageNode[key];
      const thread = document.getElementById(id);
      const content = row?.querySelector('.content');
      if (!row || !thread || !content) continue;
      // Small per-frame chunks appear in real sequence, with soft per-letter fade.
      appendShadeCharacters(content, slice, { index: 0, animated: 0 }, shadeThreadIsVisible(id) ? 0 : Number.MAX_SAFE_INTEGER);
      row.shadeDisplayedText = shadeStreamDisplayedText;
      if (thread.offsetParent) thread.scrollTop = thread.scrollHeight;
    }
  }
  if (shadeQueue.length) shadePaintFrame = requestAnimationFrame(flushShadeStreamText);
  else if (shadePendingDone) finalizeShadeStream();
}
function appendShadeDelta(text) {
  const delta = String(text || '');
  if (!delta) return;
  if (shadeStreamingIndex < 0 || !shadeConversation[shadeStreamingIndex]) startShadeStream();
  const message = shadeConversation[shadeStreamingIndex];
  if (!shadeMessagePopPlayed) { playShadeMessagePop(); shadeMessagePopPlayed = true; }
  message.text += delta;
  message.thinking = true;
  appendShadeDeltaToActiveNodes(delta);
}
function finalizeShadeStream() {
  shadePendingDone = false;
  shadeLastFrame = 0; shadeTypingCredit = 0;
  removeShadeLoadingPlaceholder();
  const message = shadeStreamingIndex >= 0 ? shadeConversation[shadeStreamingIndex] : null;
  if (message) {
    message.thinking = false; message.complete = true; message.animationPlayed = true;
    shadeMessageAnimationState.set(shadeMessageId(message), true);
  }
  for (const row of Object.values(shadeActiveMessageNode)) {
    if (!row) continue;
    row.classList.remove('thinking');
    if (message?.text) renderShadeAssistantMessage(row, message.text, Number.MAX_SAFE_INTEGER);
    row.shadeDisplayedText = String(message?.text || '');
    row.classList.add('complete');
    setTimeout(() => row.classList.remove('complete'), 650);
  }
  shadeStreamingIndex = -1; shadeActiveMessageNode = { main:null, sidecar:null };
  shadeRequestInFlight = false; shadeMessagePopPlayed = false;
  updateShadeSendButtons();
  saveShadeChats();
}
function finishShadeStream() {
  shadePendingDone = true;
  if (!shadeQueue.length) finalizeShadeStream();
  else if (!shadePaintFrame) shadePaintFrame = requestAnimationFrame(flushShadeStreamText);
}
function explorerClassFor(name, className, hasChildren) {
  const cls = String(className || '').toLowerCase();
  if (cls.includes('script')) return 'script';
  if (cls.includes('animation')) return 'animation';
  if (cls.includes('service')) return 'service';
  return hasChildren ? 'folder' : 'animation';
}
function renderFilteredExplorer(snapshot = currentWorkspaceSnapshot) {
  const treeEl = document.getElementById('studio-workspace-tree');
  if (!treeEl) return;
  const query = String(document.getElementById('explorer-search-input')?.value || '').trim().toLowerCase();
  const animations = Array.isArray(snapshot.animations) ? snapshot.animations : [];
  const visible = animations.filter(item => !query || `${item.name || ''} ${item.location || ''} ${item.id || ''}`.toLowerCase().includes(query));
  const root = { children: new Map(), assets: [] };
  for (const item of visible) {
    const path = String(item.location || '').replace(/^game[.\/]?/i, '').replace(/\./g, '/');
    const parts = path.split('/').map(x => x.trim()).filter(Boolean);
    let branch = root;
    for (const part of parts) {
      if (!branch.children.has(part)) branch.children.set(part, { children: new Map(), assets: [] });
      branch = branch.children.get(part);
    }
    branch.assets.push(item);
  }
  const iconFor = { Animations: 'kage-asset-animation.png' };
  function addBranch(branch, parent, depth) {
    for (const [name, child] of [...branch.children].sort(([a],[b]) => a.localeCompare(b))) {
      const folder = document.createElement('details'); folder.className = 'explorer-folder'; folder.open = depth < 1 || !!query;
      const summary = document.createElement('summary'); summary.className = 'tree-node';
      const icon = document.createElement('img'); icon.className = 'tree-folder-icon'; icon.src = '../Assets/nav-explorer.png'; icon.alt = '';
      const label = document.createElement('span'); label.className = 'tree-label'; label.textContent = name;
      summary.append(icon, label); folder.append(summary);
      const contents = document.createElement('div'); contents.className = 'explorer-folder-contents';
      addBranch(child, contents, depth + 1);
      folder.append(contents); parent.append(folder);
    }
    for (const item of branch.assets) {
      const id = String(item.id || ''); if (!/^\d+$/.test(id)) continue;
      const button = document.createElement('button'); button.type = 'button'; button.className = 'explorer-asset'; button.dataset.assetId = id;
      const icon = document.createElement('img'); icon.src = `../Assets/${iconFor[getSelectedAssetType()] || iconFor.Animations}`; icon.alt = '';
      const name = document.createElement('span'); name.textContent = item.name || `${getSelectedAssetType()} ${id}`;
      const number = document.createElement('small'); number.textContent = id;
      button.append(icon, name, number);
      button.addEventListener('click', () => {
        if (!requireStudioConnection()) return;
        treeEl.querySelectorAll('.explorer-asset').forEach(el => el.classList.toggle('selected', el === button));
        const assetName = item.name || `${getSelectedAssetType()} ${id}`;
        showConfirmModal('Reupload this asset?', `Are you sure you want to reupload ${assetName} (ID ${id})?`, () => {
          selectedExplorerAssetId = id;
          selectedExplorerAssetType = getSelectedAssetType();
          startReupload();
        });
      });
      const row = document.createElement('div'); row.className = 'explorer-asset-row';
      const preview = document.createElement('button'); preview.type = 'button'; preview.className = 'explorer-quick-preview'; preview.dataset.tooltip = 'Quick preview'; preview.setAttribute('aria-label', `Quick preview ${item.name || id}`);
      const previewIcon = document.createElement('img'); previewIcon.src = '../Assets/nav-preview.png'; previewIcon.alt = ''; preview.append(previewIcon);
      preview.addEventListener('click', event => {
        event.stopPropagation();
        if (!requireStudioConnection()) return;
        const assetType = getSelectedAssetType();
        window.dispatchEvent(new CustomEvent('kageQuickPreview', { detail: { id, name: item.name || `${assetType} ${id}`, assetType, location: item.location || '' } }));
        activateWorkspaceTab('preview');
      });
      row.append(button, preview); parent.append(row);
    }
  }
  treeEl.replaceChildren();
  if (visible.length) addBranch(root, treeEl, 0);
  else { const empty = document.createElement('div'); empty.className = 'workspace-empty'; empty.textContent = query ? 'No matching assets.' : 'No detected asset locations yet.'; treeEl.append(empty); }
  updateMetricText('explorer-result-count', animations.length);
}
function updateExplorerProjectSummary(project, assetCount) {
  const summary = document.getElementById('explorer-project-summary');
  if (!summary) return;
  const name = project?.name || 'Open project';
  const universe = project?.universeId || '—';
  const count = Math.max(0, Number(assetCount) || 0);
  const glow = document.createElement('span');
  glow.className = 'explorer-count-glow';
  glow.textContent = `${count} asset${count === 1 ? '' : 's'}`;
  const icon = document.createElement('img'); icon.className = 'gui-icon explorer-heading-icon'; icon.src = '../Assets/nav-explorer.png'; icon.alt = '';
  summary.replaceChildren(icon, document.createTextNode(`${name} · Universe ID ${universe} · `), glow);
}
renderStudioWorkspace = function(snapshot = {}) {
  currentWorkspaceSnapshot = {
    project: snapshot.project || currentWorkspaceSnapshot.project || null,
    animations: Array.isArray(snapshot.animations) ? snapshot.animations : currentWorkspaceSnapshot.animations || [],
    assetType: snapshot.assetType || currentWorkspaceSnapshot.assetType || getSelectedAssetType()
  };
  const project = currentWorkspaceSnapshot.project;
  if (project) {
    updateMetricText('reupload-project-label', project.name || 'Open Studio Project');
    updateMetricText('reupload-info-project', project.name || 'Open Studio Project');
    if (document.getElementById('reupload-connected-game-name')) animateTextBlue('reupload-connected-game-name', project.name || 'Game');
  }
  renderFilteredExplorer(currentWorkspaceSnapshot);
  updateExplorerProjectSummary(project, currentWorkspaceSnapshot.animations.length);
};

document.getElementById('explorer-search-input')?.addEventListener('input', () => renderFilteredExplorer());

// Studio UI: scan errors remain scan errors; they no longer overwrite a healthy
// connection with the misleading Connection Failed state.
updateStudioConnectionState = function(data = {}) {
  const connected = data.state === 'StudioConnected';
  isStudioConnectedForUi = connected;
  const connecting = ['Connecting', 'ScanningProject'].includes(data.state);
  const failed = ['ConnectionFailed', 'ConnectionLost', 'StudioNotInstalled'].includes(data.state);
  const info = data.project || {};
  const statusText = data.status || (connected ? 'Studio Connected' : 'Studio Offline');
  updateMetricText('title-studio-state', connected ? 'Studio Connected' : statusText);
  updateMetricText('studio-status-text', statusText);
  updateMetricText('reupload-studio-status', statusText);
  updateMetricText('studio-project-name', info.name || '—');
  updateMetricText('studio-place-id', info.placeId || '—');
  updateMetricText('studio-universe-id', info.universeId || '—');
  updateMetricText('studio-side-place-id', info.placeId || '—');
  updateMetricText('studio-side-universe-id', info.universeId || '—');
  updateMetricText('reupload-info-sync', data.activity || (connected ? 'Ready' : connecting ? 'Connecting' : 'Offline'));

  paintStudioConnectControl(connected ? 'connected' : connecting ? 'connecting' : 'idle');
  if (connected) {
    const tree = document.getElementById('studio-workspace-tree');
    if (tree && /Connect to Studio first\./i.test(tree.textContent || ''))
      tree.innerHTML = '<div class="workspace-empty">Scanning Studio project…</div>';
  }
  if (failed) updateMetricText('studio-connect-caption', data.error || 'Failed to connect. Open Roblox Studio into a game or project.');
  if (connected && lastStudioConnectionAudioState !== 'StudioConnected') playStudioConnectionSuccess();
  if (failed && lastStudioConnectionAudioState !== data.state) playStudioConnectionFailure();
  lastStudioConnectionAudioState = String(data.state || '');

  const title = document.getElementById('reupload-card-title');
  const copy = document.getElementById('reupload-card-copy');
  if (title) {
    if (connected && info?.name) {
      const universeId = escapeHtml(String(info.universeId || '—'));
      title.innerHTML = `Connected to <span id="reupload-connected-game-name"></span><span class="reupload-connected-meta"> · Universe ID ${universeId} · in Roblox Studio</span>`;
      animateTextBlue('reupload-connected-game-name', info.name);
    } else {
      title.textContent = connecting ? 'Connecting to Roblox Studio…' : failed ? 'Studio connection failed' : 'Connect to Roblox Studio';
    }
  }
  if (copy) {
    copy.textContent = connected ? '' : (data.activityError || data.error || (failed ? 'Check Roblox Studio, then connect again.' : 'Connect once to scan the open project.'));
    copy.classList.toggle('hidden', connected);
  }
};

function requestEligibleGroups() {
  const modal = document.getElementById('group-selector-modal');
  modal?.classList.add('open');
  modal?.setAttribute('aria-hidden', 'false');
  const grid = document.getElementById('group-selector-grid');
  if (grid && !groupSelector.groups.length) grid.innerHTML = '<div class="workspace-empty">Loading eligible groups…</div>';
  else renderGroupSelector({ groups: groupSelector.groups });
  bridge.send('getEligibleGroups');
}
function renderGroupSelector(data = {}) {
  groupSelector.groups = Array.isArray(data.groups) ? data.groups : groupSelector.groups;
  const grid = document.getElementById('group-selector-grid');
  if (!grid) return;
  if (data.error) { grid.innerHTML = `<div class="workspace-empty">${escapeHtml(data.error)}</div>`; return; }
  const term = String(document.getElementById('group-selector-search')?.value || '').trim().toLowerCase();
  const visible = groupSelector.groups.filter(group => `${group.name || ''} ${group.role || ''} ${group.permission || ''} ${group.id || ''}`.toLowerCase().includes(term));
  if (!visible.length) { grid.innerHTML = `<div class="workspace-empty">${groupSelector.groups.length ? 'No eligible groups match this search.' : 'No groups with verified KAGE creation permissions were found.'}</div>`; return; }
  grid.innerHTML = visible.map(group => `<button class="group-card kage-interactive" type="button" data-group-id="${escapeHtml(group.id)}"><img src="${escapeHtml(group.icon || '../Assets/roblox-studio.svg')}" alt=""><span><strong>${escapeHtml(group.name)}</strong><small>${escapeHtml(group.role || 'Member')}</small></span><em>${escapeHtml(group.permission || 'Verified creation permission')}</em></button>`).join('');
  grid.querySelectorAll('[data-group-id]').forEach(card => card.addEventListener('click', () => {
    const id = String(card.dataset.groupId || '');
    const selected = groupSelector.groups.find(group => String(group.id) === id);
    if (!selected) return;
    groupSelector.selected = selected;
    const input = document.getElementById('input-groupid'); if (input) input.value = id;
    destToggles.forEach(t => t.classList.toggle('active', t.dataset.dest === 'group'));
    groupIdField?.classList.remove('hidden');
    const preview = document.getElementById('selected-group-preview');
    if (preview) { preview.classList.add('hidden'); preview.replaceChildren(); }
    closeGroupSelector();
  }));
  bindAllKageInteractions(grid);
}
document.getElementById('group-selector-search')?.addEventListener('input', () => renderGroupSelector({ groups: groupSelector.groups }));
function closeGroupSelector() { const modal = document.getElementById('group-selector-modal'); modal?.classList.remove('open'); modal?.setAttribute('aria-hidden','true'); }
document.getElementById('group-selector-close')?.addEventListener('click', closeGroupSelector);
document.querySelector('.group-selector-backdrop')?.addEventListener('click', closeGroupSelector);

function makeShadeSidecarDraggable() {
  if (isShadePopout) return;
  const sidecar = document.getElementById('shade-sidecar');
  const handle = document.getElementById('shade-sidecar-drag-handle');
  if (!sidecar || !handle || handle.dataset.dragBound) return;
  handle.dataset.dragBound = '1';
  let startX = 0, startY = 0, baseX = 0, baseY = 0, dragging = false, originRect = null;
  handle.addEventListener('pointerdown', event => {
    if (event.button !== 0 || event.target.closest('button')) return;
    dragging = true; startX = event.clientX; startY = event.clientY;
    baseX = Number(sidecar.dataset.dragX || 0); baseY = Number(sidecar.dataset.dragY || 0);
    originRect = sidecar.getBoundingClientRect();
    sidecar.classList.add('dragging'); handle.setPointerCapture(event.pointerId);
    event.preventDefault();
  });
  handle.addEventListener('pointermove', event => {
    if (!dragging) return;
    const rect = originRect;
    const x = Math.max(baseX + 8 - rect.left, Math.min(baseX + innerWidth - rect.right - 8, baseX + event.clientX - startX));
    const y = Math.max(baseY + 8 - rect.top, Math.min(baseY + innerHeight - rect.bottom - 8, baseY + event.clientY - startY));
    sidecar.dataset.dragX = String(x); sidecar.dataset.dragY = String(y);
    sidecar.style.setProperty('--drag-x', `${x}px`);
    sidecar.style.setProperty('--drag-y', `${y}px`);
  });
  const end = event => { if (!dragging) return; dragging = false; sidecar.classList.remove('dragging'); try { handle.releasePointerCapture(event.pointerId); } catch {} };
  handle.addEventListener('pointerup', end); handle.addEventListener('pointercancel', end);
  window.addEventListener('blur', () => { dragging = false; sidecar.classList.remove('dragging'); });
}
makeShadeSidecarDraggable();

const previousToggleShadeDrawer = toggleShadeDrawer;
toggleShadeDrawer = function(force) {
  const sidecar = document.getElementById('shade-sidecar');
  const opening = typeof force === 'boolean' ? force : !sidecar?.classList.contains('open');
  if (opening && !isShadePopout) {
    activateWorkspaceTab('home');
    bridge.send('setShadeSidecar', { open: true });
    return;
  }
  previousToggleShadeDrawer(opening);
  makeShadeSidecarDraggable();
};

// Shared KAGE interactions are registered by bindAllKageInteractions() above.

// Keep destination account/profile surfaces synchronized.
const originalUpdateAccountInfoApproved = updateAccountInfo;
let groupsPreloadedFor = '';
function refreshWelcomeBackAnimatedIdentity() {
  const roblox = latestAccountInfo?.roblox || {};
  animateText('welcome-back-name', roblox.displayName || roblox.username || 'Roblox Account');
  animateText('welcome-back-id', roblox.id ? `ID: ${roblox.id}` : 'ID: —');
}

let welcomeBackDismissTimer = 0;
function setWelcomeBackButtonsDisabled(disabled) {
  ['welcome-back-login','welcome-back-different'].forEach(id => {
    const button = document.getElementById(id);
    if (button) button.disabled = !!disabled;
  });
}
function showWelcomeBackGate() {
  window.clearTimeout(welcomeBackDismissTimer);
  const gate = document.getElementById('welcome-back-gate');
  if (!gate) return;
  gate.classList.remove('hidden','is-leaving');
  setWelcomeBackButtonsDisabled(false);
  requestAnimationFrame(() => requestAnimationFrame(() => {
    gate.classList.add('is-visible');
    refreshWelcomeBackAnimatedIdentity();
  }));
}
function finishWelcomeBackDismiss() {
  window.clearTimeout(welcomeBackDismissTimer);
  const gate = document.getElementById('welcome-back-gate');
  if (!gate) return;
  gate.classList.remove('is-visible','is-leaving');
  gate.classList.add('hidden');
  setWelcomeBackButtonsDisabled(false);
}
function dismissWelcomeBackGate(afterFade) {
  const gate = document.getElementById('welcome-back-gate');
  if (!gate || gate.classList.contains('hidden') || gate.classList.contains('is-leaving')) {
    if (typeof afterFade === 'function') afterFade();
    return;
  }
  setWelcomeBackButtonsDisabled(true);
  gate.classList.add('is-leaving');
  gate.classList.remove('is-visible');
  window.clearTimeout(welcomeBackDismissTimer);
  welcomeBackDismissTimer = window.setTimeout(() => {
    gate.classList.add('hidden');
    gate.classList.remove('is-leaving');
    if (typeof afterFade === 'function') afterFade();
  }, 360);
}

updateAccountInfo = function(data) {
  latestAccountInfo = data;
  originalUpdateAccountInfoApproved(data);
  const roblox = data?.roblox || {};
  animateText('settings-roblox-display', roblox.id ? `ID ${roblox.id}` : '—');
  if (roblox.id && String(roblox.id) !== groupsPreloadedFor) {
    groupsPreloadedFor = String(roblox.id);
    groupSelector.groups = [];
    groupSelector.selected = null;
    bridge.send('getEligibleGroups');
  }
  const avatar = roblox.avatar || '';
  const destAvatar = document.getElementById('destination-account-avatar');
  if (destAvatar) destAvatar.style.backgroundImage = avatar ? `url("${avatar}")` : '';
  syncDestinationDisplayer();
  const welcomeAvatar = document.getElementById('welcome-back-avatar');
  if (welcomeAvatar) welcomeAvatar.style.backgroundImage = avatar ? `url("${avatar}")` : '';
  animateText('welcome-back-name', roblox.displayName || roblox.username || 'Roblox Account');
  animateText('welcome-back-id', roblox.id ? `ID: ${roblox.id}` : 'ID: —');
  if (data?.showWelcomeBack && roblox.id && !sessionStorage.getItem('kageWelcomeBackPassed')) {
    showWelcomeBackGate();
  } else {
    finishWelcomeBackDismiss();
  }
};
document.getElementById('welcome-back-login')?.addEventListener('click', () => {
  dismissWelcomeBackGate(() => bridge.send('resumeSavedSession'));
});
document.getElementById('welcome-back-different')?.addEventListener('click', () => {
  dismissWelcomeBackGate(() => bridge.send('useDifferentAccount'));
});

// Reupload progress result enrichment.
const originalUpdateProgressApproved = updateProgress;
updateProgress = function(data = {}) {
  const id = String(data.currentAssetId || '');
  const asset = (currentWorkspaceSnapshot.animations || []).find(item => String(item.id || '') === id);
  const resultMatch = lastReuploadResult && id === lastReuploadResult.oldId && ['Success','Failed'].includes(String(data.currentAssetStatus || ''));
  const enriched = resultMatch
    ? { ...data, currentAsset: lastReuploadResult.name, currentAssetId: lastReuploadResult.displayedId, currentAssetLocation: lastReuploadResult.location, completed: Math.max(Number(data.completed) || 0, lastReuploadResult.sequence) }
    : { ...data, currentAssetLocation: asset?.location || data.currentAssetLocation || 'Detected location' };
  originalUpdateProgressApproved(enriched);
};

function flushPendingReuploadAssetResults(jobId) {
  const key = String(jobId || '');
  const buffered = pendingReuploadAssetResults.get(key) || [];
  pendingReuploadAssetResults.delete(key);
  buffered
    .slice()
    .sort((a, b) => (Number(a?.sequence) || 0) - (Number(b?.sequence) || 0))
    .forEach(item => handleReuploadAssetResult(item));
}

function handleReuploadAssetResult(data = {}) {
  const resultJobId = String(data.jobId || '');
  if (resultJobId && !activeJobId) {
    if (pendingStudioPreparation) {
      const buffered = pendingReuploadAssetResults.get(resultJobId) || [];
      buffered.push({ ...data });
      pendingReuploadAssetResults.set(resultJobId, buffered.slice(-1000));
    }
    return;
  }
  if (resultJobId && activeJobId && resultJobId !== String(activeJobId)) return;

  const oldId = String(data.oldId || '');
  const newId = data.newId == null ? '' : String(data.newId);
  const successful = data.success === true;
  const reportedSequence = Math.max(0, Math.floor(Number(data.sequence) || 0));
  const sequence = Math.max(liveReuploadResultSequence + 1, reportedSequence);
  liveReuploadResultSequence = sequence;
  const asset = (currentWorkspaceSnapshot.animations || []).find(item => String(item.id || '') === oldId);
  const name = String(data.assetName || asset?.name || `${String(data.assetType || activeReuploadAssetType || 'Asset').replace(/s$/, '')} ${oldId}`).trim();
  const location = String(asset?.location || data.location || 'Detected location').trim();
  const displayedId = successful ? (newId || oldId || '—') : (oldId || '—');
  lastReuploadResult = { oldId, newId, displayedId, name, location, successful, sequence };

  // Result text stays inline: AssetName / Location / ID / #. Outcome colors are
  // applied only to the ID and sequence so the rest of the row stays readable.
  progressView.setAsset({
    currentAsset: name,
    currentAssetLocation: location,
    currentAssetId: displayedId,
    currentAssetStatus: successful ? 'Success' : 'Failed',
    completed: sequence
  });

  const idFlow = successful && newId && newId !== oldId ? `${oldId} → ${newId}` : displayedId;
  const assetLabel = String(data.assetType || activeReuploadAssetType || 'Animations').replace(/s$/i, '');
  const suffix = successful
    ? `UPLOAD OK / ${assetLabel} / ${name} / ${location} / ${idFlow} / #${sequence}`
    : `UPLOAD FAILED / ${assetLabel} / ${name} / ${location} / ${displayedId} / #${sequence}${data.error ? ` / ${String(data.error)}` : ''}`;
  appendLog(successful ? 'SUCCESS' : 'ERROR', suffix);
}

// Fetch public Roblox place thumbnails for history; never sends credentials.
const historyThumbnailCache = new Map();
const historyThumbnailPending = new Map();
const historyThumbnailFailedAt = new Map();
const historyThumbnailUnavailable = new Set();
const historyThumbnailInvalid = new Set();
const HISTORY_ICON_RETRY_MS = 60_000;
function isHistoryThumbnailUrl(url) {
  return /^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(url) ||
    /^https:\/\/(?:[A-Za-z0-9-]+\.)*rbxcdn\.com\/(?:[^\s"'<>]*)$/i.test(url);
}
function hydrateHistoryGameIcons(items = []) {
  for (const item of items) {
    const placeId = Number(item?.placeId) || 0;
    if (!placeId || historyThumbnailCache.has(placeId)) continue;
    const pendingAt = historyThumbnailPending.get(placeId);
    if (pendingAt && Date.now() - pendingAt < 30_000) continue;
    if (pendingAt) historyThumbnailPending.delete(placeId);
    if (historyThumbnailUnavailable.has(placeId)) {
      const failedAt = historyThumbnailFailedAt.get(placeId) || 0;
      if (Date.now() - failedAt < 5 * HISTORY_ICON_RETRY_MS) continue;
      historyThumbnailUnavailable.delete(placeId);
    }
    const lastFailure = historyThumbnailFailedAt.get(placeId) || 0;
    if (Date.now() - lastFailure < HISTORY_ICON_RETRY_MS) continue;
    // A live Studio project already supplies its universe ID, so avoid an
    // extra, sometimes unavailable, Roblox Place -> Universe lookup.
    const current = currentWorkspaceSnapshot?.project;
    const universeId = Number(item?.universeId) ||
      (Number(current?.placeId) === placeId ? Number(current?.universeId) || 0 : 0);
    historyThumbnailPending.set(placeId, Date.now());
    const request = { placeId, universeId };
    if (historyThumbnailInvalid.has(placeId)) request.invalidateCache = true;
    bridge.send('getHistoryThumbnail', request);
  }
  applyHistoryThumbnails();
}
function applyHistoryThumbnails() {
  for (const icon of activityList?.querySelectorAll?.('.activity-item[data-place-id] .history-game-icon') || []) {
    const placeId = Number(icon.closest('.activity-item')?.dataset.placeId) || 0;
    const url = historyThumbnailCache.get(placeId) || '';
    // The native client may inline verified Roblox icons as PNG/JPEG/WebP data
    // URLs, preventing Chromium from blocking external CDN thumbnail loads.
    if (url && isHistoryThumbnailUrl(url)) {
      icon.style.backgroundImage = `url("${url}")`;
      icon.dataset.thumbnailState = 'ready';
    } else if (!placeId || historyThumbnailUnavailable.has(placeId)) {
      icon.style.backgroundImage = 'url("../Assets/roblox-studio-2022-flat.svg")';
      icon.dataset.thumbnailState = 'unavailable';
    } else {
      icon.style.backgroundImage = historyThumbnailFailedAt.has(placeId)
        ? 'url("../Assets/roblox-studio-2022-flat.svg")' : 'none';
      icon.dataset.thumbnailState = 'loading';
    }
  }
}
// Better history composition, preserving the existing durable history data.
renderRecentHistory = function() {
  if (!activityList) return;
  const visible = recentHistory.slice(0, 12);
  if (!visible.length) {
    if (!activityList.querySelector('.activity-empty')) activityList.innerHTML = '<div class="activity-empty">No recent KAGE runs yet</div>';
    delete activityList.dataset.historyRenderKey;
    return;
  }
  const scrollTop = activityList.scrollTop;
  const markup = visible.map(item => {
    const placeName = normalizeHistoryPlaceName(item);
    const status = String(item.status || 'Unknown');
    const metaTime = formatHistoryTime(item.finishedUtc || item.createdUtc);
    return `<div class="activity-item kage-interactive" data-place-id="${Number(item.placeId) || 0}" data-status="${escapeHtml(status.toLowerCase())}"><div class="history-game-icon" role="img" aria-label="${escapeHtml(placeName)} icon"></div><div class="activity-place"><div class="activity-name">${escapeHtml(placeName)}</div><div class="activity-meta">${escapeHtml(item.assetType || 'Animations')} · Place ${escapeHtml(item.placeId || '—')}</div></div><div class="activity-count"><strong>${Number(item.successful || 0)} / ${Number(item.total || 0)}</strong><span>${escapeHtml(status)}${metaTime ? ` · ${escapeHtml(metaTime)}` : ''}</span></div></div>`;
  }).join('');
  if (activityList.dataset.historyRenderKey === markup) { hydrateHistoryGameIcons(visible); return; }
  activityList.innerHTML = markup;
  activityList.dataset.historyRenderKey = markup;
  activityList.scrollTop = scrollTop;
  bindAllKageInteractions(activityList);
  void hydrateHistoryGameIcons(visible);
};
renderRecentHistory();
// Recheck unsuccessful requests occasionally even when Recent History remains
// unchanged; otherwise a transient HTTP error leaves the fallback forever.
setInterval(() => {
  if (recentHistory.length && activityList?.isConnected) hydrateHistoryGameIcons(recentHistory.slice(0, 12));
}, HISTORY_ICON_RETRY_MS);

// Semantic log highlighting, including asset IDs.
const originalAppendLogApproved = appendLog;
appendLog = function(level, message) {
  originalAppendLogApproved(level, message);
  const consoleEl = document.getElementById('logs-console');
  const row = consoleEl?.lastElementChild; const code = row?.querySelector('code');
  if (!code) return;
  code.innerHTML = escapeHtml(code.textContent || '').replace(/(\b\d+(?:\.\d+)?\b)/g, '<span class="log-number">$1</span>');
  refreshWatchRows();
};
let watchFilter = 'all';
function refreshWatchRows() {
  const rows = [...document.querySelectorAll('#logs-console .log-row')];
  for (const row of rows) {
    const level = row.dataset.level || 'INFO';
    row.classList.toggle('log-filtered', watchFilter !== 'all' &&
      !(watchFilter === 'ERROR' ? level === 'ERROR' || level === 'BUG' : level === watchFilter));
  }
  const label = document.getElementById('watch-event-count');
  if (label) label.textContent = `${rows.length} SESSION EVENT${rows.length === 1 ? '' : 'S'}`;
}
document.querySelectorAll('[data-log-filter]').forEach(button => button.addEventListener('click', () => {
  watchFilter = button.dataset.logFilter || 'all';
  document.querySelectorAll('[data-log-filter]').forEach(item => item.classList.toggle('active', item === button));
  refreshWatchRows();
}));
document.getElementById('clear-log-view')?.addEventListener('click', () => setTimeout(refreshWatchRows, 0));

// Respect the Settings close and AI close hover/pointer hit targets.
for (const id of ['settings-close','shade-sidecar-close']) {
  const el = document.getElementById(id); if (el) { el.style.cursor = 'pointer'; el.setAttribute('role','button'); }
}


// User transcript labels use the verified Discord identity KAGE already holds.
const kageCreateShadeEntryWithIdentity = createShadeEntry;
createShadeEntry = function(item) {
  const row = kageCreateShadeEntryWithIdentity(item);
  if (item?.role === 'user') {
    const who = row.querySelector('.who');
    const discord = latestAccountInfo?.discord || {};
    if (who) { who.textContent = ''; Array.from(discord.username || 'You').forEach((letter, index) => { const span = document.createElement('span'); span.className = 'assistant-name-letter'; span.style.setProperty('--letter-index', index); span.textContent = letter; who.append(span); }); }
    const rb = latestAccountInfo?.roblox || {};
    if (rb.avatar) { const avatar = document.createElement('img'); avatar.className = 'user-chat-avatar'; avatar.src = rb.avatar; avatar.alt = ''; row.prepend(avatar); }
  }
  return row;
};
const kageUpdateAccountInfoAnimated = updateAccountInfo;
updateAccountInfo = function(data) {
  kageUpdateAccountInfoAnimated(data);
  const rb = data?.roblox || {};
  if (rb.displayName || rb.username) animateText('home-profile-name', rb.displayName || rb.username);
  if (rb.id) animateText('home-profile-id', `ID: ${rb.id}`);
  if (rb.displayName || rb.username) animateText('settings-avatar-name', rb.displayName || rb.username);
  if (rb.id) animateText('settings-avatar-id', `ID: ${rb.id}`);
};

// Conversation navigation stays in the UI; the existing Shade request protocol is unchanged.
const shadeChatsKey = 'kage_shade_chats_v2';
let shadeChats = [];
let currentShadeChatId = null;
try {
  const saved = JSON.parse(localStorage.getItem(shadeChatsKey) || '[]');
  if (Array.isArray(saved)) shadeChats = saved.filter(x => x && Array.isArray(x.messages)).slice(0, 20);
} catch { /* A damaged local draft starts clean. */ }
function shadeChatTitle(messages) {
  const reply = messages.find(x => x.role === 'assistant')?.text;
  const first = reply?.split('\n').find(line => line.trim()) || messages.find(x => x.role === 'user')?.text || 'New chat';
  return String(first).replace(/^[#*\-\s]+/, '').replace(/\s+/g, ' ').trim().slice(0, 38) || 'New chat';
}
function saveShadeChats() {
  const chat = shadeChats.find(x => x.id === currentShadeChatId);
  if (chat) {
    chat.messages = shadeConversation.filter(x => x.text && !x.thinking).map(item => ({ id: shadeMessageId(item), role: item.role, text: item.text, animationPlayed: true })).slice(-SHADE_HISTORY_LIMIT);
    chat.title = shadeChatTitle(chat.messages);
    chat.updated = Date.now();
  }
  try { localStorage.setItem(shadeChatsKey, JSON.stringify(shadeChats.slice(0, 20))); } catch {}
  renderShadeChatList();
}
function activateShadeChat(chat) {
  if (!chat || shadeRequestInFlight) return;
  saveShadeChats();
  currentShadeChatId = chat.id;
  shadeConversation.splice(0, shadeConversation.length, ...chat.messages.map(restoreShadeMessage));
  renderShadeConversation();
  renderShadeChatList();
}
function deleteShadeChat(chatId) {
  if (!chatId || shadeRequestInFlight || shadeStreamingIndex >= 0) return;
  const index = shadeChats.findIndex(chat => chat.id === chatId);
  if (index < 0) return;
  const ordered = [...shadeChats].sort((a, b) => (b.updated || 0) - (a.updated || 0));
  const activeIndex = ordered.findIndex(chat => chat.id === chatId);
  shadeChats.splice(index, 1);
  if (currentShadeChatId === chatId) {
    const nextActive = ordered[activeIndex + 1] || ordered[activeIndex - 1] || shadeChats[0] || null;
    currentShadeChatId = nextActive?.id || null;
    shadeConversation.splice(0, shadeConversation.length, ...(nextActive?.messages || []).map(restoreShadeMessage));
  }
  if (!shadeChats.length) {
    currentShadeChatId = null;
    shadeConversation.length = 0;
  }
  saveShadeChats();
  renderShadeConversation();
}
function renderShadeChatList() {
  const list = document.getElementById('shade-chat-list');
  const tabs = document.getElementById('shade-editor-tabs');
  if (!list && !tabs) return;
  list?.replaceChildren();
  tabs?.replaceChildren();
  const ordered = [...shadeChats].sort((a,b) => (b.updated || 0) - (a.updated || 0));
  for (const chat of ordered) {
    if (list) {
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = chat.title || 'New chat';
      button.className = chat.id === currentShadeChatId ? 'active' : '';
      button.addEventListener('click', () => activateShadeChat(chat));
      list.append(button);
    }
  }
  if (tabs) {
    for (const chat of ordered.slice(0, 8)) {
      const tab = document.createElement('div');
      tab.className = `shade-chat-tab ${chat.id === currentShadeChatId ? 'active' : ''}`;
      tab.dataset.tooltip = chat.title || 'New chat';
      const label = document.createElement('button');
      label.type = 'button';
      label.className = 'shade-chat-tab-label';
      label.textContent = chat.title || 'New chat';
      label.addEventListener('click', () => activateShadeChat(chat));
      const close = document.createElement('button');
      close.type = 'button';
      close.className = 'shade-chat-tab-close';
      close.setAttribute('aria-label', `Delete ${chat.title || 'chat'}`);
      const closeIcon = document.createElement('img'); closeIcon.className = 'gui-icon'; closeIcon.src = '../Assets/window-close.svg'; closeIcon.alt = ''; close.append(closeIcon);
      close.addEventListener('click', event => {
        event.preventDefault();
        event.stopPropagation();
        deleteShadeChat(chat.id);
      });
      tab.append(label, close);
      tabs.append(tab);
    }
  }
}

function newShadeChat() {
  if (shadeRequestInFlight || shadeStreamingIndex >= 0) return;
  saveShadeChats();
  const chat = { id: `${Date.now()}-${Math.random().toString(36).slice(2)}`, title: 'New chat', messages: [], updated: Date.now() };
  shadeChats.unshift(chat); currentShadeChatId = chat.id;
  shadeConversation.length = 0;
  renderShadeConversation(); saveShadeChats();
}
document.getElementById('shade-new-chat')?.addEventListener('click', newShadeChat);
const previousShadeRenderConversation = renderShadeConversation;
renderShadeConversation = function(options = {}) {
  previousShadeRenderConversation(options);
  // Re-run navigation token upgrading after every transcript rebuild. This keeps
  // saved/rehydrated Shade replies clickable when the user leaves and returns.
  for (const id of ['shade-thread-main','shade-thread-sidecar']) {
    const thread = document.getElementById(id);
    if (thread) upgradeShadeTabTokens(thread);
  }
  const empty = shadeConversation.length === 0;
  for (const id of ['shade-empty-main','shade-empty-sidecar']) document.getElementById(id)?.classList.toggle('hidden', !empty);
  for (const id of ['shade-thread-main','shade-thread-sidecar']) document.getElementById(id)?.classList.toggle('hidden', empty);
};
const previousShadeSend = sendShadeFrom;
sendShadeFrom = function(inputId) {
  if (shadeRequestInFlight || !document.getElementById(inputId)?.value?.trim()) return;
  if (!currentShadeChatId) newShadeChat();
  shadeRequestInFlight = true;
  ensureShadeAudio();
  updateShadeSendButtons();
  previousShadeSend(inputId);
  saveShadeChats();
};
function updateShadeSendButtons() {
  for (const [inputId, buttonId] of [['shade-input-main','shade-send-main'],['shade-input-sidecar','shade-send-sidecar']]) {
    const input = document.getElementById(inputId), button = document.getElementById(buttonId);
    if (button) button.disabled = shadeRequestInFlight || !input?.value?.trim();
  }
}
for (const id of ['shade-input-main','shade-input-sidecar']) document.getElementById(id)?.addEventListener('input', updateShadeSendButtons);
for (const button of document.querySelectorAll('[data-shade-prompt]')) button.addEventListener('click', () => {
  const input = document.getElementById(button.closest('#shade-sidecar') ? 'shade-input-sidecar' : 'shade-input-main');
  if (input) { input.value = button.dataset.shadePrompt; sendShadeFrom(input.id); }
});
if (shadeChats.length) {
  currentShadeChatId = shadeChats[0].id;
  shadeConversation.splice(0, shadeConversation.length, ...shadeChats[0].messages.map(restoreShadeMessage));
}
renderShadeConversation(); renderShadeChatList(); updateShadeSendButtons(); updateHomeStatistics();
if (isShadePopout) {
  document.body.classList.add('shade-popout-mode');
  document.getElementById('shade-sidecar')?.classList.add('open');
  document.getElementById('shade-sidecar')?.setAttribute('aria-hidden', 'false');
  document.getElementById('shade-sidecar-drag-handle')?.addEventListener('mousedown', event => {
    if (event.button === 0 && !event.target.closest('button')) bridge.send('dragShadeWindow');
  });
}
window.addEventListener('storage', event => {
  if (event.key !== shadeChatsKey || shadeStreamingIndex >= 0) return;
  try {
    const shared = JSON.parse(event.newValue || '[]');
    if (!Array.isArray(shared)) return;
    shadeChats = shared.filter(chat => chat && Array.isArray(chat.messages)).slice(0, 20);
    const current = shadeChats.find(chat => chat.id === currentShadeChatId) || shadeChats[0];
    if (current) {
      currentShadeChatId = current.id;
      shadeConversation.splice(0, shadeConversation.length, ...current.messages.map(restoreShadeMessage));
      renderShadeConversation();
    }
    renderShadeChatList();
  } catch { /* Ignore a partial local draft. */ }
});

// A dragged sidecar carries an inline transform; clear it when closing.
const closeShadeSidecarOriginal = closeShadeSidecar;
closeShadeSidecar = function() {
  const panel = document.getElementById('shade-sidecar');
  if (panel) { panel.style.removeProperty('--drag-x'); panel.style.removeProperty('--drag-y'); delete panel.dataset.dragX; delete panel.dataset.dragY; }
  closeShadeSidecarOriginal();
};

// Native account manager already limits stored accounts and handles switching.

const initialGroupSelectorRender = renderGroupSelector;
function setAnimatedDestinationName(value) {
  const el = document.getElementById('destination-account-name');
  if (!el || el.textContent === String(value)) return;
  el.replaceChildren(...Array.from(String(value), (character, index) => {
    const letter = document.createElement('span');
    letter.className = 'destination-letter';
    letter.style.setProperty('--letter-index', index);
    letter.textContent = character;
    return letter;
  }));
}
function syncDestinationDisplayer() {
  const isGroup = document.querySelector('.dest-toggle[data-dest="group"]')?.classList.contains('active');
  const selectedGroup = isGroup ? groupSelector.selected : null;
  const account = latestAccountInfo?.roblox || {};
  const avatar = document.getElementById('destination-account-avatar');
  const image = selectedGroup ? (selectedGroup.icon || '../Assets/kage-groups.png') : (account.avatar || '../Assets/roblox-studio.svg');
  if (avatar) avatar.style.backgroundImage = image ? `url("${String(image).replace(/["\\]/g, '')}")` : '';
  setAnimatedDestinationName(selectedGroup ? selectedGroup.name || 'Group' : account.displayName || account.username || 'My Account');
  updateMetricText('destination-account-id', selectedGroup ? `Group ${selectedGroup.id || '—'}` : account.id ? `ID ${account.id}` : '—');
  // The main displayer already shows the group; never leave a second group card below an account.
  const preview = document.getElementById('selected-group-preview');
  if (preview) { preview.classList.add('hidden'); preview.replaceChildren(); preview.setAttribute('aria-hidden', 'true'); }
  groupIdField?.classList.add('hidden');
  const groupSwitch = document.querySelector('.dest-toggle[data-dest="group"] span');
  if (groupSwitch) groupSwitch.textContent = selectedGroup ? 'Change group' : 'Switch to group';
  const userSwitch = document.querySelector('.dest-toggle[data-dest="user"] span');
  if (userSwitch) userSwitch.textContent = 'Switch to account';
}
renderGroupSelector = function(data) {
  initialGroupSelectorRender(data);
  syncDestinationDisplayer();
};
document.querySelector('.dest-toggle[data-dest="user"]')?.addEventListener('click', () => {
  // This runs after the original destination handler clears group selection.
  syncDestinationDisplayer();
  animateReuploadSurfaceChange('#destination-account-card');
});
document.getElementById('group-selector-grid')?.addEventListener('click', event => {
  if (!event.target.closest('[data-group-id]')) return;
  queueMicrotask(() => {
    syncDestinationDisplayer();
    animateReuploadSurfaceChange('#destination-account-card');
  });
});
for (const toggle of assetToggles) toggle.addEventListener('click', () => {
  selectedExplorerAssetId = null;
  animateReuploadSurfaceChange('.asset-type-card', toggle);
  const tree = document.getElementById('studio-workspace-tree');
  if (!requireStudioConnection()) {
    if (tree) tree.innerHTML = '<div class="workspace-empty">Connect to Studio first.</div>';
    return;
  }
  if (tree) tree.innerHTML = '<div class="workspace-empty">Scanning selected asset type…</div>';
  bridge.send('refreshStudioWorkspace', { assetType: toggle.dataset.type });
});
document.getElementById('destination-account-card')?.addEventListener('click', () => {
  if (getSelectedDestination() === 'user') {
    if (savedAccountsCount > 1) openAccountManager('accounts');
    return;
  }
  requestEligibleGroups();
});

// v49 follow-up polish: keep the terminal count simple. Native Shade owns request timeouts.
const previousWatchRefreshV49 = refreshWatchRows;
refreshWatchRows = function() {
  previousWatchRefreshV49();
  const rows = [...document.querySelectorAll('#logs-console .log-row')].filter(row => !row.classList.contains('log-filtered'));
  const label = document.getElementById('watch-event-count');
  if (label) label.textContent = `${rows.length} log${rows.length === 1 ? '' : 's'}`;
};
setTimeout(refreshWatchRows, 0);


// === v96 log renderer: full per-session event retention, bounded DOM and accessible paging ===
// Keep log messages in memory, but never render the whole session in a single frame.
const KAGE_V96_LOG_CAP = 30000;
const KAGE_V96_LOG_PAGE = 120;
let kageLogPages = 1;
let kageLogFlush = 0;
function kageLogMatches(level) {
  return watchFilter === 'all' || (watchFilter === 'ERROR' ? level === 'ERROR' || level === 'BUG' : level === watchFilter);
}
function kageLogRow(entry) {
  const row = document.createElement('div');
  row.className = 'log-row'; row.dataset.level = entry.level;
  const time = document.createElement('time'); time.textContent = entry.stamp;
  const badge = document.createElement('span'); badge.className = 'log-level'; badge.textContent = entry.level;
  const code = document.createElement('code');
  // Only genuine long asset IDs are colored; short counters/timestamps remain white.
  const parts = String(entry.text || '').split(/(\b\d{6,20}\b)/g);
  for (const part of parts) {
    if (/^\d{6,20}$/.test(part)) {
      const id = document.createElement('span');
      id.className = entry.level === 'ERROR' ? 'kage-log-id-failed' : 'kage-log-id-success';
      id.textContent = part; code.append(id);
    } else code.append(document.createTextNode(part));
  }
  row.append(time, badge, code); return row;
}
function renderKageLogs() {
  kageLogFlush = 0;
  const consoleEl = document.getElementById('logs-console'); if (!consoleEl) return;
  const filtered = kageLogs.filter(entry => kageLogMatches(entry.level));
  const displayed = filtered.slice(-KAGE_V96_LOG_PAGE * kageLogPages);
  const fragment = document.createDocumentFragment();
  for (const item of displayed) fragment.append(kageLogRow(item));
  consoleEl.replaceChildren(fragment);
  consoleEl.scrollTop = consoleEl.scrollHeight;
  const label = document.getElementById('watch-event-count');
  if (label) label.textContent = `${filtered.length.toLocaleString()} events · showing ${displayed.length.toLocaleString()}`;
  const older = document.getElementById('kage-log-older');
  if (older) older.hidden = filtered.length <= displayed.length;
}
function scheduleKageLogRender() {
  if (kageLogFlush || !document.getElementById('tab-watch')?.classList.contains('active')) return;
  kageLogFlush = requestAnimationFrame(renderKageLogs);
}
appendLog = function(level, message) {
  const normalized = String(level || 'INFO').toUpperCase();
  const text = String(message || '').trim(); if (!text) return;
  kageLogs.push({ level: normalized, text, stamp: new Date().toLocaleTimeString([], { hour12: false }) });
  if (kageLogs.length > KAGE_V96_LOG_CAP) kageLogs.splice(0, kageLogs.length - KAGE_V96_LOG_CAP);
  scheduleKageLogRender();
};
refreshWatchRows = renderKageLogs;
const logToolbar = document.querySelector('.logs-toolbar');
if (logToolbar && !document.getElementById('kage-log-older')) {
  const older = document.createElement('button'); older.id = 'kage-log-older';
  older.type = 'button'; older.textContent = 'Load earlier'; older.hidden = true;
  older.addEventListener('click', () => { kageLogPages++; renderKageLogs(); });
  logToolbar.append(older);
}
document.querySelectorAll('[data-log-filter]').forEach(button => button.addEventListener('click', () => {
  kageLogPages = 1;
  requestAnimationFrame(renderKageLogs);
}));
document.querySelector('.tab-btn[data-tab="watch"]')?.addEventListener('click', () => requestAnimationFrame(renderKageLogs));
document.getElementById('clear-log-view')?.addEventListener('click', () => {
  kageLogs.length = 0; kageLogPages = 1;
  requestAnimationFrame(renderKageLogs);
});
