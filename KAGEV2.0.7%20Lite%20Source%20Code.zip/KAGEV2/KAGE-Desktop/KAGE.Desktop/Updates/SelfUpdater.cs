using System.Diagnostics;
using System.IO.Compression;
using System.Text.Json;
using Kage.Security;

namespace KAGE.Desktop.Updates;

public sealed record UpdatedStartupContext(string? TemporaryUpdaterPath, string? BackupPath,
    string RepositoryRevision = "", string PackageSha256 = "", long ManifestBuildId = 0, bool UpdatedFlag = false)
{
    public bool WasUpdated => UpdatedFlag || !string.IsNullOrWhiteSpace(TemporaryUpdaterPath) || !string.IsNullOrWhiteSpace(BackupPath);
}

internal static class SelfUpdater
{
    public static bool IsApplyMode(string[] args) =>
        args.Any(arg => string.Equals(arg, "--apply-update", StringComparison.OrdinalIgnoreCase));

    public static UpdatedStartupContext ParseUpdatedStartup(string[] args)
    {
        string? updater = null;
        string? backup = null;
        string revision = "", packageSha256 = "";
        long manifestBuildId = 0;
        var updated = args.Any(arg => string.Equals(arg, "--updated", StringComparison.OrdinalIgnoreCase));
        for (var i = 0; i < args.Length; i++)
        {
            if (string.Equals(args[i], "--cleanup-updater", StringComparison.OrdinalIgnoreCase) && i + 1 < args.Length)
                updater = args[++i];
            else if (string.Equals(args[i], "--cleanup-backup", StringComparison.OrdinalIgnoreCase) && i + 1 < args.Length)
                backup = args[++i];
            else if (string.Equals(args[i], "--update-revision", StringComparison.OrdinalIgnoreCase) && i + 1 < args.Length)
                revision = UpdateChangelogStore.BoundRevision(args[++i]);
            else if (string.Equals(args[i], "--update-sha256", StringComparison.OrdinalIgnoreCase) && i + 1 < args.Length)
                packageSha256 = args[++i];
            else if (string.Equals(args[i], "--update-build-id", StringComparison.OrdinalIgnoreCase) && i + 1 < args.Length)
                long.TryParse(args[++i], out manifestBuildId);
        }
        return new UpdatedStartupContext(updater, backup, revision, packageSha256, manifestBuildId, updated);
    }

    public static int RunApplyMode(string[] args)
    {
        try
        {
            var applyIndex = Array.FindIndex(args, arg => string.Equals(arg, "--apply-update", StringComparison.OrdinalIgnoreCase));
            if (applyIndex < 0 || applyIndex + 4 >= args.Length)
                return 21;

            var packagePath = Path.GetFullPath(args[applyIndex + 1]);
            var installDirectory = Path.GetFullPath(args[applyIndex + 2]);
            if (!int.TryParse(args[applyIndex + 3], out var parentPid))
                return 22;
            var temporaryUpdaterPath = Path.GetFullPath(args[applyIndex + 4]);
            var selectedUpdate = ParseUpdatedStartup(args);
            var manifestIndex = Array.FindIndex(args, arg => arg == "--update-manifest");
            if (manifestIndex < 0 || manifestIndex + 1 >= args.Length) return 23;
            var manifestPath = Path.GetFullPath(args[manifestIndex + 1]);
            var manifest = UpdateInstallVerifier.ReadManifest(manifestPath);
            UpdateInstallVerifier.VerifyFile(packagePath, manifest.Sha256, manifest.Size);
            UpdateSupportGuard.RequireSupportedPolicyAsync().GetAwaiter().GetResult();

            WaitForParent(parentPid);
            Environment.CurrentDirectory = Path.GetTempPath();

            var updateRoot = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "KAGE",
                "Updates");
            Directory.CreateDirectory(updateRoot);

            var stageDirectory = Path.Combine(updateRoot, "stage-" + Guid.NewGuid().ToString("N"));
            var backupDirectory = Path.Combine(updateRoot, "backup-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(stageDirectory);
            UpdateInstallVerifier.ExtractVerifiedZip(packagePath, stageDirectory, manifest);

            var stagedExe = Path.Combine(stageDirectory, "KAGE.exe");
            if (!File.Exists(stagedExe))
                throw new InvalidDataException("The update package does not contain KAGE.exe.");

            if (Directory.Exists(installDirectory))
                CopyDirectory(installDirectory, backupDirectory);

            try
            {
                UpdateSupportGuard.RequireSupportedPolicyAsync().GetAwaiter().GetResult();
                UpdateInstallVerifier.VerifyFile(stagedExe, manifest.ExecutableSha256);
                ReplaceInstallDirectory(stageDirectory, installDirectory);
                var updatedExe = Path.Combine(installDirectory, "KAGE.exe");
                var process = new ProcessStartInfo
                {
                    FileName = updatedExe,
                    UseShellExecute = true,
                    WorkingDirectory = installDirectory
                };
                process.ArgumentList.Add("--updated");
                process.ArgumentList.Add("--cleanup-updater");
                process.ArgumentList.Add(temporaryUpdaterPath);
                process.ArgumentList.Add("--cleanup-backup");
                process.ArgumentList.Add(backupDirectory);
                AddUpdateIdentity(process, selectedUpdate.RepositoryRevision, selectedUpdate.PackageSha256, selectedUpdate.ManifestBuildId);
                UpdateInstallVerifier.VerifyFile(updatedExe, manifest.ExecutableSha256);
                UpdateSupportGuard.RequireSupportedPolicyAsync().GetAwaiter().GetResult();
                Process.Start(process);
            }
            catch
            {
                if (Directory.Exists(backupDirectory))
                    ReplaceInstallDirectory(backupDirectory, installDirectory);
                throw;
            }
            finally
            {
                TryDeleteDirectory(stageDirectory);
                TryDeleteFile(packagePath);
                TryDeleteFile(manifestPath);
            }

            return 0;
        }
        catch
        {
            return 29;
        }
    }

    public static string CreateTemporaryUpdaterCopy()
    {
        if (KageSupportPolicy.IsBlocked) throw new UnauthorizedAccessException("KAGE access is disabled.");
        var processPath = Environment.ProcessPath ?? throw new InvalidOperationException("KAGE executable path is unavailable.");
        var destination = Path.Combine(Path.GetTempPath(), $"KAGE-Updater-{Guid.NewGuid():N}.exe");
        File.Copy(processPath, destination, true);
        return destination;
    }

    public static void LaunchTemporaryUpdater(string temporaryUpdaterPath, string packagePath, AvailableUpdate? update = null)
    {
        if (KageSupportPolicy.IsBlocked || update is null || !UpdateSignatureVerifier.Verify(update.Manifest) ||
            !UpdateReleasePolicy.CanAutomaticallyInstall(update.Manifest.ReleaseVersion, update.Manifest.ProtocolGeneration))
            throw new InvalidDataException("An authenticated supported update is required.");
        UpdateInstallVerifier.VerifyFile(packagePath, update.Manifest.Sha256, update.Manifest.Size);
        var manifestPath = Path.GetFullPath(packagePath) + ".manifest.json";
        File.WriteAllBytes(manifestPath, JsonSerializer.SerializeToUtf8Bytes(update.Manifest, new JsonSerializerOptions(JsonSerializerDefaults.Web)));
        UpdateInstallVerifier.ReadManifest(manifestPath);
        var processPath = Environment.ProcessPath ?? throw new InvalidOperationException("KAGE executable path is unavailable.");
        var installDirectory = Path.GetDirectoryName(processPath) ?? AppContext.BaseDirectory;
        var start = new ProcessStartInfo
        {
            FileName = temporaryUpdaterPath,
            UseShellExecute = true,
            WorkingDirectory = Path.GetTempPath()
        };
        start.ArgumentList.Add("--apply-update");
        start.ArgumentList.Add(Path.GetFullPath(packagePath));
        start.ArgumentList.Add(Path.GetFullPath(installDirectory));
        start.ArgumentList.Add(Environment.ProcessId.ToString());
        start.ArgumentList.Add(Path.GetFullPath(temporaryUpdaterPath));
        start.ArgumentList.Add("--update-manifest");
        start.ArgumentList.Add(manifestPath);
        if (update is not null)
            AddUpdateIdentity(start, update.RepositoryRevision, update.Manifest.Sha256, update.Manifest.BuildId);
        if (update is not null) UpdateChangelogStore.Current().Prepare(update, packagePath);
        Process.Start(start);
    }

    private static void AddUpdateIdentity(ProcessStartInfo start, string revision, string packageSha256, long manifestBuildId)
    {
        revision = UpdateChangelogStore.BoundRevision(revision);
        if (revision.Length > 0)
        {
            start.ArgumentList.Add("--update-revision");
            start.ArgumentList.Add(revision);
        }
        if (GitHubUpdateClient.IsHash(packageSha256, 64))
        {
            start.ArgumentList.Add("--update-sha256");
            start.ArgumentList.Add(packageSha256);
        }
        if (manifestBuildId > 0)
        {
            start.ArgumentList.Add("--update-build-id");
            start.ArgumentList.Add(manifestBuildId.ToString(System.Globalization.CultureInfo.InvariantCulture));
        }
    }

    public static async Task CleanupAfterSuccessfulStartupAsync(UpdatedStartupContext context)
    {
        if (!context.WasUpdated)
            return;

        await Task.Delay(TimeSpan.FromSeconds(4));
        if (!string.IsNullOrWhiteSpace(context.BackupPath))
            TryDeleteDirectory(context.BackupPath);
        if (!string.IsNullOrWhiteSpace(context.TemporaryUpdaterPath))
            TryDeleteFile(context.TemporaryUpdaterPath);
    }

    private static void WaitForParent(int parentPid)
    {
        try
        {
            using var process = Process.GetProcessById(parentPid);
            if (!process.WaitForExit(60_000)) throw new InvalidOperationException("KAGE did not exit before the update could be applied.");
        }
        catch (ArgumentException)
        {
            // Parent already exited.
        }
    }

    private static void ReplaceInstallDirectory(string sourceDirectory, string installDirectory)
    {
        // Apply the protected update as an overlay. This intentionally preserves local
        // sidecars such as DiscordBot and any non-update files that are not shipped in
        // the public GitHub update package.
        Directory.CreateDirectory(installDirectory);
        CopyDirectory(sourceDirectory, installDirectory);
    }

    private static void CopyDirectory(string source, string destination)
    {
        Directory.CreateDirectory(destination);
        foreach (var directory in Directory.GetDirectories(source, "*", SearchOption.AllDirectories))
        {
            var relative = Path.GetRelativePath(source, directory);
            Directory.CreateDirectory(Path.Combine(destination, relative));
        }
        foreach (var file in Directory.GetFiles(source, "*", SearchOption.AllDirectories))
        {
            var relative = Path.GetRelativePath(source, file);
            var target = Path.Combine(destination, relative);
            Directory.CreateDirectory(Path.GetDirectoryName(target)!);
            File.Copy(file, target, true);
        }
    }

    private static void TryDeleteDirectory(string? path)
    {
        try
        {
            if (!string.IsNullOrWhiteSpace(path) && Directory.Exists(path))
                Directory.Delete(path, true);
        }
        catch { }
    }

    private static void TryDeleteFile(string? path)
    {
        try
        {
            if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
                File.Delete(path);
        }
        catch { }
    }
}
