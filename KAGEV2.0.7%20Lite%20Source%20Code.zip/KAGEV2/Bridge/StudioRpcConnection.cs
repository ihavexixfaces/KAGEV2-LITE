using System.Collections.Concurrent;
using System.Text.Json;

namespace Kage.Bridge;

/// <summary>One stdio session. A single reader dispatches replies by ID, including late replies.</summary>
internal sealed class StudioRpcConnection : IAsyncDisposable
{
    private readonly StreamWriter _input;
    private readonly StreamReader _output;
    private readonly Action<string>? _diagnostic;
    private readonly SemaphoreSlim _writeGate = new(1, 1);
    private readonly CancellationTokenSource _lifetime = new();
    private readonly CancellationToken _lifetimeToken;
    private readonly ConcurrentDictionary<long, TaskCompletionSource<JsonElement>> _pending = new();
    private readonly Task _reader;
    private long _nextId;
    private int _closed;

    public StudioRpcConnection(StreamWriter input, StreamReader output, Action<string>? diagnostic = null)
    {
        _input = input;
        _output = output;
        _diagnostic = diagnostic;
        _lifetimeToken = _lifetime.Token;
        _reader = ReadResponsesAsync();
    }

    public bool IsOpen => Volatile.Read(ref _closed) == 0;

    public async Task<JsonElement> RequestAsync(string method, object parameters, TimeSpan timeout, CancellationToken ct)
    {
        if (!IsOpen) throw new IOException("Roblox Studio MCP connection closed.");
        ct.ThrowIfCancellationRequested();
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(ct, _lifetimeToken);
        deadline.CancelAfter(timeout);
        var id = Interlocked.Increment(ref _nextId);
        var completion = new TaskCompletionSource<JsonElement>(TaskCreationOptions.RunContinuationsAsynchronously);
        _pending[id] = completion;
        try
        {
            await WriteAsync(JsonSerializer.Serialize(new { jsonrpc = "2.0", id, method, @params = parameters }), deadline.Token).ConfigureAwait(false);
            return await completion.Task.WaitAsync(deadline.Token).ConfigureAwait(false);
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested && !IsOpen)
        {
            throw new IOException("Roblox Studio MCP disconnected during the request.");
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested)
        {
            throw new TimeoutException($"Roblox Studio MCP '{method}' did not respond within {timeout.TotalSeconds:0} seconds. Reconnect Studio and retry.");
        }
        finally { _pending.TryRemove(id, out _); }
    }

    public Task NotifyAsync(string method, object parameters, CancellationToken ct) =>
        WriteAsync(JsonSerializer.Serialize(new { jsonrpc = "2.0", method, @params = parameters }), ct);

    private async Task WriteAsync(string line, CancellationToken ct)
    {
        using var linked = CancellationTokenSource.CreateLinkedTokenSource(ct, _lifetimeToken);
        await _writeGate.WaitAsync(linked.Token).ConfigureAwait(false);
        try
        {
            if (!IsOpen) throw new IOException("Roblox Studio MCP connection closed.");
            await _input.WriteLineAsync(line.AsMemory(), linked.Token).ConfigureAwait(false);
            await _input.FlushAsync(linked.Token).ConfigureAwait(false);
        }
        finally { _writeGate.Release(); }
    }

    private async Task ReadResponsesAsync()
    {
        try
        {
            while (!_lifetimeToken.IsCancellationRequested)
            {
                var line = await _output.ReadLineAsync(_lifetimeToken).ConfigureAwait(false);
                if (line is null) throw new IOException("Roblox Studio MCP closed its output stream.");
                if (string.IsNullOrWhiteSpace(line)) continue;
                JsonDocument document;
                try { document = JsonDocument.Parse(line); }
                catch (JsonException) { _diagnostic?.Invoke(line.Trim()); continue; }
                using (document)
                {
                    var root = document.RootElement;
                    if (root.ValueKind != JsonValueKind.Object || !root.TryGetProperty("id", out var identifier) ||
                        identifier.ValueKind != JsonValueKind.Number || !identifier.TryGetInt64(out var id) ||
                        !_pending.TryRemove(id, out var completion)) continue;
                    if (root.TryGetProperty("error", out var error) && error.ValueKind != JsonValueKind.Null)
                    {
                        var detail = error.ValueKind == JsonValueKind.Object && error.TryGetProperty("message", out var message)
                            ? message.ToString() : error.ToString();
                        completion.TrySetException(new InvalidOperationException($"Roblox Studio MCP error: {detail}"));
                    }
                    else if (root.TryGetProperty("result", out var result)) completion.TrySetResult(result.Clone());
                    else completion.TrySetException(new InvalidOperationException("Roblox Studio MCP returned no result."));
                }
            }
        }
        catch (OperationCanceledException) when (_lifetimeToken.IsCancellationRequested) { }
        catch (Exception ex) { _diagnostic?.Invoke(ex.Message); }
        finally { Abort(); }
    }

    public void Abort()
    {
        if (Interlocked.Exchange(ref _closed, 1) != 0) return;
        _lifetime.Cancel();
        foreach (var pair in _pending)
            if (_pending.TryRemove(pair.Key, out var pending)) pending.TrySetException(new IOException("Roblox Studio MCP connection closed."));
    }

    public async ValueTask DisposeAsync()
    {
        Abort();
        try { await _reader.ConfigureAwait(false); } catch { }
        // Readers/writers are owned by the launcher. Do not dispose cancellation
        // sources/semaphores while canceled callers are still unwinding.
    }
}
