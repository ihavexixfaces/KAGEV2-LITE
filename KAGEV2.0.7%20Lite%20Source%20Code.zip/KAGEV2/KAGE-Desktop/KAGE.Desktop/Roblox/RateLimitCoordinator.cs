using System.Globalization;
using System.Net;
using System.Net.Http;

namespace Kage.Roblox;

/// <summary>
/// Endpoint-local rate-limit coordinator.
///
/// 2.0.5 rule: only authoritative server guidance can create a long pause.
/// - Retry-After is authoritative and is honored.
/// - x-ratelimit-remaining == 0 is authoritative quota exhaustion; wait for reset.
/// - A 429 with remaining > 0 (or no remaining header) is treated as a transient /
///   undocumented throttle. It must NOT zero the documented quota or force a full
///   x-ratelimit-reset sleep. The caller performs short jittered backoff instead.
///
/// Healthy requests are never continuously spaced by this coordinator.
/// </summary>
public sealed class RateLimitCoordinator
{
    private const int FinalPermitReserve = 2;

    private readonly object _sync = new();
    private DateTimeOffset _resumeAt = DateTimeOffset.MinValue;
    private DateTimeOffset _quotaResetAt = DateTimeOffset.MinValue;
    private double? _quotaLimit;
    private double? _quotaRemaining;
    private long _rateLimitHits;
    private long _proactivePauses;
    private long _authoritativeQuotaPauses;
    private long _transient429s;
    private readonly bool _proactiveQuotaPauses;

    public RateLimitCoordinator(int inFlightReserve = 8, bool proactiveQuotaPauses = true)
    {
        _ = inFlightReserve;
        _proactiveQuotaPauses = proactiveQuotaPauses;
    }

    public long RateLimitHits => Interlocked.Read(ref _rateLimitHits);
    public long ProactivePauses => Interlocked.Read(ref _proactivePauses);
    public long AuthoritativeQuotaPauses => Interlocked.Read(ref _authoritativeQuotaPauses);
    public long Transient429s => Interlocked.Read(ref _transient429s);

    public async Task WaitAsync(CancellationToken ct)
    {
        while (true)
        {
            DateTimeOffset waitUntil;

            lock (_sync)
            {
                var now = DateTimeOffset.UtcNow;
                RefreshExpiredWindowNoLock(now);

                if (_resumeAt > now)
                {
                    waitUntil = _resumeAt;
                }
                else if (_proactiveQuotaPauses &&
                         _quotaRemaining.HasValue &&
                         _quotaResetAt > now &&
                         _quotaRemaining.Value <= FinalPermitReserve)
                {
                    if (_quotaRemaining.Value >= 1)
                    {
                        // Consume the final reported permits immediately. No smoothing.
                        _quotaRemaining = Math.Max(0, _quotaRemaining.Value - 1);
                        return;
                    }

                    waitUntil = _quotaResetAt + TimeSpan.FromMilliseconds(10);
                    Interlocked.Increment(ref _proactivePauses);
                }
                else
                {
                    return;
                }
            }

            var delay = waitUntil - DateTimeOffset.UtcNow;
            if (delay > TimeSpan.Zero)
                await Task.Delay(delay, ct);
        }
    }

    /// <summary>
    /// Observes one response. Returns a server-directed delay only when Roblox gave
    /// authoritative pause guidance (Retry-After or explicit remaining==0 + reset).
    /// A bare/undocumented 429 intentionally returns null so the caller uses short backoff.
    /// </summary>
    public TimeSpan? Observe(HttpResponseMessage response)
    {
        var now = DateTimeOffset.UtcNow;
        var hasRemaining = TryGetMinimumHeaderNumber(response, "x-ratelimit-remaining", out var responseRemaining) && responseRemaining >= 0;

        lock (_sync)
        {
            RefreshExpiredWindowNoLock(now);
            ObserveQuotaHeadersNoLock(response, now);
        }

        if (response.StatusCode != HttpStatusCode.TooManyRequests)
            return null;

        Interlocked.Increment(ref _rateLimitHits);

        // Retry-After is Roblox's explicit instruction for a 429. Honor it globally.
        var retryAfter = GetRetryAfter(response);
        if (retryAfter.HasValue)
        {
            var pause = Clamp429Delay(retryAfter.Value);
            PauseFor(pause + TimeSpan.FromMilliseconds(Random.Shared.Next(10, 40)));
            return pause;
        }

        // Only treat the documented quota as exhausted if the response actually says 0.
        // This is the key 2.0.5 fix: an undocumented/stability 429 with quota remaining
        // no longer turns into a fake 30-60 second reset-window freeze.
        if (hasRemaining && responseRemaining <= 0)
        {
            var reset = GetRateLimitResetDelay(response);
            if (reset.HasValue)
            {
                var pause = Clamp429Delay(reset.Value);
                lock (_sync)
                {
                    _quotaRemaining = 0;
                    if (_quotaResetAt <= now)
                        _quotaResetAt = now + pause;
                }
                Interlocked.Increment(ref _authoritativeQuotaPauses);
                return pause;
            }
        }

        Interlocked.Increment(ref _transient429s);
        return null;
    }

    public void PauseFor(TimeSpan delay)
    {
        if (delay <= TimeSpan.Zero) return;
        if (delay > TimeSpan.FromSeconds(60)) delay = TimeSpan.FromSeconds(60);

        var candidate = DateTimeOffset.UtcNow + delay;
        lock (_sync)
        {
            if (candidate > _resumeAt)
                _resumeAt = candidate;
        }
    }

    /// <summary>
    /// For exception metadata, expose only Retry-After. x-ratelimit-reset is quota state,
    /// not a generic retry delay for every 429.
    /// </summary>
    public static TimeSpan? GetServerDelay(HttpResponseMessage response) => GetRetryAfter(response);

    private void ObserveQuotaHeadersNoLock(HttpResponseMessage response, DateTimeOffset now)
    {
        var haveLimit = TryGetMinimumHeaderNumber(response, "x-ratelimit-limit", out var limit) && limit > 0;
        var haveRemaining = TryGetMinimumHeaderNumber(response, "x-ratelimit-remaining", out var remaining) && remaining >= 0;
        var haveReset = TryGetMinimumHeaderNumber(response, "x-ratelimit-reset", out var rawReset) && rawReset > 0;

        if (haveLimit)
            _quotaLimit = limit;

        if (haveReset)
        {
            var resetDelay = ParseResetValue(rawReset, now);
            if (resetDelay > TimeSpan.Zero)
            {
                var candidateReset = now + resetDelay;

                // Newer window: discard remaining from the previous generation.
                if (_quotaResetAt != DateTimeOffset.MinValue &&
                    candidateReset > _quotaResetAt + TimeSpan.FromSeconds(2))
                {
                    _quotaRemaining = null;
                }

                _quotaResetAt = candidateReset;
            }
        }

        if (haveRemaining)
        {
            // Concurrent responses can arrive out of order. Keep the lowest remaining
            // number observed for the current quota window.
            _quotaRemaining = _quotaRemaining.HasValue
                ? Math.Min(_quotaRemaining.Value, remaining)
                : remaining;
        }
    }

    private void RefreshExpiredWindowNoLock(DateTimeOffset now)
    {
        if (_quotaResetAt == DateTimeOffset.MinValue || now < _quotaResetAt)
            return;

        _quotaRemaining = null;
        _quotaResetAt = DateTimeOffset.MinValue;
        if (_resumeAt <= now)
            _resumeAt = DateTimeOffset.MinValue;
    }

    private static TimeSpan? GetRetryAfter(HttpResponseMessage response)
    {
        if (response.Headers.RetryAfter?.Delta is TimeSpan delta && delta > TimeSpan.Zero)
            return ClampRetryAfter(delta);

        if (response.Headers.RetryAfter?.Date is DateTimeOffset date)
        {
            var until = date - DateTimeOffset.UtcNow;
            if (until > TimeSpan.Zero)
                return ClampRetryAfter(until);
        }

        return null;
    }

    private static TimeSpan? GetRateLimitResetDelay(HttpResponseMessage response)
    {
        if (!TryGetMinimumHeaderNumber(response, "x-ratelimit-reset", out var rawReset) || rawReset <= 0)
            return null;

        var delay = ParseResetValue(rawReset, DateTimeOffset.UtcNow);
        return delay > TimeSpan.Zero ? ClampRetryAfter(delay) : null;
    }

    private static TimeSpan ParseResetValue(double value, DateTimeOffset now)
    {
        if (value > 1_000_000_000_000)
            return DateTimeOffset.FromUnixTimeMilliseconds((long)value) - now;
        if (value > 1_000_000_000)
            return DateTimeOffset.FromUnixTimeSeconds((long)value) - now;
        return TimeSpan.FromSeconds(value);
    }

    private static bool TryGetMinimumHeaderNumber(HttpResponseMessage response, string name, out double value)
    {
        value = 0;
        if (!response.Headers.TryGetValues(name, out var values)) return false;

        var found = false;
        var min = double.MaxValue;
        foreach (var raw in values)
        {
            foreach (var part in raw.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
            {
                var numeric = part.Split(';', 2)[0].Trim();
                if (!double.TryParse(numeric, NumberStyles.Float, CultureInfo.InvariantCulture, out var parsed))
                    continue;

                found = true;
                min = Math.Min(min, parsed);
            }
        }

        if (!found) return false;
        value = min;
        return true;
    }

    private static TimeSpan ClampRetryAfter(TimeSpan value)
    {
        if (value < TimeSpan.FromMilliseconds(50)) return TimeSpan.FromMilliseconds(50);
        if (value > TimeSpan.FromSeconds(60)) return TimeSpan.FromSeconds(60);
        return value;
    }

    private static TimeSpan Clamp429Delay(TimeSpan value)
    {
        if (value < TimeSpan.FromMilliseconds(100)) return TimeSpan.FromMilliseconds(100);
        if (value > TimeSpan.FromSeconds(60)) return TimeSpan.FromSeconds(60);
        return value;
    }
}
