using System.Runtime.CompilerServices;
using System.Text.Json;

namespace KAGE.Desktop.Shade;

internal static class SseReader
{
    public static async IAsyncEnumerable<ShadeStreamEvent> ReadAsync(
        Stream stream,
        [EnumeratorCancellation] CancellationToken ct = default)
    {
        using var reader = new StreamReader(stream);
        string? eventName = null;
        var data = new List<string>();

        while (true)
        {
            var line = await reader.ReadLineAsync(ct).ConfigureAwait(false);
            if (line is null)
            {
                var final = TryParseEvent(eventName, data);
                if (final is not null) yield return final;
                yield break;
            }

            // SSE comments are commonly used as provider/edge heartbeats. Surface
            // them as activity so the native inactivity timer is not allowed to
            // cancel a healthy request while the model is still generating.
            if (line.StartsWith(':'))
            {
                yield return new ShadeStreamEvent("heartbeat");
                continue;
            }

            if (line.Length == 0)
            {
                var parsed = TryParseEvent(eventName, data);
                if (parsed is not null) yield return parsed;
                eventName = null;
                data.Clear();
                continue;
            }

            if (line.StartsWith("event:", StringComparison.OrdinalIgnoreCase))
                eventName = line[6..].Trim();
            else if (line.StartsWith("data:", StringComparison.OrdinalIgnoreCase))
                data.Add(line[5..].TrimStart());
        }
    }

    private static ShadeStreamEvent? TryParseEvent(string? eventName, List<string> dataLines)
    {
        var kind = string.IsNullOrWhiteSpace(eventName) ? "message" : eventName.Trim().ToLowerInvariant();
        if (kind is "ping" or "heartbeat" or "keepalive" or "keep-alive")
            return new ShadeStreamEvent("heartbeat");

        var payload = string.Join("\n", dataLines).Trim();
        if (string.Equals(payload, "[DONE]", StringComparison.OrdinalIgnoreCase))
            return new ShadeStreamEvent("done");
        if (payload.Length == 0)
            return kind is "start" or "done" ? new ShadeStreamEvent(kind) : null;

        // Preserve useful plain-text deltas from older/compatible workers.
        if (kind == "delta" && !payload.StartsWith('{') && !payload.StartsWith('['))
            return new ShadeStreamEvent("delta", payload);

        try
        {
            using var doc = JsonDocument.Parse(payload);
            var root = doc.RootElement;
            if (root.ValueKind != JsonValueKind.Object) return null;

            if (kind == "message")
            {
                if (root.TryGetProperty("kind", out var kindValue) && kindValue.ValueKind == JsonValueKind.String)
                    kind = kindValue.GetString()?.Trim().ToLowerInvariant() ?? "message";
                else if (root.TryGetProperty("event", out var eventValue) && eventValue.ValueKind == JsonValueKind.String)
                    kind = eventValue.GetString()?.Trim().ToLowerInvariant() ?? "message";
                else if (root.TryGetProperty("type", out var typeValue) && typeValue.ValueKind == JsonValueKind.String)
                    kind = typeValue.GetString()?.Trim().ToLowerInvariant() ?? "message";
                else if (root.TryGetProperty("text", out _))
                    kind = "delta";
            }

            if (kind is "ping" or "heartbeat" or "keepalive" or "keep-alive")
                return new ShadeStreamEvent("heartbeat");
            if (kind is not ("start" or "delta" or "done" or "error"))
                return null; // One unknown provider event must not destroy the conversation.

            var text = root.TryGetProperty("text", out var textValue) && textValue.ValueKind == JsonValueKind.String
                ? textValue.GetString()
                : null;
            var error = root.TryGetProperty("error", out var errorValue) && errorValue.ValueKind == JsonValueKind.String
                ? errorValue.GetString()
                : null;
            return new ShadeStreamEvent(kind, text, error);
        }
        catch (JsonException)
        {
            // Ignore one malformed SSE frame and continue. The caller still rejects
            // a stream that reaches EOF without ever producing usable content.
            return null;
        }
    }
}
