// v58 — final identity paint safety net. The primary app.js handler owns state;
// this only guarantees late-loaded identity surfaces receive the same accountInfo.
(() => {
  'use strict';
  if (new URLSearchParams(location.search).get('shadePopout') === '1') return;

  function paintRobloxAvatar(data) {
    const avatar = String(data?.roblox?.avatar || '').trim();
    const node = document.getElementById('settings-roblox-avatar');
    if (node) node.style.backgroundImage = avatar ? `url("${avatar.replace(/["\\]/g, '')}")` : 'none';
  }

  try {
    window.chrome?.webview?.addEventListener?.('message', event => {
      const payload = event?.data;
      if (payload?.event !== 'accountInfo') return;
      paintRobloxAvatar(payload.data);
      window.__kagePaintDiscordIdentity?.(payload.data);
    });
  } catch { }

  const previous = window.updateAccountInfo;
  if (typeof previous === 'function' && !previous.__v58IdentityWrapped) {
    const wrapped = function(data) {
      previous(data);
      paintRobloxAvatar(data);
      window.__kagePaintDiscordIdentity?.(data);
    };
    wrapped.__v58IdentityWrapped = true;
    window.updateAccountInfo = wrapped;
  }
})();
