param(
    [ValidateSet('Standalone', 'Compact')]
    [string]$BuildMode = 'Standalone',
    [switch]$KeepStaging
)
$ErrorActionPreference = 'Stop'
$builder = Join-Path (Split-Path -Parent $PSScriptRoot) 'Scripts\Build-KageRelease.ps1'
& $builder -BuildMode $BuildMode -KeepStaging:$KeepStaging
exit $LASTEXITCODE
