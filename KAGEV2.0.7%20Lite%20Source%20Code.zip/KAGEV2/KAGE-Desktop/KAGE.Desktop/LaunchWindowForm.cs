using System.Diagnostics;
using System.Runtime.InteropServices;

namespace KAGE.Desktop;

/// <summary>A blank shell at the exact bounds of the main window during startup.</summary>
internal sealed class LaunchWindowForm : Form
{
    [DllImport("gdi32.dll")]
    private static extern IntPtr CreateRoundRectRgn(int left, int top, int right, int bottom, int width, int height);
    [DllImport("gdi32.dll")]
    private static extern bool DeleteObject(IntPtr handle);

    internal LaunchWindowForm()
    {
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        ShowInTaskbar = false;
        BackColor = Color.Black;
        Opacity = 0d;
        DoubleBuffered = true;
        AutoScaleMode = AutoScaleMode.None;
        Resize += (_, _) => RoundCorners();
    }

    protected override bool ShowWithoutActivation => true;

    private void RoundCorners()
    {
        if (Width <= 0 || Height <= 0) return;
        // The main KAGE window uses the same 24-pixel corner ellipse.
        var handle = CreateRoundRectRgn(0, 0, Width + 1, Height + 1, 24, 24);
        if (handle == IntPtr.Zero) return;
        try
        {
            var previous = Region;
            Region = System.Drawing.Region.FromHrgn(handle);
            previous?.Dispose();
        }
        finally { DeleteObject(handle); }
    }

    internal async Task OpenAsync(Rectangle targetBounds)
    {
        const double durationMs = 320d;
        Bounds = ScaleBounds(targetBounds, .94d);
        Show();
        var clock = Stopwatch.StartNew();
        while (!IsDisposed && clock.Elapsed.TotalMilliseconds < durationMs)
        {
            var raw = Math.Clamp(clock.Elapsed.TotalMilliseconds / durationMs, 0d, 1d);
            var eased = 1d - Math.Pow(1d - raw, 3d);
            Bounds = ScaleBounds(targetBounds, .94d + .06d * eased);
            Opacity = eased;
            await Task.Delay(8);
        }
        if (!IsDisposed)
        {
            Bounds = targetBounds;
            Opacity = 1d;
        }
    }

    private static Rectangle ScaleBounds(Rectangle bounds, double scale)
    {
        var width = Math.Max(1, (int)Math.Round(bounds.Width * scale));
        var height = Math.Max(1, (int)Math.Round(bounds.Height * scale));
        return new Rectangle(bounds.Left + (bounds.Width - width) / 2,
            bounds.Top + (bounds.Height - height) / 2, width, height);
    }
}
