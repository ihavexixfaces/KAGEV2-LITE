namespace Kage.Bridge;

public enum StudioConnectionState
{
    StudioNotInstalled,
    StudioNotRunning,
    StudioDetected,
    Connecting,
    StudioConnected,
    ConnectionLost,
    ConnectionFailed
}

public sealed record StudioConnectionSnapshot(
    StudioConnectionState State,
    string StatusText,
    StudioProjectInfo? Project,
    string? Error = null,
    string? Activity = null,
    string? ActivityError = null);

/// <summary>
/// Owns one reusable connection to the user's open Studio place. Transport/session
/// health is intentionally independent from reupload/scan activity: a failed scan
/// must never make a healthy MCP session look disconnected.
/// </summary>
public sealed class StudioSessionManager : IAsyncDisposable
{
    private readonly StudioMcpWorkspaceService _workspace = new();
    private readonly Func<bool> _isStudioRunning;
    private readonly CancellationTokenSource _shutdown = new();
    private readonly SemaphoreSlim _connectGate = new(1, 1);
    private Task? _monitorTask;
    private StudioConnectionSnapshot _snapshot = new(StudioConnectionState.StudioNotRunning, "Studio Not Running", null);
    private int _healthyPolls;
    private int _failedPolls;
    private int _disposed;

    public event Action<StudioConnectionSnapshot>? StateChanged;
    public StudioConnectionSnapshot Snapshot => _snapshot;
    public StudioMcpWorkspaceService Workspace => _workspace;
    public bool AutoReconnectArmed { get; private set; }

    public StudioSessionManager(Func<bool>? isStudioRunning = null)
    {
        _isStudioRunning = isStudioRunning ?? StudioExecutableLocator.IsStudioRunning;
    }

    public void Start()
    {
        ObjectDisposedException.ThrowIf(Volatile.Read(ref _disposed) != 0, this);
        var token = _shutdown.Token;
        _monitorTask ??= Task.Run(() => MonitorAsync(token));
    }

    public async Task<StudioProjectInfo> ConnectByUserAsync(CancellationToken ct = default)
    {
        ObjectDisposedException.ThrowIf(Volatile.Read(ref _disposed) != 0, this);
        ct.ThrowIfCancellationRequested();
        // Starting Roblox's MCP launcher can open Studio. A manual Connect must
        // attach to an editor the user already opened instead of launching one.
        if (!_isStudioRunning())
        {
            if (_workspace.IsConnected) await _workspace.DisconnectAsync().ConfigureAwait(false);
            Publish(new StudioConnectionSnapshot(StudioConnectionState.ConnectionFailed, "Connection Failed", null, OpenProjectRequiredError));
            throw new InvalidOperationException(OpenProjectRequiredError);
        }

        try
        {
            var project = await ConnectWithTimeoutAsync(ct).ConfigureAwait(false);
            AutoReconnectArmed = true;
            return project;
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested || _shutdown.IsCancellationRequested) { throw; }
        catch (Exception ex)
        {
            // Failed discovery/read can leave MCP connected without a usable
            // editor. Clear it before publishing the failed manual handshake.
            await _workspace.DisconnectAsync().ConfigureAwait(false);
            var message = ex is OperationCanceledException
                ? "Failed to connect to Roblox Studio. Keep a game/project open and enable Studio as MCP server, then retry."
                : SanitizeError(ex.Message);
            Publish(new StudioConnectionSnapshot(StudioConnectionState.ConnectionFailed, "Connection Failed", null, message));
            throw new InvalidOperationException(message, ex);
        }
    }

    /// <summary>Compatibility entry point for native operations after a user-created session.</summary>
    public Task<StudioProjectInfo> EnsureConnectedAsync(CancellationToken ct = default)
    {
        if (_workspace.IsConnected && _workspace.Project is { } project)
            return Task.FromResult(project);
        if (!AutoReconnectArmed)
            throw new InvalidOperationException("Connect to Roblox Studio first.");
        return ConnectWithTimeoutAsync(ct);
    }

    public void ReportWorkspaceActivity(string text)
    {
        var state = _workspace.IsConnected ? StudioConnectionState.StudioConnected : _snapshot.State;
        Publish(_snapshot with
        {
            State = state,
            StatusText = state == StudioConnectionState.StudioConnected ? "Studio Connected" : _snapshot.StatusText,
            Project = _workspace.Project ?? _snapshot.Project,
            Activity = text,
            ActivityError = null
        });
    }

    public void ReportWorkspaceError(string message)
    {
        var state = _workspace.IsConnected ? StudioConnectionState.StudioConnected : _snapshot.State;
        Publish(_snapshot with
        {
            State = state,
            StatusText = state == StudioConnectionState.StudioConnected ? "Studio Connected" : _snapshot.StatusText,
            Project = _workspace.Project ?? _snapshot.Project,
            Activity = "Scan Failed",
            ActivityError = SanitizeError(message)
        });
    }

    // Kept for older reupload call sites. Connected states are mapped to activity only.
    public void SetActivity(StudioConnectionState state, string text)
    {
        if (_workspace.IsConnected && state is not StudioConnectionState.ConnectionLost and not StudioConnectionState.ConnectionFailed)
        {
            ReportWorkspaceActivity(text);
            return;
        }
        Publish(new StudioConnectionSnapshot(state, text, _workspace.Project, _snapshot.Error, text, null));
    }

    public async Task DisconnectAsync(bool userInitiated = true)
    {
        if (userInitiated) AutoReconnectArmed = false;
        await _workspace.DisconnectAsync().ConfigureAwait(false);
        var studioRunning = _isStudioRunning();
        Publish(new StudioConnectionSnapshot(
            studioRunning ? StudioConnectionState.StudioDetected : StudioConnectionState.StudioNotRunning,
            studioRunning ? "Studio Detected" : "Studio Not Running",
            null));
    }

    private async Task<StudioProjectInfo> ConnectWithTimeoutAsync(CancellationToken ct)
    {
        ObjectDisposedException.ThrowIf(Volatile.Read(ref _disposed) != 0, this);
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct, _shutdown.Token);
        timeout.CancelAfter(TimeSpan.FromSeconds(30));
        return await ConnectCoreAsync(timeout.Token).ConfigureAwait(false);
    }

    private async Task MonitorAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try
            {
                var studioInstalled = StudioExecutableLocator.IsStudioAvailable();
                var studioRunning = studioInstalled && _isStudioRunning();

                if (!studioRunning && _snapshot.State == StudioConnectionState.ConnectionFailed && _snapshot.Error == OpenProjectRequiredError)
                {
                    // Keep the user's failed manual Connect visible while Studio
                    // remains closed. Detection/retry/Disconnect clears it later.
                    if (_workspace.IsConnected) await _workspace.DisconnectAsync().ConfigureAwait(false);
                }
                else if (!studioInstalled)
                {
                    if (_workspace.IsConnected) await _workspace.DisconnectAsync().ConfigureAwait(false);
                    Publish(new StudioConnectionSnapshot(StudioConnectionState.StudioNotInstalled, "Studio Not Installed", null));
                }
                else if (!studioRunning)
                {
                    if (_workspace.IsConnected)
                    {
                        Publish(_snapshot with { State = StudioConnectionState.ConnectionLost, StatusText = "Connection Lost", Error = "Roblox Studio closed." });
                        await _workspace.DisconnectAsync().ConfigureAwait(false);
                    }
                    else
                    {
                        Publish(new StudioConnectionSnapshot(StudioConnectionState.StudioNotRunning, "Studio Not Running", null));
                    }
                }
                else if (!_workspace.IsConnected)
                {
                    // First connection is always user initiated. After one successful manual
                    // connection, reconnecting is safe and automatic for this process lifetime.
                    if (!AutoReconnectArmed)
                    {
                        Publish(new StudioConnectionSnapshot(StudioConnectionState.StudioDetected, "Studio Detected", _snapshot.Project));
                    }
                    else
                    {
                        try
                        {
                            await ConnectWithTimeoutAsync(ct).ConfigureAwait(false);
                        }
                        catch (OperationCanceledException) when (!ct.IsCancellationRequested)
                        {
                            Publish(_snapshot with { State = StudioConnectionState.ConnectionFailed, StatusText = "Reconnecting…", Error = "Studio reconnect timed out." });
                        }
                        catch (Exception ex)
                        {
                            Publish(_snapshot with { State = StudioConnectionState.ConnectionFailed, StatusText = "Reconnecting…", Error = SanitizeError(ex.Message) });
                        }
                    }
                }
                else if (_workspace.IsOperationBusy)
                {
                    // Scans, preview loads and reference writes serialize through the
                    // workspace gate. Do not let the two-second health monitor enqueue a
                    // competing RPC and retire a perfectly healthy MCP session on timeout.
                    if (_workspace.Project is { } busyProject)
                        Publish(_snapshot with { State = StudioConnectionState.StudioConnected, StatusText = "Studio Connected", Project = busyProject, Error = null });
                }
                else if (!await _workspace.PingAsync(ct).ConfigureAwait(false))
                {
                    // list_roblox_studios/get_studio_state can briefly report no target
                    // while Studio refreshes its MCP registration. Do not tear down a
                    // healthy user session on one transient miss.
                    _failedPolls++;
                    if (_failedPolls >= 3)
                    {
                        Publish(_snapshot with { State = StudioConnectionState.ConnectionLost, StatusText = "Reconnecting…", Error = "Studio MCP target temporarily disappeared." });
                        await _workspace.DisconnectAsync().ConfigureAwait(false);
                        _failedPolls = 0;
                    }
                    else if (_workspace.Project is { } transientProject)
                    {
                        Publish(_snapshot with { State = StudioConnectionState.StudioConnected, StatusText = "Studio Connected", Project = transientProject, Error = null });
                    }
                }
                else if (_workspace.Project is { } current)
                {
                    _failedPolls = 0;
                    _healthyPolls++;
                    if (_healthyPolls % 3 == 0)
                    {
                        try { current = await _workspace.ReadProjectInfoAsync(ct).ConfigureAwait(false); }
                        catch { }
                    }
                    Publish(_snapshot with
                    {
                        State = StudioConnectionState.StudioConnected,
                        StatusText = "Studio Connected",
                        Project = current,
                        Error = null
                    });
                }
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested) { break; }
            catch (Exception ex)
            {
                Publish(_snapshot with { State = StudioConnectionState.ConnectionFailed, StatusText = "Connection Failed", Error = SanitizeError(ex.Message) });
            }

            try { await Task.Delay(TimeSpan.FromSeconds(2), ct).ConfigureAwait(false); }
            catch (OperationCanceledException) { break; }
        }
    }

    private async Task<StudioProjectInfo> ConnectCoreAsync(CancellationToken ct)
    {
        await _connectGate.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            if (_workspace.IsConnected && _workspace.Project is { } existing) return existing;
            Publish(_snapshot with { State = StudioConnectionState.Connecting, StatusText = "Connecting to Studio…", Error = null, ActivityError = null });
            var project = await _workspace.ConnectAsync(ct).ConfigureAwait(false);
            // An unsaved place is valid (IDs can be zero), but an empty editor
            // identity/name is not an open game/project context.
            if (string.IsNullOrWhiteSpace(project.StudioId) || string.IsNullOrWhiteSpace(project.ProjectName) ||
                project.PlaceId < 0 || project.UniverseId < 0)
                throw new InvalidOperationException(OpenProjectRequiredError);
            _healthyPolls = 0;
            _failedPolls = 0;
            Publish(new StudioConnectionSnapshot(StudioConnectionState.StudioConnected, "Studio Connected", project));
            return project;
        }
        finally
        {
            _connectGate.Release();
        }
    }

    private void Publish(StudioConnectionSnapshot next)
    {
        if (_snapshot == next) return;
        _snapshot = next;
        try { StateChanged?.Invoke(next); } catch { }
    }

    private const string OpenProjectRequiredError = "Failed to connect. Roblox Studio needs to be open to a game/project.";

    private static string SanitizeError(string? message)
    {
        if (string.IsNullOrWhiteSpace(message)) return "Studio connection failed.";
        var value = message.Replace('\r', ' ').Replace('\n', ' ').Trim();
        if (value.Contains("no open Studio editor registered", StringComparison.OrdinalIgnoreCase) ||
            value.Contains("no open Roblox Studio", StringComparison.OrdinalIgnoreCase) ||
            value.Contains("could not see an open Studio place", StringComparison.OrdinalIgnoreCase) ||
            value.Contains("no project information", StringComparison.OrdinalIgnoreCase) ||
            value.Contains("no Roblox Studio instance is selected", StringComparison.OrdinalIgnoreCase))
            return OpenProjectRequiredError;
        if (value.Contains("launcher was not found", StringComparison.OrdinalIgnoreCase) ||
            value.Contains("mcp.bat", StringComparison.OrdinalIgnoreCase) && value.Contains("not found", StringComparison.OrdinalIgnoreCase))
            return "Roblox Studio MCP could not be found. Update/reopen Studio and turn on Enable Studio as MCP server.";
        if (value.Contains("initialize", StringComparison.OrdinalIgnoreCase) && value.Contains("MCP", StringComparison.OrdinalIgnoreCase))
            return "KAGE launched Studio MCP, but the MCP initialize handshake failed.";
        if (value.Contains("list_roblox_studios", StringComparison.OrdinalIgnoreCase))
            return "KAGE connected to Studio MCP, but Studio instance discovery failed.";
        if (value.Contains("execute_luau", StringComparison.OrdinalIgnoreCase))
            return "KAGE connected to Studio MCP, but the selected Studio editor rejected the project request.";
        if (value.Contains("did not register", StringComparison.OrdinalIgnoreCase))
            return "KAGE reached Studio MCP, but the open Studio project did not register. Keep the project open and retry.";
        return value.Length > 300 ? value[..300] : value;
    }

    public async ValueTask DisposeAsync()
    {
        if (Interlocked.Exchange(ref _disposed, 1) != 0) return;
        _shutdown.Cancel();
        await _workspace.DisconnectAsync().ConfigureAwait(false);
        if (_monitorTask is not null)
        {
            try { await _monitorTask.ConfigureAwait(false); } catch (OperationCanceledException) { }
        }
        await _workspace.DisposeAsync().ConfigureAwait(false);
        // Pending connect/UI callbacks may still be unwinding after cancellation.
        // Never dispose their source or semaphore underneath those owners.
    }
}
