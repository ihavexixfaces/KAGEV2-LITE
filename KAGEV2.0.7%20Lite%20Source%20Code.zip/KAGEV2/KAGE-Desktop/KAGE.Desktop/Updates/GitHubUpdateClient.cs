using System.Diagnostics;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Kage.Security;

namespace KAGE.Desktop.Updates;

// Kept under the historical type name so the existing UI/update-state code does not
// need a broad rename. V2 release discovery/download is now authenticated and private;
// this class no longer talks to GitHub.
internal sealed class GitHubUpdateClient : IDisposable
{
    private readonly HttpClient _http;
    private string? _executableSha256;

    internal UpdatedStartupContext StartupContext { get; set; } = new(null, null);
    internal UpdateChangelogNotification? PendingChangelog => UpdateChangelogStore.Current().Pending();

    public GitHubUpdateClient()
    {
        _http = new HttpClient { Timeout = TimeSpan.FromMinutes(5) };
        _http.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue("KAGE", "Updater"));
        _http.DefaultRequestHeaders.CacheControl = new CacheControlHeaderValue { NoCache = true };
    }

    public async Task<AvailableUpdate?> CheckAsync(CancellationToken cancellationToken = default, Action<string>? diagnostics = null)
    {
        if (KageSupportPolicy.IsBlocked) throw new UnauthorizedAccessException("KAGE access is disabled by the verified support policy.");
        var authorization = CreateAuthorizedBody(out var token);
        using var transportResponse = await new KageAuthenticatedTransport(_http).PostAsync(
            "/api/g2/releases/latest", authorization, token, cancellationToken).ConfigureAwait(false);
        UpdateServiceErrors.ThrowIfFailed(transportResponse.StatusCode);
        var envelope = transportResponse.Body.RootElement.Deserialize<PrivateReleaseEnvelope>(JsonOptions())
            ?? throw new InvalidDataException("The private release service returned an empty response.");

        if (!envelope.Success || envelope.Manifest is null)
            throw new InvalidDataException(string.IsNullOrWhiteSpace(envelope.Error) ? "No private KAGE release is available." : envelope.Error);

        var manifest = envelope.Manifest;
        var manifestValid = manifest.BuildId > 0 && manifest.Size > 0 && manifest.Size <= 1_000_000_000 &&
            UpdateReleasePolicy.CanAutomaticallyInstall(manifest.ReleaseVersion, manifest.ProtocolGeneration) &&
            UpdateRepository.IsExpectedPackageName(UpdateBuildInfo.DistributionMode, manifest.Package, manifest.ReleaseVersion) &&
            string.Equals(manifest.DistributionMode, UpdateBuildInfo.DistributionMode, StringComparison.OrdinalIgnoreCase) &&
            IsHash(manifest.Sha256, 64) &&
            IsHash(manifest.ExecutableSha256, 64);
        if (!manifestValid)
            throw new InvalidDataException("The private release manifest has an invalid build ID, package name, distribution mode, or SHA-256 checksum.");

        if (!UpdateSignatureVerifier.Verify(manifest))
            throw new InvalidDataException("The private release update manifest signature is invalid.");


        var releaseIdentity = UpdateChangelogStore.BoundRevision(envelope.Revision);
        if (releaseIdentity.Length == 0) releaseIdentity = $"build:{manifest.BuildId}";
        var notes = UpdateChangelogStore.MatchedNotes(manifest, envelope.Changelog, envelope.ChangelogBuildId);
        var changelog = UpdateChangelogStore.Current();
        if (changelog.AcceptVerifiedMetadata(manifest, releaseIdentity, notes, envelope.ChangelogBuildId, StartupContext) &&
            changelog.ConfirmedIdentity() is { } confirmed)
            UpdateInstallationState.Save(confirmed.Revision, confirmed.PackageSha256, confirmed.BuildId);
        var installed = UpdateInstallationState.Load();
        var acceptedBuildId = installed?.ManifestBuildId > 0 ? installed.ManifestBuildId : UpdateBuildInfo.BuildId;
        var buildChanged = manifest.BuildId != acceptedBuildId;
        var repositoryChanged = installed is not null && installed.RepositoryRevision.Length > 0 && releaseIdentity.Length > 0 &&
            !string.Equals(installed.RepositoryRevision, releaseIdentity, StringComparison.OrdinalIgnoreCase);
        var packageChanged = installed is not null &&
            !string.Equals(installed.PackageSha256, manifest.Sha256, StringComparison.OrdinalIgnoreCase);
        var executableChanged = false;
        if (!buildChanged && !string.IsNullOrEmpty(manifest.ExecutableSha256) && Environment.ProcessPath is { } executable)
        {
            _executableSha256 ??= await ComputeSha256Async(executable, cancellationToken).ConfigureAwait(false);
            executableChanged = !string.Equals(_executableSha256, manifest.ExecutableSha256, StringComparison.OrdinalIgnoreCase);
        }

        var available = buildChanged || repositoryChanged || packageChanged || executableChanged;
        diagnostics?.Invoke($"Private update check: mode={UpdateBuildInfo.DistributionMode}, local={UpdateBuildInfo.BuildId}, remote={manifest.BuildId}, available={available}");
        diagnostics?.Invoke($"Update comparison: build={buildChanged}, release={repositoryChanged}, package={packageChanged}, executable={executableChanged}");

        if (!available)
        {
            if (installed is null || !string.Equals(installed.RepositoryRevision, releaseIdentity, StringComparison.OrdinalIgnoreCase))
                UpdateInstallationState.Save(releaseIdentity, manifest.Sha256, manifest.BuildId);
            return null;
        }

        return new AvailableUpdate(
            manifest,
            UpdateRepository.PackageDownloadUrl,
            UpdateRepository.RepositoryPageUrl,
            releaseIdentity, notes, notes.Length > 0 ? UpdateChangelogStore.Id(manifest.BuildId) : "");
    }

    private static JsonSerializerOptions JsonOptions() => new()
    {
        PropertyNameCaseInsensitive = true,
        NumberHandling = JsonNumberHandling.Strict
    };

    internal static bool IsHash(string? value, int length) =>
        value?.Length == length && value.All(Uri.IsHexDigit);

    public async Task<string> DownloadAsync(
        AvailableUpdate update,
        IProgress<UpdateDownloadProgress>? progress,
        IProgress<string>? status = null,
        CancellationToken cancellationToken = default)
    {
        if (KageSupportPolicy.IsBlocked || !UpdateSignatureVerifier.Verify(update.Manifest) ||
            !UpdateReleasePolicy.CanAutomaticallyInstall(update.Manifest.ReleaseVersion, update.Manifest.ProtocolGeneration) ||
            !UpdateRepository.IsExpectedPackageName(UpdateBuildInfo.DistributionMode, update.Manifest.Package, update.Manifest.ReleaseVersion) ||
            !string.Equals(update.Manifest.DistributionMode, UpdateBuildInfo.DistributionMode, StringComparison.Ordinal))
            throw new InvalidDataException("The selected update is unsupported or its signature is invalid.");
        var updatesRoot = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "KAGE",
            "Updates",
            "downloads");
        Directory.CreateDirectory(updatesRoot);

        var packagePath = Path.Combine(updatesRoot, Path.GetFileName(update.Manifest.Package));
        if (File.Exists(packagePath))
            File.Delete(packagePath);

        status?.Report("Downloading authorized update...");
        var authorization = CreateAuthorizedBody(out var token);
        using var download = await new KageAuthenticatedTransport(_http, requestTimeout: TimeSpan.FromMinutes(5)).OpenDownloadAsync(
            "/api/g2/releases/download", authorization, token, cancellationToken).ConfigureAwait(false);
        var response = download.Response;
        UpdateServiceErrors.ThrowIfFailed(response.StatusCode);
        VerifyDownloadMetadata(download.Body.RootElement, update.Manifest);
        if (response.Content.Headers.ContentLength is { } contentLength && contentLength != update.Manifest.Size)
            throw new InvalidDataException("The downloaded update length differs from its signed manifest.");

        var totalBytes = response.Content.Headers.ContentLength ?? update.Manifest.Size;
        var buffer = new byte[1024 * 128];
        long received = 0;
        var stopwatch = Stopwatch.StartNew();
        double smoothedRate = 0;
        long previousBytes = 0;
        double previousSeconds = 0;

        await using (var input = await response.Content.ReadAsStreamAsync(cancellationToken).ConfigureAwait(false))
        await using (var output = new FileStream(packagePath, FileMode.CreateNew, FileAccess.Write, FileShare.None, 1024 * 128, true))
        {
            while (true)
            {
                var read = await input.ReadAsync(buffer.AsMemory(0, buffer.Length), cancellationToken).ConfigureAwait(false);
                if (read <= 0)
                    break;

                await output.WriteAsync(buffer.AsMemory(0, read), cancellationToken).ConfigureAwait(false);
                received += read;
                if (received > update.Manifest.Size || KageSupportPolicy.IsBlocked)
                    throw new InvalidDataException("Update download exceeded signed size or KAGE access was disabled.");

                var seconds = stopwatch.Elapsed.TotalSeconds;
                if (seconds - previousSeconds >= 0.2)
                {
                    var interval = Math.Max(0.001, seconds - previousSeconds);
                    var instantRate = (received - previousBytes) / interval;
                    smoothedRate = smoothedRate <= 0 ? instantRate : (smoothedRate * 0.75) + (instantRate * 0.25);
                    previousBytes = received;
                    previousSeconds = seconds;

                    double? eta = null;
                    if (totalBytes > 0 && smoothedRate > 1)
                        eta = Math.Max(0, (totalBytes - received) / smoothedRate);

                    progress?.Report(new UpdateDownloadProgress(received, totalBytes, smoothedRate, eta));
                }
            }

            await output.FlushAsync(cancellationToken).ConfigureAwait(false);
        }

        status?.Report("Verifying update...");
        var actualHash = await ComputeSha256Async(packagePath, cancellationToken).ConfigureAwait(false);
        if (received != update.Manifest.Size || !string.Equals(actualHash, update.Manifest.Sha256, StringComparison.OrdinalIgnoreCase))
        {
            File.Delete(packagePath);
            throw new InvalidDataException("The downloaded KAGE update failed integrity verification.");
        }

        progress?.Report(new UpdateDownloadProgress(received, totalBytes, smoothedRate, 0));
        return packagePath;
    }


    private static object CreateAuthorizedBody(out string token)
    {
        if (!KageResponseTrust.Default.HasPinnedKeys)
            throw new InvalidDataException("This build has no valid response signing pins. Rebuild using the owner's public release configuration.");
        if (!LiteSessionGate.TryGetSessionTransport(out token, out var clientChallenge))
            throw new UnauthorizedAccessException("A valid KAGE authorization session is required for paid release access.");
        return new
        {
            clientChallenge, distributionMode = UpdateBuildInfo.DistributionMode
        };
    }

    internal static void VerifyDownloadMetadata(JsonElement body, UpdateManifest selected)
    {
        if (!body.TryGetProperty("success", out var success) || success.ValueKind != JsonValueKind.True ||
            !body.TryGetProperty("manifest", out var element))
            throw new InvalidDataException("The update download has no authenticated release metadata.");
        var actual = element.Deserialize<UpdateManifest>(JsonOptions());
        if (actual is null || !UpdateSignatureVerifier.Verify(actual) ||
            !UpdateSignatureVerifier.CanonicalUnsignedPayload(actual).AsSpan().SequenceEqual(UpdateSignatureVerifier.CanonicalUnsignedPayload(selected)) ||
            actual.Signature != selected.Signature)
            throw new InvalidDataException("The update download belongs to a different signed release.");
    }

    private static async Task<string> ComputeSha256Async(string path, CancellationToken cancellationToken)
    {
        await using var stream = File.OpenRead(path);
        var hash = await SHA256.HashDataAsync(stream, cancellationToken).ConfigureAwait(false);
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    public void Dispose() => _http.Dispose();

    private sealed class PrivateReleaseEnvelope
    {
        public bool Success { get; set; }
        public string Error { get; set; } = string.Empty;
        public string Revision { get; set; } = string.Empty;
        public string Changelog { get; set; } = string.Empty;
        public string ChangelogBuildId { get; set; } = string.Empty;
        public UpdateManifest? Manifest { get; set; }
    }
}
