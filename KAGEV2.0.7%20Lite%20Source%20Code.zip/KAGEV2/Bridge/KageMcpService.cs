namespace Kage.Bridge;

public sealed record VerifiedReferenceReplacementResult(
    int Changed,
    int Attempts,
    IReadOnlyList<long> UnresolvedOldIds,
    IReadOnlyList<StudioReferenceChange> Changes,
    IReadOnlyList<StudioReferenceFailure> Failures,
    IReadOnlyDictionary<long, IReadOnlyList<string>> RemainingLocations);

public sealed class StudioReferenceReplacementException : InvalidOperationException
{
    public StudioReferenceReplacementException(string message, VerifiedReferenceReplacementResult result) : base(message) => Result = result;
    public VerifiedReferenceReplacementResult Result { get; }
}

/// <summary>
/// KAGE's internal Studio tool facade. UI code talks to this service instead of
/// depending on Roblox MCP/CLI implementation details. The public methods map to
/// KAGE's internal tool names: get_studio_status, connect_studio, disconnect_studio,
/// ping_studio, get_project_info, get_place_id, get_universe_id, get_project_name,
/// scan_animation_references, get_animation_references, replace_animation_reference,
/// replace_animation_references_batch, and get_reupload_progress.
/// </summary>
public sealed class KageMcpService
{
    private readonly StudioSessionManager _sessions;
    private Func<string, object?>? _reuploadProgressProvider;

    public KageMcpService(StudioSessionManager sessions) => _sessions = sessions;

    public StudioConnectionSnapshot GetStudioStatus() => _sessions.Snapshot;
    public Task<StudioProjectInfo> ConnectStudioAsync(CancellationToken ct = default) => _sessions.ConnectByUserAsync(ct);
    public Task DisconnectStudioAsync() => _sessions.DisconnectAsync(userInitiated: true);
    public Task<StudioProjectInfo> GetProjectInfoAsync(CancellationToken ct = default) => _sessions.EnsureConnectedAsync(ct);
    public async Task<long> GetPlaceIdAsync(CancellationToken ct = default) => (await GetProjectInfoAsync(ct)).PlaceId;
    public async Task<long> GetUniverseIdAsync(CancellationToken ct = default) => (await GetProjectInfoAsync(ct)).UniverseId;
    public async Task<string> GetProjectNameAsync(CancellationToken ct = default) => (await GetProjectInfoAsync(ct)).ProjectName;
    public Task<bool> PingStudioAsync(CancellationToken ct = default) => _sessions.Workspace.PingAsync(ct);

    public Task<StudioAssetScan> ScanAnimationReferencesAsync(CancellationToken ct = default) =>
        _sessions.Workspace.ScanAssetReferencesAsync("Animations", ct);
    public Task<StudioAssetScan> GetAnimationReferencesAsync(CancellationToken ct = default) => ScanAnimationReferencesAsync(ct);
    public Task<StudioAssetScan> ScanAssetReferencesAsync(string assetType, CancellationToken ct = default) =>
        _sessions.Workspace.ScanAssetReferencesAsync(assetType, ct);
    public Task<StudioAssetScan> ScanPreviewAssetReferencesAsync(string assetType, CancellationToken ct = default) =>
        _sessions.Workspace.ScanDirectAssetReferencesAsync(assetType, ct);
    public Task<IReadOnlyList<StudioTreeNode>> GetWorkspaceTreeAsync(CancellationToken ct = default) =>
        _sessions.Workspace.ReadWorkspaceTreeAsync(ct);

    public Task<int> ReplaceAnimationReferenceAsync(long oldId, long newId, CancellationToken ct = default) =>
        _sessions.Workspace.ApplyMappingAsync("Animations", new Dictionary<long, long> { [oldId] = newId }, ct);
    public Task<int> ReplaceAnimationReferencesBatchAsync(IReadOnlyDictionary<long, long> mapping, CancellationToken ct = default) =>
        _sessions.Workspace.ApplyMappingAsync("Animations", mapping, ct);
    public Task<int> ReplaceReferencesBatchAsync(string assetType, IReadOnlyDictionary<long, long> mapping, CancellationToken ct = default) =>
        _sessions.Workspace.ApplyMappingAsync(assetType, mapping, ct);

    public Task<StudioReferenceApplyResult> ApplyReferencesLiveAsync(
        string assetType,
        IReadOnlyDictionary<long, long> mapping,
        CancellationToken ct = default,
        StudioProjectInfo? expectedProject = null) =>
        // Keep Studio references synchronized with successful uploads as they arrive.
        // Unlike the v86 typed-instance optimization, this uses the original-V2
        // replacement pass so script/value/attribute references do not wait until
        // the end of a 900+ asset run. Upload workers continue concurrently.
        _sessions.Workspace.ApplyOriginalV2MappingAsync(assetType, mapping, ct, expectedProject);

    public Task<VerifiedReferenceReplacementResult> ReplaceReferencesOriginalV2Async(
        string assetType,
        IReadOnlyDictionary<long, long> mapping,
        CancellationToken ct = default,
        StudioProjectInfo? expectedProject = null) =>
        ReplaceReferencesVerifiedAsync(assetType, mapping, ct, expectedProject);

    public async Task<VerifiedReferenceReplacementResult> ReplaceReferencesVerifiedAsync(
        string assetType,
        IReadOnlyDictionary<long, long> mapping,
        CancellationToken ct = default,
        StudioProjectInfo? expectedProject = null)
    {
        if (mapping.Count == 0)
            return new VerifiedReferenceReplacementResult(
                0, 0, Array.Empty<long>(), Array.Empty<StudioReferenceChange>(), Array.Empty<StudioReferenceFailure>(),
                new Dictionary<long, IReadOnlyList<string>>());

        // Newly created upload IDs cannot also be source IDs in this batch.
        // Reject ambiguous input before a verification retry can remap a new ID.
        if (mapping.Any(pair => mapping.ContainsKey(pair.Value)))
            throw new InvalidOperationException("The upload mapping contains overlapping old and new IDs. Studio references have not been changed.");

        var allChanges = new List<StudioReferenceChange>();
        var allFailures = new List<StudioReferenceFailure>();
        var attempts = 0;
        var reportedChanged = 0;

        var applied = await ApplyReferenceMappingWithTransportRecoveryAsync(
            assetType, mapping, ct, expectedProject).ConfigureAwait(false);
        attempts++;
        reportedChanged += applied.Changed;
        allChanges.AddRange(applied.Changes);
        allFailures.AddRange(applied.Failures);

        StudioReferenceVerification verification;
        long[] unresolved;
        try
        {
            verification = await _sessions.Workspace.FindRemainingMappedReferencesAsync(assetType, mapping.Keys, ct, expectedProject).ConfigureAwait(false);
            unresolved = verification.UnresolvedOldIds.ToArray();

            for (var attempt = 0; attempt < 2 && unresolved.Length > 0; attempt++)
            {
                attempts++;
                ct.ThrowIfCancellationRequested();
                var retryMapping = unresolved.Where(mapping.ContainsKey).ToDictionary(id => id, id => mapping[id]);
                var retry = await ApplyReferenceMappingWithTransportRecoveryAsync(
                    assetType, retryMapping, ct, expectedProject).ConfigureAwait(false);
                reportedChanged += retry.Changed;
                allChanges.AddRange(retry.Changes);
                allFailures.AddRange(retry.Failures);

                verification = await _sessions.Workspace.FindRemainingMappedReferencesAsync(assetType, unresolved, ct, expectedProject).ConfigureAwait(false);
                unresolved = verification.UnresolvedOldIds.ToArray();
            }
        }
        catch (Exception ex) when (
            ex is OperationCanceledException or TimeoutException ||
            StudioMcpWorkspaceService.IsRecoverableMcpTransportFailure(ex))
        {
            // The write pass has already been acknowledged (or independently confirmed by
            // ApplyReferenceMappingWithTransportRecoveryAsync). A later read-only verification
            // transport drop must not turn a successful 1,000+ asset run into KAGE failed.
            return new VerifiedReferenceReplacementResult(
                Math.Max(reportedChanged, StudioReferenceCounts.CountInstances(allChanges)),
                attempts,
                Array.Empty<long>(),
                allChanges,
                allFailures,
                new Dictionary<long, IReadOnlyList<string>>());
        }
        catch (Exception ex) when (ex is not StudioReferenceReplacementException)
        {
            throw new StudioReferenceReplacementException(
                $"Studio reference verification did not finish: {ex.Message}",
                new VerifiedReferenceReplacementResult(
                    Math.Max(reportedChanged, StudioReferenceCounts.CountInstances(allChanges)),
                    attempts,
                    mapping.Keys.Order().ToArray(),
                    allChanges,
                    allFailures,
                    new Dictionary<long, IReadOnlyList<string>>()));
        }

        var changed = Math.Max(reportedChanged, StudioReferenceCounts.CountInstances(allChanges));
        var result = new VerifiedReferenceReplacementResult(
            changed,
            attempts,
            unresolved,
            allChanges,
            allFailures,
            verification.RemainingLocations);

        if (unresolved.Length > 0)
        {
            var detail = string.Join(" | ", unresolved.Take(6).Select(id =>
            {
                var locations = verification.RemainingLocations.TryGetValue(id, out var found)
                    ? string.Join(", ", found.Take(3))
                    : "unknown location";
                return $"{id}: {locations}";
            }));
            throw new StudioReferenceReplacementException(
                $"{unresolved.Length} old Studio references remain after replacement. {detail}",
                result);
        }

        return result;
    }

    private async Task<StudioReferenceApplyResult> ApplyReferenceMappingWithTransportRecoveryAsync(
        string assetType,
        IReadOnlyDictionary<long, long> mapping,
        CancellationToken ct,
        StudioProjectInfo? expectedProject)
    {
        var pending = mapping.Where(pair => pair.Key > 0 && pair.Value > 0)
            .ToDictionary(pair => pair.Key, pair => pair.Value);
        var changes = new List<StudioReferenceChange>();
        var failures = new List<StudioReferenceFailure>();
        var reportedChanged = 0;
        Exception? lastTransportError = null;

        for (var cycle = 0; cycle < 3 && pending.Count > 0; cycle++)
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                var applied = await _sessions.Workspace.ApplyOriginalV2MappingAsync(
                    assetType, pending, ct, expectedProject).ConfigureAwait(false);
                reportedChanged += applied.Changed;
                changes.AddRange(applied.Changes);
                failures.AddRange(applied.Failures);
                lastTransportError = null;
            }
            catch (Exception ex) when (!ct.IsCancellationRequested &&
                (StudioMcpWorkspaceService.IsRecoverableMcpTransportFailure(ex) ||
                 ex.Message.Contains("usable reference result", StringComparison.OrdinalIgnoreCase)))
            {
                // The mutation may have completed before MCP lost its response. Never guess:
                // verify the old IDs, then replay only the IDs Studio still reports.
                lastTransportError = ex;
            }

            try
            {
                var verification = await _sessions.Workspace.FindRemainingMappedReferencesAsync(
                    assetType, pending.Keys, ct, expectedProject).ConfigureAwait(false);
                var unresolved = verification.UnresolvedOldIds.Where(pending.ContainsKey).ToArray();
                if (unresolved.Length == 0)
                {
                    // For progress, a verified old->new mapping counts as synchronized even if
                    // MCP dropped the detailed mutation rows after Studio committed them.
                    return new StudioReferenceApplyResult(
                        Math.Max(mapping.Count, reportedChanged), changes, failures);
                }

                pending = unresolved.ToDictionary(id => id, id => mapping[id]);
            }
            catch (Exception ex) when (!ct.IsCancellationRequested &&
                StudioMcpWorkspaceService.IsRecoverableMcpTransportFailure(ex))
            {
                lastTransportError = ex;
            }

            if (cycle < 2)
                await Task.Delay(TimeSpan.FromMilliseconds(250 * (cycle + 1)), ct).ConfigureAwait(false);
        }

        if (lastTransportError is not null)
        {
            throw new StudioReferenceReplacementException(
                "Roblox Studio stopped responding after KAGE exhausted automatic reconnect and verification retries.",
                new VerifiedReferenceReplacementResult(
                    Math.Max(reportedChanged, StudioReferenceCounts.CountInstances(changes)),
                    3, pending.Keys.Order().ToArray(), changes, failures,
                    new Dictionary<long, IReadOnlyList<string>>()));
        }

        throw new StudioReferenceReplacementException(
            $"{pending.Count} old Studio references remain after automatic replacement retries.",
            new VerifiedReferenceReplacementResult(
                Math.Max(reportedChanged, StudioReferenceCounts.CountInstances(changes)),
                3, pending.Keys.Order().ToArray(), changes, failures,
                new Dictionary<long, IReadOnlyList<string>>()));
    }

    public object? GetReuploadProgress(string jobId) => _reuploadProgressProvider?.Invoke(jobId);

    public void SetReuploadProgressProvider(Func<string, object?> provider) =>
        _reuploadProgressProvider = provider ?? throw new ArgumentNullException(nameof(provider));
}
