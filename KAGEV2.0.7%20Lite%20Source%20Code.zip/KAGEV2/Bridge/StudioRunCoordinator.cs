namespace Kage.Bridge;

public sealed record StudioRunConfig(
    long Revision,
    string AssetType,
    string CreatorType,
    long CreatorId,
    int Concurrency);

public sealed class StudioRunCoordinator
{
    private readonly object _sync = new();
    private StudioRunConfig _current = new(0, "Animations", "User", 0, 96);

    public StudioRunConfig Snapshot()
    {
        lock (_sync) return _current;
    }

    public StudioRunConfig Set(string assetType, string creatorType, long creatorId, int concurrency)
    {
        lock (_sync)
        {
            _current = new StudioRunConfig(
                _current.Revision + 1,
                NormalizeAssetType(assetType),
                "User",
                Math.Max(0, creatorId),
                Math.Clamp(concurrency, 1, 96));
            return _current;
        }
    }

    public static string NormalizeAssetType(string? value)
    {
        var normalized = value?.Trim().ToLowerInvariant();
        if (string.IsNullOrEmpty(normalized) || normalized is "animation" or "animations") return "Animations";
        throw new InvalidOperationException("KAGE Lite supports animation assets only.");
    }
}
