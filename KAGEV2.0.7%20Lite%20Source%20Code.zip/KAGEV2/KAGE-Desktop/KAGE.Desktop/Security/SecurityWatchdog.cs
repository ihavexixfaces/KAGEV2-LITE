namespace KAGE.Desktop;

internal static class SecurityWatchdog
{
    private static readonly SemaphoreSlim RunGate = new(1, 1);

    internal static Task Start(TimeSpan interval, CancellationToken appLifetime)
    {
        if (interval <= TimeSpan.Zero)
            throw new ArgumentOutOfRangeException(nameof(interval));
        return RunAsync(interval, appLifetime);
    }

    private static async Task RunAsync(TimeSpan interval, CancellationToken appLifetime)
    {
        using var timer = new PeriodicTimer(interval);
        try
        {
            while (await timer.WaitForNextTickAsync(appLifetime).ConfigureAwait(false))
            {
                if (!await RunGate.WaitAsync(0, appLifetime).ConfigureAwait(false))
                    continue;

                try
                {
                    await SecurityRuntime.ReevaluateAsync(appLifetime).ConfigureAwait(false);
                }
                catch (OperationCanceledException) when (appLifetime.IsCancellationRequested)
                {
                    break;
                }
                catch
                {
                    SecurityRuntime.ReplaceState(SecurityState.Create(
                        SecurityLevel.Tampered,
                        new[] { "security-watchdog-check-failed" }));
                }
                finally
                {
                    RunGate.Release();
                }
            }
        }
        catch (OperationCanceledException) when (appLifetime.IsCancellationRequested)
        {
            // Expected during normal application shutdown.
        }
    }
}
