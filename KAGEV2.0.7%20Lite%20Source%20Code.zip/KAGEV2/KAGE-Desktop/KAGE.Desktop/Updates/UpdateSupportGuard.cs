using System.Text.Json;
using Kage.Security;

namespace KAGE.Desktop.Updates;

internal static class UpdateSupportGuard
{
    internal static async Task RequireSupportedPolicyAsync(CancellationToken cancellationToken = default)
    {
        if (KageSupportPolicy.IsBlocked) throw new UnauthorizedAccessException("KAGE access is disabled.");
        using var client = new HttpClient(new HttpClientHandler { AllowAutoRedirect = false }) { Timeout = TimeSpan.FromSeconds(15) };
        // The detached apply helper starts with an empty process cache. Load and
        // cryptographically validate its persisted session before the fresh server check.
        if (!LiteSessionGate.TryGetSessionTransport(out var token, out var challenge))
            throw new UnauthorizedAccessException("A current authorization session is required to apply the update.");
        using var response = await new KageAuthenticatedTransport(client).PostAsync("/api/g2/support",
            new { clientChallenge = challenge }, token, cancellationToken).ConfigureAwait(false);
        if (!response.IsSuccessStatusCode || KageSupportPolicy.IsBlocked ||
            !response.Body.RootElement.TryGetProperty("success", out var success) || success.ValueKind != JsonValueKind.True ||
            !response.Body.RootElement.TryGetProperty("supported", out var supported) || supported.ValueKind != JsonValueKind.True)
            throw new UnauthorizedAccessException("The verified support policy does not permit automatic installation or relaunch.");
    }
}
