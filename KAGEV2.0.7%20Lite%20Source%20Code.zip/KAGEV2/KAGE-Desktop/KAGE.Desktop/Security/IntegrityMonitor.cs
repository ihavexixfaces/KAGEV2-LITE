using System.Security.Cryptography;

namespace KAGE.Desktop;

internal sealed record IntegrityVerificationResult(SecurityLevel Level, IReadOnlyList<string> Codes)
{
    internal static IntegrityVerificationResult Clean { get; } =
        new(SecurityLevel.Clean, Array.Empty<string>());
}

internal static class IntegrityMonitor
{
    private const string ManifestFileName = "kage-integrity.json";

    internal static Task<IntegrityVerificationResult> VerifyAsync(
        string baseDirectory,
        CancellationToken cancellationToken,
        bool requireDetachedManifest = false)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(baseDirectory);
        return Task.Run(() => VerifyCore(baseDirectory, cancellationToken, requireDetachedManifest), cancellationToken);
    }

    private static IntegrityVerificationResult VerifyCore(
        string baseDirectory,
        CancellationToken cancellationToken,
        bool requireDetachedManifest)
    {
        var manifestPath = Path.Combine(baseDirectory, ManifestFileName);
        if (!File.Exists(manifestPath))
        {
            // Production releases intentionally distribute only KAGE.exe. The detached
            // manifest exists during release construction and is verified in strict mode,
            // then removed before packaging. Runtime integrity continues through the signed
            // updater package, Blackout verification, and NativeAOT runtime checks.
            return requireDetachedManifest
                ? new IntegrityVerificationResult(SecurityLevel.Tampered, new[] { "manifest-missing" })
                : IntegrityVerificationResult.Clean;
        }

        IntegrityManifest manifest;
        try
        {
            var bytes = File.ReadAllBytes(manifestPath);
            manifest = IntegrityManifest.Parse(bytes);
        }
        catch
        {
            return new IntegrityVerificationResult(SecurityLevel.Tampered, new[] { "manifest-invalid" });
        }

        if (manifest.BuildId != KAGE.Desktop.Updates.UpdateBuildInfo.BuildId.ToString(System.Globalization.CultureInfo.InvariantCulture))
            return new IntegrityVerificationResult(SecurityLevel.Tampered, new[] { "manifest-release-identity-mismatch" });
        cancellationToken.ThrowIfCancellationRequested();
        byte[] signature;
        try
        {
            signature = Convert.FromBase64String(manifest.Signature);
        }
        catch (FormatException)
        {
            return new IntegrityVerificationResult(SecurityLevel.Tampered, new[] { "manifest-signature-invalid" });
        }

        var payload = manifest.CanonicalUnsignedPayload();
        try
        {
            using var verifier = ECDsa.Create();
            verifier.ImportFromPem(IntegrityVerificationKey.Pem);
            if (!verifier.VerifyData(
                    payload,
                    signature,
                    HashAlgorithmName.SHA256,
                    DSASignatureFormat.Rfc3279DerSequence))
            {
                return new IntegrityVerificationResult(SecurityLevel.Tampered, new[] { "manifest-signature-invalid" });
            }
        }
        catch (CryptographicException)
        {
            return new IntegrityVerificationResult(SecurityLevel.Tampered, new[] { "manifest-signature-invalid" });
        }

        var root = Path.GetFullPath(baseDirectory);
        var rootPrefix = root.EndsWith(Path.DirectorySeparatorChar) ? root : root + Path.DirectorySeparatorChar;
        var codes = new List<string>();
        foreach (var artifact in manifest.Artifacts)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var fullPath = Path.GetFullPath(Path.Combine(root, artifact.Path.Replace('/', Path.DirectorySeparatorChar)));
            if (!fullPath.StartsWith(rootPrefix, StringComparison.OrdinalIgnoreCase))
            {
                codes.Add("artifact-path-invalid");
                continue;
            }

            if (!File.Exists(fullPath))
            {
                codes.Add("artifact-missing");
                continue;
            }

            using var stream = new FileStream(fullPath, FileMode.Open, FileAccess.Read, FileShare.Read);
            var actual = Convert.ToHexString(SHA256.HashData(stream)).ToLowerInvariant();
            if (!CryptographicOperations.FixedTimeEquals(
                    System.Text.Encoding.ASCII.GetBytes(actual),
                    System.Text.Encoding.ASCII.GetBytes(artifact.Sha256)))
            {
                codes.Add("artifact-hash-mismatch");
            }
        }

        return codes.Count == 0
            ? IntegrityVerificationResult.Clean
            : new IntegrityVerificationResult(SecurityLevel.Tampered, codes.Distinct(StringComparer.Ordinal).OrderBy(static code => code, StringComparer.Ordinal).ToArray());
    }
}
