# Embedded in kage.exe. No secrets are included in arguments, scripts, or files.
# This window uses ordinary Windows text editing instead of CMD ReadKey input.
$ErrorActionPreference = 'Stop'
$form = $null
try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()

    $optional = $env:KAGE_INPUT_OPTIONAL -eq 'true'
    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'KAGE 2.0.1 - Credential entry'
    $form.ClientSize = New-Object System.Drawing.Size(560, 235)
    $form.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi
    $form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false
    $form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
    $form.TopMost = $true

    $label = New-Object System.Windows.Forms.Label
    $label.Text = $env:KAGE_INPUT_LABEL
    $label.SetBounds(20, 18, 520, 28)

    $inputBox = New-Object System.Windows.Forms.TextBox
    $inputBox.SetBounds(20, 54, 520, 30)
    $inputBox.UseSystemPasswordChar = $true
    $inputBox.ShortcutsEnabled = $true
    $inputBox.MaxLength = 16384
    $inputBox.TabIndex = 0

    $status = New-Object System.Windows.Forms.Label
    $status.SetBounds(20, 93, 520, 28)
    $status.Text = '0 characters entered'
    $inputBox.Add_TextChanged({
        $status.Text = '{0} characters entered' -f $inputBox.Text.Length
        $confirm.Enabled = $optional -or -not [string]::IsNullOrWhiteSpace($inputBox.Text)
    })

    $hint = New-Object System.Windows.Forms.Label
    $hint.SetBounds(20, 127, 520, 42)
    $hint.Text = 'Type here or press Ctrl+V to paste. Characters stay masked.'
    if ($optional) { $hint.Text += ' Leave blank to skip.' }

    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Text = 'Cancel'
    $cancel.SetBounds(312, 185, 108, 32)
    $cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $cancel.TabIndex = 2

    $confirm = New-Object System.Windows.Forms.Button
    $confirm.Text = 'Continue'
    $confirm.SetBounds(432, 185, 108, 32)
    $confirm.Enabled = $optional
    $confirm.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $confirm.TabIndex = 1

    $form.Controls.AddRange([System.Windows.Forms.Control[]]@($label, $inputBox, $status, $hint, $cancel, $confirm))
    $form.AcceptButton = $confirm
    $form.CancelButton = $cancel
    $form.Add_Shown({
        $form.Activate()
        [void]$inputBox.Focus()
        $form.TopMost = $false
    })

    if ($form.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit 2 }

    # Only the parent process reads stdout. Never echo the value to the console.
    $encoded = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($inputBox.Text.Trim()))
    $inputBox.Clear()
    [Console]::Write($encoded)
} catch {
    # Raw exceptions may include user-entered values; keep diagnostics generic.
    [Console]::Error.WriteLine('KAGE could not open the credential entry window.')
    exit 1
} finally {
    if ($null -ne $form) { $form.Dispose() }
}
