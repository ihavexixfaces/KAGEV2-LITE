using System.Globalization;
using Kage.Security;

namespace KAGE.Desktop.Updates;

internal static class UpdateReleasePolicy
{
    internal static bool TryVersion(string? value, out Version version)
    {
        version = new Version(0, 0, 0);
        if (string.IsNullOrEmpty(value)) return false;
        var parts = value.Split('.');
        if (parts.Length != 3) return false;
        var parsed = new int[3];
        for (var i = 0; i < 3; i++)
            if (parts[i].Length == 0 || parts[i].Length > 9 ||
                (parts[i].Length > 1 && parts[i][0] == '0') ||
                !parts[i].All(c => c is >= '0' and <= '9') ||
                !int.TryParse(parts[i], NumberStyles.None, CultureInfo.InvariantCulture, out parsed[i])) return false;
        version = new Version(parsed[0], parsed[1], parsed[2]);
        return true;
    }

    internal static bool IsSupported(string? releaseVersion, int generation) =>
        generation == KageServiceConfiguration.ProtocolGeneration &&
        TryVersion(releaseVersion, out var release) && release >= new Version(2, 0, 7);

    internal static bool CanAutomaticallyInstall(string? releaseVersion, int generation) =>
        IsSupported(releaseVersion, generation) &&
        TryVersion(KageServiceConfiguration.Version, out var local) && local >= new Version(2, 0, 7) &&
        TryVersion(releaseVersion, out var remote) && remote >= local;
}
