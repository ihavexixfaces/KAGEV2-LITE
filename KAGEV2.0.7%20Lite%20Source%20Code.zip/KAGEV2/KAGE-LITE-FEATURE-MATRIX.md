# KAGE V2 Lite feature boundary

| Capability | Lite policy | Enforcement in this fork |
|---|---|---|
| Animation reupload | Included | UI selector, native request validation, bridge request validation, and engine authority all require `Animations`. |
| Sound reupload | Excluded | No UI option; unsupported asset type rejected before job creation. |
| Mesh reupload | Excluded | No UI option; unsupported asset type rejected before job creation. |
| Decal/image reupload | Excluded | No UI option; unsupported asset type rejected before job creation. |
| Animation preview | Included | Dedicated animation preview path only. |
| Sound/mesh/decal preview | Excluded | UI tabs removed; generic preview request rejected. |
| Discord OAuth / whitelist | Excluded | OAuth implementation files removed from the Lite source; Lite stubs are local-only and perform no network authorization. |
| Roblox credentials | Required | Existing local credential manager and Windows protected storage are retained. |
| Group destination | Excluded from UI | Group selector removed; native request is constrained to the current Roblox account. |

The Full source archive is not part of this fork. Do not copy Lite stubs or feature switches back into Full.
