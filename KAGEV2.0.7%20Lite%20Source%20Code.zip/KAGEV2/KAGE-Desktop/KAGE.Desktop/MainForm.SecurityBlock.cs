using System.Drawing;
using Kage.Security;

namespace KAGE.Desktop;

public partial class MainForm
{
    private int _securityBlockStarted;
    private SecurityBlockCountdown? _securityCountdown;
    private Form? _securityBlockWindow;
    private Label? _securityCountdownLabel;

    private void StartSupportMonitoring()
    {
        KageSupportPolicy.StartMonitoring();
        if (KageSupportPolicy.CurrentBlock is { } block) OnSupportBlocked(null, block);
    }

    private void OnSupportBlocked(object? sender, KageSupportBlock block)
    {
        if (Interlocked.Exchange(ref _securityBlockStarted, 1) != 0 || _closing) return;
        // Stop queued work immediately, without waiting on browser code or credential storage.
        try { _updateShutdown.Cancel(); } catch { }
        try { _applicationShutdown.Cancel(); } catch { }
        try { _bridgeShutdown.Cancel(); } catch { }
        try { _shadeRequest?.Cancel(); } catch { }
        void Present()
        {
            if (_closing || IsDisposed) return;
            CancelAssetPreviewRequests();
            CancelAnimationPreviewAvatar();
            try { _shadePopoutWindow?.Close(); } catch { }
            _availableUpdate = null;
            SignalReadyToPresent();
            ShowNativeSecurityBlock(block);
            _ = SendSecurityBlockAsync();
            _securityCountdown = new SecurityBlockCountdown(seconds =>
            {
                if (_closing || IsDisposed || !IsHandleCreated) return;
                try { BeginInvoke(new Action(() =>
                {
                    if (_securityCountdownLabel is { IsDisposed: false } label)
                        label.Text = $"Closing in {seconds} {(seconds == 1 ? "second" : "seconds")}.";
                    _ = SendToFrontend("securityBlockCountdown", new { secondsRemaining = seconds });
                })); } catch (InvalidOperationException) { }
            }, () =>
            {
                if (_closing || IsDisposed || !IsHandleCreated) return;
                try { BeginInvoke(new Action(Close)); } catch (InvalidOperationException) { }
            });
            _securityCountdown.Start();
        }
        if (IsHandleCreated)
        {
            try { BeginInvoke(new Action(Present)); } catch (InvalidOperationException) { }
        }
        else Shown += (_, _) => Present();
    }

    private Task SendSecurityBlockAsync()
    {
        if (KageSupportPolicy.CurrentBlock is not { } block) return Task.CompletedTask;
        return SendToFrontend("securityBlock", new
        {
            reason = block.Reason.ToString(), secondsRemaining = _securityCountdown?.SecondsRemaining ?? 5
        });
    }

    private bool HandleSecurityBlockAction(string action)
    {
        if (action == "securityBlockReady") { _ = SendSecurityBlockAsync(); return true; }
        if (action is "securityBlockDownload" or "securityBlockRecovery")
        {
            if (KageSupportPolicy.CurrentBlock is { } block)
            {
                var uri = action == "securityBlockDownload" ? block.DownloadUri : block.RecoveryUri;
                // Policy validates these official destinations before raising the event.
                if (uri is { Scheme: "https" }) TryOpenExternalUri(uri.AbsoluteUri);
            }
            return true;
        }
        return KageSupportPolicy.IsBlocked && action is not ("close" or "uiReady");
    }

    private void ShowNativeSecurityBlock(KageSupportBlock block)
    {
        // Native fallback remains visible even if WebView initialization or JS is stalled.
        // An owned topmost window also covers native dialogs and every popout.
        var retired = block.Reason == KageBlockReason.VersionRetired;
        var panel = new Form
        {
            Text = "KAGE", FormBorderStyle = FormBorderStyle.None, StartPosition = FormStartPosition.CenterParent,
            ClientSize = new Size(500, retired ? 300 : 350), BackColor = Color.FromArgb(12, 12, 16),
            ForeColor = Color.FromArgb(242, 242, 244), ShowInTaskbar = false, TopMost = true,
            Font = new Font("Segoe UI Variable Text", 10), Padding = new Padding(26)
        };
        var content = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 5, BackColor = panel.BackColor };
        content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 32));
        content.RowStyles.Add(new RowStyle(SizeType.Percent, 48));
        content.RowStyles.Add(new RowStyle(SizeType.Percent, 52));
        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));
        Label Copy(string text, float size, Color color) => new()
        { Text = text, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter, ForeColor = color, Font = new Font(panel.Font.FontFamily, size) };
        content.Controls.Add(Copy("KAGE", 10, Color.FromArgb(160, 160, 170)), 0, 0);
        content.Controls.Add(Copy(retired ? "This version of KAGE is no longer available to use." : "KAGE could not verify your authorization.", 17, panel.ForeColor), 0, 1);
        content.Controls.Add(Copy(retired ? "Download KAGE v2.0.7 to continue." : "Access is disabled. Please sign in again or download the official supported version.", 10, Color.FromArgb(170, 170, 180)), 0, 2);
        _securityCountdownLabel = Copy("Closing in 5 seconds.", 10, Color.FromArgb(209, 209, 216));
        content.Controls.Add(_securityCountdownLabel, 0, 3);
        var actions = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, AutoSize = false, Padding = new Padding(retired ? 102 : 35, 3, 0, 0) };
        Button Link(string text, string action) => new() { Text = text, AutoSize = true, Height = 40, FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(242, 242, 244), ForeColor = Color.FromArgb(17, 17, 17), Padding = new Padding(8, 3, 8, 3), UseVisualStyleBackColor = false };
        var download = Link("Download KAGE v2.0.7", "securityBlockDownload");
        download.Click += (_, _) => HandleSecurityBlockAction("securityBlockDownload"); actions.Controls.Add(download);
        if (!retired) { var recovery = Link("Sign in again", "securityBlockRecovery"); recovery.Click += (_, _) => HandleSecurityBlockAction("securityBlockRecovery"); actions.Controls.Add(recovery); }
        content.Controls.Add(actions, 0, 4); panel.Controls.Add(content);
        panel.FormClosing += (_, e) => { if (!_closing) e.Cancel = true; };
        _securityBlockWindow = panel;
        panel.Show(this); panel.BringToFront(); Enabled = false;
    }
}
