using System.Diagnostics;
using System.Net;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace Kage.Security;

/// <summary>Verifies a pinned asymmetric signature before any service JSON is used.</summary>
internal sealed class KageResponseTrust
{
    internal static KageResponseTrust Default { get; } = FromReleaseConfiguration();
    private readonly IReadOnlyDictionary<string, byte[]> _keys;
    private readonly Func<long> _wallClock;
    private readonly Func<long> _monotonicSeconds;
    private readonly long _initialWall, _initialMonotonic;
    private long _highWater;
    internal bool HasPinnedKeys => _keys.Count > 0;

    internal KageResponseTrust(IReadOnlyDictionary<string, byte[]> keys, Func<long>? wallClock = null, Func<long>? monotonicSeconds = null)
    {
        _keys = keys.ToDictionary(x => x.Key, x => x.Value.ToArray(), StringComparer.Ordinal);
        _wallClock = wallClock ?? (() => DateTimeOffset.UtcNow.ToUnixTimeSeconds());
        _monotonicSeconds = monotonicSeconds ?? (() => Stopwatch.GetTimestamp() / Stopwatch.Frequency);
        _initialWall = _wallClock(); _initialMonotonic = _monotonicSeconds(); _highWater = _initialWall;
    }

    internal long Now
    {
        get
        {
            var candidate = Math.Max(_wallClock(), _initialWall + Math.Max(0, _monotonicSeconds() - _initialMonotonic));
            long previous;
            do { previous = Volatile.Read(ref _highWater); if (candidate <= previous) return previous; }
            while (Interlocked.CompareExchange(ref _highWater, candidate, previous) != previous);
            return candidate;
        }
    }

    private static KageResponseTrust FromReleaseConfiguration()
    {
        var keys = new Dictionary<string, byte[]>(StringComparer.Ordinal);
        try
        {
            var encoded = KageServiceConfiguration.Metadata("KageResponsePublicKeysBase64");
            if (encoded.Length == 0) return new(keys);
            using var document = JsonDocument.Parse(Convert.FromBase64String(encoded));
            if (!UniqueProperties(document.RootElement) || document.RootElement.ValueKind != JsonValueKind.Object) return new(keys);
            foreach (var pair in document.RootElement.EnumerateObject())
            {
                if (!TokenPart(pair.Name, 1, 32) || pair.Value.ValueKind != JsonValueKind.String) return new(new Dictionary<string, byte[]>());
                var key = Convert.FromBase64String(pair.Value.GetString()!);
                using var algorithm = ECDsa.Create();
                algorithm.ImportSubjectPublicKeyInfo(key, out var read);
                if (read != key.Length || algorithm.KeySize != 256 || algorithm.ExportParameters(false).Curve.Oid.Value != "1.2.840.10045.3.1.7")
                    return new(new Dictionary<string, byte[]>());
                keys.Add(pair.Name, key);
            }
        }
        catch (Exception ex) when (ex is FormatException or JsonException or CryptographicException or ArgumentException) { keys.Clear(); }
        return new(keys);
    }

    internal JsonDocument VerifyReceipt(string receipt, string route, string nonce)
    {
        using var claims = VerifyEnvelope(receipt, "kr2");
        var root = claims.RootElement;
        RequireContext(root, "kage-desktop", "response", 60);
        if (String(root, "route") != route || String(root, "nonce") != nonce || !CanonicalPart(nonce, 32, 32) ||
            !root.TryGetProperty("body", out var body) || body.ValueKind != JsonValueKind.Object)
            throw Untrusted();
        return JsonDocument.Parse(body.GetRawText(), new JsonDocumentOptions { MaxDepth = 32 });
    }

    internal sealed record SessionClaims(string UserId, string SessionId, long ExpiresAt);

    internal SessionClaims VerifySession(string token, string challenge, string? expectedUserId = null, long? expectedExpiry = null)
    {
        if (!CanonicalPart(challenge, 32, 32)) throw Untrusted();
        using var claims = VerifyEnvelope(token, "k2");
        var root = claims.RootElement;
        RequireContext(root, "kage-service", "access", 4 * 60 * 60);
        var userId = String(root, "sub");
        var sid = String(root, "sid");
        var expiry = Integer(root, "exp");
        var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(challenge))).ToLowerInvariant();
        if (userId.Length is < 17 or > 20 || !userId.All(c => c is >= '0' and <= '9') || !userId.Any(c => c != '0') ||
            !CanonicalPart(sid, 16, 128) || String(root, "cb") != hash ||
            expectedUserId is not null && userId != expectedUserId || expectedExpiry.HasValue && expiry != expectedExpiry.Value)
            throw Untrusted();
        return new(userId, sid, expiry);
    }

    private JsonDocument VerifyEnvelope(string token, string prefix)
    {
        if (token.Length is 0 or > 131072) throw Untrusted();
        var pieces = token.Split('.');
        if (pieces.Length != 4 || pieces[0] != prefix || !TokenPart(pieces[1], 1, 32) || !_keys.TryGetValue(pieces[1], out var key) ||
            !CanonicalPart(pieces[2], 1, 98304) || !CanonicalPart(pieces[3], 64, 64)) throw Untrusted();
        try
        {
            using var algorithm = ECDsa.Create();
            algorithm.ImportSubjectPublicKeyInfo(key, out var read);
            if (read != key.Length || algorithm.KeySize != 256 || algorithm.ExportParameters(false).Curve.Oid.Value != "1.2.840.10045.3.1.7" ||
                !algorithm.VerifyData(Encoding.ASCII.GetBytes(string.Join('.', pieces.Take(3))), Decode(pieces[3]), HashAlgorithmName.SHA256,
                    DSASignatureFormat.IeeeP1363FixedFieldConcatenation)) throw Untrusted();
            var claims = JsonDocument.Parse(Decode(pieces[2]), new JsonDocumentOptions { MaxDepth = 32 });
            if (claims.RootElement.ValueKind != JsonValueKind.Object || !UniqueProperties(claims.RootElement)) { claims.Dispose(); throw Untrusted(); }
            // This is a fixed custom envelope, not a JWT. No key/algorithm selector is accepted in its payload.
            if (new[] { "alg", "jku", "jwk", "x5u", "crit" }.Any(x => claims.RootElement.TryGetProperty(x, out _))) { claims.Dispose(); throw Untrusted(); }
            return claims;
        }
        catch (Exception ex) when (ex is FormatException or CryptographicException or JsonException or ArgumentException) { throw Untrusted(); }
    }

    private void RequireContext(JsonElement root, string audience, string purpose, long lifetime)
    {
        var issued = Integer(root, "iat"); var expires = Integer(root, "exp"); var now = Now;
        if (String(root, "iss") != "kage-auth" || String(root, "aud") != audience || String(root, "purpose") != purpose ||
            Integer(root, "generation") != 2 || issued <= 0 || issued > now + 30 || expires <= now || expires <= issued || expires - issued > lifetime ||
            purpose == "response" && issued < now - 60) throw Untrusted();
    }

    internal static bool UniqueProperties(JsonElement element)
    {
        if (element.ValueKind == JsonValueKind.Object)
        {
            var names = new HashSet<string>(StringComparer.Ordinal);
            foreach (var property in element.EnumerateObject()) if (!names.Add(property.Name) || !UniqueProperties(property.Value)) return false;
        }
        else if (element.ValueKind == JsonValueKind.Array)
            foreach (var item in element.EnumerateArray()) if (!UniqueProperties(item)) return false;
        return true;
    }
    internal static string String(JsonElement root, string key) => root.ValueKind == JsonValueKind.Object && root.TryGetProperty(key, out var value) && value.ValueKind == JsonValueKind.String ? value.GetString() ?? "" : "";
    internal static long Integer(JsonElement root, string key) => root.ValueKind == JsonValueKind.Object && root.TryGetProperty(key, out var value) && value.ValueKind == JsonValueKind.Number && value.TryGetInt64(out var number) ? number : 0;
    internal static string Encode(byte[] bytes) => Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_');
    internal static byte[] Decode(string value) => Convert.FromBase64String(value.Replace('-', '+').Replace('_', '/').PadRight(value.Length + (4 - value.Length % 4) % 4, '='));
    private static bool TokenPart(string value, int min, int max) => value.Length >= min && value.Length <= max && value.All(c => char.IsAsciiLetterOrDigit(c) || c is '-' or '_');
    internal static bool CanonicalPart(string value, int minBytes, int maxBytes)
    {
        if (!TokenPart(value, 1, (maxBytes * 4 + 2) / 3)) return false;
        try { var bytes = Decode(value); return bytes.Length >= minBytes && bytes.Length <= maxBytes && Encode(bytes) == value; }
        catch (FormatException) { return false; }
    }
    internal static InvalidDataException Untrusted() => new("KAGE could not authenticate the service response. Retry sign-in or contact support.");
}

public sealed class KageAuthenticatedResponse : IDisposable
{
    public HttpStatusCode StatusCode { get; }
    public JsonDocument Body { get; }
    public bool IsSuccessStatusCode => (int)StatusCode is >= 200 and <= 299;
    internal KageAuthenticatedResponse(HttpStatusCode statusCode, JsonDocument body) { StatusCode = statusCode; Body = body; }
    public void Dispose() => Body.Dispose();
}

public sealed class KageAuthenticatedDownload : IDisposable
{
    public HttpResponseMessage Response { get; }
    public JsonDocument Body { get; }
    internal KageAuthenticatedDownload(HttpResponseMessage response, JsonDocument body) { Response = response; Body = body; }
    public void Dispose() { Response.Dispose(); Body.Dispose(); }
}

/// <summary>Fresh request-bound receipts remain trustworthy through a locally trusted HTTPS proxy.</summary>
public sealed class KageAuthenticatedTransport
{
    private readonly HttpClient _client;
    private readonly Uri _serviceBase;
    private readonly KageResponseTrust _trust;
    private readonly TimeSpan _requestTimeout;
    public KageAuthenticatedTransport(HttpClient client, Uri? serviceBase = null, TimeSpan? requestTimeout = null)
        : this(client, serviceBase ?? KageServiceConfiguration.ServiceBase, KageResponseTrust.Default, requestTimeout ?? TimeSpan.FromSeconds(12)) { }
    internal KageAuthenticatedTransport(HttpClient client, Uri serviceBase, KageResponseTrust trust, TimeSpan? requestTimeout = null)
    { _client = client; _serviceBase = serviceBase; _trust = trust; _requestTimeout = requestTimeout ?? TimeSpan.FromSeconds(12); }

    public async Task<KageAuthenticatedResponse> PostAsync(string path, object body, string? bearer = null, CancellationToken cancellationToken = default)
    {
        var intent = LiteSessionGate.CaptureSessionIntent();
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        deadline.CancelAfter(_requestTimeout);
        var nonce = KageResponseTrust.Encode(RandomNumberGenerator.GetBytes(32));
        using var request = Request(path, body, bearer, nonce);
        using var response = await _client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, deadline.Token).ConfigureAwait(false);
        var verified = await ReadReceiptAsync(response, path, nonce, deadline.Token).ConfigureAwait(false);
        KageSupportPolicy.ObserveVerifiedResponse(path, response.StatusCode, verified.RootElement, intent, bearer);
        return new(response.StatusCode, verified);
    }

    public async Task<KageAuthenticatedDownload> OpenDownloadAsync(string path, object body, string? bearer = null, CancellationToken cancellationToken = default)
    {
        var intent = LiteSessionGate.CaptureSessionIntent();
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        deadline.CancelAfter(_requestTimeout);
        var nonce = KageResponseTrust.Encode(RandomNumberGenerator.GetBytes(32));
        using var request = Request(path, body, bearer, nonce);
        var response = await _client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, deadline.Token).ConfigureAwait(false);
        try
        {
            JsonDocument verified;
            if (response.IsSuccessStatusCode)
            {
                if (!response.Headers.TryGetValues("X-Kage-Receipt", out var headers)) throw KageResponseTrust.Untrusted();
                var receipts = headers.ToArray();
                if (receipts.Length != 1) throw KageResponseTrust.Untrusted();
                verified = _trust.VerifyReceipt(receipts[0], path, nonce);
            }
            else verified = await ReadReceiptAsync(response, path, nonce, deadline.Token).ConfigureAwait(false);
            KageSupportPolicy.ObserveVerifiedResponse(path, response.StatusCode, verified.RootElement, intent, bearer);
            return new(response, verified);
        }
        catch { response.Dispose(); throw; }
    }

    private HttpRequestMessage Request(string path, object body, string? bearer, string nonce)
    {
        if (!path.StartsWith("/api/g2/", StringComparison.Ordinal) || !path.All(c => char.IsAsciiLetterOrDigit(c) || c is '/' or '-' or '_'))
            throw new ArgumentException("A generation 2 route is required.", nameof(path));
        var input = JsonSerializer.SerializeToElement(body);
        if (input.ValueKind != JsonValueKind.Object || !KageResponseTrust.UniqueProperties(input)) throw new ArgumentException("The request body must be an object.", nameof(body));
        using var bytes = new MemoryStream();
        using (var writer = new Utf8JsonWriter(bytes))
        {
            writer.WriteStartObject();
            foreach (var field in input.EnumerateObject())
            {
                if (field.Name is "requestNonce" or "clientVersion" or "clientBuild" or "protocolGeneration") throw new ArgumentException("Reserved request metadata.", nameof(body));
                field.WriteTo(writer);
            }
            writer.WriteString("requestNonce", nonce); writer.WriteString("clientVersion", KageServiceConfiguration.Version);
            writer.WriteString("clientBuild", KageServiceConfiguration.Build); writer.WriteNumber("protocolGeneration", 2); writer.WriteEndObject();
        }
        var data = bytes.ToArray();
        if (data.Length > (path.StartsWith("/api/g2/shade/", StringComparison.Ordinal) ? 65536 : 16384)) throw new ArgumentException("The service request is too large.", nameof(body));
        var request = new HttpRequestMessage(HttpMethod.Post, new Uri(_serviceBase, path));
        request.Headers.CacheControl = new CacheControlHeaderValue { NoStore = true, NoCache = true };
        if (!string.IsNullOrEmpty(bearer)) request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearer);
        request.Content = new ByteArrayContent(data); request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
        return request;
    }

    private async Task<JsonDocument> ReadReceiptAsync(HttpResponseMessage response, string route, string nonce, CancellationToken ct)
    {
        if (response.Content.Headers.ContentLength is > 262144) throw KageResponseTrust.Untrusted();
        await using var stream = await response.Content.ReadAsStreamAsync(ct).ConfigureAwait(false);
        using var buffer = new MemoryStream(); var block = new byte[4096]; int read;
        while ((read = await stream.ReadAsync(block.AsMemory(), ct).ConfigureAwait(false)) > 0)
        { if (buffer.Length + read > 262144) throw KageResponseTrust.Untrusted(); buffer.Write(block, 0, read); }
        using var wrapper = JsonDocument.Parse(buffer.ToArray(), new JsonDocumentOptions { MaxDepth = 32 });
        if (!KageResponseTrust.UniqueProperties(wrapper.RootElement) || wrapper.RootElement.ValueKind != JsonValueKind.Object || wrapper.RootElement.EnumerateObject().Count() != 1)
            throw KageResponseTrust.Untrusted();
        return _trust.VerifyReceipt(KageResponseTrust.String(wrapper.RootElement, "receipt"), route, nonce);
    }
}
