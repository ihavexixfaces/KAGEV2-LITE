using System.Text.Json;

namespace Kage.Bridge;

public sealed partial class StudioMcpWorkspaceService
{
    private readonly string _previewOwner = Guid.NewGuid().ToString("N");

    public Task<JsonElement> LoadAnimationPreviewAsync(long assetId, string rigType, string clipToken, CancellationToken ct = default)
        => LoadAnimationPreviewAsync(assetId, rigType, 0, clipToken, ct);

    public Task<JsonElement> LoadAnimationPreviewAsync(long assetId, string rigType, long avatarUserId, string clipToken, CancellationToken ct = default)
    {
        if (assetId <= 0) throw new ArgumentOutOfRangeException(nameof(assetId));
        if (avatarUserId < 0) throw new ArgumentOutOfRangeException(nameof(avatarUserId));
        if (rigType is not ("R6" or "R15")) throw new ArgumentException("Choose R6 or R15.", nameof(rigType));
        // The viewer uses a neutral rig; account appearance must not be a
        // prerequisite for evaluating the animation's exact joint transforms.
        return ExecuteAnimationPreviewAsync("load", assetId, rigType, 0, clipToken, ct: ct);
    }

    public Task<JsonElement> ControlAnimationPreviewAsync(string command, string clipToken, double value = 0, bool loop = true, CancellationToken ct = default)
    {
        if (command is not ("play" or "pause" or "seek" or "speed" or "loop" or "status" or "stop"))
            throw new ArgumentException("Unknown preview control.", nameof(command));
        if (!double.IsFinite(value)) throw new ArgumentOutOfRangeException(nameof(value));
        return ExecuteAnimationPreviewAsync(command, clipToken: clipToken, value: value, loop: loop, ct: ct);
    }

    public Task<JsonElement> SampleAnimationPreviewAsync(string clipToken, int start, int count, CancellationToken ct = default)
    {
        if (start < 0 || count is < 1 or > 120) throw new ArgumentOutOfRangeException(nameof(count));
        return ExecuteAnimationPreviewAsync("sample", clipToken: clipToken, start: start, count: count, ct: ct);
    }

    public Task<JsonElement> StopAnimationPreviewAsync(CancellationToken ct = default) => ExecuteAnimationPreviewAsync("stop", ct: ct);

    public Task<JsonElement> GetAnimationPreviewRigInfoAsync(CancellationToken ct = default) => ExecuteAnimationPreviewAsync("rigInfo", ct: ct);

    private async Task<JsonElement> ExecuteAnimationPreviewAsync(string command, long assetId = 0, string rigType = "R15", long avatarUserId = 0, string clipToken = "",
        double value = 0, bool loop = true, int start = 0, int count = 120, CancellationToken ct = default)
    {
        if (clipToken.Length > 80) throw new ArgumentException("Invalid preview session.", nameof(clipToken));
        using var operation = BeginOperation(ct);
        ct = operation.Token;
        await _gate.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            // A cancelled catalog/older load can retire the transport while this
            // request waits in the Studio queue. Workspace disconnect cancels the
            // linked operation above, so only a still-authorized load reconnects.
            ct.ThrowIfCancellationRequested();
            if (!IsConnected && command == "load")
                await ConnectAsync(ct).ConfigureAwait(false);
            if (!IsConnected) throw new InvalidOperationException("Connect to Studio first.");
            var json = JsonSerializer.Serialize(new { owner = _previewOwner, command, assetId = assetId.ToString(), rigType, avatarUserId, clip = clipToken, value, loop, start, count });
            var code = BuildAnimationPreviewLuau(json);
            var raw = await ExecuteLuauAsync(code, ct).ConfigureAwait(false);
            using var doc = JsonDocument.Parse(ExtractJsonPayload(raw) ?? throw new InvalidOperationException("Studio returned no animation preview response."));
            if (doc.RootElement.ValueKind != JsonValueKind.Object) throw new InvalidOperationException("Studio returned an invalid animation preview response.");
            if (doc.RootElement.TryGetProperty("error", out var error)) throw new InvalidOperationException(error.GetString());
            return doc.RootElement.Clone();
        }
        finally { _gate.Release(); }
    }

    private static string BuildAnimationPreviewLuau(string json)
    {
        // JSON string escapes (for example \u0022) are not Lua string escapes.
        // Use a long-bracket literal and choose a delimiter absent from the payload.
        var equals = "=";
        while (json.Contains("]" + equals + "]", StringComparison.Ordinal)) equals += "=";
        return "local request = game:GetService(\"HttpService\"):JSONDecode([" + equals + "[" + json + "]" + equals + "])\n" + AnimationPreviewLuau;
    }

    private const string AnimationPreviewLuau = """
local HttpService = game:GetService("HttpService")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")
local folder
for _, child in ipairs(Workspace:GetChildren()) do
    if child:GetAttribute("KagePreviewOwner") == request.owner and child:GetAttribute("KagePreviewTransient") == true then
        folder = child
        break
    end
end
local function reply(value) return HttpService:JSONEncode(value) end
local function fail(message) return reply({ error = tostring(message) }) end
if request.command == "rigInfo" then
    local StarterPlayer = game:GetService("StarterPlayer")
    local rig = "R15"
    local source = "Basic rig default"
    -- A custom StarterCharacter can override the experience's normal character
    -- rig. Prefer its Humanoid when present because that is what players spawn as.
    local starterCharacter = StarterPlayer:FindFirstChild("StarterCharacter")
    local starterHumanoid = starterCharacter and starterCharacter:FindFirstChildOfClass("Humanoid")
    if starterHumanoid then
        rig = tostring(starterHumanoid.RigType)
        source = "StarterCharacter.Humanoid.RigType"
    else
        for _, candidate in ipairs(Workspace:GetDescendants()) do
            if candidate:IsA("Humanoid") then
                local parent, transient = candidate.Parent, false
                while parent and parent ~= Workspace do
                    if parent:GetAttribute("KagePreviewTransient") == true then transient = true; break end
                    parent = parent.Parent
                end
                if not transient then
                    rig = tostring(candidate.RigType)
                    source = "Workspace.Humanoid.RigType"
                    break
                end
            end
        end
    end
    local resolved = string.find(rig, "R6", 1, true) and "R6" or "R15"
    return reply({ rigType = resolved, rigSource = source })
end
if folder and request.command ~= "load" and request.clip ~= "" and folder:GetAttribute("ClipToken") ~= request.clip then
    return reply({ state = "stale" })
end
if request.command == "stop" then
    if folder then folder:Destroy() end
    return reply({ state = "stopped", position = 0 })
end
if RunService:IsRunning() then return fail("Stop Studio playtesting before using KAGE Asset Viewer.") end

local function findTrack(target)
    local model = target:FindFirstChild("Rig")
    local animator = model and model:FindFirstChildWhichIsA("Animator", true)
    local tracks = animator and animator:GetPlayingAnimationTracks() or {}
    return model, animator, tracks[1]
end
local function jointsAndParts(model)
    local parts, motors = {}, {}
    for _, inst in ipairs(model:GetDescendants()) do
        -- AvatarJointUpgrade uses AnimationConstraint on R15 rigs. Its read-only
        -- Part0/Part1/C0/C1 aliases and Transform have the same pose semantics.
        if inst:IsA("Motor6D") or inst:IsA("AnimationConstraint") then table.insert(motors, inst) end
        if inst:IsA("BasePart") and inst.Name ~= "HumanoidRootPart" and inst.Parent == model then table.insert(parts, inst) end
    end
    table.sort(parts, function(a, b) return a.Name < b.Name end)
    return motors, parts
end
local function worldPoses(model, motors)
    local root = model:FindFirstChild("HumanoidRootPart")
    if not root then error("The generated rig has no root part.") end
    local frames = { [root] = root.CFrame }
    for _ = 1, #motors do
        local added = false
        for _, motor in ipairs(motors) do
            if motor.Part0 and motor.Part1 and frames[motor.Part0] and not frames[motor.Part1] then
                frames[motor.Part1] = frames[motor.Part0] * motor.C0 * motor.Transform * motor.C1:Inverse()
                added = true
            end
        end
        if not added then break end
    end
    return frames, root.CFrame
end
local function applyPose(model, motors)
    local frames = worldPoses(model, motors)
    for part, cf in pairs(frames) do part.CFrame = cf end
end
local function status(target)
    local errorMessage = target:GetAttribute("PreviewError")
    if errorMessage then return { error = errorMessage } end
    return {
        state = target:GetAttribute("Playing") and "playing" or "paused",
        assetId = target:GetAttribute("AssetId"), rigType = target:GetAttribute("RigType"),
        position = target:GetAttribute("Position") or 0, length = target:GetAttribute("Length") or 0,
        speed = target:GetAttribute("Speed") or 1, loop = target:GetAttribute("Loop") == true,
        fps = 30, totalFrames = math.ceil((target:GetAttribute("Length") or 0) * 30) + 1
    }
end
if request.command == "load" then
    if folder then folder:Destroy() end
    folder = Instance.new("Folder")
    folder.Name = "_KAGE_PREVIEW_" .. string.sub(request.owner, 1, 8)
    folder.Archivable = false
    folder:SetAttribute("KagePreviewOwner", request.owner)
    folder:SetAttribute("KagePreviewTransient", true)
    folder:SetAttribute("ClipToken", request.clip)
    -- Rig creation yields; allow it to finish within the transport deadline.
    -- Once loaded, the shorter renewable idle lease applies again.
    folder:SetAttribute("LeaseUntil", os.clock() + 45)
    folder.Parent = Workspace
    -- Start cleanup before any yielding asset/model request, including failed or cancelled loads.
    task.spawn(function()
        while folder.Parent do
            RunService.Heartbeat:Wait()
            if folder.Parent and (os.clock() > (folder:GetAttribute("LeaseUntil") or 0) or RunService:IsRunning()) then
                folder:Destroy()
                break
            end
        end
    end)
    local ok, err = pcall(function()
        local Players = game:GetService("Players")
        local description = Instance.new("HumanoidDescription")
        local made, model = pcall(function()
            return Players:CreateHumanoidModelFromDescriptionAsync(description, Enum.HumanoidRigType[request.rigType])
        end)
        description:Destroy()
        if not made then error(model) end
        if not folder.Parent then model:Destroy(); error("Preview load timed out while creating the rig. Load again.") end
        -- Verify that Studio returned the actual Roblox body topology requested by
        -- the viewer instead of accepting a vague/custom humanoid silhouette.
        local required = request.rigType == "R6"
            and { "Head", "Torso", "Left Arm", "Right Arm", "Left Leg", "Right Leg" }
            or { "Head", "UpperTorso", "LowerTorso", "LeftUpperArm", "LeftLowerArm", "LeftHand", "RightUpperArm", "RightLowerArm", "RightHand", "LeftUpperLeg", "LeftLowerLeg", "LeftFoot", "RightUpperLeg", "RightLowerLeg", "RightFoot" }
        for _, name in ipairs(required) do
            local part = model:FindFirstChild(name)
            if not part or not part:IsA("BasePart") then
                model:Destroy()
                error("Studio returned an incomplete " .. request.rigType .. " Roblox rig (missing " .. name .. ").")
            end
        end
        model.Name = "Rig"
        model.Archivable = false
        model.Parent = folder
        for _, inst in ipairs(model:GetDescendants()) do
            if inst:IsA("LuaSourceContainer") then inst:Destroy()
            elseif inst:IsA("BasePart") then
                -- A single anchored root keeps the rig fixed without splitting
                -- its body joints into disconnected anchored assemblies.
                inst.Anchored = inst.Name == "HumanoidRootPart"
                inst.CanCollide = false
                inst.CanTouch = false
                inst.CanQuery = false
            end
        end
        local camera = Workspace.CurrentCamera
        if camera then model:PivotTo(camera.CFrame * CFrame.new(0, -1, -10) * CFrame.Angles(0, math.pi, 0)) end
        local humanoid = model:FindFirstChildOfClass("Humanoid")
        local animator = humanoid and humanoid:FindFirstChildOfClass("Animator")
        if not animator then
            if not humanoid then error("The generated rig has no Humanoid.") end
            animator = Instance.new("Animator")
            animator.Parent = humanoid
        end
        local animation = Instance.new("Animation")
        animation.Name = "Clip"
        animation.AnimationId = "rbxassetid://" .. request.assetId
        animation.Parent = folder
        local track = animator:LoadAnimation(animation)
        track.Looped = true -- Hold the track alive; KAGE handles the requested end/loop behavior.
        track:Play(0, 1, 0)
        -- Length remains zero while Roblox fetches the clip. Rig creation and
        -- asset loading share the bounded RPC window rather than an 8s cutoff.
        local deadline = (folder:GetAttribute("LeaseUntil") or 0) - 5
        while folder.Parent and track.Length <= 0 and os.clock() < deadline do task.wait(0.05) end
        if not folder.Parent then error("Preview load timed out. Load again.") end
        if track.Length <= 0 then error("Animation did not load. Check its ID, rig type, and this experience's animation permissions.") end
        if track.Length > 120 then error("Preview supports animations up to 120 seconds. This clip is longer.") end
        folder:SetAttribute("AssetId", request.assetId)
        folder:SetAttribute("RigType", request.rigType)
        folder:SetAttribute("Length", track.Length)
        folder:SetAttribute("Position", 0)
        folder:SetAttribute("Speed", 1)
        folder:SetAttribute("Loop", true)
        folder:SetAttribute("Playing", false)
        folder:SetAttribute("LeaseUntil", os.clock() + 20)
        local motors = jointsAndParts(model)
        track.TimePosition = 0
        animator:StepAnimations(0)
        applyPose(model, motors)
        task.spawn(function()
            local last = os.clock()
            while folder.Parent do
                RunService.Heartbeat:Wait()
                if not folder.Parent then break end
                local now = os.clock()
                if now > (folder:GetAttribute("LeaseUntil") or 0) or RunService:IsRunning() then break end
                local delta = math.min(now - last, 0.1)
                last = now
                if not folder:GetAttribute("Sampling") then
                    local stepped, stepError = pcall(function()
                        local position = folder:GetAttribute("Position") or 0
                        if folder:GetAttribute("Playing") then
                            position = position + delta * (folder:GetAttribute("Speed") or 1)
                            if position >= track.Length then
                                if folder:GetAttribute("Loop") then position = position % track.Length
                                else position = track.Length; folder:SetAttribute("Playing", false) end
                            end
                            folder:SetAttribute("Position", position)
                        end
                        track.TimePosition = math.min(position, math.max(0, track.Length - 0.00001))
                        animator:StepAnimations(0)
                        applyPose(model, motors)
                    end)
                    if not stepped then
                        folder:SetAttribute("PreviewError", tostring(stepError))
                        folder:SetAttribute("Playing", false)
                        break
                    end
                end
            end
            -- Keep an evaluation error until a status request can report it;
            -- the independent lease watchdog still removes this temporary rig.
            if folder.Parent and not folder:GetAttribute("PreviewError") then folder:Destroy() end
        end)
    end)
    if not ok then folder:Destroy(); return fail(err) end
    local response = status(folder)
    response.avatarUserId = 0
    return reply(response)
end
if not folder then
    if request.command == "status" then return reply({ state = "stopped", position = 0 }) end
    return fail("Load an animation before using playback controls.")
end
folder:SetAttribute("LeaseUntil", os.clock() + 20)
local model, animator, track = findTrack(folder)
if not track then folder:Destroy(); return fail("The preview track ended. Load the animation again.") end
if request.command == "play" then
    if (folder:GetAttribute("Position") or 0) >= track.Length then folder:SetAttribute("Position", 0) end
    folder:SetAttribute("Playing", true)
elseif request.command == "pause" then folder:SetAttribute("Playing", false)
elseif request.command == "seek" then folder:SetAttribute("Position", math.clamp(request.value, 0, track.Length))
elseif request.command == "speed" then folder:SetAttribute("Speed", math.clamp(request.value, 0.25, 2))
elseif request.command == "loop" then folder:SetAttribute("Loop", request.loop == true)
elseif request.command == "sample" then
    folder:SetAttribute("Sampling", true)
    local savedPosition = folder:GetAttribute("Position") or 0
    local ok, payload = pcall(function()
        local motors, parts = jointsAndParts(model)
        if #parts > 20 then error("The preview rig contains too many body parts.") end
        local geometry, frames = {}, {}
        for _, part in ipairs(parts) do
            local isHead = part.Name == "Head"
            table.insert(geometry, { name = part.Name, size = { part.Size.X, part.Size.Y, part.Size.Z }, color = { part.Color.R, part.Color.G, part.Color.B }, shape = isHead and "head" or "box" })
        end
        local total = math.ceil(track.Length * 30) + 1
        for index = request.start, math.min(total - 1, request.start + request.count - 1) do
            track.TimePosition = math.min(index / 30, math.max(0, track.Length - 0.00001))
            animator:StepAnimations(0)
            local poses, origin = worldPoses(model, motors)
            local frame = {}
            for _, part in ipairs(parts) do
                local cf = origin:ToObjectSpace(poses[part] or part.CFrame)
                local axis, angle = cf:ToAxisAngle()
                local sine = math.sin(angle / 2)
                local values = { cf.X, cf.Y, cf.Z, axis.X * sine, axis.Y * sine, axis.Z * sine, math.cos(angle / 2) }
                for _, value in ipairs(values) do table.insert(frame, math.floor(value * 100000 + 0.5) / 100000) end
            end
            table.insert(frames, frame)
        end
        return { state = "sampled", start = request.start, fps = 30, totalFrames = total, length = track.Length, parts = geometry, frames = frames }
    end)
    local restored, restoreError = pcall(function()
        track.TimePosition = math.min(savedPosition, math.max(0, track.Length - 0.00001))
        animator:StepAnimations(0)
    end)
    folder:SetAttribute("Sampling", false)
    if not ok then return fail(payload) end
    if not restored then return fail(restoreError) end
    return reply(payload)
elseif request.command ~= "status" then return fail("Unknown animation preview command.") end
return reply(status(folder))
""";
}
