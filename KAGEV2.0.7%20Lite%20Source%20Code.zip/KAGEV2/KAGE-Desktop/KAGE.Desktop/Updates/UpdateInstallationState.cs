using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace KAGE.Desktop.Updates;

// Remember what this installation actually accepted, not just the last check.
// The module identity also resets the baseline when an EXE is replaced manually.
internal sealed record UpdateInstallationState(string BinaryId, string RepositoryRevision, string PackageSha256, long ManifestBuildId = 0)
{
    private static string CurrentBinaryId => Assembly.GetExecutingAssembly().ManifestModule.ModuleVersionId.ToString("N");
    private static string StatePath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "KAGE", "Updates",
        "installation-" + Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(
            Path.GetFullPath(AppContext.BaseDirectory).ToUpperInvariant())))[..16] + ".json");

    public static UpdateInstallationState? Load()
    {
        try
        {
            if (!File.Exists(StatePath)) return null;
            var state = JsonSerializer.Deserialize<UpdateInstallationState>(File.ReadAllText(StatePath));
            return state?.BinaryId == CurrentBinaryId && state.RepositoryRevision is not null &&
                state.PackageSha256 is not null ? state : null;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException) { return null; }
    }

    public static void Save(string revision, string packageSha256, long manifestBuildId = 0)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(StatePath)!);
        var temp = StatePath + ".tmp";
        File.WriteAllText(temp, JsonSerializer.Serialize(new UpdateInstallationState(CurrentBinaryId, revision, packageSha256,
            manifestBuildId > 0 ? manifestBuildId : UpdateBuildInfo.BuildId)));
        File.Move(temp, StatePath, true);
    }
}
