// v54: composer auto-grow, Settings Discord decoration, stable Reupload surface.
(() => {
  'use strict';

  // Auto-grow Shade inputs without exposing the native WebView2 textarea
  // scrollbar arrows. A long message can grow to 96px, then the text area
  // scrolls internally while the scrollbar remains visually hidden.
  const bindComposer = textarea => {
    if (!textarea || textarea.dataset.kageAutoGrow === '1') return;
    textarea.dataset.kageAutoGrow = '1';
    const resize = () => {
      textarea.style.height = '34px';
      const next = Math.max(34, Math.min(96, textarea.scrollHeight));
      textarea.style.height = `${next}px`;
      textarea.style.overflowY = textarea.scrollHeight > 96 ? 'auto' : 'hidden';
    };
    textarea.addEventListener('input', resize, { passive: true });
    textarea.addEventListener('paste', () => requestAnimationFrame(resize));
    textarea.addEventListener('cut', () => requestAnimationFrame(resize));
    resize();
  };
  bindComposer(document.getElementById('shade-input-main'));
  bindComposer(document.getElementById('shade-input-sidecar'));

  // workspace-polish used to collapse Settings to Discord-only. v54 restores the
  // requested side-by-side Roblox + Discord identity presentation.
  const settingsDetails = document.querySelector('.settings-account-details');
  settingsDetails?.classList.remove('workspace-discord-identity');
  document.querySelector('.settings-account-details .identity-line.roblox')?.classList.remove('workspace-duplicate-identity');

  const safeMediaUrl = value => {
    const url = String(value || '').trim();
    if (!url) return '';
    try {
      const parsed = new URL(url);
      return parsed.protocol === 'https:' && parsed.hostname === 'cdn.discordapp.com' ? parsed.href : '';
    } catch { return ''; }
  };

  const paintSettingsDiscord = data => {
    const discord = data?.discord || {};
    const avatar = document.getElementById('settings-discord-avatar');
    const image = document.getElementById('settings-discord-avatar-image');
    const decoration = document.getElementById('settings-discord-decoration');
    const avatarUrl = safeMediaUrl(discord.avatar);
    const decorationUrl = safeMediaUrl(discord.decoration);
    if (avatar) avatar.style.backgroundImage = 'none';
    if (image) {
      if (avatarUrl) image.src = avatarUrl;
      else image.removeAttribute('src');
    }
    if (decoration) {
      if (decorationUrl) decoration.src = decorationUrl;
      else decoration.removeAttribute('src');
    }
  };

  // v53 already wraps updateAccountInfo. Wrap the final function so Settings
  // receives the authenticated OAuth avatar and decoration after every refresh.
  const previousUpdateAccountInfo = window.updateAccountInfo;
  if (typeof previousUpdateAccountInfo === 'function') {
    window.updateAccountInfo = function(data) {
      previousUpdateAccountInfo(data);
      paintSettingsDiscord(data);
    };
  }
})();
