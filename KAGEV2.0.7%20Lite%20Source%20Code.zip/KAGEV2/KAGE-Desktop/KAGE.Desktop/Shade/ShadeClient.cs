using System.Net;
using Kage.Security;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace KAGE.Desktop.Shade;

/// <summary>Native-only sessions and verified generation 2 replies; the WebView receives model text.</summary>
internal sealed class ShadeClient : IDisposable
{
    private readonly HttpClient _http;
    private readonly Uri _baseUri;
    private readonly KageAuthenticatedTransport _transport;

    public ShadeClient()
    {
        _http = new HttpClient(new HttpClientHandler { AllowAutoRedirect = false }) { Timeout = Timeout.InfiniteTimeSpan };
        _baseUri = KageServiceConfiguration.ServiceBase;
        _transport = new KageAuthenticatedTransport(_http, _baseUri, TimeSpan.FromSeconds(35));
    }

    internal ShadeClient(HttpClient http, Uri serviceBase, KageResponseTrust trust)
    {
        _http = http; _baseUri = serviceBase;
        _transport = new KageAuthenticatedTransport(http, serviceBase, trust, TimeSpan.FromSeconds(35));
    }

    // This public connectivity hint is never proof of authorization.
    public async Task<ShadeHealthResponse> GetHealthAsync(CancellationToken ct)
    {
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(ct);
        deadline.CancelAfter(TimeSpan.FromSeconds(12));
        try
        {
            using var response = await _http.GetAsync(new Uri(_baseUri, "/api/g2/shade/health"), HttpCompletionOption.ResponseHeadersRead, deadline.Token).ConfigureAwait(false);
            if (!response.IsSuccessStatusCode) throw new ShadeServiceException("Shade is temporarily unavailable.");
            var json = await ReadHealthAsync(response.Content, deadline.Token).ConfigureAwait(false);
            var health = JsonSerializer.Deserialize<ShadeHealthResponse>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            if (health?.Ok != true) throw new ShadeServiceException("Shade is temporarily unavailable.");
            return health;
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested) { throw new ShadeConnectionException("Shade health check timed out."); }
        catch (HttpRequestException ex) { throw new ShadeConnectionException("Could not reach Shade.", ex); }
        catch (JsonException) { throw new ShadeServiceException("Shade returned an invalid health response."); }
    }

    public async Task<bool> CheckAuthorizationAsync(CancellationToken ct)
    {
        var session = GetSession();
        try
        {
            using var response = await _transport.PostAsync("/api/g2/shade/auth/check", new { clientChallenge = session.Challenge }, session.Token, ct).ConfigureAwait(false);
            return response.IsSuccessStatusCode && response.Body.RootElement.TryGetProperty("success", out var success) && success.ValueKind == JsonValueKind.True;
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested) { throw new ShadeConnectionException("Shade authorization check timed out."); }
        catch (HttpRequestException ex) { throw new ShadeConnectionException("Could not verify Shade authorization.", ex); }
        catch (InvalidDataException) { throw new ShadeStreamProtocolException("Shade response could not be verified."); }
        catch (JsonException) { throw new ShadeStreamProtocolException("Shade response could not be verified."); }
    }

    public async IAsyncEnumerable<ShadeStreamEvent> StreamChatAsync(IReadOnlyList<ShadeMessage> messages, [EnumeratorCancellation] CancellationToken ct)
    {
        if (messages.Count is < 1 or > 8 || messages.Any(m => m.Role is not ("user" or "assistant") || m.Content.Length > 12000))
            throw new ShadeServiceException("Shade conversation is too large.");
        var session = GetSession();
        var body = new { clientChallenge = session.Challenge, surface = "desktop", messages = messages.Select(m => new { role = m.Role, content = m.Content }).ToArray() };
        using var response = await SendChatAsync(body, session.Token, ct).ConfigureAwait(false);
        EnsureSuccess(response);
        var root = response.Body.RootElement;
        var reply = KageResponseTrust.String(root, "reply").Trim();
        if (reply.Length == 0) reply = KageResponseTrust.String(root, "response").Trim();
        if (reply.Length is 0 or > 64000) throw new ShadeStreamProtocolException("Shade returned invalid reply text.");
        // Authenticate the completed service-binding JSON before adapting it
        // to the existing message animation events.
        yield return new ShadeStreamEvent("start");
        yield return new ShadeStreamEvent("delta", reply);
        yield return new ShadeStreamEvent("done");
    }

    private async Task<KageAuthenticatedResponse> SendChatAsync(object body, string session, CancellationToken ct)
    {
        for (var attempt = 0; attempt < 2; attempt++)
        {
            try
            {
                var response = await _transport.PostAsync("/api/g2/shade/chat", body, session, ct).ConfigureAwait(false);
                if ((int)response.StatusCode >= 500 && attempt == 0) { response.Dispose(); await Task.Delay(250, ct).ConfigureAwait(false); continue; }
                return response;
            }
            catch (InvalidDataException) { throw new ShadeStreamProtocolException("Shade response could not be verified."); }
            catch (JsonException) { throw new ShadeStreamProtocolException("Shade response could not be verified."); }
            catch (OperationCanceledException) when (!ct.IsCancellationRequested) { throw new ShadeConnectionException("Shade request timed out."); }
            catch (HttpRequestException) when (attempt == 0) { await Task.Delay(250, ct).ConfigureAwait(false); }
            catch (HttpRequestException ex) { throw new ShadeConnectionException("Could not reach Shade.", ex); }
        }
        throw new ShadeConnectionException("Could not reach Shade.");
    }

    private static (string Token, string Challenge) GetSession()
    {
        if (KageSupportPolicy.IsBlocked || !LiteSessionGate.TryGetSessionTransport(out var token, out var challenge))
            throw new ShadeAuthException("Authorize KAGE through Discord to use Shade.");
        return (token, challenge);
    }

    private static void EnsureSuccess(KageAuthenticatedResponse response)
    {
        if (response.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden)
            throw new ShadeAuthException("Your KAGE Discord authorization must be renewed.");
        if ((int)response.StatusCode == 429) throw new ShadeRateLimitException("Shade is receiving too many requests. Try again shortly.");
        if (!response.IsSuccessStatusCode) throw new ShadeServiceException("Shade is temporarily unavailable. Please try again.");
    }

    private static async Task<byte[]> ReadHealthAsync(HttpContent content, CancellationToken ct)
    {
        if (content.Headers.ContentLength > 16384) throw new ShadeServiceException("Shade returned an invalid health response.");
        await using var stream = await content.ReadAsStreamAsync(ct).ConfigureAwait(false);
        using var output = new MemoryStream(); var bytes = new byte[4096]; int read;
        while ((read = await stream.ReadAsync(bytes.AsMemory(), ct).ConfigureAwait(false)) > 0)
        { if (output.Length + read > 16384) throw new ShadeServiceException("Shade returned an invalid health response."); output.Write(bytes, 0, read); }
        return output.ToArray();
    }

    public void Dispose() => _http.Dispose();
}
