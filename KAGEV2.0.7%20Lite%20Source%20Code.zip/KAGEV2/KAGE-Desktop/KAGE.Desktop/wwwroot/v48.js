// v48 cohesive UI pass. Keeps existing native workflows; changes presentation and reliability handshakes only.
(() => {
  'use strict';
  if (new URLSearchParams(location.search).get('shadePopout') === '1') {
    installTooltips();
    removeNativeTitles();
    return;
  }

  function removeNativeTitles() {
    document.querySelectorAll('[title]').forEach(node => {
      if (!node.dataset.tooltip && node.getAttribute('title')) node.dataset.tooltip = node.getAttribute('title');
      node.removeAttribute('title');
    });
  }

  function installTooltips() {
    if (document.getElementById('kage-tooltip')) return;
    const tip = document.createElement('div');
    tip.id = 'kage-tooltip'; tip.className = 'kage-tooltip'; tip.setAttribute('role','tooltip');
    document.body.appendChild(tip);
    let timer = 0, target = null;
    const hide = () => { clearTimeout(timer); target = null; tip.classList.remove('visible'); };
    const place = (node) => {
      const rect = node.getBoundingClientRect();
      tip.style.left = '0px'; tip.style.top = '0px';
      const box = tip.getBoundingClientRect();
      let left = rect.left + rect.width / 2 - box.width / 2;
      let top = rect.bottom + 8;
      if (top + box.height > innerHeight - 8) top = rect.top - box.height - 8;
      left = Math.max(8, Math.min(left, innerWidth - box.width - 8));
      top = Math.max(8, Math.min(top, innerHeight - box.height - 8));
      tip.style.left = `${left}px`; tip.style.top = `${top}px`;
    };
    document.addEventListener('pointerover', event => {
      const node = event.target.closest?.('[data-tooltip]'); if (!node || !node.dataset.tooltip) return;
      clearTimeout(timer); target = node;
      timer = setTimeout(() => {
        if (target !== node || !node.isConnected) return;
        tip.textContent = node.dataset.tooltip; place(node); tip.classList.add('visible');
      }, 380);
    });
    document.addEventListener('pointerout', event => { if (event.target.closest?.('[data-tooltip]')) hide(); });
    document.addEventListener('pointerdown', hide, true);
    window.addEventListener('resize', hide);
  }

  function setAvatar(id, url) {
    const node = document.getElementById(id); if (!node) return;
    const safe = String(url || '').trim();
    node.style.backgroundImage = safe ? `url("${safe.replace(/["\\]/g,'')}")` : '';
    node.classList.toggle('avatar-missing', !safe);
  }

  // Keep all account renderers in sync, including the newly added Discord portraits.
  const previousAccountInfo = window.updateAccountInfo;
  if (typeof previousAccountInfo === 'function') {
    window.updateAccountInfo = function(data) {
      previousAccountInfo(data);
      const discord = data?.discord || {}, roblox = data?.roblox || {};
      setAvatar('home-profile-avatar', roblox.avatar);
      setAvatar('welcome-discord-avatar', discord.avatar);
      setAvatar('welcome-back-avatar', roblox.avatar);
      if (document.getElementById('home-profile-name')) animateText('home-profile-name', roblox.displayName || roblox.username || 'Roblox Account');
      if (document.getElementById('welcome-back-name')) animateText('welcome-back-name', roblox.displayName || roblox.username || 'Roblox Account');
      if (document.getElementById('welcome-discord-name')) animateText('welcome-discord-name', discord.username || 'Discord Account');
      if (document.getElementById('welcome-discord-id')) animateText('welcome-discord-id', discord.id ? `ID: ${discord.id}` : 'ID: —');
      // Report the exact upper-right logo destination before uiReady so the
      // native splash can hand its logo into the GUI instead of fading blindly.
      try {
        const logo = document.querySelector('.title-corner-logo');
        const rect = logo?.getBoundingClientRect?.();
        if (rect && rect.width > 0 && rect.height > 0) window.chrome?.webview?.postMessage({
          action:'titleLogoRect', x:rect.left, y:rect.top, width:rect.width, height:rect.height
        });
        window.chrome?.webview?.postMessage({ action:'uiReady' });
      } catch {}
    };
  }

  // The v44 workspace layer used to add redundant section headings; retire them after install too.
  const stripWorkspaceHeadings = () => document.querySelectorAll('#tab-reupload .workspace-section-title').forEach(node => node.remove());
  stripWorkspaceHeadings();
  new MutationObserver(stripWorkspaceHeadings).observe(document.getElementById('tab-reupload') || document.body,{childList:true,subtree:true});

  // Browser-like Shade content transition when switching/creating chats.
  const shadeTabs = document.getElementById('shade-editor-tabs');
  const chatCard = document.querySelector('#tab-ai .shade-chat-card');
  shadeTabs?.addEventListener('click', event => {
    if (!event.target.closest('.shade-chat-tab,.shade-chat-tab-close')) return;
    chatCard?.classList.remove('shade-tab-transition'); void chatCard?.offsetWidth; chatCard?.classList.add('shade-tab-transition');
  });
  document.getElementById('shade-new-chat')?.addEventListener('click', () => {
    chatCard?.classList.remove('shade-tab-transition'); void chatCard?.offsetWidth; chatCard?.classList.add('shade-tab-transition');
  });

  // Remove native/browser tooltip surfaces in favor of the shared KAGE tooltip.
  removeNativeTitles(); installTooltips();
  const mo = new MutationObserver(() => removeNativeTitles()); mo.observe(document.body,{subtree:true,childList:true,attributes:true,attributeFilter:['title']});

})();
