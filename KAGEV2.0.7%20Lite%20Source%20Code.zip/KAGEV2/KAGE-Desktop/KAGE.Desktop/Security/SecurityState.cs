namespace KAGE.Desktop;

internal enum SecurityLevel
{
    Clean = 0,
    Observed = 1,
    Suspicious = 2,
    Tampered = 3
}


internal enum SignalConfidence
{
    Low = 0,
    Medium = 1,
    High = 2
}

internal sealed record SecuritySignal(string Code, SignalConfidence Confidence, bool Observed);

internal sealed record SecurityState(
    SecurityLevel Level,
    IReadOnlyList<string> Codes,
    DateTimeOffset CheckedAtUtc)
{
    internal static SecurityState CleanNow() =>
        new(SecurityLevel.Clean, Array.Empty<string>(), DateTimeOffset.UtcNow);

    internal static SecurityState Create(SecurityLevel level, IEnumerable<string>? codes = null) =>
        new(
            level,
            (codes ?? Array.Empty<string>())
                .Where(code => !string.IsNullOrWhiteSpace(code))
                .Distinct(StringComparer.Ordinal)
                .OrderBy(code => code, StringComparer.Ordinal)
                .ToArray(),
            DateTimeOffset.UtcNow);

    internal static SecurityState Merge(params SecurityState[] states)
    {
        if (states.Length == 0)
            return CleanNow();

        var level = states.Max(static state => state.Level);
        var codes = states.SelectMany(static state => state.Codes)
            .Distinct(StringComparer.Ordinal)
            .OrderBy(static code => code, StringComparer.Ordinal)
            .ToArray();
        var checkedAt = states.Max(static state => state.CheckedAtUtc);
        return new SecurityState(level, codes, checkedAt);
    }
}
