using System.Reflection;

namespace KAGE.Desktop;

internal static class EmbeddedWebAssets
{
    public static readonly string[] RequiredPaths =
    {
        "index.html",
        "setup.html",
        "app.js",
        "progress-ui.js",
        "style.css",
        "v47.css",
        "v47.js",
        "v54.css",
        "v96.css",
        "v54.js",
        "setup.js",
        "setup.css",
        "kage-navigation.css",
        "kage-navigation.js",
        "kage-207-corrections.css",
        "ui-icons-polish.css",
        "Assets/kage-logout.png",
        "Assets/nav-shade.png",
        "Assets/ui-settings-check.png",
        "Assets/ui-clear-logs.png",
        "Assets/ui-secret-eye.png",
        "Assets/ui-preview-prev.png",
        "Assets/ui-preview-next.png",
        "Assets/ui-refresh.png",
        "Assets/ui-shade-compose-border.png",
        "Assets/kage-progress-empty.png",
        "Assets/kage-progress-full.png",
        "Assets/logo.png",
        "Assets/icon.ico",
        "Assets/discord-logo.png",
        "Assets/nav-home.svg",
        "Assets/nav-watch.svg",
        "Assets/nav-reupload.svg",
        "Assets/nav-stats.svg",
        "Assets/nav-settings.svg",
        "Assets/nav-shade.svg",
        "Assets/shade.png",
        "Assets/shade.ico",
        "Assets/button-click.mp3",
        "Assets/immersivecontrol-hover.mp3",
        "Assets/reupload-round-arrows.svg",
        "Assets/preview-play.svg",
        "Assets/preview-pause.svg",
        "Assets/preview-stop.svg",
        "Assets/preview-eye.svg",
        "Assets/action-trash.svg",
        "Assets/shade-popout.svg",
        "Assets/shade-new-chat.svg",
        "Assets/nav-console.svg",
        "Assets/nav-explorer.svg",
        "Assets/roblox-studio.svg",
        "Assets/roblox-studio-2025.svg",
        "Assets/folder.svg",
        "Assets/asset-animation.svg",
        "Assets/asset-sound.svg",
        "Assets/asset-mesh.svg",
        "Assets/asset-decal.svg",
        "Assets/update-cloud.svg",
        "Assets/moon-change.gif",
        "Assets/blood-drip.gif",
        "Assets/vampire-fangs.gif",
        "Assets/dark-moon.gif",
        "Assets/matt-the-bat-flying-meme.gif"
    };

    private static readonly Assembly Assembly = typeof(EmbeddedWebAssets).Assembly;
    private static readonly string[] ResourceNames = Assembly.GetManifestResourceNames();

    public static bool TryOpen(string requestPath, out Stream stream, out string contentType)
    {
        var cleanPath = Uri.UnescapeDataString(requestPath ?? string.Empty)
            .Replace('\\', '/')
            .TrimStart('/');

        if (string.IsNullOrWhiteSpace(cleanPath))
            cleanPath = "index.html";

        // Protected releases rename every embedded web/UI resource to an HMAC-derived
        // identifier. Development builds fall back to ordinary manifest suffix lookup.
        var protectedName = BlackoutRuntime.ProtectedResourceName(cleanPath);
        var resourceName = ResourceNames.FirstOrDefault(name =>
            string.Equals(name, protectedName, StringComparison.Ordinal));

        if (resourceName is null)
        {
            var webRelative = cleanPath.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase)
                ? cleanPath
                : $"wwwroot/{cleanPath}";
            var suffix = "." + webRelative.Replace('/', '.');
            resourceName = ResourceNames.FirstOrDefault(name =>
                name.EndsWith(suffix, StringComparison.OrdinalIgnoreCase));
        }

        if (resourceName is null)
        {
            stream = Stream.Null;
            contentType = "application/octet-stream";
            return false;
        }

        var rawStream = Assembly.GetManifestResourceStream(resourceName) ?? Stream.Null;
        if (rawStream == Stream.Null)
        {
            stream = Stream.Null;
            contentType = "application/octet-stream";
            return false;
        }

        stream = BlackoutRuntime.OpenProtectedResource(rawStream, resourceName);
        contentType = GetContentType(Path.GetExtension(cleanPath));
        return true;
    }

    public static bool VerifyRequiredResources(out string[] missing)
    {
        missing = RequiredPaths.Where(path =>
        {
            if (!TryOpen(path, out var stream, out _))
                return true;

            stream.Dispose();
            return false;
        }).ToArray();

        return missing.Length == 0;
    }

    private static string GetContentType(string extension) => extension.ToLowerInvariant() switch
    {
        ".html" or ".htm" => "text/html; charset=utf-8",
        ".js" or ".mjs" => "text/javascript; charset=utf-8",
        ".css" => "text/css; charset=utf-8",
        ".json" => "application/json; charset=utf-8",
        ".png" => "image/png",
        ".gif" => "image/gif",
        ".ico" => "image/x-icon",
        ".svg" => "image/svg+xml",
        ".jpg" or ".jpeg" => "image/jpeg",
        ".webp" => "image/webp",
        ".mp3" => "audio/mpeg",
        ".wav" => "audio/wav",
        ".ogg" => "audio/ogg",
        ".woff" => "font/woff",
        ".woff2" => "font/woff2",
        _ => "application/octet-stream"
    };
}
