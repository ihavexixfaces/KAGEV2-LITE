using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text;
using System.Text.Json;

namespace Kage.Bridge;

/// <summary>
/// Minimal stdio MCP client for Roblox Studio's built-in MCP server.
/// Roblox documents the Windows entry point as:
///   cmd.exe /c %LOCALAPPDATA%\Roblox\mcp.bat
/// KAGE intentionally uses that documented launcher instead of inventing Studio flags.
/// </summary>
public sealed class StudioMcpClient : IAsyncDisposable
{
    private static readonly string[] SupportedHandshakeVersions =
    {
        "2025-11-25",
        "2025-06-18",
        "2025-03-26",
        "2024-11-05"
    };

    private readonly SemaphoreSlim _rpcGate = new(1, 1);
    private readonly ConcurrentQueue<string> _diagnostics = new();
    private Process? _process;
    private StreamWriter? _stdin;
    private StreamReader? _stdout;
    private StudioRpcConnection? _connection;
    private CancellationTokenSource _sessionCancellation = new();
    private int _disconnecting;
    private int _disposed;
    private bool _initialized;
    private volatile HashSet<string> _tools = new(StringComparer.Ordinal);

    private bool IsTransportOpen
    {
        get
        {
            try { return _initialized && _connection is { IsOpen: true } && _process is { HasExited: false }; }
            catch (InvalidOperationException) { return false; }
        }
    }
    public bool IsConnected
    {
        get
        {
            var tools = _tools;
            return IsTransportOpen;
        }
    }
    public IReadOnlyCollection<string> Tools => _tools;
    public bool HasTool(string name) => _tools.Contains(name);
    public string ProtocolVersion { get; private set; } = string.Empty;
    public string LastDiagnostic => string.Join(" | ", _diagnostics.Reverse().Take(6).Reverse());

    public static string DefaultWindowsLauncher => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "Roblox", "mcp.bat");

    public static string? ResolveLauncher()
    {
        if (OperatingSystem.IsWindows())
            return File.Exists(DefaultWindowsLauncher) ? DefaultWindowsLauncher : null;

        if (OperatingSystem.IsLinux())
        {
            var configured = Environment.GetEnvironmentVariable("KAGE_STUDIO_MCP_LAUNCHER")?.Trim();
            if (!string.IsNullOrWhiteSpace(configured) && File.Exists(configured))
                return Path.GetFullPath(configured);
        }
        return null;
    }

    public static bool IsLauncherAvailable => ResolveLauncher() is not null;

    public async Task ConnectAsync(CancellationToken ct = default)
    {
        ObjectDisposedException.ThrowIf(Volatile.Read(ref _disposed) != 0, this);
        if (Volatile.Read(ref _disconnecting) != 0) throw new IOException("Studio is disconnecting. Connect again after it finishes.");
        using var connectDeadline = CancellationTokenSource.CreateLinkedTokenSource(ct);
        connectDeadline.CancelAfter(TimeSpan.FromSeconds(30));
        await _rpcGate.WaitAsync(connectDeadline.Token).ConfigureAwait(false);
        try
        {
            if (Volatile.Read(ref _disconnecting) != 0) throw new IOException("Studio disconnected while connecting.");
            // A live launcher is not evidence that its current editor still
            // exposes tools. Discover read-only capabilities before any call.
            if (IsTransportOpen)
            {
                try
                {
                    using var refresh = CancellationTokenSource.CreateLinkedTokenSource(connectDeadline.Token, _sessionCancellation.Token);
                    await RefreshToolCatalogBestEffortAsync(refresh.Token).ConfigureAwait(false);
                    return;
                }
                catch (Exception ex) when (!connectDeadline.IsCancellationRequested && !_sessionCancellation.IsCancellationRequested)
                {
                    RecordDiagnostic($"Studio MCP readiness changed: {ex.Message}; reconnecting the session.");
                    // Only discovery is retried. No execute_luau request has
                    // been sent, so replacing this transport cannot replay it.
                }
            }
            await RetireSessionAsync().ConfigureAwait(false);
            _sessionCancellation = new CancellationTokenSource();
            using var session = CancellationTokenSource.CreateLinkedTokenSource(connectDeadline.Token, _sessionCancellation.Token);
            ct = session.Token;
            _diagnostics.Clear();

            var launcher = ResolveLauncher();
            if (string.IsNullOrWhiteSpace(launcher))
            {
                if (OperatingSystem.IsLinux())
                    throw new FileNotFoundException("Roblox Studio MCP launcher was not found. Set KAGE_STUDIO_MCP_LAUNCHER to the MCP launcher used by your Linux/Wine Studio setup, then reopen KAGE.");
                throw new FileNotFoundException(
                    "Roblox Studio's MCP launcher was not found. Update Roblox Studio, enable Studio as MCP server, and reopen Studio.",
                    DefaultWindowsLauncher);
            }

            var initialize = await InitializeWithFallbackAsync(launcher, ct).ConfigureAwait(false);
            if (initialize.ValueKind != JsonValueKind.Object)
                throw new InvalidOperationException("Roblox Studio MCP returned an invalid initialize response.");

            await SendNotificationUnlockedAsync("notifications/initialized", new { }, ct).ConfigureAwait(false);
            _initialized = true;
            await RefreshToolCatalogBestEffortAsync(ct).ConfigureAwait(false);
            if (!_tools.Contains("get_studio_state"))
                RecordDiagnostic("Studio MCP does not expose get_studio_state; KAGE will use Studio discovery as its heartbeat fallback.");

            RecordDiagnostic($"Connected using MCP {ProtocolVersion}; {_tools.Count} tools currently advertised. Tool calls will refresh/probe on demand.");
        }
        catch (OperationCanceledException) when (IsTransportOpen && !_sessionCancellation.IsCancellationRequested)
        {
            // Cancelling a catalog/preview request only cancels its pending reply.
            // The RPC reader keeps matching late replies by ID; the initialized
            // transport and other queued callers still belong to this session.
            throw;
        }
        catch (Exception ex)
        {
            RecordDiagnostic(ex.Message);
            var detail = LastDiagnostic;
            await RetireSessionAsync().ConfigureAwait(false);
            if (ex is OperationCanceledException) throw;
            throw new InvalidOperationException(string.IsNullOrWhiteSpace(detail) ? ex.Message : $"{ex.Message} ({detail})", ex);
        }
        finally
        {
            _rpcGate.Release();
        }
    }

    private async Task RefreshToolCatalogBestEffortAsync(CancellationToken ct)
    {
        // Roblox Studio can initialize the MCP stdio transport before the editor
        // has finished publishing its full tool catalog. Treat tools/list as
        // advisory during connection instead of rejecting an otherwise healthy
        // transport before list_roblox_studios has had a chance to see the editor.
        // Individual tool calls perform their own bounded refresh/probe below.
        try
        {
            using var refresh = CancellationTokenSource.CreateLinkedTokenSource(ct);
            refresh.CancelAfter(TimeSpan.FromMilliseconds(1500));
            await LoadToolsAsync(refresh.Token).ConfigureAwait(false);
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested)
        {
            RecordDiagnostic("Studio MCP tool catalog was still registering; continuing with direct tool probing.");
        }
        catch (Exception ex) when (!ct.IsCancellationRequested)
        {
            RecordDiagnostic($"Studio MCP tools/list is not ready yet: {ex.Message}; continuing with direct tool probing.");
        }
    }

    private async Task EnsureToolCatalogAsync(string name, CancellationToken ct)
    {
        if (_tools.Contains(name)) return;

        // Once a Studio editor registers, tools that were absent from the very
        // first tools/list snapshot can appear without the stdio server changing.
        // Give discovery a short bounded window, but never make discovery itself
        // a hard prerequisite for dispatching the one requested MCP tool.
        var deadline = DateTimeOffset.UtcNow + TimeSpan.FromMilliseconds(1500);
        using var refresh = CancellationTokenSource.CreateLinkedTokenSource(ct);
        refresh.CancelAfter(TimeSpan.FromMilliseconds(1500));
        Exception? last = null;
        do
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                await LoadToolsAsync(refresh.Token).ConfigureAwait(false);
                if (_tools.Contains(name)) return;
            }
            catch (Exception ex) when (!ct.IsCancellationRequested)
            {
                last = ex;
            }

            if (DateTimeOffset.UtcNow < deadline)
                await Task.Delay(TimeSpan.FromMilliseconds(200), ct).ConfigureAwait(false);
        }
        while (DateTimeOffset.UtcNow < deadline);

        var available = _tools.Count == 0 ? "none advertised yet" : string.Join(", ", _tools.OrderBy(x => x, StringComparer.Ordinal));
        RecordDiagnostic(last is null
            ? $"'{name}' was not advertised after refresh; probing it directly. Advertised tools: {available}."
            : $"'{name}' catalog refresh ended with: {last.Message}; probing it directly. Advertised tools: {available}.");
    }

    private async Task<JsonElement> InitializeWithFallbackAsync(string launcher, CancellationToken ct)
    {
        Exception? lastError = null;
        foreach (var protocolVersion in SupportedHandshakeVersions)
        {
            ct.ThrowIfCancellationRequested();
            await StopCoreAsync().ConfigureAwait(false);
            StartServerProcess(launcher);
            try
            {
                var initialize = await SendRequestUnlockedAsync(
                    "initialize",
                    new
                    {
                        protocolVersion,
                        capabilities = new { },
                        clientInfo = new { name = "KAGE", version = "2.0.6" }
                    },
                    ct).ConfigureAwait(false);

                if (initialize.ValueKind != JsonValueKind.Object)
                    throw new InvalidOperationException("Roblox Studio MCP returned an invalid initialize response.");

                ProtocolVersion = initialize.TryGetProperty("protocolVersion", out var negotiated) && negotiated.ValueKind == JsonValueKind.String
                    ? negotiated.GetString() ?? protocolVersion
                    : protocolVersion;
                if (!SupportedHandshakeVersions.Contains(ProtocolVersion, StringComparer.Ordinal))
                    RecordDiagnostic($"Studio selected MCP {ProtocolVersion}; continuing with the server-selected revision.");
                return initialize;
            }
            catch (Exception ex) when (!ct.IsCancellationRequested)
            {
                lastError = ex;
                RecordDiagnostic($"MCP initialize {protocolVersion} failed: {ex.Message}");
                await StopCoreAsync().ConfigureAwait(false);
            }
        }

        throw new InvalidOperationException(
            "Roblox Studio MCP started but KAGE could not negotiate a supported MCP protocol revision.",
            lastError);
    }

    private async Task LoadToolsAsync(CancellationToken ct)
    {
        var discovered = new HashSet<string>(StringComparer.Ordinal);
        string? cursor = null;
        var seenCursors = new HashSet<string>(StringComparer.Ordinal);
        do
        {
            object parameters = cursor is null
                ? new { }
                : new Dictionary<string, object?> { ["cursor"] = cursor };
            var listed = await SendRequestUnlockedAsync("tools/list", parameters, ct).ConfigureAwait(false);
            if (listed.ValueKind != JsonValueKind.Object || !listed.TryGetProperty("tools", out var tools) || tools.ValueKind != JsonValueKind.Array)
                throw new InvalidOperationException("Roblox Studio MCP returned an invalid tools/list response.");
            foreach (var item in tools.EnumerateArray())
            {
                if (item.ValueKind == JsonValueKind.Object && item.TryGetProperty("name", out var name) &&
                    name.ValueKind == JsonValueKind.String && name.GetString() is { Length: > 0 } toolName)
                    discovered.Add(toolName);
            }

            cursor = listed.TryGetProperty("nextCursor", out var nextCursor) && nextCursor.ValueKind == JsonValueKind.String
                ? nextCursor.GetString()
                : null;
            if (!string.IsNullOrWhiteSpace(cursor) && !seenCursors.Add(cursor))
                throw new InvalidOperationException("Roblox Studio MCP returned a repeated tools/list cursor.");
        }
        while (!string.IsNullOrWhiteSpace(cursor));
        // Publish complete snapshots, never a catalog half-way through paging.
        _tools = discovered;
    }

    private void StartServerProcess(string launcher)
    {
        var isWindows = OperatingSystem.IsWindows();
        var psi = new ProcessStartInfo
        {
            FileName = isWindows ? "cmd.exe" : "/bin/sh",
            WorkingDirectory = Path.GetDirectoryName(launcher) ?? Environment.CurrentDirectory,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardInput = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            StandardInputEncoding = Encoding.UTF8,
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8
        };
        if (isWindows)
        {
            // Match Roblox's documented Windows client command: cmd.exe /c %LOCALAPPDATA%\Roblox\mcp.bat
            psi.ArgumentList.Add("/c");
            psi.ArgumentList.Add(launcher);
        }
        else
        {
            // Linux KAGE supports an explicitly configured MCP launcher without assuming
            // a particular Wine/Studio distribution. /bin/sh keeps ordinary launcher
            // scripts compatible while MCP still communicates only over redirected stdio.
            psi.ArgumentList.Add(launcher);
        }

        var process = Process.Start(psi) ?? throw new InvalidOperationException("Could not start Roblox Studio MCP.");
        _process = process;
        _stdin = process.StandardInput;
        _stdout = process.StandardOutput;
        _connection = new StudioRpcConnection(_stdin, _stdout, RecordDiagnostic);
        RecordDiagnostic($"Started Studio MCP launcher: {launcher}");

        _ = Task.Run(async () =>
        {
            try
            {
                while (!process.HasExited)
                {
                    var line = await process.StandardError.ReadLineAsync().ConfigureAwait(false);
                    if (line is null) break;
                    if (!string.IsNullOrWhiteSpace(line)) RecordDiagnostic(line.Trim());
                }
            }
            catch { }
        });
    }

    public Task<JsonElement> CallToolAsync(string name, object? arguments = null, CancellationToken ct = default) =>
        CallToolAsync(name, arguments, TimeSpan.FromSeconds(40), ct);

    public async Task<JsonElement> CallToolAsync(string name, object? arguments, TimeSpan timeout, CancellationToken ct = default)
    {
        ObjectDisposedException.ThrowIf(Volatile.Read(ref _disposed) != 0, this);
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(ct);
        deadline.CancelAfter(timeout);
        try
        {
            await ConnectAsync(deadline.Token).ConfigureAwait(false);
            using var session = CancellationTokenSource.CreateLinkedTokenSource(deadline.Token, _sessionCancellation.Token);
            await _rpcGate.WaitAsync(session.Token).ConfigureAwait(false);
            try
            {
                await EnsureToolCatalogAsync(name, session.Token).ConfigureAwait(false);
                // Do not reject a healthy Studio session only because an early
                // tools/list snapshot omitted this tool. Roblox's Studio MCP tool
                // catalog can lag editor registration. Dispatch exactly once and
                // let the server be authoritative; unknown-tool responses are
                // handled below and retire the stale session without replaying.
                var result = await SendRequestUnlockedAsync("tools/call", new { name, arguments = arguments ?? new { } }, session.Token, timeout).ConfigureAwait(false);
                ThrowIfToolError(name, result);
                return result;
            }
            catch (Exception ex) when ((ex is OperationCanceledException or TimeoutException) && IsTransportOpen && !_sessionCancellation.IsCancellationRequested)
            {
                // A local request deadline or navigation cancellation does not
                // mean Studio disconnected. Do not replay this possibly executed
                // tool; let its late response drain through the existing reader.
                throw;
            }
            catch (Exception ex) when (ex is OperationCanceledException or IOException or TimeoutException)
            {
                await RetireSessionAsync().ConfigureAwait(false);
                throw;
            }
            catch (InvalidOperationException ex) when (IsUnavailableToolError(name, ex.Message))
            {
                RecordDiagnostic(ex.Message);
                await RetireSessionAsync().ConfigureAwait(false);
                throw; // The tool may have run. Never replay a mutating request.
            }
            finally { _rpcGate.Release(); }
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested)
        {
            var nextStep = IsTransportOpen ? "Retry this request." : "Reconnect Studio and retry.";
            throw new TimeoutException($"Roblox Studio did not finish '{name}' within {Math.Ceiling(timeout.TotalSeconds)} seconds. {nextStep}");
        }
    }

    private static bool IsUnavailableToolError(string name, string message) =>
        message.Contains(name, StringComparison.OrdinalIgnoreCase) &&
        (message.Contains("unknown tool", StringComparison.OrdinalIgnoreCase) ||
         message.Contains("tool not found", StringComparison.OrdinalIgnoreCase) ||
         message.Contains("does not expose", StringComparison.OrdinalIgnoreCase) ||
         message.Contains("tool is not registered", StringComparison.OrdinalIgnoreCase) ||
         message.Contains($"{name} is not registered", StringComparison.OrdinalIgnoreCase) ||
         message.Contains($"'{name}' is not registered", StringComparison.OrdinalIgnoreCase) ||
         message.Contains("tool unavailable", StringComparison.OrdinalIgnoreCase) ||
         message.Contains($"{name} is unavailable", StringComparison.OrdinalIgnoreCase) ||
         message.Contains($"'{name}' is unavailable", StringComparison.OrdinalIgnoreCase));


    private static void ThrowIfToolError(string toolName, JsonElement result)
    {
        if (result.ValueKind != JsonValueKind.Object ||
            !result.TryGetProperty("isError", out var isError) ||
            isError.ValueKind is not (JsonValueKind.True or JsonValueKind.False) ||
            !isError.GetBoolean())
            return;

        var detail = ExtractToolError(result);
        if (string.IsNullOrWhiteSpace(detail))
            detail = "Studio returned an unspecified tool error.";
        throw new InvalidOperationException($"Roblox Studio MCP tool '{toolName}' failed: {detail}");
    }

    private static string ExtractToolError(JsonElement element)
    {
        var messages = new List<string>();
        CollectToolErrorText(element, messages);
        return string.Join(" | ", messages.Where(value => !string.IsNullOrWhiteSpace(value)).Distinct(StringComparer.OrdinalIgnoreCase)).Trim();
    }

    private static void CollectToolErrorText(JsonElement element, List<string> output)
    {
        switch (element.ValueKind)
        {
            case JsonValueKind.String:
                if (element.GetString() is { Length: > 0 } text && text.Length <= 1200)
                    output.Add(text.Replace('\r', ' ').Replace('\n', ' ').Trim());
                break;
            case JsonValueKind.Object:
                foreach (var property in element.EnumerateObject())
                {
                    if (property.NameEquals("isError") || property.NameEquals("type")) continue;
                    CollectToolErrorText(property.Value, output);
                }
                break;
            case JsonValueKind.Array:
                foreach (var item in element.EnumerateArray()) CollectToolErrorText(item, output);
                break;
        }
    }

    private Task<JsonElement> SendRequestUnlockedAsync(string method, object @params, CancellationToken ct, TimeSpan? timeoutOverride = null)
    {
        var connection = _connection ?? throw new IOException("Roblox Studio MCP process is not running.");
        var timeout = timeoutOverride ?? (method is "initialize" or "tools/list" ? TimeSpan.FromSeconds(8) : TimeSpan.FromSeconds(40));
        return connection.RequestAsync(method, @params, timeout, ct);
    }

    private Task SendNotificationUnlockedAsync(string method, object @params, CancellationToken ct) =>
        (_connection ?? throw new IOException("Roblox Studio MCP process is not running.")).NotifyAsync(method, @params, ct);

    private void RecordDiagnostic(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return;
        _diagnostics.Enqueue(value.Replace('\r', ' ').Replace('\n', ' ').Trim());
        while (_diagnostics.Count > 24) _diagnostics.TryDequeue(out _);
    }

    public async Task DisconnectAsync()
    {
        Interlocked.Exchange(ref _disconnecting, 1);
        _sessionCancellation.Cancel();
        _connection?.Abort(); // Interrupt the owner of the gate before waiting for it.
        await _rpcGate.WaitAsync().ConfigureAwait(false);
        try { await StopCoreAsync().ConfigureAwait(false); }
        finally { _rpcGate.Release(); Interlocked.Exchange(ref _disconnecting, 0); }
    }

    private Task RetireSessionAsync()
    {
        // Queued callers must not cross into a later session after discovering
        // capabilities on the retired one. Handshake-version retries only stop
        // their launcher process and retain their own session token.
        _sessionCancellation.Cancel();
        return StopCoreAsync();
    }

    private async Task StopCoreAsync()
    {
        var connection = _connection;
        _connection = null;
        connection?.Abort();
        _initialized = false;
        ProtocolVersion = string.Empty;
        _tools = new HashSet<string>(StringComparer.Ordinal);

        if (_process is not null)
        {
            try
            {
                if (!_process.HasExited)
                    _process.Kill(entireProcessTree: true);
            }
            catch { }
            try { _process.Dispose(); } catch { }
            _process = null;
        }
        try { _stdin?.Dispose(); } catch { }
        try { _stdout?.Dispose(); } catch { }
        _stdin = null;
        _stdout = null;
        if (connection is not null) await connection.DisposeAsync().ConfigureAwait(false);
    }

    public async ValueTask DisposeAsync()
    {
        if (Interlocked.Exchange(ref _disposed, 1) != 0) return;
        await DisconnectAsync().ConfigureAwait(false);
        // Cancellation owners may still be unwinding; the gates/source die with this client.
    }
}
