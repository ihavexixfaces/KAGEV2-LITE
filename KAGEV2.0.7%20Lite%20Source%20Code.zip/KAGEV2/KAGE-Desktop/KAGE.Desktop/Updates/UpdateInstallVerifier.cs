using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using Kage.Security;

namespace KAGE.Desktop.Updates;

internal static class UpdateInstallVerifier
{
    internal static UpdateManifest ReadManifest(string path)
    {
        if (new FileInfo(path).Length > 16384) throw new InvalidDataException("Update manifest exceeds its size limit.");
        var manifest = JsonSerializer.Deserialize<UpdateManifest>(File.ReadAllBytes(path), new JsonSerializerOptions(JsonSerializerDefaults.Web));
        if (manifest is null || !UpdateSignatureVerifier.Verify(manifest) ||
            !UpdateReleasePolicy.CanAutomaticallyInstall(manifest.ReleaseVersion, manifest.ProtocolGeneration) ||
            manifest.Size is <= 0 or > 1_000_000_000 ||
            !string.Equals(manifest.DistributionMode, UpdateBuildInfo.DistributionMode, StringComparison.Ordinal) ||
            !UpdateRepository.IsExpectedPackageName(UpdateBuildInfo.DistributionMode, manifest.Package, manifest.ReleaseVersion) ||
            !GitHubUpdateClient.IsHash(manifest.Sha256, 64) || !GitHubUpdateClient.IsHash(manifest.ExecutableSha256, 64))
            throw new InvalidDataException("The updater has no valid signed release manifest for this channel.");
        return manifest;
    }

    internal static void VerifyFile(string path, string expected, long? size = null)
    {
        if (size.HasValue && new FileInfo(path).Length != size.Value) throw new InvalidDataException("The signed update length changed.");
        using var input = File.OpenRead(path);
        if (!string.Equals(Convert.ToHexString(SHA256.HashData(input)), expected, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("The signed update checksum changed.");
    }

    internal static void ExtractVerifiedZip(string package, string destination, UpdateManifest manifest)
    {
        VerifyFile(package, manifest.Sha256, manifest.Size);
        using var archive = ZipFile.OpenRead(package);
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        long extracted = 0;
        foreach (var entry in archive.Entries)
        {
            var name = entry.FullName.Replace('\\', '/');
            if (name.Length == 0 || name.StartsWith('/') || name.Contains(':') ||
                name.Split('/').Any(x => x is ".." or ".") || !seen.Add(name) ||
                ((entry.ExternalAttributes >> 16) & 0xF000) == 0xA000)
                throw new InvalidDataException("Update archive contains an unsafe or duplicate path.");
            extracted = checked(extracted + entry.Length);
            if (extracted > 2_000_000_000) throw new InvalidDataException("Update archive exceeds its extraction limit.");
            var target = Path.GetFullPath(Path.Combine(destination, name));
            if (!target.StartsWith(Path.GetFullPath(destination) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Update archive escaped the staging directory.");
            if (name.EndsWith('/')) { Directory.CreateDirectory(target); continue; }
            Directory.CreateDirectory(Path.GetDirectoryName(target)!);
            entry.ExtractToFile(target, false);
        }
        VerifyFile(Path.Combine(destination, "KAGE.exe"), manifest.ExecutableSha256);
    }

}
