using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

namespace Kage.Security;

public static class CredentialInput
{
    public static async Task<string> ReadAsync(string label, bool optional, bool consoleOnly, CancellationToken ct)
    {
        if (Console.IsInputRedirected)
            return (await Console.In.ReadLineAsync(ct) ?? string.Empty).Trim();

        if (OperatingSystem.IsWindows() && !consoleOnly)
        {
            Console.WriteLine($"{label}: enter it in the KAGE input window (Alt+Tab if it is behind another window).");
            return await ReadDialogAsync(label, optional, ct);
        }

        return ReadMaskedConsole(label, ct);
    }

    private static async Task<string> ReadDialogAsync(string label, bool optional, CancellationToken ct)
    {
        var powershell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),
            "WindowsPowerShell", "v1.0", "powershell.exe");
        if (!File.Exists(powershell))
            throw new InvalidOperationException("Windows PowerShell is unavailable. Use kage.exe --console-input for masked console entry.");

        using var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Kage.Security.CredentialDialog.ps1")
            ?? throw new InvalidOperationException("The credential dialog is missing from this build. Rebuild with publish-win-x64.bat.");
        using var reader = new StreamReader(stream);
        var script = await reader.ReadToEndAsync(ct);
        var start = new ProcessStartInfo(powershell)
        {
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        };
        start.ArgumentList.Add("-NoLogo");
        start.ArgumentList.Add("-NoProfile");
        start.ArgumentList.Add("-STA");
        start.ArgumentList.Add("-EncodedCommand");
        // The encoded command contains only the bundled UI script, never credentials.
        start.ArgumentList.Add(Convert.ToBase64String(Encoding.Unicode.GetBytes(script)));
        start.Environment["KAGE_INPUT_LABEL"] = label;
        start.Environment["KAGE_INPUT_OPTIONAL"] = optional ? "true" : "false";
        start.Environment.Remove("KAGE_ROBLOX_API_KEY");
        start.Environment.Remove("ROBLOSECURITY");

        using var process = Process.Start(start)
            ?? throw new InvalidOperationException("Could not start the credential entry window.");
        var outputTask = process.StandardOutput.ReadToEndAsync();
        var errorTask = process.StandardError.ReadToEndAsync();
        try
        {
            await process.WaitForExitAsync(ct);
        }
        catch (OperationCanceledException)
        {
            try { if (!process.HasExited) process.Kill(entireProcessTree: true); }
            catch (InvalidOperationException) { }
            await Task.WhenAll(outputTask, errorTask);
            throw;
        }
        var encoded = await outputTask;
        await errorTask; // Drain diagnostics, never echo potentially sensitive output.

        if (process.ExitCode == 2)
            throw new OperationCanceledException("Credential entry cancelled.");
        if (process.ExitCode != 0)
            throw new InvalidOperationException("The credential window could not open. This input was not saved. Try kage.exe --console-input; do not disable Windows security settings.");

        byte[] bytes;
        try { bytes = Convert.FromBase64String(encoded.Trim()); }
        catch (FormatException)
        {
            throw new InvalidOperationException("The credential window returned an invalid response. This input was not saved.");
        }
        try { return Encoding.UTF8.GetString(bytes).Trim(); }
        finally { CryptographicOperations.ZeroMemory(bytes); }
    }

    private static string ReadMaskedConsole(string label, CancellationToken ct)
    {
        Console.WriteLine($"{label}: type or paste, then Enter. Escape clears. Ctrl+C cancels.");
        Console.WriteLine("Only a masked character count is displayed.");
        var previousControlC = Console.TreatControlCAsInput;
        Console.TreatControlCAsInput = true;
        var buffer = new List<char>();
        var width = 0;
        try
        {
            Render();
            while (true)
            {
                ct.ThrowIfCancellationRequested();
                var key = Console.ReadKey(intercept: true);
                var control = (key.Modifiers & ConsoleModifiers.Control) != 0;
                if (control && key.Key == ConsoleKey.C)
                    throw new OperationCanceledException("Credential entry cancelled.");
                if (key.Key == ConsoleKey.Enter)
                    return new string(buffer.ToArray()).Trim();
                if (key.Key == ConsoleKey.Escape || (control && key.Key == ConsoleKey.U))
                    buffer.Clear();
                else if (key.Key == ConsoleKey.Backspace)
                {
                    if (buffer.Count > 0) buffer.RemoveAt(buffer.Count - 1);
                }
                else if ((control && key.Key == ConsoleKey.V) ||
                         (key.Key == ConsoleKey.Insert && (key.Modifiers & ConsoleModifiers.Shift) != 0))
                {
                    if (!TryReadClipboard(out var pasted))
                    {
                        Console.WriteLine();
                        Console.WriteLine("Paste unavailable. Use the default KAGE input window, or your terminal's Paste command.");
                    }
                    else Append(pasted);
                }
                else if (!char.IsControl(key.KeyChar))
                    Append(key.KeyChar.ToString());
                Render();
            }
        }
        finally
        {
            buffer.Clear();
            Console.WriteLine();
            Console.TreatControlCAsInput = previousControlC;
        }

        void Append(string value)
        {
            // Ignore CR/LF from clipboard rather than submitting an extra prompt.
            foreach (var character in value)
                if (!char.IsControl(character) && buffer.Count < 16384)
                    buffer.Add(character);
        }

        void Render()
        {
            var text = $"> {new string('*', Math.Min(buffer.Count, 12))} ({buffer.Count} characters)";
            Console.Write("\r" + text.PadRight(width));
            width = text.Length;
        }
    }

    // Read the clipboard only in response to an explicit Ctrl+V/Shift+Insert.
    private static bool TryReadClipboard(out string text)
    {
        text = string.Empty;
        if (!OperatingSystem.IsWindows() || !OpenClipboard(IntPtr.Zero)) return false;
        try
        {
            var data = GetClipboardData(13); // CF_UNICODETEXT
            if (data == IntPtr.Zero) return false;
            var pointer = GlobalLock(data);
            if (pointer == IntPtr.Zero) return false;
            try { text = Marshal.PtrToStringUni(pointer) ?? string.Empty; }
            finally { GlobalUnlock(data); }
            return true;
        }
        finally { CloseClipboard(); }
    }

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool OpenClipboard(IntPtr owner);
    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CloseClipboard();
    [DllImport("user32.dll")]
    private static extern IntPtr GetClipboardData(uint format);
    [DllImport("kernel32.dll")]
    private static extern IntPtr GlobalLock(IntPtr memory);
    [DllImport("kernel32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GlobalUnlock(IntPtr memory);
}
