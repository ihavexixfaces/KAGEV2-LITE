using System.Text.Json;

namespace KAGE.Desktop;

internal static class AppDataStore
{
    private static readonly string DataDirectory = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "KAGE",
        "Data");

    private static readonly string RecentHistoryPath = Path.Combine(DataDirectory, "recent-history.json");

    public static JsonElement LoadRecentHistory()
    {
        try
        {
            if (!File.Exists(RecentHistoryPath))
                return EmptyArray();

            using var document = JsonDocument.Parse(File.ReadAllText(RecentHistoryPath));
            return document.RootElement.ValueKind == JsonValueKind.Array
                ? document.RootElement.Clone()
                : EmptyArray();
        }
        catch
        {
            return EmptyArray();
        }
    }

    public static void SaveRecentHistory(JsonElement history)
    {
        if (history.ValueKind != JsonValueKind.Array)
            return;

        Directory.CreateDirectory(DataDirectory);
        var tempPath = RecentHistoryPath + ".tmp";
        var json = JsonSerializer.Serialize(history, new JsonSerializerOptions { WriteIndented = false });
        File.WriteAllText(tempPath, json);
        File.Move(tempPath, RecentHistoryPath, true);
    }

    public static void ClearRecentHistory()
    {
        try
        {
            if (File.Exists(RecentHistoryPath))
                File.Delete(RecentHistoryPath);
        }
        catch
        {
            // History cleanup should never prevent KAGE from continuing.
        }
    }

    private static JsonElement EmptyArray()
    {
        using var document = JsonDocument.Parse("[]");
        return document.RootElement.Clone();
    }
}
