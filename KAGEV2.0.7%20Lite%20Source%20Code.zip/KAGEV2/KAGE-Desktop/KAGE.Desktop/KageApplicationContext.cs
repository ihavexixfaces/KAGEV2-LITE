using System.Diagnostics;
using KAGE.Desktop.Updates;

namespace KAGE.Desktop;

/// <summary>
/// Coordinates the transparent startup artwork and the real KAGE window. The
/// main window initializes while invisible, then cross-fades in only when both
/// the splash hold and UI-ready handshake have completed.
/// </summary>
internal sealed class KageApplicationContext : ApplicationContext
{
    private readonly MainForm _main;
    private readonly LaunchSplashForm _splash;
    private LaunchWindowForm? _windowShell;
    private bool _mainReady;
    private bool _splashHoldComplete;
    private bool _presenting;

    internal KageApplicationContext(UpdatedStartupContext updatedStartupContext)
    {
        _main = new MainForm(updatedStartupContext)
        {
            Opacity = 0d,
            ShowInTaskbar = false
        };
        _splash = new LaunchSplashForm(Screen.FromControl(_main).Bounds);

        _main.ReadyToPresent += (_, _) =>
        {
            _mainReady = true;
            TryPresent();
        };
        _splash.HoldCompleted += (_, _) =>
        {
            _splashHoldComplete = true;
            TryPresent();
        };
        _main.FormClosed += (_, _) =>
        {
            if (!_splash.IsDisposed) _splash.Close();
            if (_windowShell is { IsDisposed: false }) _windowShell.Close();
            ExitThread();
        };

        _splash.Show();
        _main.Show();
        _splash.BringToFront();
    }

    private async void TryPresent()
    {
        if (_presenting || !_mainReady || !_splashHoldComplete || _main.IsDisposed) return;
        _presenting = true;

        try
        {
            // Open an empty black window before revealing any GUI content. Keep it
            // opaque behind the real window throughout the final fade.
            _windowShell = new LaunchWindowForm();
            var shellOpen = _windowShell.OpenAsync(_main.Bounds);
            var splashFade = _splash.FadeOutAndCloseAsync();
            await Task.WhenAll(shellOpen, splashFade);
            if (_main.IsDisposed) return;
            await Task.Delay(120);
            if (_main.IsDisposed) return;
            _main.ShowInTaskbar = true;
            _main.Opacity = 0d;
            _main.BringToFront();

            // Cross-fade alongside the dedicated 144 Hz splash renderer instead of revealing the GUI in a
            // handful of opacity steps. The corner logo naturally cross-fades with
            // the native handoff because it is part of the main window.
            var fade = Stopwatch.StartNew();
            const double fadeMs = 520d;
            while (!_main.IsDisposed && fade.Elapsed.TotalMilliseconds < fadeMs)
            {
                var raw = Math.Clamp(fade.Elapsed.TotalMilliseconds / fadeMs, 0d, 1d);
                var eased = raw < .5d
                    ? 4d * raw * raw * raw
                    : 1d - Math.Pow(-2d * raw + 2d, 3d) / 2d;
                _main.Opacity = Math.Clamp(eased, 0d, 1d);
                await Task.Delay(4);
            }
        }
        catch
        {
            // Failure of an optional launch effect must never hide the application.
        }
        finally
        {
            if (!_main.IsDisposed)
            {
                _main.ShowInTaskbar = true;
                _main.Opacity = 1d;
                _main.Activate();
            }
            if (_windowShell is { IsDisposed: false }) _windowShell.Close();
            if (!_splash.IsDisposed) _splash.Close();
        }
    }
}
