using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Channels;
using Kage.Core;
using Kage.Roblox;
using Kage.Security;

namespace Kage.Engine;

public sealed class AnimationReuploadEngine
{
    private readonly RobloxOpenCloudClient _roblox;
    private readonly int _concurrency;
    private readonly IKageOperationAuthority _operationAuthority;
    private readonly object _progressLock = new();
    private int _lastProgressWidth;
    private readonly Stopwatch _jobTimer = new();
    private int _completedCount;
    private int _totalCount;
    private TimeSpan _lastRenderedAt;

    public event Action<StudioJob, AnimationResult>? ResultCompleted;

    public AnimationReuploadEngine(RobloxOpenCloudClient roblox, int concurrency)
        : this(roblox, concurrency, new LiteOperationAuthority()) { }

    internal AnimationReuploadEngine(RobloxOpenCloudClient roblox, int concurrency, IKageOperationAuthority operationAuthority)
    {
        _roblox = roblox;
        _concurrency = Math.Clamp(concurrency, 1, 96);
        _operationAuthority = operationAuthority;
    }

    private sealed record ReadyAsset(long OldId, byte[] Bytes, long StartedTimestamp, string OriginalName);
    private sealed record PendingCreate(long OldId, AssetOperation Operation, long StartedTimestamp);

    public async Task RunJobAsync(StudioJob job, CancellationToken ct, int? concurrencyOverride = null)
    {
        await using var authority = await _operationAuthority.AcquireAsync(job, ct).ConfigureAwait(false);
        using var authorizedCancellation = CancellationTokenSource.CreateLinkedTokenSource(ct, authority.Revoked);
        ct = authorizedCancellation.Token;
        ct.ThrowIfCancellationRequested();
        job.Status = "Processing";
        job.StartedUtc = DateTimeOffset.UtcNow;
        _jobTimer.Restart();
        var concurrency = Math.Clamp(concurrencyOverride ?? _concurrency, 1, 96);

        var ids = job.Request.EffectiveAssetIds.ToArray();
        if (ids.Length == 0)
        {
            job.Status = "Completed";
            job.FinishedUtc = DateTimeOffset.UtcNow;
            return;
        }

        _completedCount = 0;
        _totalCount = ids.Length;
        _lastRenderedAt = TimeSpan.Zero;

        if (_roblox.HasAuthenticatedSession)
        {
            try
            {
                await _roblox.PrepareAssetRoutesAsync(ids, job.Request.PlaceId, ct);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Bulk asset route discovery partially failed: {ex.Message}");
            }
        }

        const CreatorKind creatorKind = CreatorKind.User;

        // 2.0.6 sustained pipeline:
        //   IDs -> bounded download stage -> ready bytes -> paced create stage -> operations -> paced resolver
        // Each Roblox endpoint has its own pressure budget. Downloads never sit blocked behind
        // Create Asset, and Create Asset never waits for operation completion.
        var downloadWorkerCount = Math.Min(Math.Clamp(concurrency / 4, 8, 24), ids.Length);
        var createWorkerCount = Math.Min(
            _roblox.HasAuthenticatedSession
                ? Math.Clamp(concurrency, 1, 96)
                : Math.Clamp(concurrency / 12, 4, 8),
            ids.Length);
        var completionWorkerCount = Math.Min(32, ids.Length);

        var idChannel = Channel.CreateBounded<long>(new BoundedChannelOptions(Math.Max(downloadWorkerCount * 4, 64))
        {
            FullMode = BoundedChannelFullMode.Wait,
            SingleWriter = true,
            SingleReader = false
        });

        // Animations are normally small, but keeping this bounded prevents a large job from
        // buffering every downloaded file in RAM while still ensuring Create Asset stays fed.
        var readyChannel = Channel.CreateBounded<ReadyAsset>(new BoundedChannelOptions(Math.Max(createWorkerCount * 8, 48))
        {
            FullMode = BoundedChannelFullMode.Wait,
            SingleWriter = false,
            SingleReader = false
        });

        var pendingChannel = Channel.CreateBounded<PendingCreate>(new BoundedChannelOptions(256)
        {
            FullMode = BoundedChannelFullMode.Wait,
            SingleWriter = false,
            SingleReader = false
        });

        var downloadedCount = 0;
        var submittedCount = 0;

        void CompleteResult(AnimationResult result)
        {
            job.Add(result);
            var completed = Interlocked.Increment(ref _completedCount);
            try { ResultCompleted?.Invoke(job, result); }
            catch { /* UI observers must never interrupt the reupload pipeline. */ }
            RenderProgressWithETA(completed, _totalCount, result);
        }

        async Task DownloadWorkerAsync()
        {
            await foreach (var oldId in idChannel.Reader.ReadAllAsync(ct))
            {
                var started = Stopwatch.GetTimestamp();
                job.SetCurrentAsset(oldId, "Downloading");
                try
                {
                    // KAGE-Copy strategy: Get asset creator info FIRST to build place context candidates
                    byte[]? bytes = null;
                    
                    // Try download with current place context first
                    try
                    {
                        bytes = await _roblox.DownloadAssetAsync(oldId, job.Request.OpenCloudAssetType, job.Request.PlaceId, ct);
                    }
                    catch (RobloxApiException ex) when (ex.Category == "PermissionDenied")
                    {
                        // Permission denied - this is expected for unowned assets
                        // The DownloadViaCreatorPlacesAsync fallback will handle it
                        bytes = null;
                    }
                    
                    if (bytes == null)
                    {
                        // Fallback: Try creator place search (this gets asset info first)
                        bytes = await _roblox.DownloadViaCreatorPlacesAsync(oldId, ct);
                    }
                    
                    if (bytes == null)
                    {
                        throw new RobloxApiException(
                            $"{job.Request.NormalizedAssetType.TrimEnd('s')} {oldId} could not be downloaded with any available method.",
                            category: "PermissionDenied");
                    }
                    
                    Interlocked.Increment(ref downloadedCount);
                    var originalName = job.Request.NormalizedAssetType == "Animations"
                        ? await _roblox.ResolveOriginalAssetNameAsync(oldId, job.GetAssetName(oldId), ct)
                        : job.GetAssetName(oldId);
                    await readyChannel.Writer.WriteAsync(new ReadyAsset(oldId, bytes, started, originalName), ct);
                }
                catch (OperationCanceledException) when (ct.IsCancellationRequested)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    CompleteResult(ToFailure(oldId, ex, Stopwatch.GetElapsedTime(started).TotalSeconds));
                }
            }
        }

        async Task CreateWorkerAsync()
        {
            await foreach (var ready in readyChannel.Reader.ReadAllAsync(ct))
            {
                try
                {
                    job.SetCurrentAsset(ready.OldId, "Uploading");
                    var uploadName = job.Request.PreserveOriginalAssetNames
                        ? PreserveUploadName(ready.OriginalName, $"{job.Request.NormalizedAssetType.TrimEnd('s')} {ready.OldId}")
                        : job.Request.NormalizedAssetType == "Animations"
                            ? AnimationNamePolicy.Format(ready.OriginalName)
                            : $"KAGE {TrimPlaceName(job.Request.PlaceName)} {ready.OldId}";
                    var operation = await _roblox.SubmitAssetCreateAsync(
                        ready.Bytes,
                        creatorKind,
                        job.Request.CreatorId,
                        uploadName,
                        job.Request.OpenCloudAssetType,
                        job.Request.PlaceId,
                        ct);

                    Interlocked.Increment(ref submittedCount);
                    await pendingChannel.Writer.WriteAsync(
                        new PendingCreate(ready.OldId, operation, ready.StartedTimestamp), ct);
                }
                catch (OperationCanceledException) when (ct.IsCancellationRequested)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    CompleteResult(ToFailure(
                        ready.OldId,
                        ex,
                        Stopwatch.GetElapsedTime(ready.StartedTimestamp).TotalSeconds));
                }
            }
        }

        async Task CompletionWorkerAsync()
        {
            await foreach (var pending in pendingChannel.Reader.ReadAllAsync(ct))
            {
                try
                {
                    var newId = await _roblox.CompleteAssetCreateAsync(pending.Operation, ct);
                    CompleteResult(new AnimationResult(
                        pending.OldId,
                        newId,
                        true,
                        null,
                        null,
                        Stopwatch.GetElapsedTime(pending.StartedTimestamp).TotalSeconds));
                }
                catch (OperationCanceledException) when (ct.IsCancellationRequested)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    CompleteResult(ToFailure(
                        pending.OldId,
                        ex,
                        Stopwatch.GetElapsedTime(pending.StartedTimestamp).TotalSeconds));
                }
            }
        }

        var downloadWorkers = Enumerable.Range(0, downloadWorkerCount)
            .Select(_ => DownloadWorkerAsync())
            .ToArray();
        var createWorkers = Enumerable.Range(0, createWorkerCount)
            .Select(_ => CreateWorkerAsync())
            .ToArray();
        var completionWorkers = Enumerable.Range(0, completionWorkerCount)
            .Select(_ => CompletionWorkerAsync())
            .ToArray();

        try
        {
            foreach (var id in ids)
                await idChannel.Writer.WriteAsync(id, ct);
            idChannel.Writer.Complete();

            await Task.WhenAll(downloadWorkers);
            readyChannel.Writer.Complete();

            await Task.WhenAll(createWorkers);
            pendingChannel.Writer.Complete();

            await Task.WhenAll(completionWorkers);

            // Studio reference replacement is intentionally deferred until every animation
            // has a terminal mapping/error. No Studio scanning or replacement occurs here.
            ct.ThrowIfCancellationRequested();
            job.Status = "Completed";
        }
        catch (OperationCanceledException)
        {
            idChannel.Writer.TryComplete();
            readyChannel.Writer.TryComplete();
            pendingChannel.Writer.TryComplete();
            try { await Task.WhenAll(downloadWorkers.Concat(createWorkers).Concat(completionWorkers)); }
            catch { /* Every stage is stopped before the terminal report is written. */ }
            job.Status = authority.Failure is null ? "Cancelled" : "Failed";
            job.FatalError = authority.Failure ?? "The KAGE process was stopped before this job completed.";
        }
        catch (Exception ex)
        {
            authorizedCancellation.Cancel();
            idChannel.Writer.TryComplete(ex);
            readyChannel.Writer.TryComplete(ex);
            pendingChannel.Writer.TryComplete(ex);
            try { await Task.WhenAll(downloadWorkers.Concat(createWorkers).Concat(completionWorkers)); }
            catch { /* Preserve the original pipeline failure. */ }
            job.Status = "Failed";
            job.FatalError = ex.Message;
        }
        finally
        {
            _jobTimer.Stop();
            job.FinishedUtc = DateTimeOffset.UtcNow;
            FinishProgressLine();
            await WriteReportAsync(job);

            Console.WriteLine();
            Console.WriteLine($"════════════════════════════════════════════════════════════════");
            Console.WriteLine($"KAGE REUPLOAD COMPLETE");
            Console.WriteLine($"════════════════════════════════════════════════════════════════");
            Console.WriteLine($"Downloaded: {Volatile.Read(ref downloadedCount)}/{job.Total}");
            Console.WriteLine($"Create requests accepted: {Volatile.Read(ref submittedCount)}/{job.Total}");
            Console.WriteLine($"Successfully reuploaded: {job.Successful} ({(job.Total > 0 ? (job.Successful * 100.0 / job.Total).ToString("F1") : "0.0")}%)");
            Console.WriteLine($"Failed: {job.Failed}");
            Console.WriteLine($"Time elapsed: {FormatDuration(job.Elapsed)}");
            Console.WriteLine($"Average resolved rate: {job.ThroughputPerSecond:F2} animations/second");

            if (_roblox.RateLimitHits > 0)
                Console.WriteLine($"Rate limit hits: {_roblox.RateLimitHits} (server retry guidance honored)");

            if (job.Failed > 0)
            {
                Console.WriteLine();
                Console.WriteLine($"FAILURE SUMMARY:");
                Console.WriteLine($"────────────────────────────────────────────────────────────────");

                var failuresByCategory = job.Results
                    .Where(r => !r.Success)
                    .GroupBy(r => r.ErrorCategory ?? "Unknown")
                    .OrderByDescending(g => g.Count())
                    .ToList();

                foreach (var categoryGroup in failuresByCategory)
                {
                    Console.WriteLine($"{categoryGroup.Key}: {categoryGroup.Count()} failure(s)");
                    foreach (var failure in categoryGroup.Take(3))
                        Console.WriteLine($"  - Asset {failure.OldId}: {TruncateError(failure.Error)}");

                    if (categoryGroup.Count() > 3)
                        Console.WriteLine($"  ... and {categoryGroup.Count() - 3} more");
                }

                Console.WriteLine();
                Console.WriteLine($"Full failure details saved to:");
                Console.WriteLine($"{GetReportPath()}");
            }

            Console.WriteLine($"════════════════════════════════════════════════════════════════");
        }
    }

    private static AnimationResult ToFailure(long oldId, Exception ex, double elapsedSeconds)
    {
        return ex switch
        {
            RobloxApiException api => new AnimationResult(oldId, null, false, api.Category, api.Message, elapsedSeconds),
            HttpRequestException http => new AnimationResult(oldId, null, false, "Network", http.Message, elapsedSeconds),
            TaskCanceledException => new AnimationResult(oldId, null, false, "Timeout", "A Roblox request timed out.", elapsedSeconds),
            TimeoutException timeout => new AnimationResult(oldId, null, false, "Timeout", timeout.Message, elapsedSeconds),
            _ => new AnimationResult(oldId, null, false, "Unexpected", ex.Message, elapsedSeconds)
        };
    }

    private void RenderProgressWithETA(int completed, int total, AnimationResult lastResult)
    {
        var elapsed = _jobTimer.Elapsed;
        var rate = completed > 0 ? completed / elapsed.TotalSeconds : 0;
        var remaining = total - completed;
        var etaSeconds = rate > 0 ? remaining / rate : 0;
        var eta = TimeSpan.FromSeconds(etaSeconds);
        
        var status = lastResult.Success 
            ? $"✓ {lastResult.NewId}" 
            : $"✗ {lastResult.OldId} ({lastResult.ErrorCategory}: {TruncateError(lastResult.Error)})";
        
        var text = $"Reuploading: {completed}/{total} | Rate: {rate:F1}/s | ETA: {FormatDuration(eta)} | {status}";
        
        lock (_progressLock)
        {
            // Console rendering is surprisingly expensive under heavy parallel completion.
            // Keep failures and the final result immediate, but cap normal refreshes at 10 Hz.
            if (lastResult.Success && completed < total && elapsed - _lastRenderedAt < TimeSpan.FromMilliseconds(100))
                return;

            _lastRenderedAt = elapsed;
            var padded = text.PadRight(_lastProgressWidth);
            _lastProgressWidth = Math.Max(_lastProgressWidth, text.Length);
            Console.Write('\r' + padded);
        }
    }

    private static string TruncateError(string? error)
    {
        if (string.IsNullOrWhiteSpace(error)) return "Unknown";
        return error.Length <= 40 ? error : error[..37] + "...";
    }

    private void FinishProgressLine()
    {
        lock (_progressLock)
        {
            if (_lastProgressWidth > 0)
                Console.WriteLine();
            _lastProgressWidth = 0;
        }
    }

    private static string GetReportPath()
    {
        var reportDirectory = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "KAGE",
            "reports");
        return Path.Combine(reportDirectory, "last-job.json");
    }

    private static async Task WriteReportAsync(StudioJob job)
    {
        try
        {
            var reportDirectory = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "KAGE",
                "reports");
            Directory.CreateDirectory(reportDirectory);

            var reportPath = Path.Combine(reportDirectory, "last-job.json");
            var report = new
            {
                jobId = job.Id,
                status = job.Status,
                total = job.Total,
                successful = job.Successful,
                failed = job.Failed,
                elapsedSeconds = job.Elapsed.TotalSeconds,
                mappings = job.Mapping.OrderBy(x => x.Key).ToDictionary(x => x.Key, x => x.Value),
                failures = job.Results
                    .Where(x => !x.Success)
                    .OrderBy(x => x.OldId)
                    .Select(x => new { assetId = x.OldId, category = x.ErrorCategory, error = x.Error })
            };

            await File.WriteAllTextAsync(
                reportPath,
                JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch
        {
            // A report write failure must never fail a completed upload job.
        }
    }

    private static string FormatDuration(TimeSpan value)
    {
        if (value < TimeSpan.Zero) value = TimeSpan.Zero;
        if (value.TotalHours >= 1) return value.ToString(@"hh\:mm\:ss");
        return value.ToString(@"mm\:ss");
    }

    private static string PreserveUploadName(string? name, string fallback)
    {
        var clean = new string((name ?? string.Empty).Where(c => !char.IsControl(c)).ToArray()).Trim();
        if (string.IsNullOrWhiteSpace(clean)) clean = fallback;
        return clean.Length <= 50 ? clean : clean[..50].TrimEnd();
    }

    private static string TrimPlaceName(string name)
    {
        var clean = new string((name ?? "Studio").Where(c => char.IsLetterOrDigit(c) || c is ' ' or '-' or '_').ToArray()).Trim();
        if (string.IsNullOrWhiteSpace(clean)) clean = "Studio";
        return clean.Length <= 18 ? clean : clean[..18];
    }
}
