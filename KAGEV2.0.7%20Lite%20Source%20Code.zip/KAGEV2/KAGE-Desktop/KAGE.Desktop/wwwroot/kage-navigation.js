// One navigation component for both the main workspace and first-run authorization.
// Setup keeps the very same controls rendered but locked until authorization.
(function () {
  'use strict';
  const tabs = [
    { tab:'home', name:'Home', icon:'nav-home.png' },
    { tab:'watch', name:'Watch', icon:'nav-console.svg' },
    { tab:'reupload', name:'Reupload', icon:'roblox-studio-2022-flat.svg', primary:true },
    { tab:'preview', name:'Asset Viewer', icon:'kage-asset-animation.png' },
    { tab:'ai', name:'AI Assistant', icon:'Shade_Icon.png' }
  ];
  function mount(nav, locked = false) {
    if (!nav || nav.dataset.kageNavigationMounted === 'true') return;
    nav.className = 'top-icon-nav';
    nav.setAttribute('aria-label','KAGE navigation');
    nav.replaceChildren();
    for (const item of tabs) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'tab-btn' + (item.primary ? ' reupload-primary' : '') + (item.tab === 'home' ? ' active' : '');
      button.dataset.tab = item.tab;
      button.dataset.tooltip = item.name;
      button.setAttribute('aria-label', item.name);
      if (item.primary) button.id = 'reuploadTab';
      if (locked) { button.disabled = true; button.setAttribute('aria-disabled','true'); button.tabIndex = -1; }
      const img = document.createElement('img');
      img.src = '../Assets/' + item.icon;
      img.alt = '';
      const shine = document.createElement('span');
      shine.className = 'interaction-shine';
      button.append(img, shine);
      nav.append(button);
    }
    nav.dataset.kageNavigationMounted = 'true';
  }
  window.KageNavigation = Object.freeze({ mount });
})();
