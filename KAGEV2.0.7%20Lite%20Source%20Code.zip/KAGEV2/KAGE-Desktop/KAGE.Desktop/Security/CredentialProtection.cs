using Kage.Security;

namespace KAGE.Desktop;

/// <summary>
/// Single application boundary for secrets. Backing persistence is the current
/// Windows user's Credential Manager; no plaintext file fallback is permitted.
/// </summary>
internal static class CredentialProtection
{
    internal static bool TryRead(string accountId, out string secret) =>
        CredentialStore.TryRead(accountId, out secret);

    internal static void Save(string accountId, string secret)
    {
        SecurityRuntime.RequireProtectedOperation("credential-write");
        CredentialStore.Save(accountId, secret);
    }

    internal static void Delete(string accountId)
    {
        // Deletion remains available even after an integrity failure so a user can
        // always remove locally stored credentials from a suspect installation.
        CredentialStore.Delete(accountId);
    }

    internal static ValueTask<string?> TryReadAsync(string accountId, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(TryRead(accountId, out var value) ? value : null);
    }

    internal static ValueTask SaveAsync(string accountId, string secret, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        Save(accountId, secret);
        return ValueTask.CompletedTask;
    }
}
