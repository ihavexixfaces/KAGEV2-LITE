using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;

namespace Kage.Security;

/// <summary>
/// Stores KAGE secrets in the current Windows user's Credential Manager. This
/// location is independent of the application folder, so replacing/updating the
/// program does not erase credentials. No plaintext secret file is written.
/// </summary>
public static class CredentialStore
{
    private const string TargetPrefix = "KAGE/";
    private const uint CredTypeGeneric = 1;
    private const uint CredPersistLocalMachine = 2;

    public static bool TryRead(string name, out string value)
    {
        value = string.Empty;
        if (!OperatingSystem.IsWindows())
        {
            Log($"Cannot read '{name}': Windows Credential Manager is unavailable.");
            return false;
        }

        if (!CredRead(TargetPrefix + name, CredTypeGeneric, 0, out var pointer))
        {
            Log($"Credential '{name}' was not found or could not be read (Win32 error {Marshal.GetLastWin32Error()}).");
            return false;
        }

        try
        {
            var credential = Marshal.PtrToStructure<NativeCredential>(pointer);
            if (credential.CredentialBlob == IntPtr.Zero || credential.CredentialBlobSize == 0)
            {
                Log($"Credential '{name}' has an empty blob.");
                return false;
            }

            var bytes = new byte[credential.CredentialBlobSize];
            try
            {
                Marshal.Copy(credential.CredentialBlob, bytes, 0, bytes.Length);
                value = Encoding.UTF8.GetString(bytes);
                bool found = !string.IsNullOrWhiteSpace(value);
                if (!found)
                    Log($"Credential '{name}' contains an empty value.");
                return found;
            }
            finally
            {
                Array.Clear(bytes, 0, bytes.Length);
            }
        }
        finally
        {
            CredFree(pointer);
        }
    }

    public static void Save(string name, string value)
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("Windows Credential Manager is unavailable.");
        if (string.IsNullOrWhiteSpace(value))
            throw new ArgumentException($"Credential '{name}' cannot be empty.", nameof(value));

        var bytes = Encoding.UTF8.GetBytes(value.Trim());
        var blob = Marshal.AllocCoTaskMem(bytes.Length);
        try
        {
            Marshal.Copy(bytes, 0, blob, bytes.Length);
            var credential = new NativeCredential
            {
                Type = CredTypeGeneric,
                TargetName = TargetPrefix + name,
                CredentialBlobSize = (uint)bytes.Length,
                CredentialBlob = blob,
                Persist = CredPersistLocalMachine,
                UserName = Environment.UserName,
                Comment = "KAGE Studio Bridge credential"
            };

            if (!CredWrite(ref credential, 0))
                throw new Win32Exception(Marshal.GetLastWin32Error(), "Windows Credential Manager could not save the KAGE credential.");
        }

        finally
        {
            if (bytes.Length > 0) Array.Clear(bytes, 0, bytes.Length);
            Marshal.FreeCoTaskMem(blob);
        }
    }

    private static void Log(string message)
    {
        string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "KAGE", "Logs", "debug.log");
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        File.AppendAllText(path, $"[{DateTime.Now:HH:mm:ss}] CredentialStore: {message}{Environment.NewLine}");
        Console.WriteLine($"CredentialStore: {message}");
    }

    public static void Delete(string name)
    {
        if (!OperatingSystem.IsWindows()) return;
        if (!CredDelete(TargetPrefix + name, CredTypeGeneric, 0))
        {
            const int ErrorNotFound = 1168;
            var error = Marshal.GetLastWin32Error();
            if (error != ErrorNotFound)
                throw new Win32Exception(error, "Windows Credential Manager could not delete the KAGE credential.");
        }
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct NativeCredential
    {
        public uint Flags;
        public uint Type;
        [MarshalAs(UnmanagedType.LPWStr)] public string TargetName;
        [MarshalAs(UnmanagedType.LPWStr)] public string? Comment;
        public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
        public uint CredentialBlobSize;
        public IntPtr CredentialBlob;
        public uint Persist;
        public uint AttributeCount;
        public IntPtr Attributes;
        [MarshalAs(UnmanagedType.LPWStr)] public string? TargetAlias;
        [MarshalAs(UnmanagedType.LPWStr)] public string? UserName;
    }

    [DllImport("Advapi32.dll", EntryPoint = "CredReadW", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CredRead(string target, uint type, uint flags, out IntPtr credential);

    [DllImport("Advapi32.dll", EntryPoint = "CredWriteW", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CredWrite(ref NativeCredential credential, uint flags);

    [DllImport("Advapi32.dll", EntryPoint = "CredDeleteW", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CredDelete(string target, uint type, uint flags);

    [DllImport("Advapi32.dll")]
    private static extern void CredFree(IntPtr buffer);
}
