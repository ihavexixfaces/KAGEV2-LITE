// v57 correction pass — reliable Discord identity media for Settings + Welcome Back.
(() => {
  'use strict';
  if (new URLSearchParams(location.search).get('shadePopout') === '1') return;

  function safeDiscordMedia(value) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    try {
      const url = new URL(raw);
      const host = url.hostname.toLowerCase();
      if (url.protocol !== 'https:' || (host !== 'cdn.discordapp.com' && host !== 'media.discordapp.net')) return '';
      return url.href;
    } catch {
      return '';
    }
  }

  function setImage(node, url) {
    if (!node) return;
    node.onload = null;
    node.onerror = null;
    if (!url) {
      node.removeAttribute('src');
      node.style.display = 'none';
      return;
    }
    node.style.display = 'block';
    node.src = url;
    node.onload = () => { node.style.display = 'block'; };
    node.onerror = () => { node.style.display = 'none'; };
  }

  function paintDiscordIdentitySurfaces(data) {
    const discord = data?.discord || data || {};
    const avatarUrl = safeDiscordMedia(discord.avatar || discord.avatarUrl);
    const decorationUrl = safeDiscordMedia(discord.decoration || discord.decorationUrl);

    setImage(document.getElementById('settings-discord-avatar-image'), avatarUrl);
    setImage(document.getElementById('settings-discord-decoration'), decorationUrl);
    setImage(document.getElementById('welcome-discord-avatar-image'), avatarUrl);
    setImage(document.getElementById('welcome-discord-decoration'), decorationUrl);

    // Clear obsolete background-image rendering so a previous account cannot
    // remain behind the new layered avatar/decorations.
    for (const id of ['settings-discord-avatar', 'welcome-discord-avatar']) {
      const holder = document.getElementById(id);
      if (holder) holder.style.backgroundImage = 'none';
    }

    if (discord.username) {
      if (typeof window.animateText === 'function') {
        window.animateText('settings-discord-username', discord.username);
        window.animateText('welcome-discord-name', discord.username);
      } else {
        const settingsName = document.getElementById('settings-discord-username');
        const welcomeName = document.getElementById('welcome-discord-name');
        if (settingsName) settingsName.textContent = discord.username;
        if (welcomeName) welcomeName.textContent = discord.username;
      }
    }
    const idText = discord.id ? `ID ${discord.id}` : '—';
    const welcomeIdText = discord.id ? `ID: ${discord.id}` : 'ID: —';
    if (typeof window.animateText === 'function') {
      window.animateText('settings-discord-id', idText);
      window.animateText('welcome-discord-id', welcomeIdText);
    } else {
      const settingsId = document.getElementById('settings-discord-id');
      const welcomeId = document.getElementById('welcome-discord-id');
      if (settingsId) settingsId.textContent = idText;
      if (welcomeId) welcomeId.textContent = welcomeIdText;
    }
  }

  window.__kagePaintDiscordIdentity = paintDiscordIdentitySurfaces;

  // Native message path: catches the first accountInfo event even if version
  // wrappers were installed after the main account handler.
  try {
    window.chrome?.webview?.addEventListener?.('message', event => {
      const payload = event?.data;
      if (payload?.event === 'accountInfo') paintDiscordIdentitySurfaces(payload.data);
    });
  } catch { }

  // Account-switch path: repaint after the normal account update completes.
  const previousUpdate = window.updateAccountInfo;
  if (typeof previousUpdate === 'function' && !previousUpdate.__v57DiscordWrapped) {
    const wrapped = function(data) {
      previousUpdate(data);
      paintDiscordIdentitySurfaces(data);
    };
    wrapped.__v57DiscordWrapped = true;
    window.updateAccountInfo = wrapped;
  }
})();
