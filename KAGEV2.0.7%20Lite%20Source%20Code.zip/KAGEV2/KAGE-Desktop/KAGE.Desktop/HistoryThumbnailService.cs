using System.Collections.Concurrent;
using System.Text.Json;

namespace KAGE.Desktop;

internal sealed class HistoryThumbnailService(HttpClient client)
{
    internal sealed record Result(string ImageUrl, string State);
    private readonly ConcurrentDictionary<long, (string Url, DateTimeOffset At)> cache = new();
    private readonly ConcurrentDictionary<(long Place, long Universe), Lazy<Task<Result>>> pending = new();
    private readonly SemaphoreSlim slots = new(3);

    public void Invalidate(long placeId) => cache.TryRemove(placeId, out _);

    public async Task<Result> GetAsync(long placeId, long universeId = 0, Action<string>? diagnostic = null)
    {
        if (placeId <= 0) return new("", "Unavailable");
        if (cache.TryGetValue(placeId, out var hit) && DateTimeOffset.UtcNow - hit.At < TimeSpan.FromMinutes(15))
            return new(hit.Url, "Completed");
        var key = (placeId, universeId);
        var request = pending.GetOrAdd(key, _ => new(() => ResolveAsync(placeId, universeId, diagnostic)));
        try { return await request.Value.ConfigureAwait(false); }
        finally { pending.TryRemove(new KeyValuePair<(long, long), Lazy<Task<Result>>>(key, request)); }
    }

    private async Task<Result> ResolveAsync(long placeId, long universeId, Action<string>? diagnostic)
    {
        await slots.WaitAsync().ConfigureAwait(false);
        try
        {
            using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(25));
            var ct = deadline.Token;
            var suppliedUniverseId = universeId;
            // Place-only saved history can use the icon API directly. A slow
            // independent universe lookup must not delay that working route.
            var endpoints = new List<(string Url, long Target)>();
            if (universeId > 0) endpoints.Add(($"https://thumbnails.roblox.com/v1/games/icons?universeIds={universeId}&returnPolicy=PlaceHolder&size=150x150&format=Png&isCircular=false", universeId));
            endpoints.Add(($"https://thumbnails.roblox.com/v1/places/gameicons?placeIds={placeId}&returnPolicy=PlaceHolder&size=150x150&format=Png&isCircular=false", placeId));
            foreach (var endpoint in endpoints)
            {
                try
                {
                    var url = await FetchIconAsync(endpoint.Url, endpoint.Target, ct, diagnostic).ConfigureAwait(false);
                    if (string.IsNullOrEmpty(url)) continue;
                    cache[placeId] = (url, DateTimeOffset.UtcNow);
                    return new(url, "Completed");
                }
                catch (Exception ex) when (!ct.IsCancellationRequested) { diagnostic?.Invoke($"{new Uri(endpoint.Url).AbsolutePath}: {ex.GetType().Name}"); }
            }
            // History is durable, but the universe saved by Studio can become
            // obsolete. Only spend another lookup after both cheap icon paths
            // fail; a successful known universe or place icon needs no lookup.
            {
                try
                {
                    using var doc = await JsonAsync($"https://apis.roblox.com/universes/v1/places/{placeId}/universe", ct, diagnostic).ConfigureAwait(false);
                    if (doc?.RootElement.TryGetProperty("universeId", out var value) == true &&
                        value.TryGetInt64(out var canonicalUniverseId) && canonicalUniverseId > 0 && canonicalUniverseId != suppliedUniverseId)
                    {
                        var url = await FetchIconAsync($"https://thumbnails.roblox.com/v1/games/icons?universeIds={canonicalUniverseId}&returnPolicy=PlaceHolder&size=150x150&format=Png&isCircular=false", canonicalUniverseId, ct, diagnostic).ConfigureAwait(false);
                        if (!string.IsNullOrEmpty(url))
                        {
                            cache[placeId] = (url, DateTimeOffset.UtcNow);
                            return new(url, "Completed");
                        }
                    }
                }
                catch (Exception ex) when (!ct.IsCancellationRequested) { diagnostic?.Invoke($"Universe lookup: {ex.GetType().Name}"); }
            }
            return new("", "Retry");
        }
        catch (OperationCanceledException) { return new("", "Retry"); }
        finally { slots.Release(); }
    }

    private async Task<JsonDocument?> JsonAsync(string address, CancellationToken ct, Action<string>? diagnostic)
    {
        using var response = await client.GetAsync(address, ct).ConfigureAwait(false);
        if (!response.IsSuccessStatusCode) { diagnostic?.Invoke($"{new Uri(address).AbsolutePath}: HTTP {(int)response.StatusCode}"); return null; }
        return JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct).ConfigureAwait(false));
    }

    private async Task<string?> FetchIconAsync(string address, long targetId, CancellationToken ct, Action<string>? diagnostic)
    {
        using var doc = await JsonAsync(address, ct, diagnostic).ConfigureAwait(false);
        if (doc?.RootElement.TryGetProperty("data", out var rows) != true || rows.ValueKind != JsonValueKind.Array) return null;
        foreach (var row in rows.EnumerateArray())
        {
            if (!row.TryGetProperty("targetId", out var target) || !target.TryGetInt64(out var id) || id != targetId) continue;
            if (!row.TryGetProperty("state", out var state) || state.ValueKind != JsonValueKind.String || state.GetString() != "Completed")
            {
                diagnostic?.Invoke($"{new Uri(address).AbsolutePath}: thumbnail {state}");
                continue;
            }
            if (!row.TryGetProperty("imageUrl", out var image) || image.ValueKind != JsonValueKind.String) continue;
            if (!Uri.TryCreate(image.GetString(), UriKind.Absolute, out var uri) || uri.Scheme != "https" ||
                !(uri.Host.Equals("rbxcdn.com", StringComparison.OrdinalIgnoreCase) || uri.Host.EndsWith(".rbxcdn.com", StringComparison.OrdinalIgnoreCase))) continue;
            try
            {
                using var response = await client.GetAsync(uri, HttpCompletionOption.ResponseHeadersRead, ct).ConfigureAwait(false);
                if (!response.IsSuccessStatusCode)
                {
                    diagnostic?.Invoke($"Icon CDN: HTTP {(int)response.StatusCode}; using WebView image transport");
                    return uri.AbsoluteUri;
                }
                if (response.Content.Headers.ContentLength is > 1500000) continue;
                await using var stream = await response.Content.ReadAsStreamAsync(ct).ConfigureAwait(false);
                using var bytes = new MemoryStream();
                var buffer = new byte[8192];
                int read;
                while ((read = await stream.ReadAsync(buffer.AsMemory(), ct).ConfigureAwait(false)) > 0)
                {
                    if (bytes.Length + read > 1500000) return null;
                    bytes.Write(buffer, 0, read);
                }
                var content = bytes.ToArray();
                // CDN responses occasionally use application/octet-stream. Verify
                // the file signature rather than rejecting valid image bytes.
                var mime = ImageMime(content);
                if (mime is not null) return $"data:{mime};base64,{Convert.ToBase64String(content)}";
            }
            catch (Exception ex) when (ex is HttpRequestException or OperationCanceledException)
            {
                // This URL came from a Completed Roblox row and passed the CDN
                // allowlist. WebView can load it even if native HTTP is blocked
                // or slow; Chromium still validates/decodes it before display.
                diagnostic?.Invoke($"Icon CDN: {ex.GetType().Name}; using WebView image transport");
                return uri.AbsoluteUri;
            }
        }
        return null;
    }

    private static string? ImageMime(byte[] b) =>
        b.Length >= 8 && b[0] == 137 && b[1] == 80 && b[2] == 78 && b[3] == 71 && b[4] == 13 && b[5] == 10 && b[6] == 26 && b[7] == 10 ? "image/png" :
        b.Length >= 3 && b[0] == 255 && b[1] == 216 && b[2] == 255 ? "image/jpeg" :
        b.Length >= 12 && b[0] == 82 && b[1] == 73 && b[2] == 70 && b[3] == 70 && b[8] == 87 && b[9] == 69 && b[10] == 66 && b[11] == 80 ? "image/webp" : null;
}
