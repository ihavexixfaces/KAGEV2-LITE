using System.Net;

namespace KAGE.Desktop.Updates;

// Call only after the transport has verified the request-bound response receipt.
internal static class UpdateServiceErrors
{
    internal static void ThrowIfFailed(HttpStatusCode status)
    {
        if ((int)status is >= 200 and <= 299) return;
        if (status is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden)
            throw new UnauthorizedAccessException("Sign in to KAGE again to check private releases. If access was revoked, contact xix or almos.");
        var message = status switch
        {
            HttpStatusCode.NotFound => "No release is published for this distribution. Ask xix or almos to check the release channel.",
            HttpStatusCode.TooManyRequests => "Update service is busy. The next scheduled check will retry.",
            HttpStatusCode.BadRequest => "The update distribution is not configured correctly. Ask xix or almos to check this build.",
            _ => "Update service is temporarily unavailable. The next scheduled check will retry."
        };
        throw new HttpRequestException(message, null, status);
    }
}
