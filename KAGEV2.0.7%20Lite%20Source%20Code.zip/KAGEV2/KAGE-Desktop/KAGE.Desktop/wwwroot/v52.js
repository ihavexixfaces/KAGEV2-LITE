// v52 title-bar/home handoff and identity polish.
(() => {
  'use strict';
  if (new URLSearchParams(location.search).get('shadePopout') === '1') return;

  const setTextAnimated = (id, text) => {
    if (!document.getElementById(id)) return;
    if (typeof window.animateText === 'function') window.animateText(id, text);
    else document.getElementById(id).textContent = text;
  };

  // Keep Home's Discord identity beside Roblox. The portrait intentionally stays
  // off Home; Discord's portrait is reserved for authorization/setup surfaces.
  const previousUpdate = window.updateAccountInfo;
  if (typeof previousUpdate === 'function') {
    window.updateAccountInfo = function(data) {
      previousUpdate(data);
      const discord = data?.discord || {};
      setTextAnimated('home-discord-username', discord.username || 'Discord Account');
      setTextAnimated('home-discord-id', discord.id ? `ID: ${discord.id}` : 'ID: —');
      reportTitleLogoRect();
    };
  }

  // Give the native splash an exact destination for its final logo handoff.
  function reportTitleLogoRect() {
    const logo = document.querySelector('.title-corner-logo');
    if (!logo || !window.chrome?.webview) return;
    const rect = logo.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;
    try {
      window.chrome.webview.postMessage({
        action: 'titleLogoRect',
        x: rect.left,
        y: rect.top,
        width: rect.width,
        height: rect.height
      });
    } catch {}
  }
  window.addEventListener('resize', reportTitleLogoRect);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', reportTitleLogoRect, { once: true });
  else reportTitleLogoRect();

  // Protect navigation hit testing from future decorative title-bar changes.
  document.querySelectorAll('.top-icon-nav,.top-icon-nav .tab-btn').forEach(node => {
    node.style.pointerEvents = 'auto';
  });
  const nav = document.querySelector('.top-icon-nav');
  nav?.addEventListener('mousedown', event => event.stopPropagation());
  nav?.addEventListener('click', event => {
    const button = event.target.closest?.('.tab-btn[data-tab]');
    if (!button || !nav.contains(button)) return;
    const tab = String(button.dataset.tab || '').trim();
    if (!tab) return;
    document.querySelectorAll('.tab-btn[data-tab]').forEach(node => node.classList.toggle('active', node === button));
    document.querySelectorAll('.tab-content').forEach(node => node.classList.toggle('active', node.id === `tab-${tab}`));
    if (tab === 'ai' && typeof window.renderShadeConversation === 'function')
      requestAnimationFrame(() => window.renderShadeConversation({ force:true, settle:true }));
  });
})();
