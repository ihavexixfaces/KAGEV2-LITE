// v44 workspace controls. Existing controls and their native event bindings are
// retained; eligible groups and upload authorization stay in the native bridge.
(() => {
  'use strict';
  const tab = document.getElementById('tab-reupload');
  const main = tab?.querySelector('.reupload-main-column');
  if (!tab || !main) return;
  let installed = false;
  let menu, trigger, dropdown, list, grid, search, userToggle, preview;
  let open = false;
  let loading = false;
  let currentAccountId = String(latestAccountInfo?.roblox?.id || '');
  const nativeRender = initialGroupSelectorRender;
  const nativeAccountInfo = updateAccountInfo;
  const iconFallback = '../Assets/kage-groups.png';

  function restoreAccountCard() {
    const account = latestAccountInfo?.roblox || {};
    const avatar = document.getElementById('destination-account-avatar');
    if (avatar) avatar.style.backgroundImage = account.avatar ? `url("${String(account.avatar).replace(/["\\]/g, '')}")` : '';
    setAnimatedDestinationName(account.displayName || account.username || 'My Account');
    updateMetricText('destination-account-id', account.id ? `ID ${account.id}` : '—');
  }

  function syncDestination() {
    if (!installed) return;
    const chosen = groupSelector.selected;
    const active = getSelectedDestination() === 'group' && !!chosen;
    main.classList.toggle('workspace-group-selected', active);
    trigger.setAttribute('aria-pressed', String(active));
    userToggle.setAttribute('aria-pressed', String(!active));
    if (active) {
      preview.querySelector('strong')?.setAttribute('title', String(chosen.name || 'Group'));
      const details = [chosen.role || 'Member', chosen.permission || 'Verified creation permission'].join(' · ');
      preview.querySelector('small')?.setAttribute('title', details);
      const image = preview.querySelector('img');
      if (image && !chosen.icon) image.src = iconFallback;
    } else {
      preview.classList.add('hidden');
      restoreAccountCard();
    }
    // The core reads this input, but users select only native-verified entries.
    groupIdField?.classList.add('hidden');
    for (const row of grid.querySelectorAll('[data-group-id]')) {
      row.setAttribute('aria-selected', String(active && String(chosen.id) === row.dataset.groupId));
    }
  }

  function options() { return [...grid.querySelectorAll('[role="option"]')]; }

  function focusOption(index) {
    const rows = options();
    if (!rows.length) { search.focus(); return; }
    const row = rows[Math.max(0, Math.min(index, rows.length - 1))];
    row.focus({ preventScroll: true });
    row.scrollIntoView({ block: 'nearest' });
  }

  function placeMenu() {
    if (!open) return;
    const box = trigger.getBoundingClientRect();
    if (!box.width || box.bottom < 0 || box.top > window.innerHeight) { closeMenu(false); return; }
    const inset = 8, gap = 7;
    const width = Math.min(Math.max(box.width, 310), 420, window.innerWidth - inset * 2);
    const left = Math.max(inset, Math.min(box.left, window.innerWidth - width - inset));
    const below = window.innerHeight - box.bottom - gap - inset;
    const above = box.top - gap - inset;
    const upward = below < 225 && above > below;
    const room = Math.max(96, upward ? above : below);
    const height = Math.min(380, room);
    menu.style.width = `${width}px`;
    menu.style.left = `${left}px`;
    menu.style.maxHeight = `${height}px`;
    list.style.maxHeight = `${Math.max(44, height - 62)}px`;
    const actualHeight = menu.getBoundingClientRect().height;
    menu.style.top = `${Math.max(inset, Math.min(upward ? box.top - gap - actualHeight : box.bottom + gap, window.innerHeight - actualHeight - inset))}px`;
  }

  function closeMenu(returnFocus = true) {
    if (!installed) return;
    const wasOpen = open;
    open = false;
    dropdown.classList.remove('open');
    menu.hidden = true;
    trigger.setAttribute('aria-expanded', 'false');
    // The retired modal keeps its original IDs for existing bindings.
    const modal = document.getElementById('group-selector-modal');
    modal?.classList.remove('open');
    modal?.setAttribute('aria-hidden', 'true');
    if (wasOpen && returnFocus) trigger.focus({ preventScroll: true });
  }

  function prepareRows() {
    grid.setAttribute('aria-busy', String(loading));
    for (const row of grid.querySelectorAll('[data-group-id]')) {
      row.setAttribute('role', 'option');
      row.tabIndex = -1;
      row.querySelector('strong')?.setAttribute('title', row.querySelector('strong').textContent);
      row.querySelector('small')?.setAttribute('title', row.querySelector('small').textContent);
      row.querySelector('em')?.setAttribute('title', row.querySelector('em').textContent);
      const group = groupSelector.groups.find(item => String(item.id) === row.dataset.groupId);
      if (!group?.icon) row.querySelector('img').src = iconFallback;
    }
    syncDestination();
  }

  function render(data = {}) {
    if (Array.isArray(data.groups) || data.error) loading = false;
    nativeRender(data);
    if (!installed) return;
    if (loading && !groupSelector.groups.length && !data.error) grid.innerHTML = '<div class="workspace-empty" role="status">Loading eligible groups…</div>';
    prepareRows();
    placeMenu();
  }

  function openMenu(focusFirst = false) {
    if (!installed) install();
    if (!installed) return;
    open = true;
    dropdown.classList.add('open');
    menu.hidden = false;
    trigger.setAttribute('aria-expanded', 'true');
    search.value = '';
    loading = !groupSelector.groups.length;
    render({ groups: groupSelector.groups });
    // render receives a cache, not a new native reply.
    loading = !groupSelector.groups.length;
    if (loading) { grid.innerHTML = '<div class="workspace-empty" role="status">Loading eligible groups…</div>'; grid.setAttribute('aria-busy', 'true'); }
    placeMenu();
    bridge.send('getEligibleGroups');
    if (focusFirst && options().length) focusOption(0); else search.focus({ preventScroll: true });
  }

  function install() {
    // Build the V49 reupload hierarchy immediately, even while the tab is hidden.
    // Home/keyboard/programmatic navigation can activate Reupload without firing the
    // top-tab click handler; delaying installation until a later Groups click caused
    // the old pre-V49 layout to appear first and then suddenly reflow.
    if (installed) return;
    main.classList.add('workspace-polished');
    const command = main.querySelector('.reupload-command-card');
    command.classList.add('workspace-control-section', 'workspace-connections');
    const assets = main.querySelector('.reupload-asset-controls');
    const destination = main.querySelector('.reupload-destination-controls');
    assets.classList.add('workspace-control-section', 'workspace-assets');
    destination.classList.add('workspace-control-section', 'workspace-destination');
    const config = main.querySelector('.reupload-config-grid');
    config.prepend(assets);
    for (const button of assetToggles) {
      const label = document.createElement('span');label.className = 'workspace-button-label';label.textContent = button.dataset.type;
      button.append(label);button.classList.add('raised-surface');
    }
    const startLabel = document.createElement('span');startLabel.className = 'workspace-button-label';startLabel.textContent = 'Reupload';
    document.getElementById('btn-start').append(startLabel);
    const shadeLabel = document.createElement('span');shadeLabel.className = 'workspace-button-label';shadeLabel.append(document.createTextNode('Shade'));
    const shadeSubtitle = document.createElement('small');shadeSubtitle.className = 'workspace-button-subtitle';shadeSubtitle.textContent = '[AI Assistant]';
    shadeLabel.append(shadeSubtitle);
    document.getElementById('reupload-ai-assist').append(shadeLabel);
    userToggle = document.querySelector('.dest-toggle[data-dest="user"]');
    userToggle.querySelector('span').textContent = 'Account';
    userToggle.classList.add('raised-surface');
    const oldGroupToggle = document.querySelector('.dest-toggle[data-dest="group"]');
    oldGroupToggle.classList.add('workspace-native-group-toggle');
    oldGroupToggle.hidden = true;oldGroupToggle.tabIndex = -1;oldGroupToggle.setAttribute('aria-hidden', 'true');
    dropdown = document.createElement('div');dropdown.className = 'kage-dropdown workspace-groups-dropdown';dropdown.id = 'destination-groups-dropdown';
    trigger = document.createElement('button');trigger.id = 'destination-groups-trigger';trigger.className = 'kage-dropdown-trigger kage-interactive raised-surface';trigger.type = 'button';
    trigger.setAttribute('aria-haspopup', 'listbox');trigger.setAttribute('aria-expanded', 'false');trigger.setAttribute('aria-controls', 'group-selector-grid');
    trigger.innerHTML = '<img src="../Assets/kage-groups.png" alt=""><span>Groups</span><i aria-hidden="true"></i><span class="interaction-shine"></span>';
    dropdown.append(trigger);oldGroupToggle.parentElement.append(dropdown);
    preview = document.getElementById('selected-group-preview');
    destination.insertBefore(preview, userToggle.parentElement);
    menu = document.createElement('div');menu.id = 'destination-groups-menu';menu.className = 'workspace-groups-menu';menu.hidden = true;
    menu.setAttribute('aria-label', 'Eligible groups');
    search = document.getElementById('group-selector-search');search.setAttribute('aria-label', 'Search eligible groups by name, role, or permission');
    const searchWrap = document.createElement('div');searchWrap.className = 'workspace-groups-search';searchWrap.append(search);
    list = document.createElement('div');list.id = 'destination-groups-list';list.className = 'custom-scroll';
    grid = document.getElementById('group-selector-grid');grid.setAttribute('role', 'listbox');grid.setAttribute('aria-label', 'Eligible groups');
    list.append(grid);menu.append(searchWrap, list);document.body.append(menu);
    const modal = document.getElementById('group-selector-modal');modal.classList.remove('open');modal.setAttribute('aria-hidden', 'true');modal.inert = true;
    installed = true;
    trigger.addEventListener('click', () => open ? closeMenu() : openMenu());
    trigger.addEventListener('keydown', event => { if (event.key === 'ArrowDown' || event.key === 'ArrowUp') { event.preventDefault(); openMenu(true); } });
    menu.addEventListener('keydown', event => {
      const rows = options(), index = rows.indexOf(document.activeElement);
      if (event.key === 'ArrowDown') { event.preventDefault(); focusOption(index + 1); }
      else if (event.key === 'ArrowUp') { event.preventDefault(); focusOption(index < 0 ? rows.length - 1 : index - 1); }
      else if (event.key === 'Home' && index >= 0) { event.preventDefault(); focusOption(0); }
      else if (event.key === 'End' && index >= 0) { event.preventDefault(); focusOption(rows.length - 1); }
    });
    grid.addEventListener('click', event => { if (event.target.closest('[data-group-id]')) queueMicrotask(syncDestination); });
    userToggle.addEventListener('click', () => { closeMenu(false); syncDestination(); });
    document.addEventListener('pointerdown', event => { if (open && !menu.contains(event.target) && !dropdown.contains(event.target)) closeMenu(false); });
    document.addEventListener('focusin', event => { if (open && !menu.contains(event.target) && !dropdown.contains(event.target)) closeMenu(false); });
    document.addEventListener('keydown', event => { if (open && event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); closeMenu(); } });
    tab.addEventListener('scroll', placeMenu, { passive: true });
    window.addEventListener('resize', placeMenu);
    window.addEventListener('scroll', placeMenu, { passive: true });
    bindAllKageInteractions(main);bindKageInteraction(trigger);
    render({ groups: groupSelector.groups });
  }

  // Function declarations in app.js share the classic-script global scope.
  requestEligibleGroups = () => openMenu();
  renderGroupSelector = render;
  closeGroupSelector = () => closeMenu();
  updateAccountInfo = function(data) {
    const nextId = String(data?.roblox?.id || '');
    const changed = nextId !== currentAccountId;
    nativeAccountInfo(data);
    currentAccountId = nextId;
    if (changed) {
      closeMenu(false);
      groupSelector.selected = null;
      const input = document.getElementById('input-groupid');if (input) input.value = '';
      destToggles.forEach(toggle => toggle.classList.toggle('active', toggle.dataset.dest === 'user'));
      loading = true;
      if (installed) { search.value = ''; grid.replaceChildren(); syncDestination(); }
    }
  };

  // Settings presents both authenticated identities. Do not hide Roblox or collapse
  // the row into a Discord-only layout; v55 aligns Roblox on the left and the
  // decorated Discord identity beside it.
  document.querySelector('.settings-account-details .identity-line.roblox')?.classList.remove('workspace-duplicate-identity');
  document.querySelector('.settings-account-details')?.classList.remove('workspace-discord-identity');
  document.querySelector('.settings-account-row .settings-row-title h3')?.replaceChildren(document.createTextNode('Account'));
  document.querySelector('.tab-btn[data-tab="reupload"]')?.addEventListener('click', install);
  document.querySelectorAll('.tab-btn').forEach(button => button.addEventListener('click', () => { if (button.dataset.tab !== 'reupload') closeMenu(false); }));
  install();
})();
