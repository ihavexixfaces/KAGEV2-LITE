using System.Collections.Concurrent;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Kage.Core;

public enum CreatorKind
{
    User
}

public sealed record StudioStartRequest(
    long PlaceId,
    long UniverseId,
    string PlaceName,
    string CreatorType,
    long CreatorId,
    List<long>? AnimationIds = null,
    Dictionary<string, string>? AnimationNames = null,
    string AssetType = "Animations",
    List<long>? AssetIds = null,
    Dictionary<string, string>? AssetNames = null,
    bool PreserveOriginalAssetNames = false)
{
    public IReadOnlyList<long> EffectiveAssetIds =>
        (AssetIds is { Count: > 0 } ? AssetIds : AnimationIds ?? new List<long>())
        .Where(x => x > 0)
        .Distinct()
        .ToArray();

    public IReadOnlyDictionary<string, string> EffectiveAssetNames =>
        AssetNames is { Count: > 0 } ? AssetNames :
        AnimationNames is { Count: > 0 } ? AnimationNames :
        new Dictionary<string, string>();

    public string NormalizedAssetType => AssetType?.Trim().ToLowerInvariant() switch
    {
        "animations" or "animation" or "" => "Animations",
        _ => "Unsupported"
    };

    public string OpenCloudAssetType => NormalizedAssetType == "Animations"
        ? "Animation"
        : throw new InvalidOperationException("KAGE Lite supports animation assets only.");
}

public sealed record StudioStartResponse(string JobId, int UniqueAnimations);
public sealed record StudioJobStartRequest(int Concurrency = 96);

public sealed record RobloxProfile(
    long UserId,
    string UserName,
    string DisplayName,
    string? AvatarUrl);

public sealed record AnimationResult(
    long OldId,
    long? NewId,
    bool Success,
    string? ErrorCategory,
    string? Error,
    double ElapsedSeconds);

public sealed record StudioAssetProgress(string AssetId, string AssetName, string Status);

public sealed class StudioJob
{
    private readonly object _progressSync = new();
    private StudioAssetProgress? _currentAsset;
    private string _referenceStatus = "Waiting";
    private int _referencesSwapped;
    private int _referencesMapped;
    private string? _referenceError;

    public void SetReferenceProgress(string status, int changed, int mappings, string? error = null)
    {
        lock (_progressSync)
        {
            _referenceStatus = status;
            _referencesSwapped = Math.Max(0, changed);
            _referencesMapped = Math.Max(0, mappings);
            _referenceError = error;
        }
    }
    private int _completed;
    private int _success;
    private int _failed;
    private readonly int _total;

    public StudioJob(string id, StudioStartRequest request)
    {
        Id = id;
        Request = request;
        CreatedUtc = DateTimeOffset.UtcNow;
        _total = request.EffectiveAssetIds.Count;
    }

    public string Id { get; }
    public StudioStartRequest Request { get; }
    public DateTimeOffset CreatedUtc { get; }
    public DateTimeOffset? StartedUtc { get; set; }
    public DateTimeOffset? FinishedUtc { get; set; }
    public string Status { get; set; } = "Queued";
    public string? FatalError { get; set; }
    public ConcurrentDictionary<long, long> Mapping { get; } = new();
    public ConcurrentDictionary<long, string> Errors { get; } = new();
    public ConcurrentDictionary<long, string> ErrorCategories { get; } = new();
    public ConcurrentBag<AnimationResult> Results { get; } = new();
    public int Total => _total;
    public int Completed => Volatile.Read(ref _completed);
    public int Successful => Volatile.Read(ref _success);
    public int Failed => Volatile.Read(ref _failed);

    public TimeSpan Elapsed
    {
        get
        {
            var start = StartedUtc ?? CreatedUtc;
            var end = FinishedUtc ?? DateTimeOffset.UtcNow;
            var value = end - start;
            return value < TimeSpan.Zero ? TimeSpan.Zero : value;
        }
    }

    public double ThroughputPerSecond
    {
        get
        {
            var seconds = Elapsed.TotalSeconds;
            return seconds > 0.05 ? Completed / seconds : 0;
        }
    }

    public TimeSpan? Eta
    {
        get
        {
            if (Completed <= 0 || Completed >= Total) return Completed >= Total ? TimeSpan.Zero : null;
            var rate = ThroughputPerSecond;
            if (rate <= 0.001) return null;
            return TimeSpan.FromSeconds((Total - Completed) / rate);
        }
    }

    public string GetAssetName(long assetId)
    {
        if (Request.EffectiveAssetNames is { } names && names.TryGetValue(assetId.ToString(), out var name) &&
            !string.IsNullOrWhiteSpace(name))
        {
            var trimmed = name.Trim();
            return trimmed.Length > 160 ? trimmed[..160] : trimmed;
        }
        var singular = Request.NormalizedAssetType.TrimEnd('s');
        return $"{singular} {assetId}";
    }

    public void SetCurrentAsset(long assetId, string status)
    {
        lock (_progressSync)
            _currentAsset = new StudioAssetProgress(assetId.ToString(), GetAssetName(assetId), status);
    }

    public void Add(AnimationResult result)
    {
        lock (_progressSync)
        {
            Results.Add(result);
            if (result.Success && result.NewId is long newId)
            {
                Mapping[result.OldId] = newId;
                Interlocked.Increment(ref _success);
            }
            else
            {
                Errors[result.OldId] = result.Error ?? "Unknown error";
                ErrorCategories[result.OldId] = result.ErrorCategory ?? "Unknown";
                Interlocked.Increment(ref _failed);
            }
            Interlocked.Increment(ref _completed);
            _currentAsset = new StudioAssetProgress(
                result.OldId.ToString(), GetAssetName(result.OldId),
                result.Success && result.NewId.HasValue ? "Success" : "Failed");
        }
    }

    public static IReadOnlyDictionary<long, long> ReadCompletedMapping(JsonElement snapshot)
    {
        if (snapshot.ValueKind != JsonValueKind.Object ||
            !snapshot.TryGetProperty("status", out var status) || status.GetString() != "Completed" ||
            !snapshot.TryGetProperty("successful", out var successful) || !successful.TryGetInt32(out var expected) || expected < 0 ||
            !snapshot.TryGetProperty("mapping", out var mappingElement) || mappingElement.ValueKind != JsonValueKind.Object)
            throw new InvalidOperationException("KAGE returned an incomplete upload result. Studio references have not been updated.");

        var mapping = new Dictionary<long, long>();
        foreach (var property in mappingElement.EnumerateObject())
        {
            var value = property.Value.ValueKind == JsonValueKind.String ? property.Value.GetString() : property.Value.GetRawText();
            if (!long.TryParse(property.Name, out var oldId) || oldId <= 0 ||
                !long.TryParse(value, out var newId) || newId <= 0 || !mapping.TryAdd(oldId, newId))
                throw new InvalidOperationException("KAGE returned an invalid asset ID mapping. Studio references have not been updated.");
        }

        if (mapping.Count != expected)
            throw new InvalidOperationException($"KAGE received {mapping.Count} ID mappings for {expected} successful uploads. Studio references have not been updated.");
        return mapping;
    }

    public object ToDto(bool includeResults = true)
    {
        // Keep counts and the asset snapshot consistent while workers finish in parallel.
        lock (_progressSync)
        {
            // The caller may have checked Status before the final worker finished.
            // A terminal snapshot must always carry the map used to update Studio.
            var status = Status;
            includeResults |= status is "Completed" or "Failed" or "Cancelled";
            return new
            {
                jobId = Id,
                status,
                placeId = Request.PlaceId,
                universeId = Request.UniverseId,
                placeName = Request.PlaceName,
                creatorType = Request.CreatorType,
                creatorId = Request.CreatorId,
                assetType = Request.NormalizedAssetType,
                total = Total,
                completed = Completed,
                successful = Successful,
                failed = Failed,
                currentAsset = _currentAsset?.AssetName,
                currentAssetId = _currentAsset?.AssetId,
                currentAssetStatus = _currentAsset?.Status,
                mapping = includeResults
                    ? Mapping.ToDictionary(x => x.Key.ToString(), x => x.Value.ToString())
                    : new Dictionary<string, string>(),
                errors = includeResults
                    ? Errors.ToDictionary(x => x.Key.ToString(), x => x.Value)
                    : new Dictionary<string, string>(),
                errorCategories = includeResults
                    ? ErrorCategories.ToDictionary(x => x.Key.ToString(), x => x.Value)
                    : new Dictionary<string, string>(),
                fatalError = FatalError,
                referenceStatus = _referenceStatus,
                referencesSwapped = _referencesSwapped,
                referencesMapped = _referencesMapped,
                referenceError = _referenceError,
                createdUtc = CreatedUtc,
                startedUtc = StartedUtc,
                finishedUtc = FinishedUtc,
                elapsedSeconds = Elapsed.TotalSeconds,
                etaSeconds = Eta?.TotalSeconds,
                throughputPerSecond = ThroughputPerSecond
            };
        }
    }
}

public sealed record AssetDeliveryTicket(
    [property: JsonPropertyName("location")] string Location,
    [property: JsonPropertyName("IsCopyrightProtected")] bool IsCopyrightProtected,
    [property: JsonPropertyName("assetTypeId")] long? AssetTypeId);

public sealed record AssetOperation(
    [property: JsonPropertyName("path")] string Path,
    [property: JsonPropertyName("done")] bool Done,
    [property: JsonPropertyName("response")] AssetOperationResponse? Response,
    [property: JsonPropertyName("error")] AssetOperationError? Error);

public sealed record AssetOperationResponse(
    [property: JsonPropertyName("assetId")] string? AssetId,
    [property: JsonPropertyName("path")] string? Path,
    [property: JsonPropertyName("displayName")] string? DisplayName,
    [property: JsonPropertyName("assetType")] string? AssetType);

public sealed record AssetOperationError(
    [property: JsonPropertyName("code")] string? Code,
    [property: JsonPropertyName("message")] string? Message);

public sealed record AssetBatchResponse(
    [property: JsonPropertyName("requestId")] string? RequestId,
    [property: JsonPropertyName("locations")] AssetBatchLocation[]? Locations,
    [property: JsonPropertyName("errors")] AssetBatchError[]? Errors);

public sealed record AssetBatchLocation(
    [property: JsonPropertyName("location")] string? Location,
    [property: JsonPropertyName("assetFormat")] string? AssetFormat);

public sealed record AssetBatchError(
    [property: JsonPropertyName("code")] int Code,
    [property: JsonPropertyName("message")] string? Message);

// Supporting models for META-style bulk operations and private asset fallback
public sealed record BulkAssetResponse(
    [property: JsonPropertyName("data")] AssetInfo[]? Data);

public sealed record AssetInfo(
    [property: JsonPropertyName("id")] long Id,
    [property: JsonPropertyName("name")] string? Name,
    [property: JsonPropertyName("creator")] CreatorInfo? Creator);

public sealed record CreatorInfo(
    [property: JsonPropertyName("id")] long Id,
    [property: JsonPropertyName("targetId")] long TargetId,
    [property: JsonPropertyName("type")] string? Type,
    [property: JsonPropertyName("name")] string? Name);

public sealed record GamesResponse(
    [property: JsonPropertyName("data")] GameInfo[]? Data);

public sealed record GameInfo(
    [property: JsonPropertyName("id")] long Id,
    [property: JsonPropertyName("rootPlace")] RootPlaceInfo? RootPlace);

public sealed record RootPlaceInfo(
    [property: JsonPropertyName("id")] long Id);
