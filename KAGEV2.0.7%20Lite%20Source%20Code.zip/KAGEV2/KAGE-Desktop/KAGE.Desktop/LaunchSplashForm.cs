using System.Diagnostics;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace KAGE.Desktop;

/// <summary>
/// KAGE's transparent startup animation. The animation is rendered on a dedicated
/// high-priority thread into one persistent premultiplied-alpha DIB and presented
/// with UpdateLayeredWindow. No per-frame Bitmap/HBITMAP/DC allocation is performed,
/// and WebView2 initialization cannot starve the splash renderer on the WinForms UI
/// thread. The timeline is sampled at 144 Hz; the monitor/compositor presents at its
/// own refresh rate (60/120/144/etc.).
/// </summary>
internal sealed class LaunchSplashForm : Form
{
    private readonly Stopwatch _timeline = new();
    private readonly Stopwatch _handoffTimeline = new();
    private readonly Image? _logo;
    private readonly Font _brandFont;
    private readonly SolidBrush _brandBrush = new(Color.White);
    private readonly ImageAttributes _logoAttributes = new();
    private readonly float[] _brandAdvances = new float[BrandText.Length];
    private readonly Rectangle _splashBounds;

    private Thread? _renderThread;
    private volatile bool _stopRequested;
    private volatile bool _holdRaised;
    private volatile bool _fading;
    private volatile bool _handoffComplete;
    private volatile bool _disposeRequested;
    private int _renderingResourcesReleased;
    private bool _timerResolutionRaised;

    // Persistent layered-window backing surface. Keeping these alive for the full
    // animation is the important difference from the old per-frame GDI allocation.
    private IntPtr _screenDc;
    private IntPtr _memoryDc;
    private IntPtr _dibSection;
    private IntPtr _oldBitmap;
    private IntPtr _dibBits;
    private Bitmap? _surface;
    private Graphics? _surfaceGraphics;

    private Rectangle _handoffStartBounds;
    private Rectangle _handoffTargetBounds;

    private const int SplashWidth = 560;
    private const int SplashHeight = 260;
    private const double LogoSettleMs = 980d;
    private const double BrandStartMs = LogoSettleMs + 320d + 80d;
    private const double BrandStepMs = 105d;
    private const double BrandLetterMs = 360d;
    private const string BrandText = "KAGE";
    private static readonly double FinalAnimationMs = BrandStartMs + (BrandText.Length - 1) * BrandStepMs + BrandLetterMs;
    private static readonly double HoldUntilMs = FinalAnimationMs + 240d;
    private const double HandoffMs = 560d;
    private const double TargetFrameHz = 144d;
    private const double TargetFrameMs = 1000d / TargetFrameHz;

    internal event EventHandler? HoldCompleted;

    private const int WS_EX_LAYERED = 0x00080000;
    private const int WS_EX_TOOLWINDOW = 0x00000080;
    private const int WS_EX_NOACTIVATE = 0x08000000;
    private const int WS_EX_TRANSPARENT = 0x00000020;
    private const int ULW_ALPHA = 0x00000002;
    private const byte AC_SRC_OVER = 0x00;
    private const byte AC_SRC_ALPHA = 0x01;
    private const uint DIB_RGB_COLORS = 0;
    private const uint BI_RGB = 0;

    [StructLayout(LayoutKind.Sequential)]
    private struct PointNative
    {
        public int X;
        public int Y;
        public PointNative(int x, int y) { X = x; Y = y; }
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct SizeNative
    {
        public int Cx;
        public int Cy;
        public SizeNative(int cx, int cy) { Cx = cx; Cy = cy; }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    private struct BlendFunction
    {
        public byte BlendOp;
        public byte BlendFlags;
        public byte SourceConstantAlpha;
        public byte AlphaFormat;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct BitmapInfoHeader
    {
        public uint biSize;
        public int biWidth;
        public int biHeight;
        public ushort biPlanes;
        public ushort biBitCount;
        public uint biCompression;
        public uint biSizeImage;
        public int biXPelsPerMeter;
        public int biYPelsPerMeter;
        public uint biClrUsed;
        public uint biClrImportant;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct BitmapInfo
    {
        public BitmapInfoHeader bmiHeader;
        public uint bmiColors;
    }

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool UpdateLayeredWindow(
        IntPtr hwnd,
        IntPtr hdcDst,
        ref PointNative pptDst,
        ref SizeNative psize,
        IntPtr hdcSrc,
        ref PointNative pprSrc,
        int crKey,
        ref BlendFunction pblend,
        int dwFlags);

    [DllImport("user32.dll")] private static extern IntPtr GetDC(IntPtr hwnd);
    [DllImport("user32.dll")] private static extern int ReleaseDC(IntPtr hwnd, IntPtr hdc);
    [DllImport("gdi32.dll")] private static extern IntPtr CreateCompatibleDC(IntPtr hdc);
    [DllImport("gdi32.dll")] private static extern bool DeleteDC(IntPtr hdc);
    [DllImport("gdi32.dll")] private static extern IntPtr SelectObject(IntPtr hdc, IntPtr hgdiobj);
    [DllImport("gdi32.dll")] private static extern bool DeleteObject(IntPtr hObject);
    [DllImport("gdi32.dll", SetLastError = true)]
    private static extern IntPtr CreateDIBSection(IntPtr hdc, ref BitmapInfo pbmi, uint usage, out IntPtr bits, IntPtr section, uint offset);
    [DllImport("winmm.dll", EntryPoint = "timeBeginPeriod")] private static extern uint TimeBeginPeriod(uint period);
    [DllImport("winmm.dll", EntryPoint = "timeEndPeriod")] private static extern uint TimeEndPeriod(uint period);

    internal LaunchSplashForm(Rectangle screenBounds)
    {
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        _splashBounds = new Rectangle(
            screenBounds.Left + Math.Max(0, (screenBounds.Width - SplashWidth) / 2),
            screenBounds.Top + Math.Max(0, (screenBounds.Height - SplashHeight) / 2),
            SplashWidth,
            SplashHeight);
        Bounds = _splashBounds;
        ShowInTaskbar = false;
        TopMost = true;
        BackColor = Color.Black;
        AutoScaleMode = AutoScaleMode.Dpi;

        // Same first-choice typeface used by the main KAGE GUI.
        try
        {
            var selected = new Font("Segoe UI Variable Text", 34f, FontStyle.Bold, GraphicsUnit.Pixel);
            // GDI+ silently substitutes missing families, so match the GUI's
            // fallback order explicitly instead of relying on an exception.
            if (!selected.FontFamily.Name.Equals("Segoe UI Variable Text", StringComparison.OrdinalIgnoreCase))
            {
                selected.Dispose();
                selected = new Font("Aptos", 34f, FontStyle.Bold, GraphicsUnit.Pixel);
                if (!selected.FontFamily.Name.Equals("Aptos", StringComparison.OrdinalIgnoreCase))
                {
                    selected.Dispose();
                    selected = new Font("Segoe UI", 34f, FontStyle.Bold, GraphicsUnit.Pixel);
                }
            }
            _brandFont = selected;
        }
        catch { _brandFont = new Font("Segoe UI", 34f, FontStyle.Bold, GraphicsUnit.Pixel); }
        for (var i = 0; i < BrandText.Length; i++)
        {
            var measured = TextRenderer.MeasureText(BrandText[i].ToString(), _brandFont, Size.Empty,
                TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine);
            _brandAdvances[i] = Math.Max(1f, measured.Width + 3f);
        }

        try
        {
            if (EmbeddedWebAssets.TryOpen("Assets/logo.png", out var stream, out _))
            {
                using (stream)
                using (var loaded = Image.FromStream(stream))
                    _logo = RemoveTransparentEdgeChroma(new Bitmap(loaded));
            }
        }
        catch { _logo = null; }

        Shown += (_, _) => StartRenderer();
    }

    protected override CreateParams CreateParams
    {
        get
        {
            var cp = base.CreateParams;
            cp.ExStyle |= WS_EX_LAYERED | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE | WS_EX_TRANSPARENT;
            return cp;
        }
    }

    protected override void OnPaintBackground(PaintEventArgs e) { }
    protected override void OnPaint(PaintEventArgs e) { }

    private void StartRenderer()
    {
        if (_renderThread is not null || IsDisposed || !IsHandleCreated) return;
        try
        {
            if (!CreatePersistentSurface())
            {
                // A renderer failure must not keep an otherwise ready application invisible.
                _holdRaised = true;
                RaiseHoldCompleted();
                return;
            }

            try { _timerResolutionRaised = TimeBeginPeriod(1) == 0; }
            catch { _timerResolutionRaised = false; }

            _timeline.Restart();
            RenderMainFrame(0d);
            PresentSurface(_splashBounds.Location, 255);

            _stopRequested = false;
            _renderThread = new Thread(RenderLoop)
            {
                IsBackground = true,
                Name = "KAGE Splash 144Hz Renderer",
                Priority = ThreadPriority.Highest,
            };
            _renderThread.Start();
        }
        catch
        {
            _stopRequested = true;
            _handoffComplete = true;
            if (!_holdRaised)
            {
                _holdRaised = true;
                RaiseHoldCompleted();
            }
        }
    }

    private bool CreatePersistentSurface()
    {
        try
        {
            _screenDc = GetDC(IntPtr.Zero);
            if (_screenDc == IntPtr.Zero) return false;
            _memoryDc = CreateCompatibleDC(_screenDc);
            if (_memoryDc == IntPtr.Zero) return false;

            var info = new BitmapInfo
            {
                bmiHeader = new BitmapInfoHeader
                {
                    biSize = (uint)Marshal.SizeOf<BitmapInfoHeader>(),
                    biWidth = SplashWidth,
                    // Negative height makes the DIB top-down, matching GDI+ coordinates.
                    biHeight = -SplashHeight,
                    biPlanes = 1,
                    biBitCount = 32,
                    biCompression = BI_RGB,
                    biSizeImage = (uint)(SplashWidth * SplashHeight * 4),
                },
            };

            _dibSection = CreateDIBSection(_memoryDc, ref info, DIB_RGB_COLORS, out _dibBits, IntPtr.Zero, 0);
            if (_dibSection == IntPtr.Zero || _dibBits == IntPtr.Zero) return false;
            _oldBitmap = SelectObject(_memoryDc, _dibSection);

            _surface = new Bitmap(SplashWidth, SplashHeight, SplashWidth * 4, PixelFormat.Format32bppPArgb, _dibBits);
            _surfaceGraphics = Graphics.FromImage(_surface);
            ConfigureGraphics(_surfaceGraphics);
            return true;
        }
        catch
        {
            ReleasePersistentSurface();
            return false;
        }
    }

    private void RenderLoop()
    {
        var cadence = Stopwatch.StartNew();
        var nextFrame = 0d;
        var finalFramePresented = false;

        try
        {
            while (!_stopRequested && !IsDisposed)
            {
                if (_fading)
                {
                    var raw = Clamp01(_handoffTimeline.Elapsed.TotalMilliseconds / HandoffMs);
                    var eased = (float)EaseInOutCubic(raw);
                    var desiredLogo = Lerp(_handoffStartBounds, _handoffTargetBounds, eased);
                    RenderHandoffFrame(desiredLogo, (float)Math.Pow(1d - raw, .72d));

                    var centerX = desiredLogo.Left + desiredLogo.Width / 2;
                    var centerY = desiredLogo.Top + desiredLogo.Height / 2;
                    PresentSurface(new Point(centerX - SplashWidth / 2, centerY - SplashHeight / 2 + 32), 255);

                    if (raw >= 1d)
                    {
                        _handoffComplete = true;
                        break;
                    }
                }
                else if (!_holdRaised)
                {
                    var elapsed = _timeline.Elapsed.TotalMilliseconds;
                    if (elapsed <= FinalAnimationMs || !finalFramePresented)
                    {
                        RenderMainFrame(Math.Min(elapsed, FinalAnimationMs));
                        PresentSurface(_splashBounds.Location, 255);
                        finalFramePresented = elapsed >= FinalAnimationMs;
                    }

                    if (elapsed >= HoldUntilMs)
                    {
                        _holdRaised = true;
                        RaiseHoldCompleted();
                    }
                }

                if (_holdRaised && !_fading)
                {
                    Thread.Sleep(2);
                    continue;
                }

                nextFrame += TargetFrameMs;
                WaitUntil(cadence, nextFrame);
            }
        }
        catch
        {
            // Startup artwork is optional; recover by presenting the ready GUI.
            _stopRequested = true;
        }
        finally
        {
            _handoffComplete = true;
            if (!_holdRaised && !_disposeRequested && !IsDisposed)
            {
                _holdRaised = true;
                RaiseHoldCompleted();
            }
            if (_disposeRequested) ReleaseRenderingResources();
        }
    }

    private static void WaitUntil(Stopwatch clock, double targetMs)
    {
        while (true)
        {
            var remaining = targetMs - clock.Elapsed.TotalMilliseconds;
            if (remaining <= 0d) return;
            if (remaining > 2.0d) Thread.Sleep(1);
            else if (remaining > .30d) Thread.Yield();
            else Thread.SpinWait(55);
        }
    }

    private void RaiseHoldCompleted()
    {
        if (IsDisposed) return;
        try
        {
            BeginInvoke(new Action(() =>
            {
                if (!IsDisposed) HoldCompleted?.Invoke(this, EventArgs.Empty);
            }));
        }
        catch { }
    }

    private void BeginTransparentFrame()
    {
        if (_surfaceGraphics is null) return;
        _surfaceGraphics.CompositingMode = CompositingMode.SourceCopy;
        _surfaceGraphics.Clear(Color.Transparent);
        _surfaceGraphics.CompositingMode = CompositingMode.SourceOver;
    }

    private void RenderMainFrame(double t)
    {
        var g = _surfaceGraphics;
        if (g is null) return;
        BeginTransparentFrame();

        var textReveal = (float)EaseOutCubic(Clamp01((t - LogoSettleMs) / 320d));
        var centerY = SplashHeight * .50f - 32f * textReveal;
        var logoCenterX = SplashWidth * .50f;
        const float logoTarget = 176f;
        var logoProgress = EaseOutBack(Clamp01(t / LogoSettleMs));
        var logoAlpha = (float)EaseOutCubic(Clamp01(t / 360d));
        var angle = (float)((1d - logoProgress) * 160d);
        var translateX = (float)((1d - logoProgress) * 130d);
        var scale = .70f + (float)logoProgress * .30f;

        DrawLogo(g, logoCenterX + translateX, centerY, logoTarget * scale, angle, logoAlpha);
        var brandWidth = _brandAdvances.Sum();
        DrawBrandLetters(g, t, (SplashWidth - brandWidth) / 2f, 222f, 1f);
    }

    private void RenderHandoffFrame(Rectangle desiredLogo, float alpha)
    {
        var g = _surfaceGraphics;
        if (g is null) return;
        BeginTransparentFrame();

        var size = Math.Max(1f, Math.Min(desiredLogo.Width, desiredLogo.Height));
        var centerX = SplashWidth / 2f;
        var centerY = SplashHeight / 2f - 32f;
        if (_logo is not null)
            DrawImageWithAlpha(g, _logo, new RectangleF(centerX - size / 2f, centerY - size / 2f, size, size), alpha);
        DrawBrandLetters(g, FinalAnimationMs, (SplashWidth - _brandAdvances.Sum()) / 2f, 222f, alpha);
    }

    private static void ConfigureGraphics(Graphics g)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        // HighQualityBilinear is far cheaper than Bicubic while the source is already
        // high-resolution. Reducing per-frame filtering work prevents cadence stalls.
        g.InterpolationMode = InterpolationMode.HighQualityBilinear;
        g.PixelOffsetMode = PixelOffsetMode.HighQuality;
        g.CompositingQuality = CompositingQuality.HighSpeed;
        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
    }

    private void PresentSurface(Point location, byte opacity)
    {
        if (IsDisposed || !IsHandleCreated || _memoryDc == IntPtr.Zero || _screenDc == IntPtr.Zero) return;
        try
        {
            var dst = new PointNative(location.X, location.Y);
            var src = new PointNative(0, 0);
            var size = new SizeNative(SplashWidth, SplashHeight);
            var blend = new BlendFunction
            {
                BlendOp = AC_SRC_OVER,
                BlendFlags = 0,
                SourceConstantAlpha = opacity,
                AlphaFormat = AC_SRC_ALPHA,
            };
            _ = UpdateLayeredWindow(Handle, _screenDc, ref dst, ref size, _memoryDc, ref src, 0, ref blend, ULW_ALPHA);
        }
        catch { }
    }

    private void DrawLogo(Graphics g, float centerX, float centerY, float size, float angle, float alpha)
    {
        if (_logo is null || alpha <= 0f) return;
        var state = g.Save();
        g.TranslateTransform(centerX, centerY);
        g.RotateTransform(angle);
        g.TranslateTransform(-centerX, -centerY);
        DrawImageWithAlpha(g, _logo, new RectangleF(centerX - size / 2f, centerY - size / 2f, size, size), alpha);
        g.Restore(state);
    }

    private void DrawBrandLetters(Graphics g, double t, float x, float centerY, float globalAlpha)
    {
        var cursor = x;
        var baseY = centerY - _brandFont.Height * .48f;
        for (var i = 0; i < BrandText.Length; i++)
        {
            var text = BrandText[i].ToString();
            var start = BrandStartMs + i * BrandStepMs;
            var local = Clamp01((t - start) / BrandLetterMs);
            if (local <= 0d)
            {
                cursor += _brandAdvances[i];
                continue;
            }

            var eased = EaseOutCubic(local);
            var alpha = Math.Clamp((int)Math.Round(255d * Math.Min(1d, local * 1.35d) * globalAlpha), 0, 255);
            var jump = (float)((1d - eased) * 5d);
            _brandBrush.Color = Color.FromArgb(alpha, 244, 244, 247);
            g.DrawString(text, _brandFont, _brandBrush, cursor, baseY + jump, StringFormat.GenericTypographic);
            cursor += _brandAdvances[i];
        }
    }

    internal async Task FadeOutAndCloseAsync(Rectangle? titleLogoScreenBounds = null)
    {
        if (_fading || IsDisposed) return;
        if (_renderThread is not { IsAlive: true })
        {
            Close();
            return;
        }

        var centerY = _splashBounds.Height * .50f - 32f;
        var logoCenterX = _splashBounds.Width * .50f;
        const float logoSize = 176f;
        _handoffStartBounds = new Rectangle(
            _splashBounds.Left + (int)Math.Round(logoCenterX - logoSize / 2f),
            _splashBounds.Top + (int)Math.Round(centerY - logoSize / 2f),
            (int)logoSize,
            (int)logoSize);
        _handoffTargetBounds = titleLogoScreenBounds is Rectangle target && target.Width > 0 && target.Height > 0
            ? target
            : _handoffStartBounds;

        _handoffComplete = false;
        _fading = true;
        _handoffTimeline.Restart();
        var deadline = Stopwatch.StartNew();
        while (!IsDisposed && !_handoffComplete && _renderThread is { IsAlive: true } && deadline.ElapsedMilliseconds < 1600)
            await Task.Delay(3);

        _stopRequested = true;
        if (!IsDisposed) Close();
    }

    private static Bitmap RemoveTransparentEdgeChroma(Bitmap source)
    {
        var clean = new Bitmap(source.Width, source.Height, PixelFormat.Format32bppArgb);
        using (var g = Graphics.FromImage(clean))
        {
            g.CompositingMode = CompositingMode.SourceCopy;
            g.DrawImageUnscaled(source, 0, 0);
        }

        for (var y = 0; y < clean.Height; y++)
        for (var x = 0; x < clean.Width; x++)
        {
            var c = clean.GetPixel(x, y);
            if (c.A > 32) continue;
            if (c.A <= 10)
            {
                clean.SetPixel(x, y, Color.FromArgb(c.A, 0, 0, 0));
                continue;
            }
            var spread = Math.Max(c.R, Math.Max(c.G, c.B)) - Math.Min(c.R, Math.Min(c.G, c.B));
            if (spread > 36)
            {
                var neutral = (c.R + c.G + c.B) / 3;
                clean.SetPixel(x, y, Color.FromArgb(c.A, neutral, neutral, neutral));
            }
        }
        source.Dispose();
        return clean;
    }

    private void DrawImageWithAlpha(Graphics g, Image image, RectangleF bounds, float alpha)
    {
        var clamped = Math.Clamp(alpha, 0f, 1f);
        var destination = Rectangle.Round(bounds);
        if (clamped >= .999f)
        {
            g.DrawImage(image, destination, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel);
            return;
        }

        var matrix = new ColorMatrix { Matrix33 = clamped };
        _logoAttributes.SetColorMatrix(matrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap);
        g.DrawImage(image, destination, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, _logoAttributes);
    }

    private static Rectangle Lerp(Rectangle a, Rectangle b, float t) => new(
        (int)Math.Round(a.X + (b.X - a.X) * t),
        (int)Math.Round(a.Y + (b.Y - a.Y) * t),
        Math.Max(1, (int)Math.Round(a.Width + (b.Width - a.Width) * t)),
        Math.Max(1, (int)Math.Round(a.Height + (b.Height - a.Height) * t)));

    private static double Clamp01(double value) => Math.Max(0d, Math.Min(1d, value));
    private static double EaseOutCubic(double value) => 1d - Math.Pow(1d - Clamp01(value), 3d);
    private static double EaseInOutCubic(double value)
    {
        var x = Clamp01(value);
        return x < .5d ? 4d * x * x * x : 1d - Math.Pow(-2d * x + 2d, 3d) / 2d;
    }

    private static double EaseOutBack(double value)
    {
        var x = Clamp01(value);
        const double c1 = 1.15d;
        const double c3 = c1 + 1d;
        return 1d + c3 * Math.Pow(x - 1d, 3d) + c1 * Math.Pow(x - 1d, 2d);
    }

    private void ReleasePersistentSurface()
    {
        try { _surfaceGraphics?.Dispose(); } catch { }
        _surfaceGraphics = null;
        try { _surface?.Dispose(); } catch { }
        _surface = null;

        if (_memoryDc != IntPtr.Zero && _oldBitmap != IntPtr.Zero)
        {
            try { _ = SelectObject(_memoryDc, _oldBitmap); } catch { }
            _oldBitmap = IntPtr.Zero;
        }
        if (_dibSection != IntPtr.Zero)
        {
            try { _ = DeleteObject(_dibSection); } catch { }
            _dibSection = IntPtr.Zero;
        }
        if (_memoryDc != IntPtr.Zero)
        {
            try { _ = DeleteDC(_memoryDc); } catch { }
            _memoryDc = IntPtr.Zero;
        }
        if (_screenDc != IntPtr.Zero)
        {
            try { _ = ReleaseDC(IntPtr.Zero, _screenDc); } catch { }
            _screenDc = IntPtr.Zero;
        }
        _dibBits = IntPtr.Zero;
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _disposeRequested = true;
            _stopRequested = true;
            try
            {
                if (_renderThread is { IsAlive: true } && Thread.CurrentThread != _renderThread)
                    _renderThread.Join(400);
            }
            catch { }

            // A blocked native frame may outlive the bounded join. That renderer
            // owns cleanup when it exits; never free its backing DIB underneath it.
            if (_renderThread is not { IsAlive: true }) ReleaseRenderingResources();
        }
        base.Dispose(disposing);
    }

    private void ReleaseRenderingResources()
    {
        if (Interlocked.Exchange(ref _renderingResourcesReleased, 1) != 0) return;
        ReleasePersistentSurface();
        _logo?.Dispose();
        _brandFont.Dispose();
        _brandBrush.Dispose();
        _logoAttributes.Dispose();
        if (_timerResolutionRaised)
        {
            try { _ = TimeEndPeriod(1); } catch { }
            _timerResolutionRaised = false;
        }
    }
}
