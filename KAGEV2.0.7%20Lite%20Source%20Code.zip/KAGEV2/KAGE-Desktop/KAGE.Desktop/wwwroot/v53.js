// v53: harden tab switching, compact history composition, settings Discord identity.
(() => {
  'use strict';
  if (new URLSearchParams(location.search).get('shadePopout') === '1') return;

  const tabButtons = [...document.querySelectorAll('.top-icon-nav .tab-btn[data-tab]')];
  const tabContents = [...document.querySelectorAll('.tab-content[id^="tab-"]')];

  function activateKageTab(tab, sourceButton = null) {
    const name = String(tab || '').trim();
    const target = document.getElementById(`tab-${name}`);
    if (!name || !target) return false;
    for (const button of tabButtons) {
      const active = button === sourceButton || button.dataset.tab === name;
      button.classList.toggle('active', active);
      button.setAttribute('aria-selected', active ? 'true' : 'false');
    }
    for (const content of tabContents) content.classList.toggle('active', content === target);
    if (name === 'reupload' && typeof window.scheduleExplorerAlignment === 'function') window.scheduleExplorerAlignment();
    if (name === 'ai' && typeof window.renderShadeConversation === 'function') requestAnimationFrame(() => window.renderShadeConversation({ force: true, settle: true }));
    return true;
  }
  window.activateKageTab = activateKageTab;

  // Bind directly on the actual buttons and stop title-bar drag handling before
  // it can ever consume the pointer sequence in WebView2.
  for (const button of tabButtons) {
    button.type = 'button';
    button.style.pointerEvents = 'auto';
    button.addEventListener('pointerdown', event => event.stopPropagation(), true);
    button.addEventListener('mousedown', event => event.stopPropagation(), true);
    button.addEventListener('click', event => {
      event.preventDefault();
      event.stopPropagation();
      activateKageTab(button.dataset.tab, button);
    }, true);
  }

  // Home quick actions use the same hard navigation path instead of synthesizing
  // a click on another control.
  for (const button of document.querySelectorAll('[data-home-tab]')) {
    button.addEventListener('click', event => {
      const tab = String(button.dataset.homeTab || '');
      if (!tab) return;
      event.preventDefault();
      activateKageTab(tab, tabButtons.find(node => node.dataset.tab === tab));
    }, true);
  }

  // Keep game title/meta anchored to the left of each history row. The durable
  // history data and thumbnail hydrator remain the existing KAGE implementation.
  const previousRenderHistory = window.renderRecentHistory;
  if (typeof previousRenderHistory === 'function') {
    window.renderRecentHistory = function() {
      previousRenderHistory();
      document.querySelectorAll('#activity-list .activity-item').forEach(row => {
        const place = row.querySelector('.activity-place');
        if (place) place.style.textAlign = 'left';
      });
    };
  }

  // Settings no longer mirrors the large Roblox PFP. Show the authenticated
  // Discord avatar beside its username and ID instead.
  const previousUpdateAccountInfo = window.updateAccountInfo;
  if (typeof previousUpdateAccountInfo === 'function') {
    window.updateAccountInfo = function(data) {
      previousUpdateAccountInfo(data);
      const discord = data?.discord || {};
      const avatar = document.getElementById('settings-discord-avatar');
      if (avatar) {
        const url = String(discord.avatar || '');
        avatar.style.backgroundImage = url ? `url("${url.replace(/["\\]/g, '')}")` : '';
      }
    };
  }

  // The logout overlay intentionally has no copy/card. Existing logout state
  // management only toggles this overlay and remains unchanged.
})();
