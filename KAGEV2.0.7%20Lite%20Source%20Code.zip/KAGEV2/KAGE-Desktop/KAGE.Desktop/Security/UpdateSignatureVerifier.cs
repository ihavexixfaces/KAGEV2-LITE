using System.Security.Cryptography;
using System.Text.Json;
using KAGE.Desktop.Updates;

namespace KAGE.Desktop;

internal static class UpdateSignatureVerifier
{
    internal const string Algorithm = "ECDSA_P256_SHA256";

    internal static bool Verify(UpdateManifest manifest)
    {
        if (manifest is null || manifest.Version != 2 || !UpdateReleasePolicy.IsSupported(manifest.ReleaseVersion, manifest.ProtocolGeneration) || manifest.Package is null ||
            manifest.Sha256 is null || manifest.ExecutableSha256 is null || manifest.DistributionMode is null ||
            !string.Equals(manifest.SignatureAlgorithm, Algorithm, StringComparison.Ordinal) ||
            string.IsNullOrWhiteSpace(manifest.Signature))
            return false;

        byte[] signature;
        try { signature = Convert.FromBase64String(manifest.Signature); }
        catch (FormatException) { return false; }

        var payload = CanonicalUnsignedPayload(manifest);
        try
        {
            using var key = ECDsa.Create();
            key.ImportFromPem(IntegrityVerificationKey.Pem);
            return key.KeySize == 256 && key.VerifyData(
                payload,
                signature,
                HashAlgorithmName.SHA256,
                DSASignatureFormat.Rfc3279DerSequence);
        }
        catch (CryptographicException)
        {
            return false;
        }
        finally
        {
            CryptographicOperations.ZeroMemory(signature);
            CryptographicOperations.ZeroMemory(payload);
        }
    }

    internal static byte[] CanonicalUnsignedPayload(UpdateManifest manifest)
    {
        using var buffer = new MemoryStream();
        using (var writer = new Utf8JsonWriter(buffer, new JsonWriterOptions { Indented = false }))
        {
            writer.WriteStartObject();
            writer.WriteNumber("version", manifest.Version);
            writer.WriteString("releaseVersion", manifest.ReleaseVersion);
            writer.WriteNumber("protocolGeneration", manifest.ProtocolGeneration);
            writer.WriteNumber("buildId", manifest.BuildId);
            writer.WriteString("package", manifest.Package);
            writer.WriteString("sha256", manifest.Sha256.ToLowerInvariant());
            writer.WriteString("executableSha256", manifest.ExecutableSha256.ToLowerInvariant());
            writer.WriteNumber("size", manifest.Size);
            writer.WriteString("distributionMode", manifest.DistributionMode);
            writer.WriteString("signatureAlgorithm", Algorithm);
            writer.WriteEndObject();
        }
        return buffer.ToArray();
    }
}
