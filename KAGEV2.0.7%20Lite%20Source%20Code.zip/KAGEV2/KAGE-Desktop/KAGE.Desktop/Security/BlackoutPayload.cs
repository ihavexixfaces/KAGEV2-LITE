using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text;

namespace KAGE.Desktop;

// Shared by the offline protector and runtime so authenticated framing cannot drift.
internal static class BlackoutPayload
{
    internal const int MaximumBytes = 64 * 1024 * 1024;
    private const int HeaderLength = 44;
    private const int Overhead = HeaderLength + 12 + 16;
    private static readonly byte[] Magic = "KB10"u8.ToArray();

    internal static byte[] Encrypt(byte[] plain, string name, byte[] key, byte[] buildSalt)
    {
        if (plain.Length > MaximumBytes || key.Length != 32 || buildSalt.Length != 32)
            throw new InvalidDataException("Invalid Blackout payload size or key material.");
        var output = new byte[checked(Overhead + plain.Length)];
        Magic.CopyTo(output, 0); output[4] = 10; output[5] = Kind(name);
        BinaryPrimitives.WriteInt32LittleEndian(output.AsSpan(8,4), plain.Length);
        SHA256.HashData(buildSalt).CopyTo(output,12);
        RandomNumberGenerator.Fill(output.AsSpan(HeaderLength,12));
        var aad = AssociatedData(output.AsSpan(0,HeaderLength), name);
        using var aes = new AesGcm(key,16);
        aes.Encrypt(output.AsSpan(HeaderLength,12),plain,output.AsSpan(Overhead),output.AsSpan(HeaderLength+12,16),aad);
        CryptographicOperations.ZeroMemory(aad);
        return output;
    }

    internal static byte[] Decrypt(byte[] payload, string name, byte[] key, byte[] salt, bool requireV10)
    {
        if (payload.Length > MaximumBytes + Overhead) throw new InvalidDataException("Blackout payload exceeds the bounded decode limit.");
        if (!payload.AsSpan().StartsWith(Magic))
        {
            if (requireV10) throw new InvalidDataException("Blackout V10 authenticated payload is required.");
            var protectedName = IsProtectedName(name);
            if (payload.Length < 32 || !payload.AsSpan(0,4).SequenceEqual("KBR2"u8))
            {
                if (protectedName) throw new InvalidDataException("Protected resource framing is missing or damaged.");
                return payload;
            }
            var legacyPlain = new byte[payload.Length-32];
            try { using var legacy = new AesGcm(key,16); legacy.Decrypt(payload.AsSpan(4,12),payload.AsSpan(32),payload.AsSpan(16,16),legacyPlain,Encoding.UTF8.GetBytes(name)); return legacyPlain; }
            catch { CryptographicOperations.ZeroMemory(legacyPlain); throw; }
        }
        if (payload.Length < Overhead || payload[4] != 10 || payload[5] != Kind(name) || payload[6] != 0 || payload[7] != 0 || salt.Length != 32)
            throw new InvalidDataException("Blackout V10 payload header is invalid.");
        var length = BinaryPrimitives.ReadInt32LittleEndian(payload.AsSpan(8,4));
        if (length < 0 || length > MaximumBytes || length != payload.Length-Overhead)
            throw new InvalidDataException("Blackout V10 payload length is invalid.");
        var binding = SHA256.HashData(salt);
        try { if (!CryptographicOperations.FixedTimeEquals(binding,payload.AsSpan(12,32))) throw new CryptographicException("Blackout payload belongs to a different build."); }
        finally { CryptographicOperations.ZeroMemory(binding); }
        var plain = new byte[length];
        var aad = AssociatedData(payload.AsSpan(0,HeaderLength),name);
        try { using var aes = new AesGcm(key,16); aes.Decrypt(payload.AsSpan(HeaderLength,12),payload.AsSpan(Overhead),payload.AsSpan(HeaderLength+12,16),plain,aad); return plain; }
        catch { CryptographicOperations.ZeroMemory(plain); throw; }
        finally { CryptographicOperations.ZeroMemory(aad); }
    }

    internal static byte[] ReadBounded(Stream source)
    {
        if (source.CanSeek && source.Length-source.Position > MaximumBytes+Overhead)
            throw new InvalidDataException("Blackout resource exceeds the bounded decode limit.");
        using var buffer = new MemoryStream();
        var block = new byte[16384];
        int count;
        while ((count=source.Read(block,0,block.Length)) > 0)
        {
            if (buffer.Length+count > MaximumBytes+Overhead) throw new InvalidDataException("Blackout resource exceeds the bounded decode limit.");
            buffer.Write(block,0,count);
        }
        return buffer.ToArray();
    }

    internal static Dictionary<int,byte[]> ReadStringVault(Stream source)
    {
        var bytes = ReadBounded(source);
        using var stream = new MemoryStream(bytes,false);
        using var reader = new BinaryReader(stream,Encoding.UTF8);
        if (!reader.ReadBytes(4).AsSpan().SequenceEqual("KBV3"u8)) throw new InvalidDataException("Protected string vault header is invalid.");
        var count = reader.ReadInt32();
        if (count < 0 || count > 100_000 || count > (stream.Length-stream.Position)/36)
            throw new InvalidDataException("Protected string vault count is invalid.");
        var records = new Dictionary<int,byte[]>(count);
        for (var i=0;i<count;i++)
        {
            var token=reader.ReadInt32(); var length=reader.ReadInt32();
            if (token==0 || length<28 || length>16*1024*1024 || length>stream.Length-stream.Position || records.ContainsKey(token))
                throw new InvalidDataException("Protected string vault record is invalid or duplicated.");
            records.Add(token,reader.ReadBytes(length));
        }
        if (stream.Position!=stream.Length) throw new InvalidDataException("Protected string vault contains trailing data.");
        return records;
    }

    internal static bool IsProtectedName(string name) => name.StartsWith("kbr_",StringComparison.Ordinal)||name.StartsWith("kbg_",StringComparison.Ordinal)||name.StartsWith("kbp_",StringComparison.Ordinal)||name.StartsWith("kbv_",StringComparison.Ordinal)||name.StartsWith("kbm_",StringComparison.Ordinal);
    internal static byte[] StringAssociatedData(int token)
    {
        var aad=Encoding.UTF8.GetBytes("KAGE/Blackout/string-entry/v10\0").Concat(new byte[4]).ToArray();
        BinaryPrimitives.WriteInt32LittleEndian(aad.AsSpan(aad.Length-4),token);return aad;
    }
    private static byte Kind(string name) => name.StartsWith("kbr_",StringComparison.Ordinal)||name.StartsWith("kbg_",StringComparison.Ordinal)?(byte)1:name.StartsWith("kbp_",StringComparison.Ordinal)?(byte)2:name.StartsWith("kbm_",StringComparison.Ordinal)?(byte)3:name.StartsWith("kbv_",StringComparison.Ordinal)?(byte)4:throw new InvalidDataException("Invalid protected payload domain.");
    private static byte[] AssociatedData(ReadOnlySpan<byte> header,string name)
    {
        if (name.Length is < 1 or > 512) throw new InvalidDataException("Invalid protected resource name.");
        var domain = Encoding.UTF8.GetBytes("KAGE/Blackout/payload/v10\0"+name);
        var aad = new byte[header.Length+domain.Length];header.CopyTo(aad);domain.CopyTo(aad,header.Length);return aad;
    }
}
