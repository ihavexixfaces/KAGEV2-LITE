namespace Kage.Security;

// The host owns shutdown. WebView timers and the wall clock never determine exit.
internal sealed class SecurityBlockCountdown : IDisposable
{
    private readonly TimeProvider _clock;
    private readonly Action<int> _changed;
    private readonly Action _close;
    private readonly object _sync = new();
    private ITimer? _timer;
    private long _started;
    private bool _running, _closed, _disposed;
    private int _last = -1;

    internal SecurityBlockCountdown(Action<int> changed, Action close, TimeProvider? clock = null)
    { _changed = changed; _close = close; _clock = clock ?? TimeProvider.System; }

    internal void Start()
    {
        lock (_sync)
        {
            if (_running || _disposed) return;
            _running = true;
            _started = _clock.GetTimestamp();
            _timer = _clock.CreateTimer(_ => Pump(), null, TimeSpan.FromMilliseconds(100), TimeSpan.FromMilliseconds(100));
        }
        Pump();
    }

    internal int SecondsRemaining
    {
        get { lock (_sync) return _running ? Math.Clamp((int)Math.Ceiling(5 - _clock.GetElapsedTime(_started).TotalSeconds), 0, 5) : 5; }
    }

    internal void Pump()
    {
        int seconds;
        bool changed, close;
        lock (_sync)
        {
            if (!_running || _disposed || _closed) return;
            var elapsed = _clock.GetElapsedTime(_started);
            seconds = Math.Clamp((int)Math.Ceiling(5 - elapsed.TotalSeconds), 0, 5);
            changed = seconds != _last;
            _last = seconds;
            close = elapsed >= TimeSpan.FromSeconds(5);
            if (close) { _closed = true; _timer?.Change(Timeout.InfiniteTimeSpan, Timeout.InfiniteTimeSpan); }
        }
        try { if (changed) _changed(seconds); }
        finally { if (close) _close(); }
    }

    public void Dispose()
    {
        lock (_sync) { _disposed = true; _timer?.Dispose(); _timer = null; }
    }
}
