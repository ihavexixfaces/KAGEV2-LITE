@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title KAGE V2 Lite Build
where dotnet >nul 2>nul
if errorlevel 1 (
  echo .NET 8 SDK was not found. Install the .NET 8 SDK and run this file again.
  pause
  exit /b 1
)
if exist "LiteBuild" rmdir /s /q "LiteBuild"
mkdir "LiteBuild"
echo Building KAGE V2 Lite for Windows x64...
dotnet publish "KAGE-Desktop\KAGE.Desktop\KAGE.Desktop.csproj" -c Debug -r win-x64 --self-contained true -p:EnableWindowsTargeting=true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:KageDistributionMode=lite -p:KageReleaseVersion=2.0.7-lite -p:KageBuildId=1791511201 -o "LiteBuild"
if errorlevel 1 (
  echo.
  echo Lite build failed. No release executable was produced.
  pause
  exit /b 1
)
if exist "LiteBuild\RuntimeHost.exe" ren "LiteBuild\RuntimeHost.exe" "KAGE Lite.exe"
if not exist "LiteBuild\KAGE Lite.exe" (
  echo Expected Lite executable was not produced.
  pause
  exit /b 1
)
echo.
echo KAGE V2 Lite build completed:
echo %CD%\LiteBuild\KAGE Lite.exe
echo.
echo This local build is for testing. Run the protected release workflow before public distribution.
pause
