using System.Buffers.Binary;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO.Pipes;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;

namespace Kage.Core;

/// <summary>
/// Optional local Discord Rich Presence. Never uses Discord user/bot tokens or network APIs.
/// All I/O happens on its own background task; Studio uploads never wait on Discord.
/// </summary>
public sealed class KageDiscordPresence : IAsyncDisposable
{
    private readonly string _applicationId;
    private readonly CancellationTokenSource _stop = new();
    private readonly object _stateLock = new();
    private readonly SemaphoreSlim _writeLock = new(1, 1);
    private readonly SemaphoreSlim _stateChanged = new(0, 1);
    private readonly Func<CancellationToken, Task<Stream?>>? _connector;
    private readonly Task _background;
    private string _area = "Home";
    private int _disposed;
    private string _gameName = string.Empty;
    private string _lastDiagnostic = string.Empty;
    private readonly object _diagnosticLock = new();
    private int _assetsFound;
    private int _completed;
    private int _total;
    private bool _reuploading;
    private readonly long _started = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

    public KageDiscordPresence() : this(ReadApplicationId(), null) { }

    // Transport injection keeps protocol handling independent of the OS IPC
    // transport. Hosts can supply a different local stream without changing it.
    internal KageDiscordPresence(string applicationId, Func<CancellationToken, Task<Stream?>>? connector)
    {
        _applicationId = IsApplicationId(applicationId) ? applicationId : string.Empty;
        _connector = connector;
        _background = string.IsNullOrEmpty(_applicationId)
            ? Task.CompletedTask : Task.Run(() => RunAsync(_stop.Token));
        LogState(string.IsNullOrEmpty(_applicationId)
            ? "DISABLED: Public Discord Application ID not configured. Run Setup-KAGE-Discord-RPC.bat BEFORE compiling the EXE."
            : "Configured; trying local Discord Desktop IPC connection.");
    }

    public bool IsConfigured => _applicationId.Length != 0;

    public void SetArea(string? area)
    {
        var label = (area ?? "").Trim().ToLowerInvariant() switch
        {
            "home" => "Home",
            "reupload" => "Reupload",
            "preview" or "previews" or "asset-preview" or "previewer" => "Asset previews",
            "ai" or "shade" => "Shade",
            "settings" => "Settings",
            "logs" => "Logs",
            "watch" => "Watch",
            "history" => "Recent history",
            "setup" or "auth" => "Signing in",
            _ => string.Empty
        };
        if (label.Length == 0) return;
        lock (_stateLock)
        {
            if (_area == label) return;
            _area = label;
        }
        Refresh();
    }

    // OAuth refresh republishes local activity; it never substitutes an OAuth
    // identity for the account signed into the user's Discord desktop client.
    public void Refresh()
    {
        if (Volatile.Read(ref _disposed) != 0) return;
        try { _stateChanged.Release(); }
        catch (SemaphoreFullException) { /* Coalesce rapid progress/tab changes. */ }
        catch (ObjectDisposedException) { /* Shutdown raced the UI update. */ }
    }

    public void SetProject(string? gameName)
    {
        lock (_stateLock)
        {
            var cleaned = (gameName ?? string.Empty).Trim();
            if (string.Equals(cleaned, _gameName, StringComparison.Ordinal)) return;
            _gameName = cleaned;
            _assetsFound = 0;
            _completed = 0;
            _total = 0;
            _reuploading = false;
        }
        Refresh();
    }

    public void SetAssetCount(int count)
    {
        lock (_stateLock)
        {
            if (_reuploading || _assetsFound == Math.Max(0, count)) return;
            _assetsFound = Math.Max(0, count);
        }
        Refresh();
    }

    public void BeginReupload(string? gameName, int total)
    {
        lock (_stateLock)
        {
            _gameName = (gameName ?? _gameName).Trim();
            _total = Math.Max(0, total);
            _assetsFound = _total;
            _completed = 0;
            _reuploading = true;
        }
        Refresh();
    }

    public void ReportReupload(int completed, int total)
    {
        lock (_stateLock)
        {
            if (!_reuploading) return;
            _total = Math.Max(_total, Math.Max(0, total));
            _completed = Math.Clamp(completed, 0, Math.Max(0, _total));
        }
        Refresh();
    }

    public void FinishReupload()
    {
        lock (_stateLock)
        {
            _reuploading = false;
            _assetsFound = Math.Max(_assetsFound, _total);
        }
        Refresh();
    }

    private (string Details, string State) Snapshot()
    {
        lock (_stateLock)
        {
            var details = _gameName.Length == 0 ? "KAGE V2.0.7" : $"KAGE V2.0.7 - {_gameName}";
            if (details.Length > 128) details = details[..128];
            var state = _reuploading
                ? $"{_completed:N0}/{_total:N0} assets"
                : _assetsFound > 0 ? $"{_assetsFound:N0} assets found" : string.Empty;
            return (details, state.Length == 0 ? _area : (_reuploading ? state : $"{_area} · {state}"));
        }
    }

    private static string ReadApplicationId()
    {
        var overrideId = Environment.GetEnvironmentVariable("KAGE_DISCORD_RPC_APP_ID")?.Trim() ?? "";
        if (IsApplicationId(overrideId)) return overrideId;
        var value = KageDiscordRpcConfig.ApplicationId;
        return IsApplicationId(value) ? value : "";
    }

    private static bool IsApplicationId(string value) => value.Length is >= 17 and <= 20 && value.All(c => c is >= '0' and <= '9') && value.Any(c => c != '0');

    private async Task RunAsync(CancellationToken stop)
    {
        while (!stop.IsCancellationRequested)
        {
            try
            {
                await using var connection = await ConnectAsync(stop).ConfigureAwait(false);
                if (connection != null)
                {
                    LogState("CONNECTED: Discord Desktop RPC handshake accepted.");
                    await RunConnectedAsync(connection, stop).ConfigureAwait(false);
                }
                else LogState("DISCONNECTED: No responding Discord Desktop IPC endpoint; retrying.");
            }
            catch (OperationCanceledException) when (stop.IsCancellationRequested) { break; }
            catch (TimeoutException)
            {
                // The local IPC pipe can handshake before Discord is ready to
                // process activity. Retry without blocking KAGE's UI.
                LogState("DISCONNECTED: Discord did not acknowledge Rich Presence activity; retrying.");
            }
            catch (Exception ex) when (IsConnectionError(ex))
            {
                // Discord may be closed, disabled, frozen, or restarted. Never interrupt KAGE.
                LogState("DISCONNECTED: " + ex.GetType().Name + "; retrying.");
            }
            try { await Task.Delay(TimeSpan.FromSeconds(8), stop).ConfigureAwait(false); }
            catch (OperationCanceledException) { break; }
        }
    }

    private async Task RunConnectedAsync(Stream connection, CancellationToken stop)
    {
        using var connected = CancellationTokenSource.CreateLinkedTokenSource(stop);
        stop = connected.Token;
        var responses = new ConcurrentDictionary<string, TaskCompletionSource>();
        var receive = ReceiveAsync(connection, responses, connected.Token);
        try
        {
            while (!stop.IsCancellationRequested)
            {
                while (_stateChanged.Wait(0)) { }
                var (details, state) = Snapshot();
                var nonce = Guid.NewGuid().ToString("N");
                var acknowledged = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
                responses[nonce] = acknowledged;
                try
                {
                    await WriteLockedFrameAsync(connection, 1, new
                    {
                        cmd = "SET_ACTIVITY", nonce,
                        args = new { pid = Environment.ProcessId, activity = new
                        {
                            type = 0, details, state, timestamps = new { start = _started }
                        } }
                    }, connected.Token).ConfigureAwait(false);
                    // A socket can remain open after Discord stops responding.
                    // Require the matching command response so this state reconnects too.
                    await Task.WhenAny(receive, acknowledged.Task).WaitAsync(TimeSpan.FromSeconds(12), connected.Token).ConfigureAwait(false);
                    if (receive.IsCompleted)
                    {
                        await receive.ConfigureAwait(false);
                        throw new IOException("Discord closed its local RPC session.");
                    }
                    await acknowledged.Task.ConfigureAwait(false);
                    // Handshake is not proof that Discord is actually displaying
                    // activity. Record the first successful SET_ACTIVITY response.
                    LogState("ACTIVE: Discord acknowledged KAGE Rich Presence activity.");
                }
                finally { responses.TryRemove(nonce, out _); }

                // Avoid flooding Discord during scans. Changes are coalesced and
                // published after at most this short cadence instead of waiting 12s.
                await Task.WhenAny(receive, Task.Delay(TimeSpan.FromSeconds(2), stop)).ConfigureAwait(false);
                if (receive.IsCompleted) await receive.ConfigureAwait(false);
                var changed = _stateChanged.WaitAsync(TimeSpan.FromSeconds(12), stop);
                await Task.WhenAny(receive, changed).ConfigureAwait(false);
                if (receive.IsCompleted)
                {
                    await receive.ConfigureAwait(false);
                    throw new IOException("Discord closed its local RPC session.");
                }
                await changed.ConfigureAwait(false);
            }
        }
        finally
        {
            connected.Cancel();
            // Observe the reader before disposing its stream or synchronization
            // primitives. A reconnect must not leave a reader writing an old PONG.
            try { await receive.ConfigureAwait(false); }
            catch (Exception ex) when (IsConnectionError(ex)) { }
        }
    }

    private async Task ReceiveAsync(Stream stream, ConcurrentDictionary<string, TaskCompletionSource> responses, CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            var (op, payload) = await ReadFrameAsync(stream, cancellationToken).ConfigureAwait(false);
            if (op == 2) throw new IOException("Discord closed its local RPC session.");
            if (op == 3)
            {
                await WriteLockedRawFrameAsync(stream, 4, payload, cancellationToken).ConfigureAwait(false);
                continue;
            }
            if (op != 1 || payload.Length == 0) continue;
            // Discord events/responses can contain identity information. Only
            // inspect protocol fields; never retain or log their raw payload.
            using var message = JsonDocument.Parse(payload);
            var root = message.RootElement;
            if (root.ValueKind != JsonValueKind.Object) continue;
            var error = root.TryGetProperty("evt", out var evt) && evt.ValueKind == JsonValueKind.String && evt.GetString() == "ERROR";
            if (root.TryGetProperty("nonce", out var nonce) && nonce.ValueKind == JsonValueKind.String &&
                responses.TryGetValue(nonce.GetString() ?? "", out var pending))
            {
                if (error) pending.TrySetException(new IOException("Discord rejected a Rich Presence update."));
                else if (root.TryGetProperty("cmd", out var cmd) && cmd.ValueKind == JsonValueKind.String && cmd.GetString() == "SET_ACTIVITY")
                    pending.TrySetResult();
            }
            else if (error) throw new IOException("Discord rejected its local RPC session.");
        }
    }

    private static bool IsConnectionError(Exception ex) =>
        ex is IOException or SocketException or TimeoutException or UnauthorizedAccessException or JsonException or OperationCanceledException;

    private async Task HandshakeAsync(Stream stream, CancellationToken stop)
    {
        using var handshake = CancellationTokenSource.CreateLinkedTokenSource(stop);
        handshake.CancelAfter(TimeSpan.FromSeconds(5));
        await WriteFrameAsync(stream, 0, new { v = 1, client_id = _applicationId }, handshake.Token).ConfigureAwait(false);
        while (true)
        {
            var (op, payload) = await ReadFrameAsync(stream, handshake.Token).ConfigureAwait(false);
            if (op == 3)
            {
                await WriteRawFrameAsync(stream, 4, payload, handshake.Token).ConfigureAwait(false);
                continue;
            }
            if (op != 1) throw new IOException("Discord rejected local RPC handshake.");
            using var response = JsonDocument.Parse(payload);
            var root = response.RootElement;
            if (root.ValueKind != JsonValueKind.Object || !root.TryGetProperty("evt", out var evt) ||
                evt.ValueKind != JsonValueKind.String || evt.GetString() != "READY")
                throw new IOException("Discord did not return the READY handshake event.");
            return;
        }
    }

    private async Task<Stream?> ConnectAsync(CancellationToken token)
    {
        if (_connector is not null)
        {
            var stream = await _connector(token).ConfigureAwait(false);
            if (stream is null) return null;
            try { await HandshakeAsync(stream, token).ConfigureAwait(false); return stream; }
            catch { await stream.DisposeAsync().ConfigureAwait(false); throw; }
        }
        for (var i = 0; i < 10 && !token.IsCancellationRequested; i++)
        {
            if (OperatingSystem.IsWindows())
            {
                var pipe = new NamedPipeClientStream(".", $"discord-ipc-{i}", PipeDirection.InOut, PipeOptions.Asynchronous);
                try
                {
                    await pipe.ConnectAsync(350, token).ConfigureAwait(false);
                    await HandshakeAsync(pipe, token).ConfigureAwait(false);
                    return pipe;
                }
                catch (Exception ex) when (IsConnectionError(ex)) { pipe.Dispose(); }
            }
            if (OperatingSystem.IsLinux())
            {
                foreach (var path in UnixSocketPaths(i))
                {
                    if (!File.Exists(path)) continue;
                    Socket? socket = null;
                    Stream? stream = null;
                    try
                    {
                        socket = new Socket(AddressFamily.Unix, SocketType.Stream, ProtocolType.Unspecified);
                        using var attempt = CancellationTokenSource.CreateLinkedTokenSource(token);
                        attempt.CancelAfter(TimeSpan.FromMilliseconds(350));
                        await socket.ConnectAsync(new UnixDomainSocketEndPoint(path), attempt.Token).ConfigureAwait(false);
                        stream = new NetworkStream(socket, ownsSocket: true);
                        await HandshakeAsync(stream, token).ConfigureAwait(false);
                        return stream;
                    }
                    catch (Exception ex) when (IsConnectionError(ex) || ex is ArgumentException)
                    {
                        if (stream is not null) await stream.DisposeAsync().ConfigureAwait(false);
                        else socket?.Dispose();
                    }
                    token.ThrowIfCancellationRequested();
                }
            }
        }
        token.ThrowIfCancellationRequested();
        return null;
    }

    private static IEnumerable<string> UnixSocketPaths(int index)
    {
        var roots = new[] { "XDG_RUNTIME_DIR", "TMPDIR", "TMP", "TEMP" }
            .Select(Environment.GetEnvironmentVariable).Where(p => !string.IsNullOrWhiteSpace(p))
            .Append("/tmp").Distinct(StringComparer.Ordinal);
        var subdirectories = new[] { "", "app/com.discordapp.Discord", "app/com.discordapp.DiscordCanary",
            "app/com.discordapp.DiscordPTB", "snap.discord", "snap.discord-canary", "snap.discord-ptb" };
        return roots.SelectMany(root => subdirectories.Select(subdirectory =>
            Path.Combine(root!, subdirectory, $"discord-ipc-{index}"))).Distinct(StringComparer.Ordinal);
    }

    private Task WriteLockedFrameAsync(Stream stream, int opcode, object payload, CancellationToken token) =>
        WriteLockedRawFrameAsync(stream, opcode, JsonSerializer.SerializeToUtf8Bytes(payload), token);

    private async Task WriteLockedRawFrameAsync(Stream stream, int opcode, byte[] payload, CancellationToken token)
    {
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(token);
        deadline.CancelAfter(TimeSpan.FromSeconds(5));
        await _writeLock.WaitAsync(deadline.Token).ConfigureAwait(false);
        try { await WriteRawFrameAsync(stream, opcode, payload, deadline.Token).ConfigureAwait(false); }
        finally { _writeLock.Release(); }
    }

    private static Task WriteFrameAsync(Stream stream, int opcode, object payload, CancellationToken token) =>
        WriteRawFrameAsync(stream, opcode, JsonSerializer.SerializeToUtf8Bytes(payload), token);

    private static async Task WriteRawFrameAsync(Stream stream, int opcode, byte[] bytes, CancellationToken token)
    {
        var frame = new byte[bytes.Length + 8];
        BinaryPrimitives.WriteInt32LittleEndian(frame.AsSpan(0, 4), opcode);
        BinaryPrimitives.WriteInt32LittleEndian(frame.AsSpan(4, 4), bytes.Length);
        bytes.CopyTo(frame, 8);
        await stream.WriteAsync(frame, token).ConfigureAwait(false);
        await stream.FlushAsync(token).ConfigureAwait(false);
    }

    private static async Task<(int Opcode, byte[] Payload)> ReadFrameAsync(Stream stream, CancellationToken token)
    {
        var header = new byte[8];
        await stream.ReadExactlyAsync(header, token).ConfigureAwait(false);
        var opcode = BinaryPrimitives.ReadInt32LittleEndian(header.AsSpan(0, 4));
        var length = BinaryPrimitives.ReadInt32LittleEndian(header.AsSpan(4, 4));
        if (length < 0 || length > 1024 * 1024) throw new IOException("Invalid Discord IPC message size.");
        var payload = new byte[length];
        await stream.ReadExactlyAsync(payload, token).ConfigureAwait(false);
        return (opcode, payload);
    }

    // Bounded status-only diagnostics. No credentials, Discord user information,
    // project names, tokens, or raw Discord responses are written to this file.
    private void LogState(string state)
    {
        lock (_diagnosticLock)
        {
            if (state == _lastDiagnostic) return;
            _lastDiagnostic = state;
            Debug.WriteLine("KAGE Discord RPC " + state);
            try
            {
                var directory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "KAGE", "Logs");
                Directory.CreateDirectory(directory);
                var path = Path.Combine(directory, "discord-rpc.log");
                if (File.Exists(path) && new FileInfo(path).Length > 65536)
                    File.WriteAllText(path, "");
                File.AppendAllText(path, DateTimeOffset.Now.ToString("u") + " " + state + Environment.NewLine);
            }
            catch (Exception) { /* Diagnostics never affect KAGE startup. */ }
        }
    }

    public async ValueTask DisposeAsync()
    {
        if (Interlocked.Exchange(ref _disposed, 1) != 0) return;
        _stop.Cancel();
        try { await _background.ConfigureAwait(false); }
        catch (Exception ex) when (IsConnectionError(ex)) { }
        _stop.Dispose();
        _writeLock.Dispose();
        _stateChanged.Dispose();
    }
}
