using System.Text.Json;
using KAGE.Desktop.Preview;

namespace KAGE.Desktop;

public partial class MainForm
{
    private sealed record AnimationPreviewAvatar(string ClipToken, long AvatarUserId, JsonElement Definition);
    private AnimationPreviewAvatar? _animationPreviewAvatar;
    private CancellationTokenSource? _animationPreviewAvatarCancellation;
    private long _animationPreviewAvatarVersion;

    private void CancelAnimationPreviewAvatar()
    {
        lock (_animationPreviewRequestGate)
            CancelAnimationPreviewAvatarLocked();
    }

    private void CancelAnimationPreviewAvatarLocked()
    {
        _animationPreviewAvatarCancellation?.Cancel();
        _animationPreviewAvatarCancellation = null;
        _animationPreviewAvatar = null;
        _animationPreviewAvatarVersion++;
    }

    private void CancelAnimationPreviewAvatarIfAccountChanged()
    {
        var activeUserId = AccountManager.GetActiveProfile()?.UserId ?? 0;
        lock (_animationPreviewRequestGate)
        {
            if (_animationPreviewAvatar is { } avatar && avatar.AvatarUserId != activeUserId)
                CancelAnimationPreviewAvatarLocked();
        }
    }

    private void CacheAnimationPreviewAvatar(JsonElement result, string clipToken, long avatarUserId,
        CancellationTokenSource request, long loadVersion)
    {
        lock (_animationPreviewRequestGate)
        {
            request.Token.ThrowIfCancellationRequested();
            if (!ReferenceEquals(_animationPreviewLoadCancellation, request) || loadVersion != _animationPreviewAvatarVersion)
                throw new OperationCanceledException(request.Token);
            if (AccountManager.GetActiveProfile()?.UserId != avatarUserId)
                throw new InvalidOperationException("The active Roblox account changed. Load the animation again.");
            // Only Studio's successfully applied HumanoidDescription can authorize
            // the separate appearance request. Frontend avatar fields are ignored.
            if (result.ValueKind == JsonValueKind.Object &&
                result.TryGetProperty("avatarUserId", out var user) && user.TryGetInt64(out var loadedUserId) && loadedUserId == avatarUserId &&
                result.TryGetProperty("avatarDefinition", out var definition) && definition.ValueKind == JsonValueKind.Object)
                _animationPreviewAvatar = new AnimationPreviewAvatar(clipToken, avatarUserId, definition.Clone());
        }
    }

    private async Task<JsonElement> LoadAnimationPreviewAvatarAsync(string clipToken, CancellationTokenSource request)
    {
        AnimationPreviewAvatar avatar;
        string cookie;
        lock (_animationPreviewRequestGate)
        {
            request.Token.ThrowIfCancellationRequested();
            avatar = _animationPreviewAvatar ?? throw new InvalidOperationException("Load the animation before requesting its avatar appearance.");
            if (clipToken.Length == 0 || avatar.ClipToken != clipToken)
                throw new InvalidOperationException("That animation preview is no longer active. Load the animation again.");
            if (!AccountManager.TryGetActiveCredentials(out cookie, out _, out _) || string.IsNullOrWhiteSpace(cookie))
                throw new InvalidOperationException("Sign in to Roblox before loading your avatar appearance.");
            if (AccountManager.GetActiveProfile()?.UserId != avatar.AvatarUserId)
            {
                CancelAnimationPreviewAvatarLocked();
                throw new InvalidOperationException("The active Roblox account changed. Load the animation again.");
            }
            _animationPreviewAvatarCancellation?.Cancel();
            _animationPreviewAvatarCancellation = request;
        }

        // Avatar HTTP traffic does not acquire the Studio queue or hold the rig
        // lease. Sampling can finish and stop its Studio rig while this runs.
        using var client = new AvatarAppearanceClient(cookie);
        var appearance = await client.LoadAsync(avatar.Definition, avatar.AvatarUserId, request.Token);
        lock (_animationPreviewRequestGate)
        {
            request.Token.ThrowIfCancellationRequested();
            if (!ReferenceEquals(_animationPreviewAvatar, avatar) || !ReferenceEquals(_animationPreviewAvatarCancellation, request))
                throw new OperationCanceledException(request.Token);
            if (AccountManager.GetActiveProfile()?.UserId != avatar.AvatarUserId)
            {
                CancelAnimationPreviewAvatarLocked();
                throw new InvalidOperationException("The active Roblox account changed. Load the animation again.");
            }
            if (appearance.AvatarUserId != avatar.AvatarUserId)
                throw new InvalidOperationException("Roblox returned avatar appearance for a different account.");
        }
        return JsonSerializer.SerializeToElement(new
        {
            state = "avatar",
            avatarUserId = appearance.AvatarUserId,
            obj = appearance.Obj,
            mtl = appearance.Mtl,
            textures = appearance.Textures
        });
    }
}
