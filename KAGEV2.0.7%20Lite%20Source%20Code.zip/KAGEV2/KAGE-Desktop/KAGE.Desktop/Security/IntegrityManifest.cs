using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace KAGE.Desktop;

internal sealed record IntegrityArtifact(string Path, string Sha256);

internal sealed record IntegrityManifest(
    int Version,
    string BuildId,
    IReadOnlyList<IntegrityArtifact> Artifacts,
    string SignatureAlgorithm,
    string Signature,
    string ReleaseVersion = "2.0.7",
    int ProtocolGeneration = 2)
{
    internal const string SupportedSignatureAlgorithm = "ECDSA_P256_SHA256";
    private static readonly Regex LowerSha256 = new("^[0-9a-f]{64}$", RegexOptions.CultureInvariant);

    internal static IntegrityManifest Parse(ReadOnlySpan<byte> utf8Json)
    {
        using var document = JsonDocument.Parse(utf8Json.ToArray());
        var root = document.RootElement;
        if (root.ValueKind != JsonValueKind.Object)
            throw new InvalidDataException("Integrity manifest root must be an object.");

        EnsureUniqueProperties(root, "manifest");
        EnsureOnlyProperties(root, "version", "releaseVersion", "protocolGeneration", "buildId", "artifacts", "signatureAlgorithm", "signature");

        var version = GetRequiredInt32(root, "version");
        if (version != 2)
            throw new InvalidDataException("Unsupported integrity manifest version.");

        var releaseVersion = GetRequiredString(root, "releaseVersion");
        var generation = GetRequiredInt32(root, "protocolGeneration");
        if (releaseVersion != "2.0.7" || generation != 2)
            throw new InvalidDataException("Integrity manifest release identity is invalid.");

        var buildId = GetRequiredString(root, "buildId");
        if (string.IsNullOrWhiteSpace(buildId) || buildId.Length > 128)
            throw new InvalidDataException("Integrity manifest buildId is invalid.");

        var algorithm = GetRequiredString(root, "signatureAlgorithm");
        if (!string.Equals(algorithm, SupportedSignatureAlgorithm, StringComparison.Ordinal))
            throw new InvalidDataException("Integrity manifest signature algorithm is unsupported.");

        var signature = GetRequiredString(root, "signature");
        try
        {
            _ = Convert.FromBase64String(signature);
        }
        catch (FormatException ex)
        {
            throw new InvalidDataException("Integrity manifest signature is not valid base64.", ex);
        }

        if (!root.TryGetProperty("artifacts", out var artifactsElement) || artifactsElement.ValueKind != JsonValueKind.Array)
            throw new InvalidDataException("Integrity manifest artifacts array is required.");

        var artifacts = new List<IntegrityArtifact>();
        var seenPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var element in artifactsElement.EnumerateArray())
        {
            if (element.ValueKind != JsonValueKind.Object)
                throw new InvalidDataException("Integrity manifest artifact must be an object.");

            EnsureUniqueProperties(element, "artifact");
            EnsureOnlyProperties(element, "path", "sha256");
            var path = GetRequiredString(element, "path");
            var sha256 = GetRequiredString(element, "sha256");
            ValidateRelativeArtifactPath(path);
            if (!LowerSha256.IsMatch(sha256))
                throw new InvalidDataException("Artifact SHA-256 must be lowercase 64-character hex.");
            if (!seenPaths.Add(path))
                throw new InvalidDataException($"Duplicate artifact path: {path}");

            artifacts.Add(new IntegrityArtifact(path, sha256));
        }

        if (artifacts.Count == 0 || artifacts.Count > 10_000)
            throw new InvalidDataException("Integrity manifest artifact count is invalid.");

        var ordered = artifacts.OrderBy(static item => item.Path, StringComparer.Ordinal).ToArray();
        return new IntegrityManifest(version, buildId, ordered, algorithm, signature, releaseVersion, generation);
    }

    internal byte[] CanonicalUnsignedPayload()
    {
        using var buffer = new MemoryStream();
        using (var writer = new Utf8JsonWriter(buffer, new JsonWriterOptions { Indented = false }))
        {
            writer.WriteStartObject();
            writer.WriteNumber("version", Version);
            writer.WriteString("releaseVersion", ReleaseVersion);
            writer.WriteNumber("protocolGeneration", ProtocolGeneration);
            writer.WriteString("buildId", BuildId);
            writer.WritePropertyName("artifacts");
            writer.WriteStartArray();
            foreach (var artifact in Artifacts.OrderBy(static item => item.Path, StringComparer.Ordinal))
            {
                writer.WriteStartObject();
                writer.WriteString("path", artifact.Path);
                writer.WriteString("sha256", artifact.Sha256);
                writer.WriteEndObject();
            }
            writer.WriteEndArray();
            writer.WriteString("signatureAlgorithm", SignatureAlgorithm);
            writer.WriteEndObject();
        }
        return buffer.ToArray();
    }

    private static void ValidateRelativeArtifactPath(string path)
    {
        if (string.IsNullOrWhiteSpace(path) || path.Length > 512)
            throw new InvalidDataException("Artifact path is invalid.");
        if (Path.IsPathRooted(path) || path.Contains('\\') || path.StartsWith("/", StringComparison.Ordinal))
            throw new InvalidDataException("Artifact path must be normalized and relative.");

        var segments = path.Split('/', StringSplitOptions.None);
        if (segments.Any(static segment => segment.Length == 0 || segment is "." or ".."))
            throw new InvalidDataException("Artifact path traversal is not allowed.");
    }

    private static void EnsureUniqueProperties(JsonElement element, string context)
    {
        var names = new HashSet<string>(StringComparer.Ordinal);
        foreach (var property in element.EnumerateObject())
        {
            if (!names.Add(property.Name))
                throw new InvalidDataException($"Duplicate {context} property: {property.Name}");
        }
    }

    private static void EnsureOnlyProperties(JsonElement element, params string[] allowed)
    {
        var set = new HashSet<string>(allowed, StringComparer.Ordinal);
        foreach (var property in element.EnumerateObject())
        {
            if (!set.Contains(property.Name))
                throw new InvalidDataException($"Unknown integrity manifest property: {property.Name}");
        }
    }

    private static string GetRequiredString(JsonElement element, string name)
    {
        if (!element.TryGetProperty(name, out var property) || property.ValueKind != JsonValueKind.String)
            throw new InvalidDataException($"Integrity manifest property '{name}' is required.");
        return property.GetString() ?? string.Empty;
    }

    private static int GetRequiredInt32(JsonElement element, string name)
    {
        if (!element.TryGetProperty(name, out var property) || property.ValueKind != JsonValueKind.Number || !property.TryGetInt32(out var value))
            throw new InvalidDataException($"Integrity manifest property '{name}' is required.");
        return value;
    }
}
