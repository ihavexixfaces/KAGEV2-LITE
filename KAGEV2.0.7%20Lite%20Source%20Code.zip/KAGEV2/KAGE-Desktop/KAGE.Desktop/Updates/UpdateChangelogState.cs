using System.Globalization;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace KAGE.Desktop.Updates;

internal sealed record UpdateChangelogNotification(string BuildId, string Changelog);

// Separate from the ordinary check baseline: only a verified, successfully installed
// package can create a confirmed record. Empty notes stay eligible for later hydration.
internal sealed class UpdateChangelogStore
{
    internal const int MaxChangelogCharacters = 65536;
    private const long MaxStateFileBytes = 524288;
    private readonly string _path, _binaryId, _mode, _executablePath;
    private readonly long _buildId;
    internal UpdateChangelogStore(string path, string binaryId, long buildId, string mode, string executablePath)
        => (_path, _binaryId, _buildId, _mode, _executablePath) = (path, binaryId, buildId, mode, executablePath);

    internal static UpdateChangelogStore Current() => new(
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "KAGE", "Updates",
            "changelog-" + Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(
                Path.GetFullPath(AppContext.BaseDirectory).ToUpperInvariant())))[..16] + ".json"),
        Assembly.GetExecutingAssembly().ManifestModule.ModuleVersionId.ToString("N"),
        UpdateBuildInfo.BuildId, UpdateBuildInfo.DistributionMode,
        Environment.ProcessPath ?? throw new InvalidOperationException("KAGE executable path is unavailable."));

    internal void Prepare(AvailableUpdate update, string packagePath)
    {
        if (!ValidManifest(update.Manifest) || !MatchesHash(packagePath, update.Manifest.Sha256) ||
            new FileInfo(packagePath).Length != update.Manifest.Size)
            throw new InvalidDataException("Cannot stage release notes for an unverified update package.");
        var old = Read();
        Write(new State
        {
            Status = "prepared", Manifest = update.Manifest, RepositoryRevision = BoundRevision(update.RepositoryRevision),
            Changelog = MatchedNotes(update.Manifest, update.Changelog, update.ChangelogBuildId),
            DismissedBuildId = old?.DismissedBuildId ?? ""
        });
    }

    internal bool ConfirmStartup(UpdatedStartupContext context)
    {
        var state = Read();
        if (state is null && context.WasUpdated && context.ManifestBuildId == _buildId &&
            GitHubUpdateClient.IsHash(context.PackageSha256, 64))
        {
            // The v46 updater cannot prepare a signed sidecar. Capture the successful
            // startup identity durably even while authorization/network is unavailable.
            // This candidate grants no baseline or notes until signed metadata confirms it.
            var installedHash = FileHash(_executablePath);
            if (installedHash.Length > 0)
                Write(new State
                {
                    Status = "migration", BinaryId = _binaryId, InstalledExecutableSha256 = installedHash,
                    RepositoryRevision = BoundRevision(context.RepositoryRevision),
                    Manifest = new UpdateManifest { BuildId = _buildId, Sha256 = context.PackageSha256,
                        ExecutableSha256 = installedHash, DistributionMode = _mode, Package = UpdateRepository.PackageAssetName(_mode) }
                });
            return false;
        }
        if (state?.Status != "prepared" || !context.WasUpdated || !MatchesStartup(state.Manifest, context) ||
            !MatchesInstalled(state.Manifest)) return false;
        Confirm(state);
        return true;
    }

    // Called only after the authenticated envelope and production manifest verifier
    // pass. For v46's first migration there is no prepared sidecar: reconstruct it
    // from current signed metadata only when the successful --updated identity matches.
    internal bool AcceptVerifiedMetadata(UpdateManifest manifest, string revision, string notes, string notesBuildId,
        UpdatedStartupContext context)
    {
        if (!ValidManifest(manifest)) return false;
        ConfirmStartup(context);
        var state = Read();
        if (state?.Status == "migration" && state.BinaryId == _binaryId && state.Manifest.BuildId == _buildId &&
            state.Manifest.BuildId == manifest.BuildId &&
            string.Equals(state.Manifest.Sha256, manifest.Sha256, StringComparison.OrdinalIgnoreCase) &&
            state.InstalledExecutableSha256.Equals(manifest.ExecutableSha256, StringComparison.OrdinalIgnoreCase) &&
            (!context.WasUpdated || MatchesStartup(manifest, context)) && MatchesInstalled(manifest))
        {
            state.Manifest = manifest;
            if (state.RepositoryRevision.Length == 0) state.RepositoryRevision = BoundRevision(revision);
            Confirm(state);
        }
        if (!IsConfirmed(state) || !SamePackage(state!.Manifest, manifest)) return false;
        if (state.Changelog.Length == 0 && state.DismissedBuildId != Id(manifest.BuildId))
        {
            var matched = MatchedNotes(manifest, notes, notesBuildId);
            if (matched.Length > 0) { state.Changelog = matched; Write(state); }
        }
        return true;
    }

    internal UpdateChangelogNotification? Pending()
    {
        var state = Read();
        return IsConfirmed(state) && state!.Changelog.Length > 0 && state.Changelog.Length <= 4096 &&
            state.DismissedBuildId != Id(state.Manifest.BuildId)
            ? new(Id(state.Manifest.BuildId), state.Changelog) : null;
    }

    internal bool Dismiss(string buildId)
    {
        var state = Read();
        if (!IsConfirmed(state) || state!.Changelog.Length == 0 || buildId != Id(state.Manifest.BuildId)) return false;
        state.DismissedBuildId = buildId;
        Write(state);
        return true;
    }

    internal (string Revision, string PackageSha256, long BuildId)? ConfirmedIdentity()
    {
        var state = Read();
        return IsConfirmed(state) ? (state!.RepositoryRevision, state.Manifest.Sha256, state.Manifest.BuildId) : null;
    }

    private void Confirm(State state)
    {
        state.Status = "confirmed";
        state.BinaryId = _binaryId;
        state.InstalledExecutableSha256 = state.Manifest.ExecutableSha256;
        Write(state);
    }

    private bool IsConfirmed(State? state) => state?.Status == "confirmed" && state.BinaryId == _binaryId &&
        state.InstalledExecutableSha256.Equals(state.Manifest.ExecutableSha256, StringComparison.OrdinalIgnoreCase) &&
        MatchesInstalled(state.Manifest);

    private bool MatchesInstalled(UpdateManifest manifest) => ValidManifest(manifest) && manifest.BuildId == _buildId &&
        MatchesHash(_executablePath, manifest.ExecutableSha256);

    private static bool MatchesStartup(UpdateManifest manifest, UpdatedStartupContext context) =>
        context.ManifestBuildId == manifest.BuildId &&
        GitHubUpdateClient.IsHash(context.PackageSha256, 64) &&
        context.PackageSha256.Equals(manifest.Sha256, StringComparison.OrdinalIgnoreCase);

    private bool ValidManifest(UpdateManifest manifest) => manifest is not null &&
        manifest.BuildId > 0 && manifest.Size > 0 && GitHubUpdateClient.IsHash(manifest.Sha256, 64) &&
        GitHubUpdateClient.IsHash(manifest.ExecutableSha256, 64) &&
        string.Equals(manifest.DistributionMode, _mode, StringComparison.OrdinalIgnoreCase) &&
        UpdateRepository.IsExpectedPackageName(_mode, manifest.Package, manifest.ReleaseVersion) && UpdateSignatureVerifier.Verify(manifest);

    private static bool SamePackage(UpdateManifest a, UpdateManifest b) => a.Version == b.Version && a.ReleaseVersion == b.ReleaseVersion &&
        a.ProtocolGeneration == b.ProtocolGeneration && a.BuildId == b.BuildId && a.Size == b.Size &&
        a.Sha256.Equals(b.Sha256, StringComparison.OrdinalIgnoreCase) &&
        a.ExecutableSha256.Equals(b.ExecutableSha256, StringComparison.OrdinalIgnoreCase) &&
        a.Package.Equals(b.Package, StringComparison.Ordinal) && a.DistributionMode.Equals(b.DistributionMode, StringComparison.Ordinal);

    internal static string MatchedNotes(UpdateManifest manifest, string? notes, string? notesBuildId) =>
        notesBuildId == Id(manifest.BuildId) && !string.IsNullOrWhiteSpace(notes) && notes.Length <= MaxChangelogCharacters ? notes : "";
    internal static string Id(long value) => value.ToString(CultureInfo.InvariantCulture);
    // Revisions are opaque transport identifiers, never a command, URL or Git hash.
    internal static string BoundRevision(string? value) => value is { Length: > 0 and <= 512 } &&
        !value.Any(char.IsControl) ? value : "";

    private static bool MatchesHash(string path, string hash)
    {
        var actual = FileHash(path);
        return actual.Length > 0 && actual.Equals(hash, StringComparison.OrdinalIgnoreCase);
    }

    private static string FileHash(string path)
    {
        try { using var stream = File.OpenRead(path); return Convert.ToHexString(SHA256.HashData(stream)); }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { return ""; }
    }

    private State? Read()
    {
        try
        {
            if (!File.Exists(_path) || new FileInfo(_path).Length > MaxStateFileBytes) return null;
            var state = JsonSerializer.Deserialize<State>(File.ReadAllText(_path));
            return state?.Manifest is not null && state.Changelog is not null && state.RepositoryRevision is not null &&
                state.BinaryId is not null && state.InstalledExecutableSha256 is not null && state.DismissedBuildId is not null ? state : null;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException) { return null; }
    }

    private void Write(State state)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(_path)!);
        var temporary = _path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try { File.WriteAllText(temporary, JsonSerializer.Serialize(state)); File.Move(temporary, _path, true); }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
    }

    private sealed class State
    {
        public string Status { get; set; } = "";
        public UpdateManifest Manifest { get; set; } = new();
        public string RepositoryRevision { get; set; } = "";
        public string BinaryId { get; set; } = "";
        public string InstalledExecutableSha256 { get; set; } = "";
        public string Changelog { get; set; } = "";
        public string DismissedBuildId { get; set; } = "";
    }
}
